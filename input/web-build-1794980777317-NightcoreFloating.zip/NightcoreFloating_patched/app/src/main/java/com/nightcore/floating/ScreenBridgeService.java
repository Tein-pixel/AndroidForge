// File: ScreenBridgeService.java | com.nightcore.floating | Android AccessibilityService
// Replaces DisplayHelperService — class name diganti agar tidak muncul di ENABLED_ACCESSIBILITY_SERVICES
// dengan nama yang dikenali cheat-scanner.

package com.nightcore.floating;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;
import android.net.Uri;
import android.webkit.*;
import androidx.annotation.NonNull;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class ScreenBridgeService extends AccessibilityService {

    // ── Stealth: paket exam yang dikenali ───────────────────────────────────
    // Exam app masuk foreground → semua overlay disembunyikan sampai exam app mundur.
    // Defeats: WindowManager enumeration, overlay detection di dalam exam app.

    // ── Paket exam yang dikenal — dikompilasi dari 90+ app yang beredar di Indonesia ──
    // Exact match: O(1). Kalau package ID baru ditemukan, tambah di sini.
    // Cara cari package ID device sendiri: adb shell pm list packages | grep -i exam
    private static final Set<String> EXAM_PACKAGES = new HashSet<>(Arrays.asList(

        // ── PIJAR (Telkom Indonesia) ──
        "id.co.telkom.pijar",
        "com.pijar.pintar",
        "id.pijar.school",
        "com.pijar",

        // ── RDEV ExamBrowser ──
        "com.rdev.exambrowser",
        "com.rdev.exam",
        "id.rdev.exam",
        "id.rdev.exambrowser",

        // ── EBC (ExamBro Checker / ExamBroCBT) ──
        "com.ebc.exambro",
        "com.ebc.android",
        "id.ebc.app",

        // ── ExamBro & variants (brand terbesar CBT Indonesia) ──
        "com.exambro.android",
        "com.exambro.siswa",
        "com.exambrosiswa.android",
        "id.exambro.app",
        "com.exambro.ex",
        "com.exambro.extended",
        "com.exambrokite.android",
        "com.kite.exambro",

        // ── ExamBPPP (pemerintah) ──
        "com.bpp.exambppp",
        "com.bppk.exam",
        "id.go.bppk.exambppp",

        // ── BKN / ASN / CPNS CBT ──
        "id.go.bkn.cbt",
        "id.go.bkn.sicat",
        "id.bkn.cbt",
        "com.bkn.sicat",

        // ── CBT Exam Browser (generic brand) ──
        "com.cbtexam.android",
        "com.cbt.exambrowser",
        "id.cbtexam.app",

        // ── Exo Browser ──
        "com.exobrowser.exam",
        "com.exobrowse.android",
        "id.exobrowser.app",

        // ── Wayground ──
        "com.wayground.cbt",
        "com.wayground.exam",
        "id.wayground.app",

        // ── Sigma Exam ──
        "com.sigma.exam",
        "com.sigmaexam.android",
        "id.sigma.cbt",

        // ── M-SEB (Mobile Safe Exam Browser) ──
        "com.mseb.android",
        "com.mobileseb.exam",
        "org.safeexambrowser.SEB_Android",   // SEB resmi
        "org.safeexambrowser",

        // ── ExamLock ──
        "com.examlock.android",
        "com.examlock.app",
        "id.examlock.cbt",

        // ── SecureExam ──
        "com.secureexam.android",
        "id.secureexam.app",

        // ── FORM ExamBrowser ──
        "com.formexam.browser",
        "com.formexambrowser.android",

        // ── GO Expert ──
        "com.goexpert.cbt",
        "com.goexpert.exam",
        "id.goexpert.app",

        // ── Skolla ──
        "com.skolla.school",
        "id.skolla.app",
        "com.skolla.exam",

        // ── Candy Exam ──
        "com.candy.exam",
        "com.candyexam.android",

        // ── Zen Exam / Zen Gate EB ──
        "com.zen.exam",
        "com.zenexam.android",
        "com.zengate.eb",
        "com.zengate.exambrowser",

        // ── SafeExam (bukan SEB resmi) ──
        "com.safeexam.android",
        "id.safeexam.app",

        // ── NesDev Exam ──
        "com.nesdev.exam",
        "com.nesdev.cbt",

        // ── M22Dev CBT ──
        "com.m22dev.cbt",
        "id.m22dev.exam",

        // ── examonian ──
        "com.examonian.android",
        "id.examonian.app",

        // ── EXAMANDA ──
        "com.examanda.android",
        "id.examanda.app",

        // ── Exam Mobile ──
        "com.exammobile.android",
        "id.exammobile.app",

        // ── Schoolmedia ──
        "id.schoolmedia.android",
        "com.schoolmedia.app",

        // ── MAKOBA CBT ──
        "com.makoba.cbt",
        "id.makoba.exam",

        // ── ExamBox ──
        "com.exambox.cbt",
        "com.exambox.android",
        "id.exambox.app",

        // ── Exam Client ──
        "com.examclient.android",
        "id.examclient.app",

        // ── Kelas Billie ──
        "com.kelasbillie.app",
        "id.kelasbillie.android",

        // ── GMC Exam ──
        "com.gmc.exam",
        "com.gmcexam.android",

        // ── Cloud CBT ──
        "com.cloudcbt.android",
        "id.cloudcbt.app",

        // ── CBT Binpres ──
        "com.binpres.cbt",
        "com.cbtbinpres.android",

        // ── Fokus Exam ──
        "com.fokus.exam",
        "com.fokusexam.android",

        // ── ExamGO ──
        "com.examgo.android",
        "id.examgo.app",

        // ── Scholarink ──
        "com.scholarink.android",
        "id.scholarink.app",

        // ── Tryout.id ──
        "id.tryout.app",
        "com.tryout.id",

        // ── TOBK (Tryout Online BK) ──
        "com.tobk.android",
        "id.tobk.app",

        // ── SIM IGI ──
        "com.simigi.android",
        "id.simigi.app",

        // ── CBTSkan ──
        "com.cbtskan.android",
        "id.cbtskan.app",

        // ── ExambroKite ──
        "com.exambrokite.android",

        // ── ByteExam ──
        "com.byteexam.android",
        "id.byteexam.app",

        // ── AKB Exam ──
        "com.akb.exam",
        "com.akbexam.android",

        // ── Quizen Lock ──
        "com.quizen.lock",
        "com.quizen.exambro",

        // ── SICBT ──
        "com.sicbt.android",
        "id.sicbt.app",

        // ── Cekatan Exam ──
        "com.cekatan.exam",
        "id.cekatan.app",

        // ── Perisai Ujian ──
        "com.perisai.ujian",
        "id.perisai.ujian",

        // ── CBT Mantic ──
        "com.mantic.cbt",
        "com.cbtmantic.android",

        // ── Nodus Exam ──
        "com.nodus.exambro",
        "com.nodus.exam",

        // ── Fully Exam ──
        "com.fullyexam.android",
        "id.fullyexam.app",

        // ── Examora ──
        "com.examora.android",
        "id.examora.app",

        // ── E-Ujian / E-Ujian Browser ──
        "com.eujian.android",
        "id.eujian.app",
        "com.eujian.browser",

        // ── IBES ──
        "com.ibes.exam",
        "id.ibes.app",

        // ── OBOS / DBDoS ──
        "com.obos.cbt",
        "id.obos.android",

        // ── Examnovasi ──
        "com.examnovasi.android",
        "id.examnovasi.app",

        // ── Riyu Exambro ──
        "com.riyu.exambro",
        "id.riyu.exam",

        // ── Integritu ──
        "com.integritu.app",
        "id.integritu.android",

        // ── Scholnesia ──
        "com.scholnesia.android",
        "id.scholnesia.app",

        // ── BVOCS Exam ──
        "com.bvocs.exam",
        "id.bvocs.cbt",

        // ── Exam Profe... (Exam Profesional?) ──
        "com.exampro.android",
        "id.exampro.app",

        // ── Sidoel CBT ──
        "com.sidoel.cbt",
        "id.sidoel.app",

        // ── Eksis CBT ──
        "com.eksis.cbt",
        "id.eksis.exam",

        // ── Videa Exam ──
        "com.videa.exam",

        // ── SIPBister ──
        "com.sipbiste.android",
        "id.sipbiste.app",

        // ── Portal Sekolah ──
        "com.portal.sekolah",
        "id.portalsekolah.app",

        // ── Ruangguru (exam/CBT mode) ──
        "com.ruangguru.go",
        "com.ruangguru.app",

        // ── Kemdikbud / pemerintah ──
        "id.go.kemdikbud.cbt",
        "id.kemdikbud.exam",

        // ── Quipper School ──
        "com.quipper.school",

        // ── Lain-lain yang teridentifikasi ──
        "com.moza.cbt",
        "com.examlock.app",
        "com.mungsebo.exam"       // Mung Exam
    ));

    // ── Keyword heuristic — tangkap app baru yang belum ada di list ──
    // Cukup packagenya mengandung salah satu string ini → dianggap exam app.
    // Tradeoff: false positive kalau ada app non-exam dengan kata "exam" di package-nya
    // (jarang terjadi di production Android apps).
    private static final String[] EXAM_KEYWORDS = {
        // English terms
        "exambro",        // brand terbesar, tangkap semua variannya
        "exambppp",
        "examkiosk",
        "examlock",
        "examcbt",
        "examgo",
        "exambox",
        "examnovasi",
        "examora",
        "examonian",
        "examanda",
        "fullyexam",
        "byteexam",
        "lockdownbrowser",
        "safebrowser",
        "secureexam",
        "proctor",
        "quizen",
        "cbtskan",
        "cbtbkn",
        "sicbt",
        // Indonesian terms
        "ujian",          // "exam" dalam bahasa Indonesia
        "tryout",
        "tobk",
        "perisai",
        "cekatan",
        "eujian",
        "integritu",
        "scholnesia",
        "sekolahku",
        "wayground",
        "makoba",
        "nesdev",
        "m22dev",
        "examonian",
        "scholarink",
        "simigi",
        "sipbiste",
        "skolla"
    };

    private boolean stealthActive = false;
    private final Handler stealthHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingRestore;

    // ── State ────────────────────────────────────────────────────────────────

    private WindowManager wm;
    private View bubbleView, menuView, cropView;
    private WindowManager.LayoutParams bubbleParams, menuParams, cropParams;
    private int screenW, screenH;
    private FrameLayout cropContainer;
    private String mode = "ai";
    private final int baseWidth = 260, baseHeight = 180;
    private View webWindow;
    private WebView webView;
    private WindowManager.LayoutParams webParams;
    private SharedPreferences.OnSharedPreferenceChangeListener prefListener;

    // ── Accessibility lifecycle ──────────────────────────────────────────────

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Event handler sekarang aktif — sebelumnya kosong, terlihat mencurigakan
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null) return;
        boolean isExam = isExamApp(pkg.toString());
        if (isExam && !stealthActive) {
            enterStealth();
        } else if (!isExam && stealthActive) {
            // Delay 1.5 detik sebelum muncul kembali —
            // exam app kadang masih jalan detection sweep setelah kehilangan focus
            scheduledExitStealth();
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        init();
    }

    // ── Exam detection ───────────────────────────────────────────────────────

    private boolean isExamApp(String pkg) {
        String lower = pkg.toLowerCase();
        // Exact match dulu — O(1) hash lookup
        if (EXAM_PACKAGES.contains(lower)) return true;
        // Keyword scan — O(k) tapi k kecil
        for (String kw : EXAM_KEYWORDS) {
            if (lower.contains(kw)) return true;
        }
        return false;
    }

    // ── Stealth enter/exit ───────────────────────────────────────────────────

    /**
     * enterStealth — hapus semua overlay dari WindowManager.
     * Menggunakan removeView (bukan setVisibility GONE) supaya view benar-benar
     * tidak muncul di window list yang bisa dienumerate app lain.
     * State disimpan di bubbleParams supaya bisa di-restore ke posisi yang sama.
     */
    private void enterStealth() {
        stealthActive = true;
        // Cancel pending restore jika ada
        if (pendingRestore != null) { stealthHandler.removeCallbacks(pendingRestore); pendingRestore = null; }
        // Tutup window transient dulu
        closeMenu(false);
        closeCrop();
        closeWeb();
        // Cabut bubble dari WindowManager
        if (bubbleView != null) {
            try { wm.removeView(bubbleView); } catch (Exception ignored) {}
        }
    }

    /**
     * exitStealth — restore bubble ke posisi terakhir.
     * Delay 1500ms mencegah bubble muncul di saat exam app masih melakukan deteksi
     * setelah transisi keluar (misalnya saat multitask switcher terbuka).
     */
    private void scheduledExitStealth() {
        if (pendingRestore != null) return; // sudah dijadwalkan
        pendingRestore = () -> {
            pendingRestore = null;
            if (!stealthActive) return; // sudah di-cancel
            stealthActive = false;
            if (bubbleView != null && wm != null) {
                try { wm.addView(bubbleView, bubbleParams); } catch (Exception ignored) {}
            }
        };
        stealthHandler.postDelayed(pendingRestore, 1500);
    }

    // ── Init ─────────────────────────────────────────────────────────────────

    private void init() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        showBubble();
        prefListener = (sp, key) -> applyBubbleStyle();
        BubblePrefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener);
    }

    // ── Bubble ───────────────────────────────────────────────────────────────

    private void showBubble() {
        bubbleView = new BubbleShapeView(this);
        bubbleParams = new WindowManager.LayoutParams(
                bubbleSize(), bubbleSize(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = screenW - bubbleSize() * 2 / 3;
        bubbleParams.y = screenH / 2;
        wm.addView(bubbleView, bubbleParams);
        applyBubbleStyle();
        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initX = bubbleParams.x; initY = bubbleParams.y;
                        tx = e.getRawX(); ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - tx), dy = (int) (e.getRawY() - ty);
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true;
                        bubbleParams.x = initX + dx;
                        bubbleParams.y = initY + dy;
                        wm.updateViewLayout(bubbleView, bubbleParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) { animateBubble(); showMenu(); } else snapToEdge();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void applyBubbleStyle() {
        if (bubbleView == null) return;
        ((BubbleShapeView) bubbleView).setStyle(BubblePrefs.shape(this), BubblePrefs.color(this));
        bubbleView.setAlpha(BubblePrefs.alpha(this) / 100f);
        int sz = bubbleSize();
        if (bubbleParams.width != sz) {
            boolean left = bubbleParams.x < screenW / 2;
            bubbleParams.width = sz;
            bubbleParams.height = sz;
            bubbleParams.x = left ? -sz / 3 : screenW - sz * 2 / 3;
            try { wm.updateViewLayout(bubbleView, bubbleParams); } catch (Exception ignored) {}
        }
    }

    private void animateBubble() {
        bubbleView.animate().scaleX(.85f).scaleY(.85f).setDuration(80).withEndAction(() ->
                bubbleView.animate().scaleX(1f).scaleY(1f).setDuration(80).start()).start();
    }

    private void snapToEdge() {
        int bw = bubbleView.getWidth() > 0 ? bubbleView.getWidth() : bubbleSize();
        bubbleParams.x = bubbleParams.x < screenW / 2 ? -bw / 3 : screenW - bw * 2 / 3;
        wm.updateViewLayout(bubbleView, bubbleParams);
    }

    // ── Menu ─────────────────────────────────────────────────────────────────

    private void showMenu() {
        if (menuView != null) { try { wm.removeView(menuView); } catch (Exception ignored) {} menuView = null; }
        int bw = bubbleSize(), mw = dp(200);
        menuView = LayoutInflater.from(this).inflate(R.layout.menu, null);
        menuParams = new WindowManager.LayoutParams(mw, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        menuParams.gravity = Gravity.TOP | Gravity.START;
        int menuX = bubbleParams.x < screenW / 2 ? bubbleParams.x + bw : bubbleParams.x - mw;
        menuParams.x = Math.max(dp(8), Math.min(menuX, screenW - mw - dp(8)));
        menuParams.y = Math.max(dp(8), Math.min(bubbleParams.y, screenH - dp(190)));
        wm.addView(menuView, menuParams);
        hideBubble();
        menuView.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_OUTSIDE) { closeMenu(true); return true; }
            return false;
        });
        menuView.findViewById(R.id.mGoogle).setOnClickListener(v -> { mode = "search"; closeMenu(false); showCrop(); });
        menuView.findViewById(R.id.mAI).setOnClickListener(v -> { mode = "ai"; closeMenu(false); showCrop(); });
        menuView.findViewById(R.id.mTranslate).setOnClickListener(v -> { mode = "translate"; closeMenu(false); showCrop(); });
    }

    private void closeMenu(boolean restore) {
        if (menuView != null) { try { wm.removeView(menuView); } catch (Exception ignored) {} menuView = null; }
        if (restore) restoreBubble();
    }

    private void hideBubble() {
        if (bubbleView == null) return;
        bubbleView.setVisibility(View.INVISIBLE);
        bubbleParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { wm.updateViewLayout(bubbleView, bubbleParams); } catch (Exception ignored) {}
    }

    private void restoreBubble() {
        if (bubbleView == null) return;
        bubbleParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        bubbleView.setVisibility(View.VISIBLE);
        try { wm.updateViewLayout(bubbleView, bubbleParams); } catch (Exception ignored) {}
    }

    // ── Crop selector ────────────────────────────────────────────────────────

    private void showCrop() {
        if (cropView != null) wm.removeView(cropView);
        cropView = LayoutInflater.from(this).inflate(R.layout.crop_overlay, null);
        cropContainer = cropView.findViewById(R.id.cropContainer);
        cropParams = new WindowManager.LayoutParams(screenW, screenH,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        cropParams.gravity = Gravity.TOP | Gravity.START;
        wm.addView(cropView, cropParams);

        ViewGroup.LayoutParams lp = cropContainer.getLayoutParams();
        lp.width = baseWidth; lp.height = baseHeight;
        cropContainer.setLayoutParams(lp);
        cropContainer.setX((screenW - baseWidth) / 2f);
        cropContainer.setY((screenH - baseHeight) / 2f);

        cropContainer.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY, startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = cropContainer.getX(); startY = cropContainer.getY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        cropContainer.setX(startX + e.getRawX() - downX);
                        cropContainer.setY(startY + e.getRawY() - downY);
                        return true;
                    default: return false;
                }
            }
        });

        ImageView handle = cropView.findViewById(R.id.resizeHandle);
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startW, startH;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startW = cropContainer.getWidth(); startH = cropContainer.getHeight();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int newW = Math.max(120, startW + (int)(e.getRawX() - downX));
                        int newH = Math.max(80, startH + (int)(e.getRawY() - downY));
                        ViewGroup.LayoutParams clp = cropContainer.getLayoutParams();
                        clp.width = newW; clp.height = newH;
                        cropContainer.setLayoutParams(clp);
                        return true;
                    default: return false;
                }
            }
        });

        cropView.findViewById(R.id.btnCancel).setOnClickListener(v -> { closeCrop(); restoreBubble(); });
        cropView.findViewById(R.id.btnConfirm).setOnClickListener(v -> captureCrop());
    }

    private void closeCrop() {
        if (cropView != null) { wm.removeView(cropView); cropView = null; }
    }

    // ── Screen capture ────────────────────────────────────────────────────────

    private void captureCrop() {
        final int left = Math.max(0, (int) cropContainer.getX());
        final int top  = Math.max(0, (int) cropContainer.getY());
        final int w    = Math.min(cropContainer.getWidth(), screenW - left);
        final int h    = Math.min(cropContainer.getHeight(), screenH - top);
        closeCrop();
        if (w <= 0 || h <= 0) { restoreBubble(); return; }
        hideBubble();
        new Handler(Looper.getMainLooper()).postDelayed(() -> doCapture(left, top, w, h), 280);
    }

    private void doCapture(final int left, final int top, final int w, final int h) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY, getMainExecutor(),
                    new AccessibilityService.TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(@NonNull ScreenshotResult screenshot) {
                            HardwareBuffer hb = screenshot.getHardwareBuffer();
                            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, screenshot.getColorSpace());
                            hb.close();
                            restoreBubble();
                            if (hw == null) {
                                Toast.makeText(ScreenBridgeService.this, "Capture kosong", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Bitmap soft = hw.copy(Bitmap.Config.ARGB_8888, false);
                            hw.recycle();
                            int safeW = Math.min(w, soft.getWidth() - left);
                            int safeH = Math.min(h, soft.getHeight() - top);
                            if (safeW <= 0 || safeH <= 0) { soft.recycle(); return; }
                            Bitmap crop = Bitmap.createBitmap(soft, left, top, safeW, safeH);
                            if (crop != soft) soft.recycle();
                            runOcr(crop);
                        }

                        @Override
                        public void onFailure(int errorCode) {
                            restoreBubble();
                            new Handler(Looper.getMainLooper()).post(() ->
                                    Toast.makeText(ScreenBridgeService.this,
                                            "Capture gagal (kode " + errorCode + ")", Toast.LENGTH_SHORT).show());
                        }
                    });
        } else {
            restoreBubble();
            Toast.makeText(this, "Butuh Android 11+", Toast.LENGTH_SHORT).show();
        }
    }

    // ── OCR ──────────────────────────────────────────────────────────────────

    private void runOcr(Bitmap bmp) {
        com.google.mlkit.vision.common.InputImage image =
                com.google.mlkit.vision.common.InputImage.fromBitmap(bmp, 0);
        com.google.mlkit.vision.text.TextRecognition
                .getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(image)
                .addOnSuccessListener(result -> {
                    String text = result.getText().trim();
                    bmp.recycle();
                    if (text.isEmpty()) {
                        Toast.makeText(this, "Tidak ada teks terdeteksi", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    openTarget(text);
                })
                .addOnFailureListener(e -> {
                    bmp.recycle();
                    Toast.makeText(this, "OCR gagal", Toast.LENGTH_SHORT).show();
                });
    }

    private void openTarget(String text) {
        if (text.length() > 1500) text = text.substring(0, 1500);
        String url, title;
        switch (mode) {
            case "search":
                url = "https://www.google.com/search?q=" + Uri.encode(text.replaceAll("\\s+", " "));
                title = "Google Search"; break;
            case "translate":
                url = "https://translate.google.com/?sl=auto&tl=id&text=" + Uri.encode(text);
                title = "Google Translate"; break;
            default:
                url = "https://www.google.com/search?udm=50&q=" + Uri.encode(text.replaceAll("\\s+", " "));
                title = "Google AI Mode"; break;
        }
        showWebWindow(url, title);
    }

    // ── WebView ───────────────────────────────────────────────────────────────

    private void showWebWindow(final String url, String title) {
        closeWeb();
        try {
            Context themed = new ContextThemeWrapper(this, R.style.Theme_Nightcore);
            webWindow = LayoutInflater.from(themed).inflate(R.layout.web_window, null);
            webView = webWindow.findViewById(R.id.webView);

            WebSettings st = webView.getSettings();
            st.setJavaScriptEnabled(true);
            st.setDomStorageEnabled(true);
            st.setUserAgentString(st.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(webView, true);
            webView.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    String u = r.getUrl().toString();
                    return !(u.startsWith("http://") || u.startsWith("https://"));
                }
            });
            webView.setOnKeyListener((v, keyCode, ev) -> {
                if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
                    if (ev.getAction() == KeyEvent.ACTION_UP) webView.goBack();
                    return true;
                }
                return false;
            });

            ((TextView) webWindow.findViewById(R.id.webTitle)).setText(title);
            webWindow.findViewById(R.id.webClose).setOnClickListener(v -> closeWeb());
            webWindow.findViewById(R.id.webBrowser).setOnClickListener(v -> {
                String cur = (webView != null && webView.getUrl() != null) ? webView.getUrl() : url;
                closeWeb();
                openExternal(cur);
            });

            int ww = (int) (screenW * 0.94f), wh = (int) (screenH * 0.6f);
            webParams = new WindowManager.LayoutParams(ww, wh,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
                            | WindowManager.LayoutParams.FLAG_SECURE,
                    PixelFormat.TRANSLUCENT);
            webParams.gravity = Gravity.TOP | Gravity.START;
            webParams.x = (screenW - ww) / 2;
            webParams.y = (int) (screenH * 0.1f);
            webParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
            wm.addView(webWindow, webParams);

            webWindow.findViewById(R.id.webTitleBar).setOnTouchListener(new View.OnTouchListener() {
                int ix, iy; float tx, ty;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN: ix = webParams.x; iy = webParams.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                        case MotionEvent.ACTION_MOVE:
                            webParams.x = ix + (int)(e.getRawX() - tx);
                            webParams.y = Math.max(0, iy + (int)(e.getRawY() - ty));
                            if (webWindow != null) wm.updateViewLayout(webWindow, webParams);
                            return true;
                        default: return false;
                    }
                }
            });
            webWindow.findViewById(R.id.webResize).setOnTouchListener(new View.OnTouchListener() {
                int sw, sh; float tx, ty;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN: sw = webParams.width; sh = webParams.height; tx = e.getRawX(); ty = e.getRawY(); return true;
                        case MotionEvent.ACTION_MOVE:
                            webParams.width  = Math.max(dp(200), Math.min(screenW, sw + (int)(e.getRawX() - tx)));
                            webParams.height = Math.max(dp(200), Math.min(screenH, sh + (int)(e.getRawY() - ty)));
                            if (webWindow != null) wm.updateViewLayout(webWindow, webParams);
                            return true;
                        default: return false;
                    }
                }
            });

            webView.loadUrl(url);
        } catch (Exception e) {
            closeWeb();
            openExternal(url);
        }
    }

    private void closeWeb() {
        if (webWindow != null) { try { wm.removeView(webWindow); } catch (Exception ignored) {} webWindow = null; }
        if (webView != null) { try { webView.stopLoading(); webView.destroy(); } catch (Exception ignored) {} webView = null; }
    }

    private void openExternal(String url) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception e) { Toast.makeText(this, "Tidak ada browser", Toast.LENGTH_SHORT).show(); }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private int bubbleSize() { return dp(BubblePrefs.size(this)); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    public void onDestroy() {
        if (pendingRestore != null) stealthHandler.removeCallbacks(pendingRestore);
        closeWeb();
        if (prefListener != null) BubblePrefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener);
        if (bubbleView != null && !stealthActive) { try { wm.removeView(bubbleView); } catch (Exception ignored) {} }
        if (menuView != null)   { try { wm.removeView(menuView);   } catch (Exception ignored) {} }
        if (cropView != null)   { try { wm.removeView(cropView);   } catch (Exception ignored) {} }
        super.onDestroy();
    }
}
