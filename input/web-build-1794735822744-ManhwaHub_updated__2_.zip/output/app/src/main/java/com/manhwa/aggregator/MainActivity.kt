package com.manhwa.aggregator

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.chip.Chip
import com.manhwa.aggregator.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scraper = ManhwaScraper()
    private var currentQuery = ""
    private var currentGenre = ""
    private var loadJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupSearch()
        setupChips()
        setupSwipeRefresh()
        setupEntranceAnimations()
        loadData()
    }

    // ─── Setup ───────────────────────────────────────────────────

    private fun setupRecyclerView() {
        binding.rvManhwa.layoutManager = GridLayoutManager(this, 2)
    }

    private fun setupSearch() {
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                currentQuery = binding.etSearch.text.toString().trim()
                currentGenre = ""
                // reset chips without triggering genre reload
                binding.chipGroupGenre.setOnCheckedStateChangeListener(null)
                binding.chipAll.isChecked = true
                allChips().forEach { applyChipStyle(it, it.id == R.id.chipAll) }
                reattachChipListener()
                loadData()
                true
            } else false
        }

        binding.etSearch.setOnFocusChangeListener { v, hasFocus ->
            v.background = ContextCompat.getDrawable(
                this,
                if (hasFocus) R.drawable.glass_search_focused else R.drawable.glass_search
            )
            v.animate()
                .scaleX(if (hasFocus) 1.025f else 1f)
                .scaleY(if (hasFocus) 1.025f else 1f)
                .setDuration(220)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private fun setupChips() {
        allChips().forEach { chip ->
            applyChipStyle(chip, chip.isChecked)
            chip.setOnCheckedChangeListener { _, isChecked ->
                applyChipStyle(chip, isChecked)
                if (isChecked) bounceChip(chip)
            }
        }
        reattachChipListener()
    }

    private fun reattachChipListener() {
        binding.chipGroupGenre.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                currentQuery = ""
                binding.etSearch.text.clear()
                currentGenre = when (checkedIds[0]) {
                    R.id.chipAction  -> "Action"
                    R.id.chipFantasy -> "Fantasy"
                    R.id.chipRomance -> "Romance"
                    R.id.chipMartial -> "Martial Arts"
                    else             -> "Semua"
                }
                loadData()
            }
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener { loadData(isRefresh = true) }
        binding.swipeRefresh.setColorSchemeColors(Color.parseColor("#00FFCC"))
    }

    // ─── Entrance animations ─────────────────────────────────────

    private fun setupEntranceAnimations() {
        binding.topBar.apply {
            translationY = -100f
            alpha = 0f
            animate()
                .translationY(0f).alpha(1f)
                .setDuration(550)
                .setInterpolator(DecelerateInterpolator(2.2f))
                .start()
        }
        binding.swipeRefresh.apply {
            alpha = 0f
            animate()
                .alpha(1f)
                .setStartDelay(250)
                .setDuration(400)
                .start()
        }
    }

    // ─── Chip helpers ─────────────────────────────────────────────

    private fun allChips(): List<Chip> = listOf(
        binding.chipAll, binding.chipAction,
        binding.chipFantasy, binding.chipRomance, binding.chipMartial
    )

    private fun applyChipStyle(chip: Chip, isChecked: Boolean) {
        val density = resources.displayMetrics.density
        chip.chipBackgroundColor = ColorStateList.valueOf(
            if (isChecked) Color.parseColor("#2600FFCC") else Color.parseColor("#1A1F2E")
        )
        chip.chipStrokeColor = ColorStateList.valueOf(
            if (isChecked) Color.parseColor("#8000FFCC") else Color.parseColor("#28FFFFFF")
        )
        chip.chipStrokeWidth = density * 1f
        chip.isCheckedIconVisible = false
        chip.setTextColor(
            if (isChecked) Color.parseColor("#00FFCC") else Color.parseColor("#7A8599")
        )
        chip.chipCornerRadius = density * 20f
    }

    private fun bounceChip(chip: Chip) {
        chip.animate()
            .scaleX(1.14f).scaleY(1.14f)
            .setDuration(85)
            .withEndAction {
                chip.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(160)
                    .setInterpolator(OvershootInterpolator(2.5f))
                    .start()
            }.start()
    }

    // ─── Loading ──────────────────────────────────────────────────

    private fun showLoading() {
        binding.progressBar.visibility = View.VISIBLE
        binding.progressBar.alpha = 0f
        binding.progressBar.scaleX = 0.5f
        binding.progressBar.scaleY = 0.5f
        binding.progressBar.animate()
            .alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(300)
            .setInterpolator(OvershootInterpolator(1.5f))
            .start()
        binding.rvManhwa.animate()
            .alpha(0f).setDuration(150).start()
    }

    private fun hideLoading() {
        binding.progressBar.animate()
            .alpha(0f).scaleX(0.5f).scaleY(0.5f)
            .setDuration(200)
            .withEndAction { binding.progressBar.visibility = View.GONE }
            .start()
        binding.rvManhwa.visibility = View.VISIBLE
        binding.rvManhwa.alpha = 0f
        binding.rvManhwa.animate()
            .alpha(1f)
            .setDuration(350)
            .setStartDelay(80)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    // ─── Data ─────────────────────────────────────────────────────

    private fun loadData(isRefresh: Boolean = false) {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            if (!isRefresh) {
                delay(40) // debounce back-to-back calls
                showLoading()
            }
            try {
                val list = scraper.fetchLatest(currentQuery, currentGenre)
                binding.rvManhwa.adapter = ManhwaAdapter(list)
                hideLoading()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                binding.progressBar.visibility = View.GONE
                binding.rvManhwa.visibility = View.VISIBLE
            } finally {
                if (isRefresh) binding.swipeRefresh.isRefreshing = false
            }
        }
    }
}
