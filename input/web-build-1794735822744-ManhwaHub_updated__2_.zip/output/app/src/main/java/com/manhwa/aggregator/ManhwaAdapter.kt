package com.manhwa.aggregator

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import coil.ImageLoader
import coil.load
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class ManhwaAdapter(private val manhwaList: List<Manhwa>) :
    RecyclerView.Adapter<ManhwaAdapter.ViewHolder>() {

    private val animatedPositions = mutableSetOf<Int>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgCover: ImageView = view.findViewById(R.id.imgCover)
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvChapter: TextView = view.findViewById(R.id.tvChapter)
        val tvSource: TextView = view.findViewById(R.id.tvSource)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_manhwa, parent, false)
        val vh = ViewHolder(view)

        // Cyan glow on chapter text — set once per holder
        vh.tvChapter.setShadowLayer(10f, 0f, 0f, Color.parseColor("#9900FFCC"))

        // Text shadow on title for readability over image
        vh.tvTitle.setShadowLayer(6f, 0f, 2f, Color.parseColor("#B3000000"))

        return vh
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = manhwaList[position]
        holder.tvTitle.text = item.title
        holder.tvChapter.text = item.latestChapter
        holder.tvSource.text = item.source

        // Image load with crossfade
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .addHeader("Referer", item.link)
                        .addHeader(
                            "User-Agent",
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                        )
                        .build()
                )
            }
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        val loader = ImageLoader.Builder(holder.itemView.context)
            .okHttpClient { client }
            .crossfade(350)
            .build()

        holder.imgCover.load(item.imageUrl, loader)

        // Press scale — squish down on touch, spring back on release
        holder.itemView.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> v.animate()
                    .scaleX(0.94f).scaleY(0.94f)
                    .setDuration(90)
                    .setInterpolator(DecelerateInterpolator())
                    .start()

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(260)
                    .setInterpolator(OvershootInterpolator(1.8f))
                    .start()
            }
            false
        }

        // Click — open in browser
        holder.itemView.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(item.link))
                holder.itemView.context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(
                    holder.itemView.context,
                    "Tidak dapat membuka link",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Stagger entrance — only animate once per position per adapter lifecycle
        if (!animatedPositions.contains(position)) {
            animatedPositions.add(position)
            holder.itemView.alpha = 0f
            holder.itemView.translationY = 70f
            holder.itemView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(430)
                .setStartDelay((position % 8 * 55).toLong())
                .setInterpolator(DecelerateInterpolator(2f))
                .start()
        }
    }

    override fun getItemCount() = manhwaList.size
}
