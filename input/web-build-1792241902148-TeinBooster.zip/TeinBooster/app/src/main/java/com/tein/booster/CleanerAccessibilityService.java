package com.tein.booster;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * 1-Tap Cache Cleaner: untuk setiap aplikasi, buka halaman "Info aplikasi", masuk ke Penyimpanan,
 * lalu tekan "Hapus cache". TIDAK PERNAH menekan "Hapus data"/"Hapus penyimpanan".
 */
public class CleanerAccessibilityService extends AccessibilityService {

    public static volatile CleanerAccessibilityService instance;

    /** Status bersama yang dibaca layar Cache Cleaner. */
    public static final class State {
        public volatile boolean running;
        public volatile boolean finished;
        public volatile int total;
        public volatile int done;
        public volatile int cleaned;
        public volatile int already;
        public volatile int failed;
        public volatile String current = "";
        public volatile String message = "";
        public volatile long startBytes = -1L;
        public final StringBuilder log = new StringBuilder();
    }

    public static final State STATE = new State();

    public interface Listener {
        void onChanged();
    }

    private static volatile Listener listener;

    public static void setListener(Listener l) { listener = l; }

    private static void notifyUi() {
        final Listener l = listener;
        if (l != null) Bg.ui(() -> l.onChanged());
    }

    // ---- fase ----
    private static final int PH_LAUNCH = 1;
    private static final int PH_ENTRY = 2;
    private static final int PH_STORAGE = 3;
    private static final int PH_SHEET = 4;
    private static final int PH_AFTER = 5;

    private static final long TICK_MS = 250L;
    private static final long SETTLE_MS = 550L;
    private static final long PHASE_TIMEOUT_MS = 6000L;
    private static final long AFTER_WAIT_MS = 800L;
    private static final long DISABLED_WAIT_MS = 1500L;
    private static final long MAX_TOTAL_MS = 30L * 60L * 1000L;

    // ---- kamus label (EN, ID, + beberapa bahasa lain) ----
    private static final String[] CACHE_WORDS = {
            "cache", "cach\u00e9", "cach\u00ea", "tembolok", "b\u1ed9 nh\u1edb \u0111\u1ec7m", "\u0e41\u0e04\u0e0a",
            "\u7f13\u5b58", "\u5feb\u53d6", "\u30ad\u30e3\u30c3\u30b7\u30e5", "\uce90\uc2dc", "\u043a\u044d\u0448", "\u043a\u0435\u0448",
            "\u00f6nbelle", "\u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u062a\u062e\u0632\u064a\u0646 \u0627\u0644\u0645\u0624\u0642\u062a"
    };
    private static final String[] CLEAR_VERBS = {
            "clear", "delete", "remove", "empty", "hapus", "bersihkan", "kosongkan", "borrar", "limpiar", "limpar",
            "vider", "effacer", "leeren", "l\u00f6schen", "temizle", "x\u00f3a", "\u6e05\u9664", "\u6e05\u7a7a",
            "\u524a\u9664", "\uc0ad\uc81c", "\u043e\u0447\u0438\u0441\u0442\u0438\u0442\u044c", "\u0443\u0434\u0430\u043b\u0438\u0442\u044c",
            "\u0e25\u0e49\u0e32\u0e07", "\u0645\u0633\u062d"
    };
    private static final String[] STORAGE_EXACT = {
            "storage", "storage & cache", "storage and cache", "storage usage", "penyimpanan", "penyimpanan & cache",
            "penyimpanan dan cache", "penggunaan penyimpanan", "almacenamiento", "almacenamiento y cach\u00e9",
            "armazenamento", "armazenamento e cache", "stockage", "speicher", "depolama", "l\u01b0u tr\u1eef",
            "\u5b58\u50a8", "\u5b58\u50a8\u7a7a\u95f4", "\u30b9\u30c8\u30ec\u30fc\u30b8", "\uc800\uc7a5\uacf5\uac04",
            "\u0445\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0435", "\u043f\u0430\u043c\u044f\u0442\u044c"
    };
    private static final String[] STORAGE_WORDS = {
            "storage", "penyimpanan", "almacenamiento", "armazenamento", "stockage", "speicher", "depolama",
            "l\u01b0u tr\u1eef", "\u5b58\u50a8", "\u30b9\u30c8\u30ec\u30fc\u30b8", "\uc800\uc7a5\uacf5\uac04",
            "\u0445\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0435"
    };
    /** Label yang TIDAK PERNAH boleh diklik. */
    private static final String[] NEVER_CLICK = {
            "clear data", "clear storage", "clear all data", "delete data", "delete app data", "hapus data",
            "hapus penyimpanan", "hapus semua data", "kosongkan data", "kosongkan penyimpanan", "manage space",
            "kelola ruang", "uninstall", "copot", "hapus instal", "nonaktifkan", "disable", "force stop",
            "paksa berhenti", "reset"
    };
    /** Kalimat dialog konfirmasi hapus-DATA (bukan cache). */
    private static final String[] DANGER_DIALOG = {
            "delete app data", "hapus data aplikasi", "all of this app", "semua data aplikasi ini",
            "deleted permanently", "permanently deleted", "dihapus secara permanen", "data aplikasi ini akan",
            "this app's data will", "this app\u2019s data will"
    };
    private static final String[] CONFIRM_WORDS = {"ok", "clear", "hapus", "ya", "yes", "bersihkan", "kosongkan", "delete", "confirm", "konfirmasi"};
    private static final String[] CANCEL_WORDS = {"cancel", "batal", "tidak", "no", "jangan"};
    /** Hanya dipakai di Xiaomi/HyperOS: "Hapus data" membuka menu berisi opsi "Hapus cache". */
    private static final String[] CLEAR_DATA_OPENERS = {"clear data", "hapus data"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private List<String> queue = new ArrayList<String>();
    private List<String> labels = new ArrayList<String>();
    private int idx;
    private int phase;
    private long phaseT0;
    private long startedAt;
    private boolean sheetTried;
    private boolean confirmClicked;
    private int scrollTries;
    private int storageScrolls;
    private int consecutiveFail;
    private final Set<String> settingsPkgs = new HashSet<String>();
    private WindowManager wm;
    private View overlay;
    private GaugeView gauge;
    private TextView ovSub;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!STATE.running) return;
            try {
                step();
            } catch (Throwable t) {
                logLine("galat internal: " + t);
                failCurrent("galat internal");
            }
            if (STATE.running) handler.postDelayed(this, TICK_MS);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        notifyUi();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        stopRun();
        instance = null;
        notifyUi();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        stopRun();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Dikendalikan lewat polling; event tidak diproses.
    }

    @Override
    public void onInterrupt() {
    }

    private void stopRun() {
        handler.removeCallbacks(tick);
        removeOverlay();
        STATE.running = false;
    }

    // ------------------------------------------------------------------ API

    public boolean startClean(List<String> pkgs, List<String> names, boolean withOverlay) {
        if (STATE.running || pkgs.isEmpty()) return false;
        queue = new ArrayList<String>(pkgs);
        labels = new ArrayList<String>(names);
        while (labels.size() < queue.size()) labels.add(queue.get(labels.size()));
        idx = 0;
        consecutiveFail = 0;
        STATE.total = queue.size();
        STATE.done = 0;
        STATE.cleaned = 0;
        STATE.already = 0;
        STATE.failed = 0;
        STATE.current = "";
        STATE.message = "";
        STATE.finished = false;
        STATE.log.setLength(0);
        STATE.running = true;
        resolveSettings();
        startedAt = SystemClock.uptimeMillis();
        if (withOverlay) addOverlay();
        setPhase(PH_LAUNCH);
        handler.removeCallbacks(tick);
        handler.post(tick);
        notifyUi();
        return true;
    }

    public void cancel() {
        if (STATE.running) finishRun("Dibatalkan");
    }

    // ------------------------------------------------------------------ mesin status

    private void setPhase(int p) {
        phase = p;
        phaseT0 = SystemClock.uptimeMillis();
        if (p == PH_STORAGE) storageScrolls = 0;
    }

    private void step() {
        long now = SystemClock.uptimeMillis();
        if (now - startedAt > MAX_TOTAL_MS) {
            finishRun("Waktu habis");
            return;
        }
        switch (phase) {
            case PH_LAUNCH:
                launchCurrent();
                break;
            case PH_ENTRY:
                doEntry(now);
                break;
            case PH_STORAGE:
                doStorage(now);
                break;
            case PH_SHEET:
                doSheet(now);
                break;
            case PH_AFTER:
                doAfter(now);
                break;
            default:
                break;
        }
    }

    private String labelOf(int i) {
        return i >= 0 && i < labels.size() ? labels.get(i) : "?";
    }

    private void launchCurrent() {
        if (idx >= queue.size()) {
            finishRun("Selesai");
            return;
        }
        String pkg = queue.get(idx);
        STATE.current = labelOf(idx);
        sheetTried = false;
        confirmClicked = false;
        scrollTries = 0;
        updateOverlay();
        notifyUi();
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK
                | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        try {
            startActivity(i);
            setPhase(PH_ENTRY);
        } catch (Exception e) {
            failCurrent("tidak bisa membuka Info aplikasi");
        }
    }

    private void doEntry(long now) {
        List<AccessibilityNodeInfo> nodes = screenNodes();
        if (nodes.isEmpty()) {
            timeout(now, "halaman Pengaturan belum terbuka / tidak terbaca");
            return;
        }
        if (now - phaseT0 < SETTLE_MS) return;
        if (handleDanger(nodes)) return;
        AccessibilityNodeInfo cc = findClearCache(nodes);
        if (cc != null) {
            clickClear(cc, now);
            return;
        }
        AccessibilityNodeInfo st = findStorageEntry(nodes, scrollTries < 3);
        if (st != null) {
            if (click(st)) setPhase(PH_STORAGE);
            return;
        }
        if (scrollTries < 3 && now - phaseT0 > 1200L) {
            scrollTries++;
            scroll(nodes);
            return;
        }
        if (!sheetTried && isXiaomi()) {
            AccessibilityNodeInfo cd = findExact(nodes, CLEAR_DATA_OPENERS);
            if (cd != null) {
                sheetTried = true;
                if (clickRaw(cd)) setPhase(PH_SHEET);
                return;
            }
        }
        timeout(now, "menu Penyimpanan / Hapus cache tidak ditemukan; " + snapshot(nodes));
    }

    private void doStorage(long now) {
        List<AccessibilityNodeInfo> nodes = screenNodes();
        if (nodes.isEmpty()) {
            timeout(now, "halaman Penyimpanan tidak terbaca");
            return;
        }
        if (handleDanger(nodes)) return;
        AccessibilityNodeInfo cc = findClearCache(nodes);
        if (cc != null) {
            clickClear(cc, now);
            return;
        }
        if (now - phaseT0 > 1200L && storageScrolls < 2) {
            storageScrolls++;
            scroll(nodes);
            return;
        }
        timeout(now, "tombol Hapus cache tidak ditemukan; " + snapshot(nodes));
    }

    private void doSheet(long now) {
        List<AccessibilityNodeInfo> nodes = screenNodes();
        if (nodes.isEmpty()) {
            timeout(now, "menu Hapus data tidak terbaca");
            return;
        }
        if (handleDanger(nodes)) {
            failCurrent("dialog hapus-data muncul (dibatalkan)");
            return;
        }
        AccessibilityNodeInfo cc = findClearCache(nodes);
        if (cc != null) {
            clickClear(cc, now);
            return;
        }
        timeout(now, "opsi Hapus cache tidak muncul; " + snapshot(nodes));
    }

    private void doAfter(long now) {
        if (now - phaseT0 < AFTER_WAIT_MS) return;
        List<AccessibilityNodeInfo> nodes = screenNodes();
        if (!nodes.isEmpty()) {
            if (handleDanger(nodes)) {
                failCurrent("dialog hapus-data muncul (dibatalkan)");
                return;
            }
            AccessibilityNodeInfo ok = findExact(nodes, CONFIRM_WORDS);
            AccessibilityNodeInfo cancel = findExact(nodes, CANCEL_WORDS);
            if (ok != null && cancel != null && !confirmClicked) {
                confirmClicked = true;
                clickRaw(ok);
                phaseT0 = now;
                return;
            }
        }
        STATE.cleaned++;
        consecutiveFail = 0;
        logLine(labelOf(idx) + ": cache dihapus");
        advance();
    }

    private void clickClear(AccessibilityNodeInfo cc, long now) {
        AccessibilityNodeInfo c = clickable(cc);
        boolean enabled = c != null ? c.isEnabled() : cc.isEnabled();
        if (!enabled) {
            if (now - phaseT0 < DISABLED_WAIT_MS) return;
            STATE.already++;
            consecutiveFail = 0;
            logLine(labelOf(idx) + ": sudah bersih (tombol nonaktif)");
            advance();
            return;
        }
        if (click(cc)) {
            setPhase(PH_AFTER);
        } else {
            failCurrent("klik Hapus cache gagal");
        }
    }

    private void timeout(long now, String why) {
        if (now - phaseT0 > PHASE_TIMEOUT_MS) failCurrent(why);
    }

    private void failCurrent(String why) {
        STATE.failed++;
        consecutiveFail++;
        logLine(labelOf(idx) + ": GAGAL - " + why);
        if (consecutiveFail >= 6 && STATE.cleaned == 0 && STATE.already == 0) {
            finishRun("Dihentikan: Pengaturan tidak bisa dikendalikan di perangkat ini (lihat log)");
            return;
        }
        advance();
    }

    private void advance() {
        idx++;
        STATE.done = idx;
        updateOverlay();
        notifyUi();
        if (idx >= queue.size()) finishRun("Selesai");
        else setPhase(PH_LAUNCH);
    }

    private void finishRun(String msg) {
        handler.removeCallbacks(tick);
        STATE.running = false;
        STATE.finished = true;
        STATE.message = msg;
        STATE.current = "";
        Intent i = new Intent(this, CacheCleanerActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("finished", true);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
        handler.postDelayed(() -> removeOverlay(), 600L);
        notifyUi();
    }

    private void logLine(String s) {
        if (STATE.log.length() > 24000) STATE.log.delete(0, 8000);
        STATE.log.append(s).append('\n');
    }

    // ------------------------------------------------------------------ pembacaan layar

    private void resolveSettings() {
        settingsPkgs.clear();
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", getPackageName(), null));
            ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri != null && ri.activityInfo != null) settingsPkgs.add(ri.activityInfo.packageName);
        } catch (Exception ignored) {
        }
        settingsPkgs.add("com.android.settings");
        settingsPkgs.add("com.miui.securitycenter");
    }

    private boolean isSettingsPkg(String p) {
        if (p == null) return false;
        if (settingsPkgs.contains(p)) return true;
        String l = p.toLowerCase(Locale.ROOT);
        return l.contains("settings") || l.contains("securitycenter") || l.contains("systemmanager")
                || l.contains("appmanager") || l.contains("packageinstaller") || l.contains("permissioncontroller");
    }

    private static boolean isXiaomi() {
        String m = (Build.MANUFACTURER + " " + Build.BRAND).toLowerCase(Locale.ROOT);
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco");
    }

    /** Semua node dari jendela Pengaturan (halaman + dialog). Kosong jika Pengaturan belum terbuka. */
    private List<AccessibilityNodeInfo> screenNodes() {
        List<AccessibilityNodeInfo> out = new ArrayList<AccessibilityNodeInfo>();
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r != null && isSettingsPkg(String.valueOf(r.getPackageName()))) collect(r, out, 0);
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            if (ws != null) {
                for (AccessibilityWindowInfo w : ws) {
                    AccessibilityNodeInfo wr = w.getRoot();
                    if (wr == null || !isSettingsPkg(String.valueOf(wr.getPackageName()))) continue;
                    if (r != null && wr.equals(r)) continue;
                    collect(wr, out, 0);
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static void collect(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 40) return;
        out.add(n);
        int c = n.getChildCount();
        for (int i = 0; i < c; i++) {
            AccessibilityNodeInfo ch = n.getChild(i);
            if (ch != null) collect(ch, out, depth + 1);
        }
    }

    private static String lbl(AccessibilityNodeInfo n) {
        CharSequence t = n.getText();
        String s = t == null ? "" : t.toString();
        if (s.isEmpty()) {
            CharSequence d = n.getContentDescription();
            if (d != null) s = d.toString();
        }
        return s.trim().toLowerCase(Locale.ROOT);
    }

    private static boolean has(String s, String[] words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }

    private static boolean eq(String s, String[] words) {
        for (String w : words) if (s.equals(w)) return true;
        return false;
    }

    private static boolean startsWithAny(String s, String[] words) {
        for (String w : words) if (s.startsWith(w)) return true;
        return false;
    }

    private static boolean isNever(String l) {
        return has(l, NEVER_CLICK);
    }

    private static boolean isClearCache(String l) {
        return !l.isEmpty() && has(l, CACHE_WORDS) && has(l, CLEAR_VERBS) && !isNever(l);
    }

    private static AccessibilityNodeInfo clickable(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 7 && cur != null; i++) {
            if (cur.isClickable()) return cur;
            cur = cur.getParent();
        }
        return null;
    }

    private AccessibilityNodeInfo findClearCache(List<AccessibilityNodeInfo> nodes) {
        AccessibilityNodeInfo best = null;
        for (AccessibilityNodeInfo n : nodes) {
            if (!isClearCache(lbl(n))) continue;
            if (best == null) best = n;
            AccessibilityNodeInfo c = clickable(n);
            if (c != null && c.isEnabled()) return n;
        }
        return best;
    }

    private AccessibilityNodeInfo findStorageEntry(List<AccessibilityNodeInfo> nodes, boolean strict) {
        AccessibilityNodeInfo best = null;
        int bestScore = 0;
        for (AccessibilityNodeInfo n : nodes) {
            String l = lbl(n);
            if (l.isEmpty() || l.contains(",") || isNever(l)) continue;
            String vid = n.getViewIdResourceName();
            if (vid != null && vid.endsWith("summary")) continue;
            int sc = 0;
            if (eq(l, STORAGE_EXACT)) sc = 100;
            else if (l.length() <= 28 && startsWithAny(l, STORAGE_WORDS)) sc = 60;
            else if (l.length() <= 24 && has(l, STORAGE_WORDS)) sc = 30;
            if (sc == 0 || clickable(n) == null) continue;
            if (sc > bestScore) {
                best = n;
                bestScore = sc;
            }
        }
        if (best == null) return null;
        return bestScore >= (strict ? 60 : 30) ? best : null;
    }

    private AccessibilityNodeInfo findExact(List<AccessibilityNodeInfo> nodes, String[] words) {
        for (AccessibilityNodeInfo n : nodes) {
            if (eq(lbl(n), words) && clickable(n) != null) return n;
        }
        return null;
    }

    private boolean handleDanger(List<AccessibilityNodeInfo> nodes) {
        StringBuilder sb = new StringBuilder();
        for (AccessibilityNodeInfo n : nodes) {
            String l = lbl(n);
            if (!l.isEmpty()) sb.append(l).append(' ');
        }
        if (!has(sb.toString(), DANGER_DIALOG)) return false;
        AccessibilityNodeInfo cancel = findExact(nodes, CANCEL_WORDS);
        if (cancel == null) return false;
        clickRaw(cancel);
        logLine("dialog hapus-data terdeteksi -> dibatalkan");
        return true;
    }

    /** Klik dengan pengaman: label berbahaya tidak pernah diklik. */
    private boolean click(AccessibilityNodeInfo n) {
        if (isNever(lbl(n))) return false;
        AccessibilityNodeInfo t = clickable(n);
        if (t == null) t = n;
        if (isNever(lbl(t))) return false;
        return t.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    /** Klik tanpa filter NEVER_CLICK (hanya untuk Konfirmasi/Batal/pembuka menu Xiaomi). */
    private boolean clickRaw(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo t = clickable(n);
        if (t == null) t = n;
        return t.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private boolean scroll(List<AccessibilityNodeInfo> nodes) {
        for (AccessibilityNodeInfo n : nodes) {
            if (n.isScrollable() && n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true;
        }
        return false;
    }

    private String snapshot(List<AccessibilityNodeInfo> nodes) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (AccessibilityNodeInfo x : nodes) {
            String l = lbl(x);
            if (l.isEmpty() || l.length() > 40) continue;
            if (n > 0) sb.append(" | ");
            sb.append(l);
            n++;
            if (n >= 10) break;
        }
        return "layar: " + sb;
    }

    // ------------------------------------------------------------------ overlay progres

    private void addOverlay() {
        if (overlay != null) return;
        try {
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Ui.BG);
            root.setClickable(true);
            LinearLayout col = Ui.col(this);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            int p = Ui.dp(this, 28);
            col.setPadding(p, p, p, p);
            gauge = new GaugeView(this);
            gauge.setColors(Ui.CYAN, Ui.VIOLET);
            gauge.setCenter("0%", "memulai");
            col.addView(gauge, new LinearLayout.LayoutParams(Ui.dp(this, 230), Ui.dp(this, 230)));
            TextView title = Ui.tvb(this, "Membersihkan cache", 20, Ui.TEXT);
            title.setGravity(Gravity.CENTER);
            col.addView(title, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 24, 0, 0));
            ovSub = Ui.tv(this, "", 14, Ui.SUB);
            ovSub.setGravity(Gravity.CENTER);
            ovSub.setSingleLine(true);
            col.addView(ovSub, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
            TextView hint = Ui.tv(this, "Berjalan otomatis. Tidak perlu menyentuh layar.", 12, Ui.SUB);
            hint.setGravity(Gravity.CENTER);
            col.addView(hint, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 28));
            TextView cancel = Ui.ghost(this, "Batal", v -> cancel());
            col.addView(cancel, Ui.lp(this, Ui.dp(this, 160), Ui.WRAP, 0, 0, 0, 0));
            root.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH, Gravity.CENTER));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            wm.addView(root, lp);
            overlay = root;
        } catch (Throwable t) {
            overlay = null;
            logLine("overlay tidak bisa ditampilkan: " + t);
        }
    }

    private void updateOverlay() {
        if (overlay == null || gauge == null) return;
        int total = Math.max(1, queue.size());
        gauge.setProgress((float) idx / (float) total, true);
        gauge.setCenter(Math.round(100f * idx / total) + "%", idx + " / " + queue.size());
        if (ovSub != null) ovSub.setText(labelOf(idx));
    }

    private void removeOverlay() {
        if (overlay != null && wm != null) {
            try {
                wm.removeView(overlay);
            } catch (Throwable ignored) {
            }
        }
        overlay = null;
        gauge = null;
        ovSub = null;
    }
}
