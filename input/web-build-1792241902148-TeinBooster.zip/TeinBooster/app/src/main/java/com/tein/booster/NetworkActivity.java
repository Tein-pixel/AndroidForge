package com.tein.booster;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Network Booster: tes kecepatan unduh, tes latensi DNS (UDP), tes ping TCP, dan atur Private DNS. */
public class NetworkActivity extends BaseActivity {
    private static final String[][] PING = {
            {"Cloudflare", "1.1.1.1"}, {"Google", "8.8.8.8"}, {"Quad9", "9.9.9.9"}
    };

    private LinearLayout statusBox;
    private GaugeView speedGauge;
    private TextView speedBtn;
    private TextView speedNote;
    private LinearLayout dnsBox;
    private TextView dnsBtn;
    private LinearLayout pingBox;
    private TextView pingBtn;
    private boolean testing;
    private boolean dnsRunning;
    private boolean pingRunning;

    @Override
    protected String title() { return "Network Booster"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();

        LinearLayout st = Ui.card(this);
        st.addView(Ui.tvb(this, "Status koneksi", 15, Ui.TEXT));
        statusBox = Ui.col(this);
        st.addView(statusBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(st);

        LinearLayout sp = Ui.card(this);
        sp.addView(Ui.tvb(this, "Tes kecepatan unduh", 15, Ui.TEXT));
        speedGauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 200), Ui.dp(this, 200));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        gp.topMargin = Ui.dp(this, 8);
        sp.addView(speedGauge, gp);
        speedGauge.setCenter("0", "Mbps");
        speedNote = Ui.tv(this, "Mengunduh data uji dari Cloudflare maksimal 8 detik. Memakai kuota bila di jaringan seluler.", 12, Ui.SUB);
        speedNote.setGravity(Gravity.CENTER);
        sp.addView(speedNote, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        speedBtn = Ui.button(this, "Mulai tes", v -> runSpeed());
        sp.addView(speedBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        col.addView(sp, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout dn = Ui.card(this);
        dn.addView(Ui.tvb(this, "Latensi DNS", 15, Ui.TEXT));
        dn.addView(Ui.tv(this, "Mengukur kecepatan 4 penyedia DNS publik dari jaringanmu, lalu menerapkan yang tercepat sebagai Private DNS.", 12, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        dnsBox = Ui.col(this);
        dn.addView(dnsBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        dnsBtn = Ui.ghost(this, "Tes DNS", v -> runDns());
        dn.addView(dnsBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        if (Perm.secure(this)) {
            dn.addView(Ui.ghost(this, "Kembalikan Private DNS ke otomatis", v -> resetDns()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        }
        col.addView(dn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout pg = Ui.card(this);
        pg.addView(Ui.tvb(this, "Tes ping (TCP)", 15, Ui.TEXT));
        pingBox = Ui.col(this);
        pg.addView(pingBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        pingBtn = Ui.ghost(this, "Tes ping", v -> runPing());
        pg.addView(pingBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(pg, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        Ui.reveal(st, sp, dn, pg);
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderStatus();
    }

    private void renderStatus() {
        statusBox.removeAllViews();
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc == null) {
                statusBox.addView(Ui.kv(this, "Koneksi", "Tidak terhubung"));
                return;
            }
            boolean wifi = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
            String type = wifi ? "Wi-Fi" : (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Seluler"
                    : (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : "Terhubung"));
            statusBox.addView(Ui.kv(this, "Koneksi", type));
            statusBox.addView(Ui.kv(this, "Kapasitas turun / naik (perkiraan sistem)",
                    (nc.getLinkDownstreamBandwidthKbps() / 1000) + " / " + (nc.getLinkUpstreamBandwidthKbps() / 1000) + " Mbps"));
            if (wifi) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
                if (wi != null) {
                    statusBox.addView(Ui.kv(this, "Kecepatan link", wi.getLinkSpeed() + " Mbps"));
                    statusBox.addView(Ui.kv(this, "Sinyal", wi.getRssi() + " dBm"));
                    int f = wi.getFrequency();
                    statusBox.addView(Ui.kv(this, "Frekuensi", f + " MHz (" + (f > 5900 ? "6 GHz" : (f > 4900 ? "5 GHz" : "2,4 GHz")) + ")"));
                }
            }
        } catch (Exception e) {
            statusBox.addView(Ui.kv(this, "Koneksi", "Tidak terbaca"));
        }
    }

    private void runSpeed() {
        if (testing) return;
        testing = true;
        speedBtn.setText("Menguji...");
        speedBtn.setAlpha(0.6f);
        speedGauge.setProgress(0f, false);
        speedGauge.setCenter("0", "Mbps");
        Bg.run(() -> {
            double res = -1;
            String err = null;
            try {
                res = Net.downloadTest((m, f) -> Bg.ui(() -> {
                    if (!alive()) return;
                    speedGauge.setCenter(String.format(Locale.US, "%.1f", m), "Mbps");
                    speedGauge.setProgress(Math.min(1f, (float) (m / 100.0)), true);
                }), 8000L);
            } catch (Exception e) {
                err = e.getClass().getSimpleName();
            }
            final double fres = res;
            final String ferr = err;
            Bg.ui(() -> {
                testing = false;
                if (!alive()) return;
                speedBtn.setText("Tes lagi");
                speedBtn.setAlpha(1f);
                if (ferr != null || fres <= 0) {
                    speedGauge.setCenter("-", "gagal");
                    speedNote.setText("Tes gagal" + (ferr != null ? " (" + ferr + ")" : "") + ". Periksa koneksi internet.");
                } else {
                    speedGauge.setCenter(String.format(Locale.US, "%.1f", fres), "Mbps");
                    speedGauge.setProgress(Math.min(1f, (float) (fres / 100.0)), true);
                    speedNote.setText("Hasil unduh rata-rata (" + String.format(Locale.US, "%.1f", fres / 8.0) + " MB/detik).");
                }
            });
        });
    }

    private void runDns() {
        if (dnsRunning) return;
        dnsRunning = true;
        dnsBtn.setText("Menguji...");
        dnsBox.removeAllViews();
        Bg.run(() -> {
            final long[] ms = new long[Net.DNS.length];
            for (int i = 0; i < Net.DNS.length; i++) ms[i] = Net.dnsMedian(Net.DNS[i][1]);
            Bg.ui(() -> {
                dnsRunning = false;
                if (!alive()) return;
                dnsBtn.setText("Tes DNS lagi");
                renderDns(ms);
            });
        });
    }

    private void renderDns(final long[] ms) {
        dnsBox.removeAllViews();
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < ms.length; i++) order.add(i);
        Collections.sort(order, (a, b) -> {
            long x = ms[a] < 0 ? Long.MAX_VALUE : ms[a];
            long y = ms[b] < 0 ? Long.MAX_VALUE : ms[b];
            return Long.compare(x, y);
        });
        long best = ms[order.get(0)];
        for (int rank = 0; rank < order.size(); rank++) {
            final int i = order.get(rank);
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            LinearLayout mid = Ui.col(this);
            mid.addView(Ui.tvb(this, Net.DNS[i][0] + (rank == 0 && ms[i] >= 0 ? "  \u2605 tercepat" : ""), 14, rank == 0 && ms[i] >= 0 ? Ui.MINT : Ui.TEXT));
            BarView bar = new BarView(this);
            float frac = ms[i] < 0 ? 0f : Math.min(1f, (float) Math.max(1L, best) / (float) Math.max(1L, ms[i]));
            mid.addView(bar, Ui.lp(this, Ui.MATCH, Ui.dp(this, 5), 0, 6, 0, 0));
            bar.setSmooth(frac, rank == 0 ? Ui.MINT : Ui.BLUE);
            r.addView(mid, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            r.addView(Ui.tvb(this, ms[i] < 0 ? "gagal" : ms[i] + " ms", 13, Ui.CYAN), Ui.lp(this, Ui.WRAP, Ui.WRAP, 10, 0, 10, 0));
            if (ms[i] >= 0) {
                TextView use = Ui.tvb(this, "Pakai", 13, Ui.INK);
                use.setBackground(Ui.grad(this, Ui.CYAN, Ui.BLUE, 10));
                use.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7));
                use.setOnClickListener(v -> applyDns(Net.DNS[i][0], Net.DNS[i][2]));
                r.addView(use);
            }
            dnsBox.addView(r);
        }
    }

    private void applyDns(String name, String host) {
        if (Perm.secure(this)) {
            try {
                Settings.Global.putString(getContentResolver(), "private_dns_mode", "hostname");
                Settings.Global.putString(getContentResolver(), "private_dns_specifier", host);
                Ui.toast(this, "Private DNS diatur ke " + name);
                return;
            } catch (Exception ignored) {
            }
        }
        Ui.copy(this, "dns", host);
        new AlertDialog.Builder(this)
                .setTitle("Atur " + name)
                .setMessage("Hostname sudah disalin:\n" + host + "\n\nBuka Pengaturan \u2192 Jaringan & internet \u2192 DNS pribadi, "
                        + "pilih \"Nama host penyedia DNS pribadi\", lalu tempel.\n\n"
                        + "Tip: beri izin ADB di Pusat Izin agar DNS bisa diatur sekali tekan.")
                .setPositiveButton("Buka Pengaturan Jaringan", (d, w) -> Perm.start(this, new Intent(Settings.ACTION_WIRELESS_SETTINGS)))
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void resetDns() {
        try {
            Settings.Global.putString(getContentResolver(), "private_dns_mode", "opportunistic");
            Ui.toast(this, "Private DNS dikembalikan ke otomatis");
        } catch (Exception e) {
            Ui.toast(this, "Gagal: " + e.getMessage());
        }
    }

    private void runPing() {
        if (pingRunning) return;
        pingRunning = true;
        pingBtn.setText("Menguji...");
        pingBox.removeAllViews();
        Bg.run(() -> {
            final double[][] r = new double[PING.length][];
            for (int i = 0; i < PING.length; i++) r[i] = Net.tcpPing(PING[i][1], 443, 5);
            Bg.ui(() -> {
                pingRunning = false;
                if (!alive()) return;
                pingBtn.setText("Tes ping lagi");
                pingBox.removeAllViews();
                for (int i = 0; i < PING.length; i++) {
                    String v = r[i][0] < 0 ? "tidak terjangkau"
                            : String.format(Locale.US, "%.0f ms \u2022 jitter %.0f \u2022 loss %.0f%%", r[i][0], r[i][1], r[i][2]);
                    pingBox.addView(Ui.kv(this, PING[i][0], v));
                }
            });
        });
    }
}
