package com.tein.booster;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Logo animasi untuk splash: cincin menyapu + petir yang "mendarat" lalu berdenyut. */
public class LogoView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boltP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pulse = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path bolt = new Path();
    private final RectF oval = new RectF();
    private final Matrix gm = new Matrix();
    private SweepGradient sweep;
    private float t = 0f;
    private float beat = 0f;
    private ValueAnimator intro;
    private ValueAnimator loop;
    private float cx, cy, size;

    public LogoView(Context c) {
        super(c);
        init();
    }

    public LogoView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        track.setStyle(Paint.Style.STROKE);
        track.setColor(0xFF1C2646);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeCap(Paint.Cap.ROUND);
        boltP.setStyle(Paint.Style.FILL);
        boltP.setShader(new LinearGradient(0f, 0f, 0f, 1f, Ui.CYAN, Ui.BLUE, Shader.TileMode.CLAMP));
        pulse.setStyle(Paint.Style.FILL);
        pulse.setColor(Ui.CYAN);
        bolt.moveTo(0.58f, 0.06f);
        bolt.lineTo(0.24f, 0.54f);
        bolt.lineTo(0.46f, 0.54f);
        bolt.lineTo(0.38f, 0.94f);
        bolt.lineTo(0.76f, 0.40f);
        bolt.lineTo(0.54f, 0.40f);
        bolt.close();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        size = Math.min(w, h);
        cx = w / 2f;
        cy = h / 2f;
        float stroke = size * 0.045f;
        float r = size * 0.42f;
        oval.set(cx - r, cy - r, cx + r, cy + r);
        track.setStrokeWidth(stroke);
        ring.setStrokeWidth(stroke);
        sweep = new SweepGradient(cx, cy, new int[]{Ui.CYAN, Ui.VIOLET, Ui.CYAN}, new float[]{0f, 0.5f, 1f});
    }

    private static float backOut(float x) {
        double c1 = 1.70158;
        double c3 = c1 + 1.0;
        double p = x - 1.0;
        return (float) (1.0 + c3 * p * p * p + c1 * p * p);
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        if (sweep == null) return;
        float r = oval.width() / 2f;
        pulse.setAlpha((int) (24 + 26 * beat));
        cv.drawCircle(cx, cy, r * (0.80f + 0.07f * beat), pulse);
        cv.drawArc(oval, 0f, 360f, false, track);
        float e = 1f - (1f - t) * (1f - t);
        gm.setRotate(-90f, cx, cy);
        sweep.setLocalMatrix(gm);
        ring.setShader(sweep);
        if (t > 0.01f) cv.drawArc(oval, -90f, 360f * e, false, ring);
        float s = 0.55f + 0.45f * Math.max(0f, backOut(Math.min(1f, t * 1.15f)));
        float bs = size * 0.46f * s;
        cv.save();
        cv.translate(cx - bs / 2f, cy - bs / 2f);
        cv.scale(bs, bs);
        boltP.setAlpha((int) (255 * Math.min(1f, t * 2f)));
        cv.drawPath(bolt, boltP);
        cv.restore();
    }

    public void play() {
        if (intro != null) intro.cancel();
        intro = ValueAnimator.ofFloat(0f, 1f);
        intro.setDuration(1300);
        intro.setInterpolator(new LinearInterpolator());
        intro.addUpdateListener(a -> {
            t = (Float) a.getAnimatedValue();
            invalidate();
        });
        intro.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                startLoop();
            }
        });
        intro.start();
    }

    private void startLoop() {
        if (loop != null) loop.cancel();
        loop = ValueAnimator.ofFloat(0f, 1f);
        loop.setDuration(900);
        loop.setRepeatCount(ValueAnimator.INFINITE);
        loop.setRepeatMode(ValueAnimator.REVERSE);
        loop.addUpdateListener(a -> {
            beat = (Float) a.getAnimatedValue();
            invalidate();
        });
        loop.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (intro != null) intro.cancel();
        if (loop != null) loop.cancel();
    }
}
