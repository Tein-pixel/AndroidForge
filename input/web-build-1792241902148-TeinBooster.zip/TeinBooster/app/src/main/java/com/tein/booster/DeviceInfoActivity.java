package com.tein.booster;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;

/** Info Perangkat: semua nilai dibaca langsung dari sistem. */
public class DeviceInfoActivity extends BaseActivity {
    private LinearLayout col;

    @Override
    protected String title() { return "Info Perangkat"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        col = scrollBody();
        build();
    }

    private void section(String name, String[][] rows) {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.tvb(this, name, 15, Ui.CYAN));
        for (int i = 0; i < rows.length; i++) {
            c.addView(Ui.kv(this, rows[i][0], rows[i][1]), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, i == 0 ? 6 : 0, 0, 0));
        }
        col.addView(c, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
    }

    private static String readLine(String path) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(path));
            String l = br.readLine();
            return l == null ? null : l.trim();
        } catch (Exception e) {
            return null;
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static String ghz(long khz) {
        return String.format(Locale.US, "%.2f GHz", khz / 1000000.0);
    }

    private String cpuFreq() {
        int n = Runtime.getRuntime().availableProcessors();
        long min = Long.MAX_VALUE;
        long max = 0L;
        for (int i = 0; i < n; i++) {
            String s = readLine("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            if (s == null) continue;
            try {
                long k = Long.parseLong(s);
                min = Math.min(min, k);
                max = Math.max(max, k);
            } catch (NumberFormatException ignored) {
            }
        }
        if (max == 0L) return "tidak terbaca";
        return min == max ? ghz(max) : ghz(min) + " - " + ghz(max);
    }

    private void build() {
        String soc = Build.HARDWARE;
        if (Build.VERSION.SDK_INT >= 31) soc = Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL;
        section("Perangkat", new String[][]{
                {"Merek", Build.MANUFACTURER},
                {"Model", Build.MODEL},
                {"Kode perangkat", Build.DEVICE},
                {"Android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"},
                {"Patch keamanan", Build.VERSION.SECURITY_PATCH},
                {"Build", Build.DISPLAY}
        });
        String abis = "";
        for (String a : Build.SUPPORTED_ABIS) abis += (abis.isEmpty() ? "" : ", ") + a;
        section("Prosesor", new String[][]{
                {"SoC / hardware", soc},
                {"Arsitektur (ABI)", abis},
                {"Jumlah core", String.valueOf(Runtime.getRuntime().availableProcessors())},
                {"Frekuensi maksimum", cpuFreq()}
        });
        long rt = Sys.ramTotal(this);
        long ra = Sys.ramAvail(this);
        section("Memori & penyimpanan", new String[][]{
                {"RAM total", Fmt.bytes(rt)},
                {"RAM tersedia", Fmt.bytes(ra)},
                {"Penyimpanan total", Fmt.bytes(Sys.storageTotal())},
                {"Penyimpanan kosong", Fmt.bytes(Sys.storageFree())}
        });
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float hz = getWindowManager().getDefaultDisplay().getRefreshRate();
        section("Layar", new String[][]{
                {"Resolusi", dm.widthPixels + " x " + dm.heightPixels},
                {"Kepadatan", dm.densityDpi + " dpi"},
                {"Refresh rate", String.format(Locale.US, "%.0f Hz", hz)}
        });
        Sys.Batt b = Sys.battery(this);
        section("Baterai", new String[][]{
                {"Level", b.level + "%"},
                {"Status", Sys.battStatus(b.status)},
                {"Suhu", String.format(Locale.US, "%.1f\u00B0C", b.tempC)},
                {"Tegangan", String.format(Locale.US, "%.2f V", b.voltageMv / 1000f)},
                {"Kesehatan", Sys.battHealth(b.health)},
                {"Teknologi", b.tech}
        });
        SensorManager sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        int sensors = sm == null ? 0 : sm.getSensorList(Sensor.TYPE_ALL).size();
        section("Sistem", new String[][]{
                {"Waktu aktif", Fmt.uptime(SystemClock.elapsedRealtime())},
                {"Jumlah sensor", String.valueOf(sensors)},
                {"Bahasa", Locale.getDefault().getDisplayName()}
        });
    }
}
