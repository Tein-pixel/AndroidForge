package com.tein.booster;

import android.app.usage.UsageStats;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Hemat Baterai: profil hemat daya nyata (kecerahan, timeout layar, sinkronisasi) + daftar aplikasi terlama dipakai. */
public class BatteryActivity extends BaseActivity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private GaugeView gauge;
    private LinearLayout chipRow;
    private TextView profDesc;
    private TextView applyBtn;
    private LinearLayout permCard;
    private LinearLayout topBox;
    private int selProfile;

    private static final String[] DESC = {
            "Tidak mengubah apa pun. Memulihkan pengaturan awalmu bila sebelumnya memakai profil hemat.",
            "Menutup aplikasi latar, kecerahan \u00B135%, layar mati 30 detik, sinkronisasi otomatis dimatikan.",
            "Seperti Hemat, tetapi kecerahan \u00B118% dan layar mati 15 detik. Untuk saat baterai kritis."
    };

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            updateBattery(false);
            h.postDelayed(this, 3000L);
        }
    };

    @Override
    protected String title() { return "Hemat Baterai"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();
        selProfile = Prefs.getInt(this, Prefs.BATT_PROFILE, 0);

        LinearLayout hero = Ui.card(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 200), Ui.dp(this, 200));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);
        chipRow = Ui.row(this);
        chipRow.setGravity(Gravity.CENTER);
        hero.addView(chipRow, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(hero);

        LinearLayout prof = Ui.card(this);
        prof.addView(Ui.tvb(this, "Profil hemat daya", 15, Ui.TEXT));
        prof.addView(Ui.segment(this, new String[]{"Normal", "Hemat", "Ultra"}, selProfile, i -> {
            selProfile = i;
            profDesc.setText(DESC[i]);
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        profDesc = Ui.tv(this, DESC[selProfile], 13, Ui.SUB);
        prof.addView(profDesc, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        applyBtn = Ui.button(this, "Terapkan profil", v -> apply());
        prof.addView(applyBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        prof.addView(Ui.ghost(this, "Pengaturan hemat baterai sistem", v -> {
            if (!Perm.start(this, new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))) {
                Ui.toast(this, "Tidak tersedia di perangkat ini");
            }
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(prof, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        permCard = Ui.card(this);
        permCard.addView(Ui.tvb(this, "Butuh izin ubah pengaturan sistem", 14, Ui.EMBER));
        permCard.addView(Ui.tv(this, "Agar bisa mengatur kecerahan dan waktu layar mati.", 13, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        permCard.addView(Ui.ghost(this, "Beri izin", v -> Perm.openWriteSettings(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(permCard, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        col.addView(Ui.sectionTitle(this, "Paling lama dipakai (24 jam)"));
        topBox = Ui.card(this);
        col.addView(topBox);
        Ui.reveal(hero, prof);
    }

    @Override
    protected void onResume() {
        super.onResume();
        permCard.setVisibility(Perm.writeSettings(this) ? View.GONE : View.VISIBLE);
        updateBattery(true);
        h.postDelayed(loop, 3000L);
        loadTop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(loop);
    }

    private void updateBattery(boolean animate) {
        Sys.Batt b = Sys.battery(this);
        int c = b.level >= 50 ? Ui.MINT : (b.level >= 20 ? Ui.EMBER : Ui.CORAL);
        gauge.setColors(c, Ui.CYAN);
        gauge.setProgress(b.level / 100f, animate);
        gauge.setCenter(b.level + "%", Sys.battStatus(b.status));
        chipRow.removeAllViews();
        addChip(String.format(Locale.US, "%.1f\u00B0C", b.tempC), Sys.tempColor(b.tempC));
        addChip(String.format(Locale.US, "%.2f V", b.voltageMv / 1000f), Ui.BLUE);
        addChip(Sys.battHealth(b.health), b.health == 2 ? Ui.MINT : Ui.EMBER);
    }

    private void addChip(String t, int color) {
        chipRow.addView(Ui.chip(this, t, color), Ui.lp(this, Ui.WRAP, Ui.WRAP, 3, 0, 3, 0));
    }

    private void saveOriginals(Context app) {
        if (Prefs.getBool(app, Prefs.BATT_SAVED, false)) return;
        ContentResolver cr = app.getContentResolver();
        Prefs.putInt(app, Prefs.BATT_BRIGHT, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128));
        Prefs.putInt(app, Prefs.BATT_MODE, Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0));
        Prefs.putInt(app, Prefs.BATT_TIMEOUT, Settings.System.getInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, 60000));
        Prefs.putBool(app, Prefs.BATT_SYNC, ContentResolver.getMasterSyncAutomatically());
        Prefs.putBool(app, Prefs.BATT_SAVED, true);
    }

    private void apply() {
        if (selProfile == 0) {
            restore();
            return;
        }
        if (!Perm.writeSettings(this)) {
            Perm.openWriteSettings(this);
            return;
        }
        final Context app = getApplicationContext();
        saveOriginals(app);
        int bright = selProfile == 1 ? 90 : 45;
        int timeout = selProfile == 1 ? 30000 : 15000;
        try {
            ContentResolver cr = getContentResolver();
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, bright);
            Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, timeout);
        } catch (Exception e) {
            Ui.toast(this, "Gagal mengubah pengaturan: " + e.getMessage());
            return;
        }
        try {
            ContentResolver.setMasterSyncAutomatically(false);
        } catch (Exception ignored) {
        }
        Prefs.putInt(app, Prefs.BATT_PROFILE, selProfile);
        applyBtn.setText("Menerapkan...");
        Bg.run(() -> {
            final Optimizer.Result r = Optimizer.boostRam(app);
            Bg.ui(() -> {
                if (!alive()) return;
                applyBtn.setText("Terapkan profil");
                Ui.toast(this, "Profil aktif \u2022 " + r.killed + " aplikasi ditutup");
            });
        });
    }

    private void restore() {
        final Context app = getApplicationContext();
        if (!Prefs.getBool(app, Prefs.BATT_SAVED, false)) {
            Ui.toast(this, "Tidak ada pengaturan yang perlu dipulihkan");
            return;
        }
        if (!Perm.writeSettings(app)) {
            Perm.openWriteSettings(this);
            return;
        }
        try {
            ContentResolver cr = getContentResolver();
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, Prefs.getInt(app, Prefs.BATT_BRIGHT, 128));
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Prefs.getInt(app, Prefs.BATT_MODE, 0));
            Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, Prefs.getInt(app, Prefs.BATT_TIMEOUT, 60000));
            ContentResolver.setMasterSyncAutomatically(Prefs.getBool(app, Prefs.BATT_SYNC, true));
        } catch (Exception e) {
            Ui.toast(this, "Gagal memulihkan: " + e.getMessage());
            return;
        }
        Prefs.putBool(app, Prefs.BATT_SAVED, false);
        Prefs.putInt(app, Prefs.BATT_PROFILE, 0);
        Ui.toast(this, "Pengaturan dipulihkan");
    }

    private void loadTop() {
        topBox.removeAllViews();
        if (!Perm.usage(this)) {
            topBox.addView(Ui.tv(this, "Beri Akses Penggunaan untuk melihat aplikasi yang paling lama dipakai.", 13, Ui.SUB));
            topBox.addView(Ui.ghost(this, "Beri akses", v -> Perm.openUsage(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
            return;
        }
        final Context app = getApplicationContext();
        Bg.run(() -> {
            Map<String, UsageStats> m = Sys.usageMap(app, 24L * 60L * 60L * 1000L);
            Map<String, Apps.Item> byPkg = new HashMap<String, Apps.Item>();
            for (Apps.Item it : Apps.loadAll(app)) byPkg.put(it.pkg, it);
            final List<Apps.Item> rows = new ArrayList<Apps.Item>();
            for (Map.Entry<String, UsageStats> e : m.entrySet()) {
                long t = e.getValue().getTotalTimeInForeground();
                Apps.Item it = byPkg.get(e.getKey());
                if (it == null || t < 60000L || e.getKey().equals(app.getPackageName())) continue;
                it.fgTime = t;
                it.right = Fmt.duration(t);
                rows.add(it);
            }
            Collections.sort(rows, (a, b) -> Long.compare(b.fgTime, a.fgTime));
            Bg.ui(() -> {
                if (!alive()) return;
                topBox.removeAllViews();
                if (rows.isEmpty()) {
                    topBox.addView(Ui.tv(this, "Belum ada data pemakaian.", 13, Ui.SUB));
                    return;
                }
                int n = Math.min(6, rows.size());
                for (int i = 0; i < n; i++) {
                    Apps.Item it = rows.get(i);
                    LinearLayout r = Ui.row(this);
                    r.setPadding(0, Ui.dp(this, 7), 0, Ui.dp(this, 7));
                    ImageView iv = new ImageView(this);
                    r.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));
                    IconLoader.load(this, it.pkg, iv);
                    TextView nm = Ui.tvb(this, it.label, 14, Ui.TEXT);
                    nm.setSingleLine(true);
                    LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
                    np.setMargins(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
                    r.addView(nm, np);
                    r.addView(Ui.tvb(this, it.right, 13, Ui.CYAN));
                    topBox.addView(r);
                }
            });
        });
    }
}
