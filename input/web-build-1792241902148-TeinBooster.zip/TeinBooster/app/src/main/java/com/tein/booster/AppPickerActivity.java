package com.tein.booster;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Pemilih aplikasi: daftar putih (dilindungi) atau daftar game untuk Game Booster. Tersimpan otomatis. */
public class AppPickerActivity extends BaseActivity {
    public static final String EXTRA_MODE = "mode";
    private AppAdapter adapter;
    private String key;

    private boolean gamesMode() {
        return "games".equals(getIntent().getStringExtra(EXTRA_MODE));
    }

    @Override
    protected String title() {
        return gamesMode() ? "Pilih game" : "Daftar putih";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final boolean games = gamesMode();
        key = games ? Prefs.GAMES : Prefs.WHITELIST;
        ListView lv = listBody();
        TextView hint = Ui.tv(this, games
                ? "Centang game atau aplikasi yang ingin di-boost lewat Game Booster."
                : "Aplikasi yang dicentang TIDAK akan ditutup atau dibersihkan oleh booster.", 13, Ui.SUB);
        hint.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 10));
        hint.setGravity(Gravity.START);
        lv.addHeaderView(hint, null, false);
        adapter = new AppAdapter(this, true);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            int idx = pos - 1;
            if (idx < 0 || idx >= adapter.getCount()) return;
            Apps.Item it = adapter.getItem(idx);
            adapter.toggle(it.pkg);
            Prefs.putSet(this, key, adapter.checked());
        });
        final Context app = getApplicationContext();
        Bg.run(() -> {
            List<Apps.Item> all = Apps.loadAll(app);
            final List<Apps.Item> list = new ArrayList<Apps.Item>();
            for (Apps.Item it : all) {
                if (!it.launchable || it.pkg.equals(app.getPackageName())) continue;
                it.sub = games ? (it.game ? "Game" : it.pkg) : it.pkg;
                list.add(it);
            }
            if (games) {
                Collections.sort(list, (a, b) -> {
                    if (a.game != b.game) return a.game ? -1 : 1;
                    return a.label.compareToIgnoreCase(b.label);
                });
            }
            Bg.ui(() -> {
                if (!alive()) return;
                adapter.setItems(list);
                adapter.setChecked(Prefs.getSet(app, key));
            });
        });
    }
}
