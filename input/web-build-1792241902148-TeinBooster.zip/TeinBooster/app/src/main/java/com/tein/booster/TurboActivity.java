package com.tein.booster;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Turbo UI: percepat skala animasi sistem (butuh izin WRITE_SECURE_SETTINGS sekali via ADB). */
public class TurboActivity extends BaseActivity {
    private static final String[] KEYS = {
            Settings.Global.WINDOW_ANIMATION_SCALE,
            Settings.Global.TRANSITION_ANIMATION_SCALE,
            Settings.Global.ANIMATOR_DURATION_SCALE
    };
    private static final float[] PRESET = {1f, 0.5f, 0.25f, 0f};
    private static final String[] PRESET_NAME = {"Normal", "Cepat", "Turbo", "Mati"};

    private TextView current;
    private LinearLayout setup;

    @Override
    protected String title() { return "Turbo UI"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();

        LinearLayout card = Ui.card(this);
        card.addView(Ui.tvb(this, "Percepat animasi sistem", 16, Ui.TEXT));
        card.addView(Ui.tv(this, "Mengecilkan skala animasi jendela, transisi, dan durasi animator membuat HP terasa jauh lebih ngebut "
                + "tanpa mengubah kinerja asli.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        current = Ui.tvb(this, "", 13, Ui.CYAN);
        card.addView(current, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        card.addView(Ui.segment(this, PRESET_NAME, nearest(readScale()), i -> apply(PRESET[i])),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(card);

        setup = Ui.card(this);
        setup.addView(Ui.tvb(this, "Butuh izin sekali lewat ADB", 15, Ui.EMBER));
        setup.addView(Ui.tv(this, "Android hanya mengizinkan aplikasi mengubah skala animasi jika diberi izin WRITE_SECURE_SETTINGS. "
                + "Jalankan perintah ini sekali dari PC (USB debugging aktif):", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        TextView cmd = Ui.tv(this, Perm.adbCommand(this), 12, Ui.TEXT);
        cmd.setTextIsSelectable(true);
        cmd.setBackground(Ui.rect(this, Ui.PANEL2, 10));
        cmd.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        setup.addView(cmd, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        setup.addView(Ui.ghost(this, "Salin perintah", v -> Guides.adb(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        setup.addView(Ui.tv(this, "Tanpa PC: buka Opsi Pengembang, lalu setel \"Skala animasi jendela / transisi / durasi animator\" ke 0,5x secara manual.",
                12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        setup.addView(Ui.ghost(this, "Buka Opsi Pengembang", v -> {
            if (!Perm.start(this, new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))) {
                Ui.toast(this, "Aktifkan Opsi Pengembang dulu (ketuk Nomor build 7 kali).");
            }
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(setup, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        Ui.reveal(card, setup);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setup.setVisibility(Perm.secure(this) ? View.GONE : View.VISIBLE);
        showCurrent();
    }

    private float readScale() {
        try {
            return Settings.Global.getFloat(getContentResolver(), KEYS[0], 1f);
        } catch (Exception e) {
            return 1f;
        }
    }

    private int nearest(float v) {
        int best = 0;
        float d = Float.MAX_VALUE;
        for (int i = 0; i < PRESET.length; i++) {
            float x = Math.abs(PRESET[i] - v);
            if (x < d) {
                d = x;
                best = i;
            }
        }
        return best;
    }

    private void showCurrent() {
        current.setText(String.format(Locale.US, "Skala sekarang: jendela %.2fx \u2022 transisi %.2fx \u2022 animator %.2fx",
                get(0), get(1), get(2)));
    }

    private float get(int i) {
        try {
            return Settings.Global.getFloat(getContentResolver(), KEYS[i], 1f);
        } catch (Exception e) {
            return 1f;
        }
    }

    private void apply(float v) {
        if (!Perm.secure(this)) {
            Ui.toast(this, "Beri izin ADB dulu (lihat kartu di bawah).");
            return;
        }
        try {
            for (String k : KEYS) Settings.Global.putFloat(getContentResolver(), k, v);
            Ui.toast(this, "Skala animasi diatur ke " + v + "x");
        } catch (Exception e) {
            Ui.toast(this, "Gagal: " + e.getMessage());
        }
        showCurrent();
    }
}
