package com.tein.booster;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import android.widget.ImageView;

/** Memuat ikon aplikasi di thread latar + cache memori kecil (agar scroll tetap mulus). */
public final class IconLoader {
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(6 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            return value.getByteCount();
        }
    };

    private IconLoader() {}

    public static void load(final Context c, final String pkg, final ImageView iv) {
        final Context app = c.getApplicationContext();
        iv.setTag(pkg);
        Bitmap hit = CACHE.get(pkg);
        if (hit != null) {
            iv.setImageBitmap(hit);
            return;
        }
        iv.setImageDrawable(null);
        Bg.run(() -> {
            final Bitmap bm = render(app, pkg);
            if (bm != null) CACHE.put(pkg, bm);
            Bg.ui(() -> {
                if (bm != null && pkg.equals(iv.getTag())) iv.setImageBitmap(bm);
            });
        });
    }

    private static Bitmap render(Context c, String pkg) {
        try {
            int px = Ui.dp(c, 44);
            Drawable d = c.getPackageManager().getApplicationIcon(pkg);
            Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            d.setBounds(0, 0, px, px);
            d.draw(cv);
            return b;
        } catch (Throwable t) {
            return null;
        }
    }
}
