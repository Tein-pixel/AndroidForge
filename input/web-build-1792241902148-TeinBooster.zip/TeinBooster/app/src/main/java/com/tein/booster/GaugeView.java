package com.tein.booster;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/** Gauge melingkar ala panel instrumen: cincin gradasi + 60 tick + angka di tengah. */
public class GaugeView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bigP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint smallP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Matrix gm = new Matrix();
    private SweepGradient shader;
    private int c1 = Ui.CYAN;
    private int c2 = Ui.BLUE;
    private float shown = 0f;
    private float spin = 0f;
    private boolean spinning = false;
    private String big = "";
    private String small = "";
    private ValueAnimator progAnim;
    private ValueAnimator spinAnim;
    private float cx, cy, tickIn, tickOut;

    public GaugeView(Context c) {
        super(c);
        init();
    }

    public GaugeView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(0xFF1C2646);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        tick.setStyle(Paint.Style.STROKE);
        tick.setStrokeCap(Paint.Cap.ROUND);
        bigP.setTextAlign(Paint.Align.CENTER);
        bigP.setColor(Ui.TEXT);
        bigP.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        smallP.setTextAlign(Paint.Align.CENTER);
        smallP.setColor(Ui.SUB);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float size = Math.min(w, h);
        cx = w / 2f;
        cy = h / 2f;
        tickOut = size / 2f - size * 0.01f;
        tickIn = tickOut - size * 0.05f;
        float stroke = size * 0.07f;
        float r = tickIn - size * 0.045f - stroke / 2f;
        oval.set(cx - r, cy - r, cx + r, cy + r);
        track.setStrokeWidth(stroke);
        arc.setStrokeWidth(stroke);
        glow.setStrokeWidth(stroke * 1.9f);
        tick.setStrokeWidth(Math.max(2f, size * 0.008f));
        bigP.setTextSize(size * 0.2f);
        smallP.setTextSize(size * 0.062f);
        rebuild();
    }

    private void rebuild() {
        if (getWidth() == 0) return;
        shader = new SweepGradient(cx, cy, new int[]{c1, c2, c1}, new float[]{0f, 0.5f, 1f});
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        if (shader == null) return;
        int n = 60;
        float lit = spinning ? 0f : shown * n;
        for (int i = 0; i < n; i++) {
            boolean major = i % 5 == 0;
            float inner = major ? tickIn : tickIn + (tickOut - tickIn) * 0.45f;
            tick.setColor(i < lit ? c1 : 0xFF26335A);
            cv.save();
            cv.rotate(i * (360f / n), cx, cy);
            cv.drawLine(cx, cy - tickOut, cx, cy - inner, tick);
            cv.restore();
        }
        cv.drawArc(oval, 0f, 360f, false, track);
        float start = spinning ? spin - 90f : -90f;
        float sweep = spinning ? 110f : 360f * shown;
        gm.setRotate(start, cx, cy);
        shader.setLocalMatrix(gm);
        arc.setShader(shader);
        glow.setShader(shader);
        glow.setAlpha(60);
        if (sweep > 0.5f) {
            cv.drawArc(oval, start, sweep, false, glow);
            cv.drawArc(oval, start, sweep, false, arc);
        }
        float bs = bigP.getTextSize();
        float avail = (oval.width()) * 0.86f;
        float tw = Math.max(1f, bigP.measureText(big));
        float scale = Math.min(1f, avail / tw);
        bigP.setTextSize(bs * scale);
        float base = cy + (small.isEmpty() ? bs * 0.34f * scale : bs * 0.14f);
        cv.drawText(big, cx, base, bigP);
        bigP.setTextSize(bs);
        if (!small.isEmpty()) {
            cv.drawText(small, cx, base + smallP.getTextSize() * 1.9f, smallP);
        }
    }

    public void setCenter(String bigText, String smallText) {
        big = bigText == null ? "" : bigText;
        small = smallText == null ? "" : smallText;
        invalidate();
    }

    public void setColors(int a, int b) {
        c1 = a;
        c2 = b;
        rebuild();
    }

    public void setProgress(float p, boolean animate) {
        float target = Math.max(0f, Math.min(1f, p));
        if (progAnim != null) progAnim.cancel();
        if (!animate) {
            shown = target;
            invalidate();
            return;
        }
        progAnim = ValueAnimator.ofFloat(shown, target);
        progAnim.setDuration(850);
        progAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        progAnim.addUpdateListener(a -> {
            shown = (Float) a.getAnimatedValue();
            invalidate();
        });
        progAnim.start();
    }

    public void setSpinning(boolean on) {
        if (on == spinning) return;
        spinning = on;
        if (on) {
            spinAnim = ValueAnimator.ofFloat(0f, 360f);
            spinAnim.setDuration(1100);
            spinAnim.setRepeatCount(ValueAnimator.INFINITE);
            spinAnim.setInterpolator(new LinearInterpolator());
            spinAnim.addUpdateListener(a -> {
                spin = (Float) a.getAnimatedValue();
                invalidate();
            });
            spinAnim.start();
        } else {
            if (spinAnim != null) spinAnim.cancel();
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (progAnim != null) progAnim.cancel();
        if (spinAnim != null) spinAnim.cancel();
    }
}
