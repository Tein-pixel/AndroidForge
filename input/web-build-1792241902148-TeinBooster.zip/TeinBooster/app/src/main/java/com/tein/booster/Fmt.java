package com.tein.booster;

import java.util.Locale;

public final class Fmt {
    private Fmt() {}

    public static String bytes(long b) {
        if (b <= 0) return "0 B";
        if (b < 1024) return b + " B";
        String[] u = {"KB", "MB", "GB", "TB"};
        double v = b;
        int i = -1;
        do {
            v /= 1024.0;
            i++;
        } while (v >= 1024.0 && i < u.length - 1);
        String f = v >= 100 ? "%.0f" : (v >= 10 ? "%.1f" : "%.2f");
        return String.format(Locale.US, f, v) + " " + u[i];
    }

    public static String pct(float f) {
        return Math.round(Math.max(0f, Math.min(1f, f)) * 100f) + "%";
    }

    public static String ago(long t) {
        if (t <= 0) return "belum pernah";
        long s = (System.currentTimeMillis() - t) / 1000;
        if (s < 60) return "baru saja";
        if (s < 3600) return (s / 60) + " menit lalu";
        if (s < 86400) return (s / 3600) + " jam lalu";
        return (s / 86400) + " hari lalu";
    }

    public static String duration(long ms) {
        long m = ms / 60000;
        if (m < 1) return "<1 mnt";
        if (m < 60) return m + " mnt";
        return (m / 60) + " j " + (m % 60) + " mnt";
    }

    public static String uptime(long ms) {
        long s = ms / 1000;
        long d = s / 86400;
        long h = (s % 86400) / 3600;
        long m = (s % 3600) / 60;
        return (d > 0 ? d + " hr " : "") + h + " j " + m + " mnt";
    }
}
