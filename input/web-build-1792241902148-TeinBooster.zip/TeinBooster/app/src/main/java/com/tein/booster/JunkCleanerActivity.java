package com.tein.booster;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Junk Cleaner: pindai & hapus file sampah sungguhan (tmp, log, thumbnail, unduhan gagal, folder kosong, dll). */
public class JunkCleanerActivity extends BaseActivity {
    private static final int IDLE = 0;
    private static final int SCANNING = 1;
    private static final int READY = 2;
    private static final int CLEANING = 3;
    private static final int DONE = 4;

    private LinearLayout col;
    private GaugeView gauge;
    private TextView statusTv;
    private TextView actionBtn;
    private TextView resultTv;
    private LinearLayout listBox;
    private LinearLayout permCard;

    private int state = IDLE;
    private volatile boolean cancel;
    private FileScan.Result res;
    private long sysEst;
    private final boolean[] sel = new boolean[FileScan.N_CAT + 1];

    @Override
    protected String title() { return "Junk Cleaner"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        col = scrollBody();
        LinearLayout hero = Ui.card(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 210), Ui.dp(this, 210));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);
        gauge.setCenter("0 B", "sampah");
        statusTv = Ui.tv(this, "Siap memindai penyimpanan.", 13, Ui.SUB);
        statusTv.setGravity(Gravity.CENTER);
        statusTv.setSingleLine(true);
        hero.addView(statusTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        actionBtn = Ui.button(this, "Pindai sampah", v -> onAction());
        hero.addView(actionBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));
        resultTv = Ui.tvb(this, "", 14, Ui.MINT);
        resultTv.setGravity(Gravity.CENTER);
        hero.addView(resultTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(hero);

        permCard = Ui.card(this);
        permCard.addView(Ui.tvb(this, "Butuh akses semua file", 15, Ui.EMBER));
        permCard.addView(Ui.tv(this, "Agar bisa memindai dan menghapus sampah di penyimpanan, beri izin \"Akses semua file\".", 13, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        permCard.addView(Ui.ghost(this, "Beri akses", v -> Perm.openAllFiles(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(permCard, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        listBox = Ui.col(this);
        col.addView(listBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        for (int i = 0; i < FileScan.N_CAT; i++) sel[i] = FileScan.CAT_DEFAULT[i];
        sel[FileScan.N_CAT] = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean ok = Perm.allFiles(this);
        permCard.setVisibility(ok ? View.GONE : View.VISIBLE);
        Intent in = getIntent();
        if (ok && state == IDLE && in != null && "com.tein.booster.action.JUNK".equals(in.getAction())) {
            in.setAction(null);
            startScan();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permCard.setVisibility(Perm.allFiles(this) ? View.GONE : View.VISIBLE);
    }

    private void onAction() {
        if (!Perm.allFiles(this)) {
            Perm.openAllFiles(this);
            return;
        }
        switch (state) {
            case SCANNING:
                cancel = true;
                break;
            case READY:
                confirmClean();
                break;
            case CLEANING:
                break;
            default:
                startScan();
                break;
        }
    }

    private static String shortPath(String p) {
        String root = Environment.getExternalStorageDirectory().getPath();
        if (p.startsWith(root)) p = p.substring(root.length());
        if (p.length() > 40) p = "..." + p.substring(p.length() - 37);
        return p;
    }

    private void startScan() {
        state = SCANNING;
        cancel = false;
        res = null;
        listBox.removeAllViews();
        resultTv.setText("");
        actionBtn.setText("Batalkan");
        gauge.setSpinning(true);
        gauge.setCenter("...", "memindai");
        final Context app = getApplicationContext();
        Bg.run(() -> {
            final FileScan.Result r = FileScan.scan(new FileScan.Progress() {
                @Override
                public void update(final int files, final String path) {
                    Bg.ui(() -> {
                        if (alive() && state == SCANNING) statusTv.setText(files + " file \u2022 " + shortPath(path));
                    });
                }

                @Override
                public boolean cancelled() { return cancel; }
            });
            final long est = Optimizer.systemCacheEstimate(app);
            Bg.ui(() -> {
                if (!alive()) return;
                res = r;
                sysEst = est;
                gauge.setSpinning(false);
                state = READY;
                renderResults();
            });
        });
    }

    private long selectedBytes() {
        long s = 0L;
        if (res == null) return 0L;
        for (int c = 0; c < FileScan.N_CAT; c++) if (sel[c]) s += res.junkSize(c);
        if (sel[FileScan.N_CAT]) s += sysEst;
        return s;
    }

    private void updateTotals() {
        long s = selectedBytes();
        gauge.setCenter(Fmt.bytes(s), "dipilih");
        actionBtn.setText(s > 0 ? "Bersihkan " + Fmt.bytes(s) : "Tidak ada yang dipilih");
    }

    private void renderResults() {
        listBox.removeAllViews();
        long all = 0L;
        for (int c = 0; c < FileScan.N_CAT; c++) all += res.junkSize(c);
        all += sysEst;
        gauge.setProgress(Math.min(1f, all / (1024f * 1024f * 1024f)), true);
        statusTv.setText(res.files + " file diperiksa" + (res.cancelled ? " (dibatalkan)" : ""));
        for (int c = 0; c < FileScan.N_CAT; c++) {
            int n = res.junkCount(c);
            if (n == 0) continue;
            listBox.addView(catRow(c, FileScan.CAT_NAME[c], n + " item \u2022 " + Fmt.bytes(res.junkSize(c)), true),
                    Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        }
        listBox.addView(catRow(FileScan.N_CAT, "Cache aplikasi (via sistem Android)",
                sysEst > 0 ? "\u2248 " + Fmt.bytes(sysEst) : "tidak ada yang bisa dipangkas", false),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        updateTotals();
        actionBtn.setAlpha(1f);
    }

    private View catRow(final int cat, String name, String sub, boolean viewable) {
        LinearLayout card = Ui.card(this);
        LinearLayout r = Ui.row(this);
        final CheckBox cb = new CheckBox(this);
        cb.setChecked(sel[cat]);
        cb.setOnCheckedChangeListener((b, c) -> {
            sel[cat] = c;
            updateTotals();
        });
        r.addView(cb);
        LinearLayout mid = Ui.col(this);
        mid.addView(Ui.tvb(this, name, 14, Ui.TEXT));
        mid.addView(Ui.tv(this, sub, 12, Ui.SUB));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        mp.setMargins(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        r.addView(mid, mp);
        if (viewable) {
            TextView see = Ui.tvb(this, "Lihat", 13, Ui.CYAN);
            see.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
            see.setOnClickListener(v -> showFiles(cat));
            r.addView(see);
        }
        card.addView(r);
        return card;
    }

    private void showFiles(int cat) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (FileScan.Item it : res.junk) {
            if (it.cat != cat) continue;
            sb.append(shortPath(it.file.getPath())).append("  (").append(Fmt.bytes(it.size)).append(")\n");
            if (++n >= 200) {
                sb.append("... dan lainnya");
                break;
            }
        }
        TextView tv = Ui.tv(this, sb.toString(), 12, Ui.TEXT);
        tv.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 4));
        tv.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this).setTitle(FileScan.CAT_NAME[cat]).setView(sv).setPositiveButton("Tutup", null).show();
    }

    private void confirmClean() {
        long s = selectedBytes();
        if (s <= 0L) {
            Ui.toast(this, "Pilih minimal satu kategori.");
            return;
        }
        Ui.confirm(this, "Bersihkan sekarang?", "File yang dipilih (" + Fmt.bytes(s) + ") akan dihapus permanen.", "Bersihkan", () -> startClean());
    }

    private void startClean() {
        state = CLEANING;
        actionBtn.setText("Membersihkan...");
        actionBtn.setAlpha(0.6f);
        gauge.setSpinning(true);
        final boolean[] s = sel.clone();
        final FileScan.Result r = res;
        final Context app = getApplicationContext();
        Bg.run(() -> {
            long freed = 0L;
            List<String> paths = new ArrayList<String>();
            for (FileScan.Item it : r.junk) {
                if (!s[it.cat]) continue;
                if (it.cat == FileScan.APPCACHE) {
                    freed += it.size;
                    Optimizer.deleteContents(it.file);
                } else if (it.dir) {
                    it.file.delete();
                } else {
                    freed += Optimizer.deleteTree(it.file);
                    paths.add(it.file.getPath());
                }
            }
            if (s[FileScan.N_CAT]) freed += Optimizer.trimSystemCaches(app);
            Optimizer.rescan(app, paths);
            final long total = freed;
            Bg.ui(() -> {
                if (!alive()) return;
                state = DONE;
                gauge.setSpinning(false);
                gauge.setProgress(1f, true);
                gauge.setCenter("\u2713", "selesai");
                listBox.removeAllViews();
                actionBtn.setText("Pindai lagi");
                actionBtn.setAlpha(1f);
                statusTv.setText("Pembersihan selesai");
                resultTv.setText("Dibebaskan: " + Fmt.bytes(total));
                state = IDLE;
            });
        });
    }
}
