package com.tein.booster;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/** Auto Boost terjadwal (RAM + cache sendiri) memakai JobScheduler. */
public class AutoBoostService extends JobService {
    private static final int JOB_ID = 4201;

    @Override
    public boolean onStartJob(final JobParameters params) {
        final Context app = getApplicationContext();
        Bg.run(() -> {
            try {
                Optimizer.fullBoost(app);
            } catch (Throwable ignored) {
            }
            jobFinished(params, false);
        });
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }

    public static void schedule(Context c, int hours) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        js.cancel(JOB_ID);
        if (hours <= 0) return;
        long interval = hours * 60L * 60L * 1000L;
        ComponentName cn = new ComponentName(c, AutoBoostService.class);
        try {
            JobInfo.Builder b = new JobInfo.Builder(JOB_ID, cn);
            b.setPeriodic(interval);
            b.setPersisted(true);
            js.schedule(b.build());
        } catch (Exception e) {
            JobInfo.Builder b2 = new JobInfo.Builder(JOB_ID, cn);
            b2.setPeriodic(interval);
            js.schedule(b2.build());
        }
    }
}
