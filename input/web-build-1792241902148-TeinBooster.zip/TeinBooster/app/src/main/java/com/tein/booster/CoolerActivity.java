package com.tein.booster;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Pendingin: pantau suhu baterai secara live, tutup aplikasi boros, ukur hasil sebelum/sesudah apa adanya. */
public class CoolerActivity extends BaseActivity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private GaugeView gauge;
    private TextView state;
    private TextView btn;
    private TextView result;
    private boolean working;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            update(false);
            h.postDelayed(this, 2500L);
        }
    };

    @Override
    protected String title() { return "Pendingin"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();
        LinearLayout hero = Ui.card(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 220), Ui.dp(this, 220));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);
        state = Ui.tvb(this, "", 14, Ui.TEXT);
        state.setGravity(Gravity.CENTER);
        hero.addView(state, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        btn = Ui.button(this, "Dinginkan sekarang", v -> cool());
        hero.addView(btn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));
        result = Ui.tv(this, "", 13, Ui.MINT);
        result.setGravity(Gravity.CENTER);
        hero.addView(result, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(hero);

        LinearLayout tips = Ui.card(this);
        tips.addView(Ui.tvb(this, "Yang benar-benar membantu", 15, Ui.TEXT));
        String[] t = {
                "Tutup aplikasi & game berat (tombol di atas melakukannya untuk proses latar).",
                "Lepas casing tebal dan jangan bermain sambil mengisi daya.",
                "Hindari sinar matahari langsung / dashboard mobil.",
                "Turunkan kecerahan layar dan matikan Bluetooth/GPS bila tidak dipakai.",
                "Suhu yang dipantau adalah suhu baterai (sensor resmi Android); turunnya butuh beberapa menit."
        };
        for (String s : t) {
            tips.addView(Ui.tv(this, "\u2022 " + s, 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        }
        col.addView(tips, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        Ui.reveal(hero, tips);
    }

    @Override
    protected void onResume() {
        super.onResume();
        update(true);
        h.postDelayed(loop, 2500L);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(loop);
    }

    private void update(boolean animate) {
        if (working) return;
        Sys.Batt b = Sys.battery(this);
        int c = Sys.tempColor(b.tempC);
        gauge.setColors(c, Ui.CYAN);
        gauge.setProgress(Math.max(0f, Math.min(1f, (b.tempC - 20f) / 35f)), animate);
        gauge.setCenter(String.format(Locale.US, "%.1f\u00B0", b.tempC), "suhu baterai");
        state.setText(Sys.tempLabel(b.tempC));
        state.setTextColor(c);
    }

    private void cool() {
        if (working) return;
        working = true;
        btn.setText("Mendinginkan...");
        btn.setAlpha(0.6f);
        result.setText("");
        gauge.setSpinning(true);
        final float before = Sys.battery(this).tempC;
        final Context app = getApplicationContext();
        Bg.run(() -> {
            final Optimizer.Result r = Optimizer.boostRam(app);
            Bg.ui(() -> {
                if (!alive()) return;
                gauge.setSpinning(false);
                result.setText(r.killed + " aplikasi latar ditutup. Mengukur ulang suhu...");
                Bg.uiDelayed(() -> {
                    if (!alive()) return;
                    float after = Sys.battery(app).tempC;
                    working = false;
                    btn.setText("Dinginkan sekarang");
                    btn.setAlpha(1f);
                    update(true);
                    result.setText(String.format(Locale.US, "Suhu: %.1f\u00B0C \u2192 %.1f\u00B0C. ", before, after)
                            + "Penurunan suhu perlu waktu; hindari beban berat beberapa menit.");
                }, 6000L);
            });
        });
    }
}
