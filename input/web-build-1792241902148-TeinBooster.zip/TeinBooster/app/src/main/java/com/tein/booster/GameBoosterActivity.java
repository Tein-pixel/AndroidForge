package com.tein.booster;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Game Booster: tutup aplikasi latar, aktifkan Jangan Ganggu, lalu luncurkan game. DND dipulihkan saat kembali. */
public class GameBoosterActivity extends BaseActivity {
    private LinearLayout listBox;
    private LinearLayout dndCard;
    private TextView restoreBtn;

    @Override
    protected String title() { return "Game Booster"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();

        LinearLayout opt = Ui.card(this);
        opt.addView(Ui.tvb(this, "Saat tekan \"Boost & Main\"", 15, Ui.TEXT));
        opt.addView(switchRow("Tutup aplikasi latar dulu", Prefs.GAME_KILL, true), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        opt.addView(Ui.divider(this));
        opt.addView(switchRow("Mode Jangan Ganggu (hanya prioritas)", Prefs.GAME_DND, true));
        dndCard = Ui.col(this);
        dndCard.addView(Ui.tv(this, "Butuh izin Jangan Ganggu agar notifikasi bisa dibisukan.", 12, Ui.EMBER),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        dndCard.addView(Ui.ghost(this, "Beri izin", v -> Perm.openDnd(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        opt.addView(dndCard);
        opt.addView(Ui.tv(this, "Catatan: tanpa root, CPU/GPU tidak bisa diubah. Booster ini membebaskan RAM dan membungkam gangguan.", 12, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(opt);

        col.addView(Ui.sectionTitle(this, "Game kamu"));
        listBox = Ui.col(this);
        col.addView(listBox);

        col.addView(Ui.ghost(this, "Tambah / ubah game", v -> {
            Intent i = new Intent(this, AppPickerActivity.class);
            i.putExtra(AppPickerActivity.EXTRA_MODE, "games");
            startActivity(i);
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        restoreBtn = Ui.ghost(this, "Selesai bermain (pulihkan notifikasi)", v -> {
            restoreDnd(this);
            Ui.toast(this, "Notifikasi dipulihkan");
            refreshRestore();
        });
        col.addView(restoreBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
    }

    private View switchRow(String label, final String key, boolean def) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        r.addView(Ui.tv(this, label, 14, Ui.TEXT), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(Prefs.getBool(this, key, def));
        sw.setOnCheckedChangeListener((CompoundButton b, boolean c) -> Prefs.putBool(this, key, c));
        r.addView(sw);
        return r;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Prefs.getBool(this, Prefs.DND_ACTIVE, false)) {
            restoreDnd(this);
            Ui.toast(this, "Mode Jangan Ganggu dipulihkan");
        }
        dndCard.setVisibility(Perm.dnd(this) ? View.GONE : View.VISIBLE);
        refreshRestore();
        loadGames();
    }

    private void refreshRestore() {
        restoreBtn.setVisibility(Prefs.getBool(this, Prefs.DND_ACTIVE, false) ? View.VISIBLE : View.GONE);
    }

    public static void enableDnd(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || !nm.isNotificationPolicyAccessGranted()) return;
            if (!Prefs.getBool(c, Prefs.DND_ACTIVE, false)) {
                Prefs.putInt(c, Prefs.DND_PREV, nm.getCurrentInterruptionFilter());
            }
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            Prefs.putBool(c, Prefs.DND_ACTIVE, true);
        } catch (Exception ignored) {
        }
    }

    public static void restoreDnd(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.isNotificationPolicyAccessGranted()) {
                int prev = Prefs.getInt(c, Prefs.DND_PREV, NotificationManager.INTERRUPTION_FILTER_ALL);
                nm.setInterruptionFilter(prev);
            }
        } catch (Exception ignored) {
        }
        Prefs.putBool(c, Prefs.DND_ACTIVE, false);
    }

    private void loadGames() {
        final Context app = getApplicationContext();
        final Set<String> pkgs = Prefs.getSet(app, Prefs.GAMES);
        Bg.run(() -> {
            final List<Apps.Item> games = new ArrayList<Apps.Item>();
            for (Apps.Item it : Apps.loadAll(app)) {
                if (pkgs.contains(it.pkg) && it.launchable) games.add(it);
            }
            Bg.ui(() -> {
                if (!alive()) return;
                listBox.removeAllViews();
                if (games.isEmpty()) {
                    LinearLayout empty = Ui.card(this);
                    empty.addView(Ui.tv(this, "Belum ada game. Tambahkan dulu agar bisa di-boost dan diluncurkan dari sini.", 13, Ui.SUB));
                    listBox.addView(empty);
                    return;
                }
                for (final Apps.Item it : games) {
                    LinearLayout card = Ui.card(this);
                    LinearLayout r = Ui.row(this);
                    ImageView iv = new ImageView(this);
                    r.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
                    IconLoader.load(this, it.pkg, iv);
                    TextView nm = Ui.tvb(this, it.label, 15, Ui.TEXT);
                    nm.setSingleLine(true);
                    LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
                    np.setMargins(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
                    r.addView(nm, np);
                    card.addView(r);
                    card.addView(Ui.button2(this, "Boost & Main", Ui.PINK, Ui.VIOLET, v -> play(it.pkg, it.label)),
                            Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
                    listBox.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
                }
            });
        });
    }

    private void play(final String pkg, final String label) {
        final Context app = getApplicationContext();
        final boolean kill = Prefs.getBool(app, Prefs.GAME_KILL, true);
        final boolean dnd = Prefs.getBool(app, Prefs.GAME_DND, true) && Perm.dnd(app);
        Ui.toast(this, "Memboost " + label + "...");
        Bg.run(() -> {
            if (kill) Optimizer.boostRam(app);
            Bg.ui(() -> {
                if (dnd) enableDnd(app);
                Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
                if (li != null) {
                    startActivity(li);
                } else {
                    Ui.toast(this, "Tidak bisa membuka " + label);
                }
            });
        });
    }
}
