package com.tein.booster;

import android.app.ActivityManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.StatFs;

import java.util.HashMap;
import java.util.Map;

/** Pembacaan kondisi sistem secara nyata: RAM, penyimpanan, baterai, penggunaan aplikasi. */
public final class Sys {
    private Sys() {}

    public static final class Batt {
        public int level;
        public float tempC;
        public int voltageMv;
        public int status;
        public int health;
        public int plugged;
        public String tech = "-";
        public boolean charging;
    }

    private static ActivityManager.MemoryInfo mem(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return mi;
    }

    public static long ramTotal(Context c) { return mem(c).totalMem; }

    public static long ramAvail(Context c) { return mem(c).availMem; }

    public static float ramUsed(Context c) {
        ActivityManager.MemoryInfo m = mem(c);
        return m.totalMem > 0 ? 1f - (float) m.availMem / (float) m.totalMem : 0f;
    }

    public static long storageTotal() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getTotalBytes();
        } catch (Exception e) {
            return 0L;
        }
    }

    public static long storageFree() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes();
        } catch (Exception e) {
            return 0L;
        }
    }

    public static float storageUsed() {
        long t = storageTotal();
        return t > 0 ? 1f - (float) storageFree() / (float) t : 0f;
    }

    public static Batt battery(Context c) {
        Batt b = new Batt();
        try {
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return b;
            int lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            b.level = scale > 0 ? Math.round(lvl * 100f / scale) : 0;
            b.tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            b.voltageMv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
            b.status = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0);
            b.health = i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
            b.plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            String t = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
            b.tech = t == null ? "-" : t;
            b.charging = b.status == BatteryManager.BATTERY_STATUS_CHARGING
                    || b.status == BatteryManager.BATTERY_STATUS_FULL;
        } catch (Exception ignored) {
        }
        return b;
    }

    public static String battStatus(int s) {
        if (s == BatteryManager.BATTERY_STATUS_CHARGING) return "Mengisi daya";
        if (s == BatteryManager.BATTERY_STATUS_FULL) return "Penuh";
        if (s == BatteryManager.BATTERY_STATUS_DISCHARGING) return "Dipakai";
        if (s == BatteryManager.BATTERY_STATUS_NOT_CHARGING) return "Tidak mengisi";
        return "Tidak diketahui";
    }

    public static String battHealth(int h) {
        if (h == BatteryManager.BATTERY_HEALTH_GOOD) return "Baik";
        if (h == BatteryManager.BATTERY_HEALTH_OVERHEAT) return "Terlalu panas";
        if (h == BatteryManager.BATTERY_HEALTH_DEAD) return "Rusak";
        if (h == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE) return "Tegangan berlebih";
        if (h == BatteryManager.BATTERY_HEALTH_COLD) return "Terlalu dingin";
        if (h == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE) return "Gangguan";
        return "Tidak diketahui";
    }

    public static int tempColor(float t) {
        if (t < 35f) return Ui.MINT;
        if (t < 40f) return Ui.CYAN;
        if (t < 45f) return Ui.EMBER;
        return Ui.CORAL;
    }

    public static String tempLabel(float t) {
        if (t < 35f) return "Dingin";
        if (t < 40f) return "Normal";
        if (t < 45f) return "Hangat";
        return "Panas";
    }

    /** Skor 10..100 dari RAM, penyimpanan, dan suhu (nilai nyata perangkat). */
    public static int score(Context c) {
        float ram = ramUsed(c);
        float st = storageUsed();
        float temp = battery(c).tempC;
        float p = 0f;
        if (ram > 0.6f) p += Math.min(35f, (ram - 0.6f) / 0.4f * 35f);
        if (st > 0.7f) p += Math.min(30f, (st - 0.7f) / 0.3f * 30f);
        if (temp > 38f) p += Math.min(20f, (temp - 38f) * 2.5f);
        return Math.max(10, Math.round(100f - p));
    }

    public static String scoreLabel(int s) {
        if (s >= 85) return "Prima";
        if (s >= 65) return "Baik";
        if (s >= 45) return "Cukup";
        return "Perlu dioptimalkan";
    }

    /** Statistik pemakaian per paket dalam jendela waktu (butuh Akses Penggunaan). */
    public static Map<String, UsageStats> usageMap(Context c, long windowMs) {
        Map<String, UsageStats> out = new HashMap<String, UsageStats>();
        if (!Perm.usage(c)) return out;
        try {
            UsageStatsManager um = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            Map<String, UsageStats> m = um.queryAndAggregateUsageStats(now - windowMs, now);
            if (m != null) out.putAll(m);
        } catch (Exception ignored) {
        }
        return out;
    }
}
