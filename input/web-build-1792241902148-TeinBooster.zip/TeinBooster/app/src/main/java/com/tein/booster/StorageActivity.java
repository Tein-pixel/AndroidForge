package com.tein.booster;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Analisis Penyimpanan: ringkasan kategori, file besar, dan duplikat sungguhan (hash MD5). */
public class StorageActivity extends BaseActivity {
    private LinearLayout col;
    private GaugeView gauge;
    private TextView statusTv;
    private TextView scanBtn;
    private LinearLayout permCard;
    private LinearLayout catBox;
    private LinearLayout bigBox;
    private LinearLayout dupBox;
    private BarView stack;
    private FileScan.Result res;
    private volatile boolean cancel;
    private boolean scanning;
    private final Set<File> bigSel = new HashSet<File>();
    private final Set<File> dupSel = new HashSet<File>();

    @Override
    protected String title() { return "Analisis Penyimpanan"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        col = scrollBody();
        LinearLayout hero = Ui.card(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 210), Ui.dp(this, 210));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);
        statusTv = Ui.tv(this, "", 13, Ui.SUB);
        statusTv.setGravity(Gravity.CENTER);
        statusTv.setSingleLine(true);
        hero.addView(statusTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        scanBtn = Ui.button(this, "Pindai penyimpanan", v -> onScan());
        hero.addView(scanBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));
        col.addView(hero);

        permCard = Ui.card(this);
        permCard.addView(Ui.tvb(this, "Butuh akses semua file", 15, Ui.EMBER));
        permCard.addView(Ui.tv(this, "Beri izin \"Akses semua file\" agar bisa memindai penyimpanan.", 13, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        permCard.addView(Ui.ghost(this, "Beri akses", v -> Perm.openAllFiles(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(permCard, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        catBox = Ui.card(this);
        stack = new BarView(this);
        catBox.addView(stack, Ui.lp(this, Ui.MATCH, Ui.dp(this, 12), 0, 0, 0, 12));
        catBox.setVisibility(View.GONE);
        col.addView(catBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        bigBox = Ui.col(this);
        col.addView(bigBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        dupBox = Ui.col(this);
        col.addView(dupBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        showDisk();
    }

    @Override
    protected void onResume() {
        super.onResume();
        permCard.setVisibility(Perm.allFiles(this) ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permCard.setVisibility(Perm.allFiles(this) ? View.GONE : View.VISIBLE);
    }

    private void showDisk() {
        long t = Sys.storageTotal();
        long f = Sys.storageFree();
        gauge.setColors(Ui.BLUE, Ui.VIOLET);
        gauge.setProgress(Sys.storageUsed(), true);
        gauge.setCenter(Fmt.bytes(t - f), "terpakai dari " + Fmt.bytes(t));
        statusTv.setText(Fmt.bytes(f) + " masih kosong");
    }

    private static String shortPath(String p) {
        String root = Environment.getExternalStorageDirectory().getPath();
        if (p.startsWith(root)) p = p.substring(root.length());
        if (p.length() > 44) p = "..." + p.substring(p.length() - 41);
        return p;
    }

    private void onScan() {
        if (!Perm.allFiles(this)) {
            Perm.openAllFiles(this);
            return;
        }
        if (scanning) {
            cancel = true;
            return;
        }
        scanning = true;
        cancel = false;
        scanBtn.setText("Batalkan");
        gauge.setSpinning(true);
        gauge.setCenter("...", "memindai");
        bigBox.removeAllViews();
        dupBox.removeAllViews();
        catBox.setVisibility(View.GONE);
        Bg.run(() -> {
            final FileScan.Result r = FileScan.scan(new FileScan.Progress() {
                @Override
                public void update(final int files, final String path) {
                    Bg.ui(() -> {
                        if (alive() && scanning) statusTv.setText(files + " file \u2022 " + shortPath(path));
                    });
                }

                @Override
                public boolean cancelled() { return cancel; }
            });
            Bg.ui(() -> {
                if (!alive()) return;
                scanning = false;
                res = r;
                gauge.setSpinning(false);
                scanBtn.setText("Pindai ulang");
                showDisk();
                renderCats();
                renderBig();
                renderDupIntro();
            });
        });
    }

    private void legend(String name, long bytes, int color) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        TextView dot = Ui.tv(this, "\u25CF", 14, color);
        r.addView(dot);
        TextView n = Ui.tv(this, name, 13, Ui.TEXT);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        np.setMargins(Ui.dp(this, 8), 0, 0, 0);
        r.addView(n, np);
        r.addView(Ui.tvb(this, Fmt.bytes(bytes), 13, Ui.TEXT));
        catBox.addView(r);
    }

    private void renderCats() {
        while (catBox.getChildCount() > 1) catBox.removeViewAt(1);
        catBox.setVisibility(View.VISIBLE);
        long total = Math.max(1L, res.total);
        long[] v = {res.images, res.videos, res.audio, res.docs, res.archives, res.apks, res.other};
        String[] names = {"Foto", "Video", "Audio", "Dokumen", "Arsip", "APK", "Lainnya"};
        int[] colors = {Ui.CYAN, Ui.PINK, Ui.VIOLET, Ui.BLUE, Ui.EMBER, Ui.MINT, 0xFF5C6A94};
        float[] fr = new float[v.length];
        for (int i = 0; i < v.length; i++) fr[i] = (float) v[i] / (float) total;
        stack.setSegments(fr, colors);
        for (int i = 0; i < v.length; i++) legend(names[i], v[i], colors[i]);
        catBox.addView(Ui.tv(this, "Total file dipindai: " + Fmt.bytes(res.total) + " (" + res.files + " file)", 12, Ui.SUB),
                Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 8, 0, 0));
    }

    private View fileRow(final File f, long size, boolean checked, final Set<File> target, final Runnable onChange) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        CheckBox cb = new CheckBox(this);
        cb.setChecked(checked);
        cb.setOnCheckedChangeListener((b, c) -> {
            if (c) target.add(f);
            else target.remove(f);
            onChange.run();
        });
        r.addView(cb);
        LinearLayout mid = Ui.col(this);
        TextView n = Ui.tvb(this, f.getName(), 13, Ui.TEXT);
        n.setSingleLine(true);
        TextView p = Ui.tv(this, shortPath(f.getParent() == null ? "" : f.getParent()), 11, Ui.SUB);
        p.setSingleLine(true);
        mid.addView(n);
        mid.addView(p);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        mp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 8), 0);
        r.addView(mid, mp);
        r.addView(Ui.tvb(this, Fmt.bytes(size), 12, Ui.CYAN));
        return r;
    }

    // ------------------------------------------------------------ file besar
    private TextView bigDelBtn;

    private void renderBig() {
        bigBox.removeAllViews();
        bigSel.clear();
        bigBox.addView(Ui.sectionTitle(this, "File besar (\u2265 30 MB)"));
        LinearLayout card = Ui.card(this);
        if (res.large.isEmpty()) {
            card.addView(Ui.tv(this, "Tidak ada file besar.", 13, Ui.SUB));
        } else {
            for (FileScan.Item it : res.large) {
                card.addView(fileRow(it.file, it.size, false, bigSel, () -> updateBigBtn()));
            }
            bigDelBtn = Ui.ghost(this, "Hapus terpilih", v -> deleteBig());
            card.addView(bigDelBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
            updateBigBtn();
        }
        bigBox.addView(card);
    }

    private long sizeOfSel(Set<File> s) {
        long t = 0L;
        for (File f : s) t += f.length();
        return t;
    }

    private void updateBigBtn() {
        if (bigDelBtn != null) bigDelBtn.setText(bigSel.isEmpty() ? "Pilih file untuk dihapus" : "Hapus " + bigSel.size() + " file (" + Fmt.bytes(sizeOfSel(bigSel)) + ")");
    }

    private void deleteBig() {
        if (bigSel.isEmpty()) return;
        final Set<File> copy = new HashSet<File>(bigSel);
        Ui.confirm(this, "Hapus file terpilih?", copy.size() + " file akan dihapus permanen.", "Hapus", () -> {
            final Context app = getApplicationContext();
            Bg.run(() -> {
                long freed = 0L;
                List<String> paths = new ArrayList<String>();
                for (File f : copy) {
                    freed += Optimizer.deleteTree(f);
                    paths.add(f.getPath());
                }
                Optimizer.rescan(app, paths);
                final long total = freed;
                Bg.ui(() -> {
                    if (!alive()) return;
                    Ui.toast(this, "Dibebaskan " + Fmt.bytes(total));
                    List<FileScan.Item> keep = new ArrayList<FileScan.Item>();
                    for (FileScan.Item it : res.large) if (it.file.exists()) keep.add(it);
                    res.large.clear();
                    res.large.addAll(keep);
                    renderBig();
                    showDisk();
                });
            });
        });
    }

    // ------------------------------------------------------------ duplikat
    private TextView dupBtn;
    private TextView dupDelBtn;

    private void renderDupIntro() {
        dupBox.removeAllViews();
        dupSel.clear();
        dupBox.addView(Ui.sectionTitle(this, "File duplikat"));
        LinearLayout card = Ui.card(this);
        card.addView(Ui.tv(this, "Mencari file yang isinya identik (ukuran sama + hash MD5). Bisa memakan waktu bila banyak file.", 13, Ui.SUB));
        dupBtn = Ui.ghost(this, "Cari duplikat", v -> findDups());
        card.addView(dupBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        dupBox.addView(card);
    }

    private void findDups() {
        if (scanning) {
            cancel = true;
            return;
        }
        scanning = true;
        cancel = false;
        dupBtn.setText("Batalkan");
        gauge.setSpinning(true);
        gauge.setCenter("...", "mencari duplikat");
        Bg.run(() -> {
            FileScan.findDuplicates(res, new FileScan.Progress() {
                @Override
                public void update(final int files, final String path) {
                    Bg.ui(() -> {
                        if (alive() && scanning) statusTv.setText(path);
                    });
                }

                @Override
                public boolean cancelled() { return cancel; }
            });
            Bg.ui(() -> {
                if (!alive()) return;
                scanning = false;
                gauge.setSpinning(false);
                showDisk();
                renderDups();
            });
        });
    }

    private void renderDups() {
        dupBox.removeAllViews();
        dupSel.clear();
        dupBox.addView(Ui.sectionTitle(this, "File duplikat"));
        LinearLayout card = Ui.card(this);
        if (res.dups.isEmpty()) {
            card.addView(Ui.tv(this, "Tidak ada duplikat ditemukan.", 13, Ui.SUB));
            dupBox.addView(card);
            return;
        }
        long wasted = 0L;
        for (FileScan.Group g : res.dups) wasted += g.wasted();
        card.addView(Ui.tvb(this, res.dups.size() + " grup \u2022 boros " + Fmt.bytes(wasted), 14, Ui.EMBER));
        card.addView(Ui.tv(this, "File tertua di tiap grup dibiarkan tidak dicentang (dianggap asli).", 12, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 6));
        int shown = 0;
        for (FileScan.Group g : res.dups) {
            if (shown++ >= 40) break;
            for (int i = 0; i < g.files.size(); i++) {
                File f = g.files.get(i);
                boolean pre = i > 0;
                if (pre) dupSel.add(f);
                card.addView(fileRow(f, g.size, pre, dupSel, () -> updateDupBtn()));
            }
            card.addView(Ui.divider(this));
        }
        dupDelBtn = Ui.ghost(this, "Hapus duplikat terpilih", v -> deleteDups());
        card.addView(dupDelBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        updateDupBtn();
        dupBox.addView(card);
    }

    private void updateDupBtn() {
        if (dupDelBtn != null) dupDelBtn.setText(dupSel.isEmpty() ? "Pilih duplikat untuk dihapus" : "Hapus " + dupSel.size() + " duplikat (" + Fmt.bytes(sizeOfSel(dupSel)) + ")");
    }

    private void deleteDups() {
        if (dupSel.isEmpty()) return;
        final Set<File> copy = new HashSet<File>(dupSel);
        Ui.confirm(this, "Hapus duplikat?", copy.size() + " file akan dihapus permanen. Pastikan satu salinan asli tetap ada.", "Hapus", () -> {
            final Context app = getApplicationContext();
            Bg.run(() -> {
                long freed = 0L;
                List<String> paths = new ArrayList<String>();
                for (File f : copy) {
                    freed += Optimizer.deleteTree(f);
                    paths.add(f.getPath());
                }
                Optimizer.rescan(app, paths);
                final long total = freed;
                Bg.ui(() -> {
                    if (!alive()) return;
                    Ui.toast(this, "Dibebaskan " + Fmt.bytes(total));
                    List<FileScan.Group> keep = new ArrayList<FileScan.Group>();
                    for (FileScan.Group g : res.dups) {
                        List<File> alive = new ArrayList<File>();
                        for (File f : g.files) if (f.exists()) alive.add(f);
                        if (alive.size() > 1) {
                            g.files = alive;
                            keep.add(g);
                        }
                    }
                    res.dups.clear();
                    res.dups.addAll(keep);
                    renderDups();
                    showDisk();
                });
            });
        });
    }
}
