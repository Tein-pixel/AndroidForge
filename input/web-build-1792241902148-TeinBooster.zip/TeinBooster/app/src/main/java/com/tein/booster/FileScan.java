package com.tein.booster;

import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Pemindai penyimpanan bersama: sampah, file besar, kategori, duplikat. */
public final class FileScan {
    private FileScan() {}

    public static final int TMP = 0;
    public static final int LOG = 1;
    public static final int THUMB = 2;
    public static final int PARTIAL = 3;
    public static final int APK = 4;
    public static final int TRASH = 5;
    public static final int EMPTY = 6;
    public static final int APPCACHE = 7;
    public static final int N_CAT = 8;

    public static final String[] CAT_NAME = {
            "Berkas sementara (.tmp, .temp)",
            "Log & laporan crash (.log)",
            "Cache thumbnail galeri",
            "Unduhan tidak selesai",
            "Berkas APK sisa",
            "Tempat sampah (file terhapus)",
            "Folder kosong",
            "Cache aplikasi (penyimpanan eksternal)"
    };

    /** Default tercentang? APK & tempat sampah tidak, karena bisa jadi masih dibutuhkan. */
    public static final boolean[] CAT_DEFAULT = {true, true, true, true, false, false, true, true};

    private static final long LARGE_MIN = 30L * 1024 * 1024;
    private static final long DUP_MIN = 200L * 1024;
    private static final long DUP_MAX = 1536L * 1024 * 1024;

    public static final class Item {
        public File file;
        public long size;
        public int cat;
        public boolean dir;
    }

    public static final class Group {
        public long size;
        public List<File> files = new ArrayList<File>();

        public long wasted() { return size * (files.size() - 1); }
    }

    public static final class Result {
        public long images, videos, audio, docs, archives, apks, other;
        public int files;
        public long total;
        public boolean cancelled;
        public final List<Item> junk = new ArrayList<Item>();
        public final List<Item> large = new ArrayList<Item>();
        public final Map<Long, List<File>> bySize = new HashMap<Long, List<File>>();
        public final List<Group> dups = new ArrayList<Group>();

        public long junkSize(int cat) {
            long s = 0L;
            for (Item i : junk) if (i.cat == cat) s += i.size;
            return s;
        }

        public int junkCount(int cat) {
            int n = 0;
            for (Item i : junk) if (i.cat == cat) n++;
            return n;
        }
    }

    public interface Progress {
        void update(int files, String path);

        boolean cancelled();
    }

    public static Result scan(Progress p) {
        Result r = new Result();
        File root = Environment.getExternalStorageDirectory();
        walk(root, 0, r, p);
        if (Build.VERSION.SDK_INT <= 29) legacyAppCaches(root, r);
        Collections.sort(r.large, (a, b) -> Long.compare(b.size, a.size));
        while (r.large.size() > 60) r.large.remove(r.large.size() - 1);
        r.cancelled = p.cancelled();
        return r;
    }

    private static void walk(File dir, int depth, Result r, Progress p) {
        if (p.cancelled() || depth > 25) return;
        File[] list = dir.listFiles();
        if (list == null) return;
        boolean hadEntries = list.length > 0;
        for (File f : list) {
            if (p.cancelled()) return;
            String n = f.getName();
            if (f.isDirectory()) {
                if (depth == 0 && n.equals("Android")) continue;
                walk(f, depth + 1, r, p);
            } else {
                r.files++;
                if ((r.files & 255) == 0) p.update(r.files, dir.getPath());
                handleFile(f, n, dir, r);
            }
        }
        if (depth >= 2 && !hadEntries) {
            Item it = new Item();
            it.file = dir;
            it.size = 0L;
            it.cat = EMPTY;
            it.dir = true;
            r.junk.add(it);
        }
    }

    private static int typeOf(String ext) {
        switch (ext) {
            case "jpg": case "jpeg": case "png": case "gif": case "webp": case "heic": case "heif": case "bmp": case "dng":
                return 1;
            case "mp4": case "mkv": case "avi": case "mov": case "3gp": case "webm": case "flv": case "wmv": case "m4v":
                return 2;
            case "mp3": case "m4a": case "wav": case "flac": case "ogg": case "aac": case "opus": case "amr": case "wma":
                return 3;
            case "pdf": case "doc": case "docx": case "xls": case "xlsx": case "ppt": case "pptx": case "txt": case "csv":
            case "epub": case "rtf": case "odt":
                return 4;
            case "zip": case "rar": case "7z": case "tar": case "gz": case "bz2": case "xz":
                return 5;
            case "apk": case "xapk": case "apks": case "apkm":
                return 6;
            default:
                return 0;
        }
    }

    private static int junkCat(String lower, String ext, String parent) {
        if (lower.startsWith(".trashed-")) return TRASH;
        if (parent.equals(".thumbnails") || lower.startsWith(".thumbdata")) return THUMB;
        switch (ext) {
            case "tmp": case "temp": case "dmp": case "chk":
                return TMP;
            case "log":
                return LOG;
            case "crdownload": case "part": case "partial": case "download":
                return PARTIAL;
            case "apk":
                return APK;
            default:
                return -1;
        }
    }

    private static void handleFile(File f, String name, File parent, Result r) {
        long len = f.length();
        r.total += len;
        String lower = name.toLowerCase(Locale.ROOT);
        String ext = "";
        int dot = lower.lastIndexOf('.');
        if (dot >= 0 && dot < lower.length() - 1) ext = lower.substring(dot + 1);
        int type = typeOf(ext);
        switch (type) {
            case 1: r.images += len; break;
            case 2: r.videos += len; break;
            case 3: r.audio += len; break;
            case 4: r.docs += len; break;
            case 5: r.archives += len; break;
            case 6: r.apks += len; break;
            default: r.other += len; break;
        }
        int cat = junkCat(lower, ext, parent.getName().toLowerCase(Locale.ROOT));
        if (cat >= 0) {
            Item it = new Item();
            it.file = f;
            it.size = len;
            it.cat = cat;
            r.junk.add(it);
        }
        if (len >= LARGE_MIN) {
            Item it = new Item();
            it.file = f;
            it.size = len;
            it.cat = -1;
            r.large.add(it);
            if (r.large.size() > 400) {
                Collections.sort(r.large, (a, b) -> Long.compare(b.size, a.size));
                while (r.large.size() > 80) r.large.remove(r.large.size() - 1);
            }
        }
        if (len >= DUP_MIN && len <= DUP_MAX && type != 0 && cat < 0) {
            List<File> l = r.bySize.get(len);
            if (l == null) {
                l = new ArrayList<File>();
                r.bySize.put(len, l);
            }
            l.add(f);
        }
    }

    private static void legacyAppCaches(File root, Result r) {
        File[] pkgs = new File(root, "Android/data").listFiles();
        if (pkgs == null) return;
        for (File pk : pkgs) {
            File cache = new File(pk, "cache");
            if (cache.isDirectory()) {
                long s = Optimizer.dirSize(cache);
                if (s > 0L) {
                    Item it = new Item();
                    it.file = cache;
                    it.size = s;
                    it.cat = APPCACHE;
                    it.dir = true;
                    r.junk.add(it);
                }
            }
        }
    }

    /** Cari duplikat sungguhan (ukuran sama + hash MD5 sama). Bisa lama; dukung pembatalan. */
    public static void findDuplicates(Result r, Progress p) {
        r.dups.clear();
        List<List<File>> cands = new ArrayList<List<File>>();
        for (Map.Entry<Long, List<File>> e : r.bySize.entrySet()) {
            if (e.getValue().size() > 1) cands.add(e.getValue());
        }
        int done = 0;
        for (List<File> same : cands) {
            if (p.cancelled()) break;
            Map<String, Group> byHash = new HashMap<String, Group>();
            for (File f : same) {
                if (p.cancelled()) break;
                String h = md5(f);
                if (h == null) continue;
                Group g = byHash.get(h);
                if (g == null) {
                    g = new Group();
                    g.size = f.length();
                    byHash.put(h, g);
                }
                g.files.add(f);
            }
            for (Group g : byHash.values()) {
                if (g.files.size() > 1) {
                    Collections.sort(g.files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
                    r.dups.add(g);
                }
            }
            done++;
            p.update(done, "Memeriksa duplikat (" + done + "/" + cands.size() + ")");
        }
        Collections.sort(r.dups, (a, b) -> Long.compare(b.wasted(), a.wasted()));
    }

    private static String md5(File f) {
        FileInputStream in = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            in = new FileInputStream(f);
            byte[] buf = new byte[128 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format(Locale.US, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                }
            }
        }
    }
}
