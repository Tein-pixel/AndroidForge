package com.tein.booster;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.text.TextUtils;

/** Cek & minta semua izin yang dibutuhkan booster. */
public final class Perm {
    public static final int REQUIRED_TOTAL = 6;

    private Perm() {}

    public static boolean accessibilityOn(Context c) {
        if (CleanerAccessibilityService.instance != null) return true;
        try {
            String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (s == null) return false;
            ComponentName me = new ComponentName(c, CleanerAccessibilityService.class);
            TextUtils.SimpleStringSplitter sp = new TextUtils.SimpleStringSplitter(':');
            sp.setString(s);
            while (sp.hasNext()) {
                ComponentName cn = ComponentName.unflattenFromString(sp.next());
                if (me.equals(cn)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    public static boolean usage(Context c) {
        try {
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode;
            if (Build.VERSION.SDK_INT >= 29) {
                mode = ops.unsafeCheckOpNoThrow("android:get_usage_stats", Process.myUid(), c.getPackageName());
            } else {
                mode = ops.checkOpNoThrow("android:get_usage_stats", Process.myUid(), c.getPackageName());
            }
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean allFiles(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean writeSettings(Context c) {
        return Settings.System.canWrite(c);
    }

    public static boolean dnd(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.isNotificationPolicyAccessGranted();
    }

    public static boolean batteryWhitelist(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    public static boolean secure(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED;
    }

    public static int requiredMissing(Context c) {
        int m = 0;
        if (!accessibilityOn(c)) m++;
        if (!usage(c)) m++;
        if (!allFiles(c)) m++;
        if (!writeSettings(c)) m++;
        if (!dnd(c)) m++;
        if (!batteryWhitelist(c)) m++;
        return m;
    }

    public static String adbCommand(Context c) {
        return "adb shell pm grant " + c.getPackageName() + " android.permission.WRITE_SECURE_SETTINGS";
    }

    public static boolean start(Context c, Intent i) {
        try {
            if (!(c instanceof Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void openAccessibility(Activity a) {
        if (!start(a, new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))) openAppInfo(a);
    }

    public static void openUsage(Activity a) {
        Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        if (Build.VERSION.SDK_INT >= 29) {
            Intent direct = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + a.getPackageName()));
            if (start(a, direct)) return;
        }
        if (!start(a, i)) openAppInfo(a);
    }

    public static void openAllFiles(Activity a) {
        if (Build.VERSION.SDK_INT >= 30) {
            Intent direct = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + a.getPackageName()));
            if (start(a, direct)) return;
            if (start(a, new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))) return;
            openAppInfo(a);
        } else {
            a.requestPermissions(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 77);
        }
    }

    public static void openWriteSettings(Activity a) {
        Intent i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + a.getPackageName()));
        if (!start(a, i)) openAppInfo(a);
    }

    public static void openDnd(Activity a) {
        if (!start(a, new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))) openAppInfo(a);
    }

    public static void openBattery(Activity a) {
        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + a.getPackageName()));
        if (start(a, i)) return;
        if (!start(a, new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) openAppInfo(a);
    }

    public static void openAppInfo(Context c) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", c.getPackageName(), null));
        start(c, i);
    }
}
