package com.tein.booster;

import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Process;
import android.os.UserHandle;
import android.os.storage.StorageManager;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Data aplikasi terpasang. Semua method berat: panggil dari thread latar. */
public final class Apps {
    private Apps() {}

    public static final class Item {
        public String pkg = "";
        public String label = "";
        public String version = "";
        public String sub = "";
        public String right = "";
        public boolean system;
        public boolean launchable;
        public boolean game;
        public long cache = -1;
        public long size = -1;
        public long lastUsed;
        public long installed;
        public long fgTime;
        public String sourceDir = "";
        public String[] splits;
    }

    private static final Map<String, String> LABELS = new ConcurrentHashMap<String, String>();

    public static List<Item> loadAll(Context c) {
        PackageManager pm = c.getPackageManager();
        Set<String> launchers = new HashSet<String>();
        try {
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
                if (ri.activityInfo != null) launchers.add(ri.activityInfo.packageName);
            }
        } catch (Exception ignored) {
        }
        List<ApplicationInfo> infos = pm.getInstalledApplications(0);
        List<Item> out = new ArrayList<Item>(infos.size());
        for (ApplicationInfo ai : infos) {
            Item it = new Item();
            it.pkg = ai.packageName;
            String lab = LABELS.get(ai.packageName);
            if (lab == null) {
                CharSequence cs = pm.getApplicationLabel(ai);
                lab = cs != null ? cs.toString() : ai.packageName;
                LABELS.put(ai.packageName, lab);
            }
            it.label = lab;
            it.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                    && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
            it.launchable = launchers.contains(ai.packageName);
            it.sourceDir = ai.sourceDir == null ? "" : ai.sourceDir;
            it.splits = ai.splitSourceDirs;
            boolean g = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
            if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) g = true;
            it.game = g;
            out.add(it);
        }
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }

    public static void fillDetails(Context c, List<Item> items) {
        PackageManager pm = c.getPackageManager();
        for (Item it : items) {
            try {
                PackageInfo pi = pm.getPackageInfo(it.pkg, 0);
                it.version = pi.versionName == null ? "" : pi.versionName;
                it.installed = pi.firstInstallTime;
            } catch (Exception ignored) {
            }
        }
    }

    /** Isi ukuran cache/app per aplikasi. Butuh Akses Penggunaan + Android 8+. Return true jika berhasil. */
    public static boolean fillSizes(Context c, List<Item> items) {
        if (Build.VERSION.SDK_INT < 26 || !Perm.usage(c)) return false;
        try {
            StorageStatsManager ssm = (StorageStatsManager) c.getSystemService(Context.STORAGE_STATS_SERVICE);
            UserHandle uh = Process.myUserHandle();
            for (Item it : items) {
                try {
                    StorageStats st = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, it.pkg, uh);
                    it.cache = st.getCacheBytes();
                    it.size = st.getAppBytes() + st.getDataBytes();
                } catch (Exception ignored) {
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Paket yang TIDAK boleh disentuh booster: sistem inti, launcher, keyboard, aplikasi ini, daftar putih. */
    public static Set<String> protectedPackages(Context c) {
        Set<String> s = new HashSet<String>();
        s.add(c.getPackageName());
        s.add("android");
        s.add("com.android.systemui");
        s.add("com.android.settings");
        try {
            PackageManager pm = c.getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo ri = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri != null && ri.activityInfo != null) s.add(ri.activityInfo.packageName);
        } catch (Exception ignored) {
        }
        try {
            InputMethodManager imm = (InputMethodManager) c.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                for (InputMethodInfo i : imm.getEnabledInputMethodList()) s.add(i.getPackageName());
            }
        } catch (Exception ignored) {
        }
        s.addAll(Prefs.getSet(c, Prefs.WHITELIST));
        return s;
    }
}
