package com.tein.booster;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Manajer Aplikasi: daftar, ukuran, buka, info, bersihkan cache, cadangkan APK, hapus instalan. */
public class AppManagerActivity extends BaseActivity {
    private AppAdapter adapter;
    private final List<Apps.Item> all = new ArrayList<Apps.Item>();
    private int tab = 0;
    private int sort = 0;

    @Override
    protected String title() { return "Manajer Aplikasi"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ListView lv = listBody();
        LinearLayout head = Ui.col(this);
        int p = Ui.dp(this, 16);
        head.setPadding(p, Ui.dp(this, 4), p, Ui.dp(this, 10));
        head.addView(Ui.segment(this, new String[]{"Terpasang", "Sistem"}, 0, i -> {
            tab = i;
            render();
        }));
        head.addView(Ui.segment(this, new String[]{"Nama", "Ukuran", "Terbaru"}, 0, i -> {
            sort = i;
            render();
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        lv.addHeaderView(head, null, false);
        adapter = new AppAdapter(this, false);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            int idx = pos - 1;
            if (idx >= 0 && idx < adapter.getCount()) menu(adapter.getItem(idx));
        });
        load();
    }

    private void load() {
        final Context app = getApplicationContext();
        Bg.run(() -> {
            List<Apps.Item> list = Apps.loadAll(app);
            Apps.fillDetails(app, list);
            Apps.fillSizes(app, list);
            final List<Apps.Item> fin = list;
            Bg.ui(() -> {
                if (!alive()) return;
                all.clear();
                all.addAll(fin);
                render();
            });
        });
    }

    private void render() {
        SimpleDateFormat df = new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID"));
        List<Apps.Item> out = new ArrayList<Apps.Item>();
        for (Apps.Item it : all) {
            if (tab == 0 && it.system) continue;
            if (tab == 1 && !it.system) continue;
            it.sub = (it.version.isEmpty() ? it.pkg : "v" + it.version)
                    + (it.installed > 0 ? " \u2022 " + df.format(new Date(it.installed)) : "");
            it.right = it.size >= 0 ? Fmt.bytes(it.size) : "";
            out.add(it);
        }
        if (sort == 1) {
            Collections.sort(out, (a, b) -> Long.compare(b.size, a.size));
        } else if (sort == 2) {
            Collections.sort(out, (a, b) -> Long.compare(b.installed, a.installed));
        }
        adapter.setItems(out);
    }

    private void menu(final Apps.Item it) {
        final List<String> labels = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();
        if (it.launchable) {
            labels.add("Buka");
            acts.add(() -> open(it));
        }
        labels.add("Info aplikasi");
        acts.add(() -> appInfo(it.pkg));
        labels.add("Bersihkan cache (otomatis)");
        acts.add(() -> cleanCache(it));
        labels.add("Cadangkan APK");
        acts.add(() -> backup(it));
        if (!it.system) {
            labels.add("Hapus instalan");
            acts.add(() -> uninstall(it));
        }
        new AlertDialog.Builder(this)
                .setTitle(it.label)
                .setItems(labels.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    private void open(Apps.Item it) {
        Intent li = getPackageManager().getLaunchIntentForPackage(it.pkg);
        if (li == null || !Perm.start(this, li)) Ui.toast(this, "Tidak bisa dibuka");
    }

    private void appInfo(String pkg) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null));
        if (!Perm.start(this, i)) Ui.toast(this, "Tidak bisa membuka info aplikasi");
    }

    private void uninstall(Apps.Item it) {
        Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + it.pkg));
        if (!Perm.start(this, i)) Ui.toast(this, "Tidak bisa menghapus instalan");
    }

    private void cleanCache(Apps.Item it) {
        CleanerAccessibilityService svc = CleanerAccessibilityService.instance;
        if (!Perm.accessibilityOn(this) || svc == null) {
            Guides.a11y(this);
            return;
        }
        List<String> p = new ArrayList<String>();
        p.add(it.pkg);
        List<String> n = new ArrayList<String>();
        n.add(it.label);
        boolean ok = svc.startClean(p, n, !Prefs.getBool(this, Prefs.CLEAN_DEBUG, false));
        if (!ok) Ui.toast(this, "Pembersihan lain sedang berjalan");
    }

    private void backup(final Apps.Item it) {
        final Context app = getApplicationContext();
        Ui.toast(this, "Mencadangkan " + it.label + "...");
        Bg.run(() -> {
            String msg;
            try {
                File base = Perm.allFiles(app)
                        ? new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "TeinBooster")
                        : app.getExternalFilesDir("backup");
                if (base == null) throw new Exception("penyimpanan tidak tersedia");
                base.mkdirs();
                String safe = (it.label + "_" + it.version).replaceAll("[^A-Za-z0-9._-]", "_");
                List<File> src = new ArrayList<File>();
                src.add(new File(it.sourceDir));
                if (it.splits != null) {
                    for (String s : it.splits) src.add(new File(s));
                }
                if (src.size() == 1) {
                    File out = new File(base, safe + ".apk");
                    copy(src.get(0), out);
                    msg = "Tersimpan di:\n" + out.getPath();
                } else {
                    File dir = new File(base, safe);
                    dir.mkdirs();
                    for (File f : src) copy(f, new File(dir, f.getName()));
                    msg = "Aplikasi split (" + src.size() + " file) tersimpan di:\n" + dir.getPath();
                }
            } catch (Exception e) {
                msg = "Gagal mencadangkan: " + e.getMessage();
            }
            final String m = msg;
            Bg.ui(() -> {
                if (alive()) new AlertDialog.Builder(this).setMessage(m).setPositiveButton("OK", null).show();
            });
        });
    }

    private static void copy(File from, File to) throws Exception {
        InputStream in = new FileInputStream(from);
        try {
            OutputStream out = new FileOutputStream(to);
            try {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }
}
