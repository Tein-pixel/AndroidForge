package com.tein.booster;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Pusat Izin: semua izin yang dibutuhkan booster, status nyata, dan tombol untuk mengaktifkannya. */
public class PermissionsActivity extends BaseActivity {
    private LinearLayout col;

    @Override
    protected String title() { return "Pusat Izin"; }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        col = scrollBody();
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        build();
    }

    private void build() {
        col.removeAllViews();
        boolean[] ok = {
                Perm.accessibilityOn(this), Perm.usage(this), Perm.allFiles(this),
                Perm.writeSettings(this), Perm.dnd(this), Perm.batteryWhitelist(this)
        };
        int done = 0;
        for (boolean v : ok) if (v) done++;

        LinearLayout sum = Ui.card(this);
        TextView t = Ui.tvb(this, done + " dari " + Perm.REQUIRED_TOTAL + " izin utama aktif", 17, Ui.TEXT);
        sum.addView(t);
        BarView bar = new BarView(this);
        sum.addView(bar, Ui.lp(this, Ui.MATCH, Ui.dp(this, 8), 0, 12, 0, 0));
        bar.setSmooth((float) done / Perm.REQUIRED_TOTAL, done == Perm.REQUIRED_TOTAL ? Ui.MINT : Ui.CYAN);
        TextView hint = Ui.tv(this, done == Perm.REQUIRED_TOTAL
                ? "Semua booster siap bekerja penuh."
                : "Aktifkan semua agar setiap booster bisa berjalan. Setiap izin hanya dipakai untuk fiturnya.", 13, Ui.SUB);
        sum.addView(hint, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        if (done < Perm.REQUIRED_TOTAL) {
            sum.addView(Ui.button(this, "Aktifkan berikutnya", v -> requestNext()),
                    Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        }
        col.addView(sum);

        addPerm("\u267F\uFE0F", "Aksesibilitas",
                "Untuk 1-Tap Cache Cleaner: menekan tombol \"Hapus cache\" di Pengaturan otomatis. Tidak membaca atau mengirim data pribadi.",
                ok[0], "Aktifkan", v -> Guides.a11y(this));
        addPerm("\uD83D\uDCCA", "Akses Penggunaan",
                "Membaca ukuran cache tiap aplikasi dan waktu pemakaian, supaya cleaner & booster tepat sasaran.",
                ok[1], "Beri akses", v -> Perm.openUsage(this));
        addPerm("\uD83D\uDCC1", "Akses Semua File",
                "Memindai & menghapus file sampah, file besar, dan duplikat di penyimpanan.",
                ok[2], "Beri akses", v -> Perm.openAllFiles(this));
        addPerm("\uD83D\uDD06", "Ubah Pengaturan Sistem",
                "Mengatur kecerahan dan waktu layar mati untuk Hemat Baterai dan Pendingin.",
                ok[3], "Beri akses", v -> Perm.openWriteSettings(this));
        addPerm("\uD83D\uDD15", "Jangan Ganggu",
                "Game Booster membisukan notifikasi saat kamu main, lalu mengembalikannya.",
                ok[4], "Beri akses", v -> Perm.openDnd(this));
        addPerm("\uD83D\uDD0B", "Abaikan Optimasi Baterai",
                "Agar Auto Boost terjadwal tidak dimatikan sistem.",
                ok[5], "Izinkan", v -> Perm.openBattery(this));
        addPerm("\uD83D\uDD11", "Pengaturan Aman (opsional, via ADB)",
                "Membuka Turbo UI (animasi) dan Private DNS sekali-tekan. Perlu sekali perintah ADB dari PC.",
                Perm.secure(this), "Salin perintah", v -> Guides.adb(this));
    }

    private void addPerm(String emoji, String title, String desc, boolean ok, String action, View.OnClickListener l) {
        LinearLayout card = Ui.card(this);
        LinearLayout top = Ui.row(this);
        top.addView(Ui.badge(this, emoji, ok ? Ui.MINT : Ui.EMBER, 42));
        LinearLayout mid = Ui.col(this);
        mid.addView(Ui.tvb(this, title, 15, Ui.TEXT));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        mp.setMargins(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        top.addView(mid, mp);
        top.addView(Ui.chip(this, ok ? "Aktif" : "Belum", ok ? Ui.MINT : Ui.EMBER));
        card.addView(top);
        TextView d = Ui.tv(this, desc, 13, Ui.SUB);
        card.addView(d, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        if (!ok) {
            card.addView(Ui.ghost(this, action, l), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        }
        col.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
    }

    private void requestNext() {
        if (!Perm.accessibilityOn(this)) { Guides.a11y(this); return; }
        if (!Perm.usage(this)) { Perm.openUsage(this); return; }
        if (!Perm.allFiles(this)) { Perm.openAllFiles(this); return; }
        if (!Perm.writeSettings(this)) { Perm.openWriteSettings(this); return; }
        if (!Perm.dnd(this)) { Perm.openDnd(this); return; }
        if (!Perm.batteryWhitelist(this)) { Perm.openBattery(this); }
    }
}
