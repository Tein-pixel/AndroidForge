package com.tein.booster;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** RAM Booster: menutup proses latar aplikasi (kecuali daftar putih) dan mengukur hasilnya. */
public class RamBoosterActivity extends BaseActivity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private GaugeView gauge;
    private TextView info;
    private TextView btn;
    private TextView result;
    private TextView wlBtn;
    private boolean boosting;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!boosting) updateGauge(false);
            h.postDelayed(this, 2000L);
        }
    };

    @Override
    protected String title() { return "RAM Booster"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();
        LinearLayout hero = Ui.card(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 220), Ui.dp(this, 220));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);
        info = Ui.tv(this, "", 14, Ui.SUB);
        info.setGravity(Gravity.CENTER);
        hero.addView(info, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        btn = Ui.button(this, "Boost RAM", v -> doBoost());
        hero.addView(btn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));
        result = Ui.tvb(this, "", 14, Ui.MINT);
        result.setGravity(Gravity.CENTER);
        hero.addView(result, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(hero);

        LinearLayout how = Ui.card(this);
        how.addView(Ui.tvb(this, "Cara kerja", 15, Ui.TEXT));
        how.addView(Ui.tv(this, "Menutup proses latar belakang semua aplikasi (kecuali daftar putih, launcher, keyboard, dan komponen sistem). "
                + "Android memulai ulang aplikasi yang memang dibutuhkan, jadi hasil paling terasa saat RAM hampir penuh. "
                + "Angka sebelum/sesudah diukur langsung dari perangkat.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        wlBtn = Ui.ghost(this, "Daftar putih", v -> {
            Intent i = new Intent(this, AppPickerActivity.class);
            i.putExtra(AppPickerActivity.EXTRA_MODE, "whitelist");
            startActivity(i);
        });
        how.addView(wlBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(how, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        Ui.reveal(hero, how);

        Intent in = getIntent();
        if (in != null && "com.tein.booster.action.BOOST".equals(in.getAction())) {
            Bg.uiDelayed(() -> doBoost(), 600L);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateGauge(true);
        h.postDelayed(loop, 2000L);
        wlBtn.setText("Daftar putih (" + Prefs.getSet(this, Prefs.WHITELIST).size() + " aplikasi dilindungi)");
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(loop);
    }

    private void updateGauge(boolean animate) {
        float u = Sys.ramUsed(this);
        long t = Sys.ramTotal(this);
        long a = Sys.ramAvail(this);
        int c = u < 0.6f ? Ui.MINT : (u < 0.8f ? Ui.EMBER : Ui.CORAL);
        gauge.setColors(c, Ui.BLUE);
        gauge.setProgress(u, animate);
        gauge.setCenter(Fmt.pct(u), "RAM terpakai");
        info.setText(Fmt.bytes(a) + " bebas dari " + Fmt.bytes(t));
    }

    private void doBoost() {
        if (boosting) return;
        boosting = true;
        btn.setText("Memboost...");
        btn.setAlpha(0.6f);
        result.setText("");
        gauge.setSpinning(true);
        gauge.setCenter("...", "memproses");
        final Context app = getApplicationContext();
        Bg.run(() -> {
            final Optimizer.Result r = Optimizer.boostRam(app);
            Prefs.putLong(app, Prefs.LAST_BOOST, System.currentTimeMillis());
            Prefs.putLong(app, Prefs.LAST_FREED, r.ramFreed);
            Bg.ui(() -> {
                boosting = false;
                if (!alive()) return;
                gauge.setSpinning(false);
                btn.setText("Boost RAM");
                btn.setAlpha(1f);
                updateGauge(true);
                String m = r.killed + " aplikasi dioptimalkan\nBebas: " + Fmt.bytes(r.ramBefore) + " \u2192 " + Fmt.bytes(r.ramAfter);
                m += r.ramFreed > 0 ? " (+" + Fmt.bytes(r.ramFreed) + ")" : "\nRAM sudah optimal";
                result.setText(m);
            });
        });
    }
}
