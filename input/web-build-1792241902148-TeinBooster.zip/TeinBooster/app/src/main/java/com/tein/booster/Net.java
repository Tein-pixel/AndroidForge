package com.tein.booster;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.util.Arrays;

/** Pengukuran jaringan nyata: latensi DNS (UDP), ping TCP, kecepatan unduh. Jalankan di thread latar. */
public final class Net {
    private Net() {}

    public interface SpeedCb {
        void onProgress(double mbps, float frac);
    }

    /** {nama, IP, hostname DNS-over-TLS (Private DNS)} */
    public static final String[][] DNS = {
            {"Cloudflare", "1.1.1.1", "one.one.one.one"},
            {"Google", "8.8.8.8", "dns.google"},
            {"Quad9", "9.9.9.9", "dns.quad9.net"},
            {"AdGuard", "94.140.14.14", "dns.adguard-dns.com"}
    };

    private static final String[] DOMAINS = {"google.com", "wikipedia.org", "cloudflare.com", "microsoft.com", "amazon.com"};

    private static byte[] query(String domain, int id) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(id >> 8);
        o.write(id & 0xFF);
        o.write(0x01);
        o.write(0x00);
        o.write(0);
        o.write(1);
        for (int i = 0; i < 6; i++) o.write(0);
        for (String part : domain.split("\\.")) {
            byte[] b = part.getBytes();
            o.write(b.length);
            o.write(b, 0, b.length);
        }
        o.write(0);
        o.write(0);
        o.write(1);
        o.write(0);
        o.write(1);
        return o.toByteArray();
    }

    private static long dnsOnce(String ip, String domain, int id) {
        DatagramSocket s = null;
        try {
            byte[] q = query(domain, id);
            s = new DatagramSocket();
            s.setSoTimeout(1500);
            InetAddress addr = InetAddress.getByName(ip);
            byte[] buf = new byte[512];
            DatagramPacket in = new DatagramPacket(buf, buf.length);
            long t0 = System.nanoTime();
            s.send(new DatagramPacket(q, q.length, addr, 53));
            s.receive(in);
            long ms = (System.nanoTime() - t0) / 1000000L;
            if (in.getLength() >= 12 && buf[0] == q[0] && buf[1] == q[1]) return ms;
            return -1L;
        } catch (Exception e) {
            return -1L;
        } finally {
            if (s != null) s.close();
        }
    }

    /** Median latensi DNS (ms) ke resolver, atau -1 bila gagal. */
    public static long dnsMedian(String ip) {
        long[] r = new long[DOMAINS.length];
        int ok = 0;
        for (int i = 0; i < DOMAINS.length; i++) {
            long ms = dnsOnce(ip, DOMAINS[i], 0x2000 + i);
            if (ms >= 0) r[ok++] = ms;
        }
        if (ok == 0) return -1L;
        Arrays.sort(r, 0, ok);
        return r[ok / 2];
    }

    /** {rata-rata ms, jitter ms, loss %}; rata-rata -1 jika semua gagal. */
    public static double[] tcpPing(String host, int port, int count) {
        double sum = 0, sumSq = 0;
        int ok = 0;
        for (int i = 0; i < count; i++) {
            Socket s = new Socket();
            try {
                long t0 = System.nanoTime();
                s.connect(new InetSocketAddress(host, port), 2000);
                double ms = (System.nanoTime() - t0) / 1e6;
                sum += ms;
                sumSq += ms * ms;
                ok++;
            } catch (Exception ignored) {
            } finally {
                try {
                    s.close();
                } catch (Exception ignored) {
                }
            }
            try {
                Thread.sleep(120);
            } catch (InterruptedException ignored) {
            }
        }
        if (ok == 0) return new double[]{-1, 0, 100};
        double avg = sum / ok;
        double var = Math.max(0, sumSq / ok - avg * avg);
        return new double[]{avg, Math.sqrt(var), (count - ok) * 100.0 / count};
    }

    /** Unduh data uji (Cloudflare) maksimal maxMs; return Mbps akhir. */
    public static double downloadTest(SpeedCb cb, long maxMs) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL("https://speed.cloudflare.com/__down?bytes=50000000").openConnection();
        h.setConnectTimeout(7000);
        h.setReadTimeout(8000);
        h.setRequestProperty("User-Agent", "TeinBooster/1.0");
        InputStream in = h.getInputStream();
        byte[] buf = new byte[64 * 1024];
        long total = 0;
        long t0 = System.nanoTime();
        double mbps = 0;
        long lastCb = 0;
        int n;
        try {
            while ((n = in.read(buf)) > 0) {
                total += n;
                long el = (System.nanoTime() - t0) / 1000000L;
                if (el > 300) mbps = total * 8.0 / (el / 1000.0) / 1e6;
                if (el > 300 && el - lastCb > 200) {
                    lastCb = el;
                    cb.onProgress(mbps, Math.min(1f, (float) el / (float) maxMs));
                }
                if (el >= maxMs) break;
            }
        } finally {
            try {
                in.close();
            } catch (Exception ignored) {
            }
            h.disconnect();
        }
        return mbps;
    }
}
