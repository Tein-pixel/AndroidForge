package com.tein.booster;

import android.app.ActivityManager;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;
import android.os.storage.StorageManager;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Inti booster: tutup proses latar, pangkas cache, hapus file. Panggil dari thread latar. */
public final class Optimizer {
    private Optimizer() {}

    public static final class Result {
        public int killed;
        public long ramBefore;
        public long ramAfter;
        public long ramFreed;
        public long storageFreed;
    }

    public static Result boostRam(Context ctx) {
        Context c = ctx.getApplicationContext();
        Result r = new Result();
        r.ramBefore = Sys.ramAvail(c);
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        Set<String> keep = Apps.protectedPackages(c);
        for (Apps.Item it : Apps.loadAll(c)) {
            if (keep.contains(it.pkg)) continue;
            if (it.system && !it.launchable) continue;
            try {
                am.killBackgroundProcesses(it.pkg);
                r.killed++;
            } catch (Exception ignored) {
            }
        }
        SystemClock.sleep(900);
        r.ramAfter = Sys.ramAvail(c);
        r.ramFreed = Math.max(0L, r.ramAfter - r.ramBefore);
        return r;
    }

    /** Boost 1-tap: RAM + cache milik Tein Booster sendiri. */
    public static Result fullBoost(Context ctx) {
        Result r = boostRam(ctx);
        long before = freeBytes();
        trimOwnCache(ctx);
        r.storageFreed = Math.max(0L, freeBytes() - before);
        Prefs.putLong(ctx, Prefs.LAST_BOOST, System.currentTimeMillis());
        Prefs.putLong(ctx, Prefs.LAST_FREED, r.ramFreed);
        return r;
    }

    public static void trimOwnCache(Context ctx) {
        Context c = ctx.getApplicationContext();
        try {
            deleteContents(c.getCacheDir());
            File ext = c.getExternalCacheDir();
            if (ext != null) deleteContents(ext);
        } catch (Exception ignored) {
        }
    }

    /**
     * Minta sistem Android membebaskan cache semua aplikasi lewat API resmi StorageManager
     * (Android 8+). Hasil bervariasi per perangkat; return jumlah byte yang benar-benar bertambah.
     */
    public static long trimSystemCaches(Context ctx) {
        Context c = ctx.getApplicationContext();
        long before = freeBytes();
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                StorageManager sm = (StorageManager) c.getSystemService(Context.STORAGE_SERVICE);
                UUID uuid = sm.getUuidForPath(c.getCacheDir());
                long allocatable = sm.getAllocatableBytes(uuid);
                if (allocatable > 0) sm.allocateBytes(uuid, allocatable);
            } catch (Throwable ignored) {
            }
        }
        return Math.max(0L, freeBytes() - before);
    }

    /** Perkiraan cache yang bisa dipangkas lewat API sistem. */
    public static long systemCacheEstimate(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return 0L;
        try {
            Context c = ctx.getApplicationContext();
            StorageManager sm = (StorageManager) c.getSystemService(Context.STORAGE_SERVICE);
            UUID uuid = sm.getUuidForPath(c.getCacheDir());
            return Math.max(0L, sm.getAllocatableBytes(uuid) - freeBytes());
        } catch (Throwable t) {
            return 0L;
        }
    }

    public static long freeBytes() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes();
        } catch (Exception e) {
            return 0L;
        }
    }

    public static long dirSize(File f) {
        if (f == null || !f.exists()) return 0L;
        if (f.isFile()) return f.length();
        long s = 0L;
        File[] l = f.listFiles();
        if (l != null) {
            for (File x : l) s += dirSize(x);
        }
        return s;
    }

    /** Hapus file/folder rekursif. Return byte yang berhasil dihapus. */
    public static long deleteTree(File f) {
        if (f == null || !f.exists()) return 0L;
        if (f.isDirectory()) {
            long freed = 0L;
            File[] l = f.listFiles();
            if (l != null) {
                for (File x : l) freed += deleteTree(x);
            }
            f.delete();
            return freed;
        }
        long len = f.length();
        return f.delete() ? len : 0L;
    }

    public static void deleteContents(File dir) {
        if (dir == null) return;
        File[] l = dir.listFiles();
        if (l != null) {
            for (File x : l) deleteTree(x);
        }
    }

    public static void rescan(Context c, List<String> paths) {
        try {
            if (paths.isEmpty()) return;
            MediaScannerConnection.scanFile(c.getApplicationContext(), paths.toArray(new String[0]), null, null);
        } catch (Exception ignored) {
        }
    }
}
