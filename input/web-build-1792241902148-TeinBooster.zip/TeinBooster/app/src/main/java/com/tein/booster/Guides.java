package com.tein.booster;

import android.app.Activity;
import android.app.AlertDialog;

/** Dialog panduan untuk izin yang butuh langkah manual. */
public final class Guides {
    private Guides() {}

    public static void a11y(final Activity a) {
        String msg = "1. Tekan \"Buka Aksesibilitas\".\n"
                + "2. Pilih \"Tein Booster Cleaner\" (bisa di dalam \"Aplikasi terinstal\" atau \"Layanan terunduh\").\n"
                + "3. Nyalakan, lalu izinkan.\n\n"
                + "Jika tombolnya abu-abu atau muncul \"Setelan dibatasi\" (Android 13+): buka Info Aplikasi Tein Booster, "
                + "tekan menu \u22EE di kanan atas, pilih \"Izinkan setelan terbatas\", lalu ulangi langkah 1.\n\n"
                + "Layanan ini hanya dipakai untuk menekan \"Hapus cache\" di Pengaturan dan tidak membaca data pribadi.";
        new AlertDialog.Builder(a)
                .setTitle("Aktifkan Aksesibilitas")
                .setMessage(msg)
                .setPositiveButton("Buka Aksesibilitas", (d, w) -> Perm.openAccessibility(a))
                .setNeutralButton("Info Aplikasi", (d, w) -> Perm.openAppInfo(a))
                .setNegativeButton("Batal", null)
                .show();
    }

    public static void adb(final Activity a) {
        String cmd = Perm.adbCommand(a);
        Ui.copy(a, "adb", cmd);
        new AlertDialog.Builder(a)
                .setTitle("Izin lewat ADB (opsional)")
                .setMessage("Perintah sudah disalin:\n\n" + cmd
                        + "\n\nSambungkan HP ke PC (USB debugging aktif), jalankan perintah itu sekali, lalu kembali ke aplikasi. "
                        + "Izin ini dipakai Turbo UI dan Private DNS sekali-tekan.")
                .setPositiveButton("OK", null)
                .show();
    }
}
