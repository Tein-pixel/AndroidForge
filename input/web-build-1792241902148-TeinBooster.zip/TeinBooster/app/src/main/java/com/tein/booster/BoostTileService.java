package com.tein.booster;

import android.content.Context;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Ubin Quick Settings: ketuk untuk Boost RAM sekali tekan. */
public class BoostTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();
        setTile(Tile.STATE_INACTIVE, "Boost");
    }

    @Override
    public void onClick() {
        super.onClick();
        final Context app = getApplicationContext();
        setTile(Tile.STATE_ACTIVE, "Memboost...");
        Bg.run(() -> {
            final Optimizer.Result r = Optimizer.fullBoost(app);
            Bg.ui(() -> {
                Ui.toast(app, "Boost selesai: " + r.killed + " aplikasi ditutup, RAM +" + Fmt.bytes(r.ramFreed));
                setTile(Tile.STATE_INACTIVE, "Boost");
            });
        });
    }

    private void setTile(int state, String label) {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(state);
        t.setLabel(label);
        t.updateTile();
    }
}
