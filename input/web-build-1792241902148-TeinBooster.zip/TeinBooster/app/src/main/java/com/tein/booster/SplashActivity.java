package com.tein.booster;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.concurrent.atomic.AtomicBoolean;

/** Layar loading saat aplikasi dibuka: logo animasi + pemanasan data nyata di latar. */
public class SplashActivity extends Activity {
    private final AtomicBoolean warm = new AtomicBoolean(false);
    private boolean went = false;
    private long t0;
    private BarView bar;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        t0 = System.currentTimeMillis();
        final android.content.Context app = getApplicationContext();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        LinearLayout col = Ui.col(this);
        col.setGravity(Gravity.CENTER);
        LogoView logo = new LogoView(this);
        col.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 170), Ui.dp(this, 170)));
        TextView name = Ui.tvb(this, "Tein Booster", 30, Ui.TEXT);
        col.addView(name, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 22, 0, 0));
        TextView tag = Ui.tv(this, "Booster & cleaner Android", 14, Ui.SUB);
        col.addView(tag, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 6, 0, 0));
        bar = new BarView(this);
        col.addView(bar, Ui.lp(this, Ui.dp(this, 200), Ui.dp(this, 6), 0, 38, 0, 0));
        status = Ui.tv(this, "Memeriksa sistem...", 12, Ui.SUB);
        col.addView(status, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 12, 0, 0));
        root.addView(col, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH, Gravity.CENTER));
        setContentView(root);

        logo.play();
        Ui.reveal(name, tag, bar, status);
        bar.setSmooth(0.25f, Ui.CYAN);

        Bg.run(() -> {
            try {
                Apps.loadAll(app);
                Sys.score(app);
            } catch (Throwable ignored) {
            }
            warm.set(true);
        });

        stage(700L, "Memuat modul booster...", 0.55f);
        stage(1500L, "Menyiapkan layanan & izin...", 0.85f);
        stage(2300L, "Siap!", 1f);
        Bg.uiDelayed(() -> next(), 2700L);
    }

    private void stage(long delay, final String text, final float frac) {
        Bg.uiDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            status.setText(text);
            bar.setSmooth(frac, Ui.CYAN);
        }, delay);
    }

    private void next() {
        if (went || isFinishing() || isDestroyed()) return;
        if (!warm.get() && System.currentTimeMillis() - t0 < 6000L) {
            Bg.uiDelayed(() -> next(), 150L);
            return;
        }
        went = true;
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
