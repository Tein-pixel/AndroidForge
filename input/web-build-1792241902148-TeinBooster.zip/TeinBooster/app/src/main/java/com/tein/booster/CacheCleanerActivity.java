package com.tein.booster;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Layar 1-Tap Cache Cleaner (mengendalikan CleanerAccessibilityService). */
public class CacheCleanerActivity extends BaseActivity {
    private LinearLayout col;
    private GaugeView gauge;
    private TextView statusTv;
    private TextView actionBtn;
    private TextView resultTv;
    private TextView a11yChip;
    private TextView usageBtn;
    private LinearLayout listBox;

    private List<Apps.Item> targets = new ArrayList<Apps.Item>();
    private Set<String> initialPkgs = new HashSet<String>();
    private long totalCache = -1L;
    private long beforeTotal = -1L;
    private long sysFreed = 0L;
    private boolean sizesKnown;
    private boolean loading;
    private boolean starting;
    private boolean autostartPending;

    @Override
    protected String title() { return "1-Tap Cache Cleaner"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        col = scrollBody();
        Intent in = getIntent();
        autostartPending = in != null && (in.getBooleanExtra("autostart", false)
                || "com.tein.booster.action.CLEAN_CACHE".equals(in.getAction()));

        LinearLayout hero = Ui.card(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 220), Ui.dp(this, 220));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);
        statusTv = Ui.tv(this, "Memindai aplikasi...", 14, Ui.SUB);
        statusTv.setGravity(Gravity.CENTER);
        hero.addView(statusTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        actionBtn = Ui.button(this, "Bersihkan semua cache", v -> onAction());
        hero.addView(actionBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));
        resultTv = Ui.tvb(this, "", 14, Ui.MINT);
        resultTv.setGravity(Gravity.CENTER);
        hero.addView(resultTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(hero);

        LinearLayout info = Ui.card(this);
        LinearLayout st = Ui.row(this);
        st.addView(Ui.tvb(this, "Layanan Aksesibilitas", 14, Ui.TEXT), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        a11yChip = Ui.chip(this, "-", Ui.EMBER);
        st.addView(a11yChip);
        info.addView(st);
        info.addView(Ui.tv(this, "Cara kerja: untuk tiap aplikasi, Tein Booster membuka Info Aplikasi \u2192 Penyimpanan \u2192 \"Hapus cache\" "
                + "secara otomatis. Tidak pernah menekan \"Hapus data\" atau \"Hapus penyimpanan\".", 12, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        info.addView(Ui.ghost(this, "Panduan mengaktifkan", v -> Guides.a11y(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        usageBtn = Ui.ghost(this, "Beri Akses Penggunaan (agar ukuran cache terbaca)", v -> Perm.openUsage(this));
        info.addView(usageBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(info, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout opt = Ui.card(this);
        opt.addView(switchRow("Sertakan aplikasi sistem", Prefs.getBool(this, Prefs.CLEAN_SYSTEM, false), (b, c) -> {
            Prefs.putBool(this, Prefs.CLEAN_SYSTEM, c);
            load();
        }));
        opt.addView(Ui.divider(this));
        opt.addView(switchRow("Tampilkan proses (mode debug)", Prefs.getBool(this, Prefs.CLEAN_DEBUG, false), (b, c) ->
                Prefs.putBool(this, Prefs.CLEAN_DEBUG, c)));
        col.addView(opt, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        col.addView(Ui.sectionTitle(this, "Aplikasi dengan cache terbesar"));
        listBox = Ui.card(this);
        col.addView(listBox);
        col.addView(Ui.ghost(this, "Lihat log pembersihan", v -> showLog()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
    }

    private LinearLayout switchRow(String label, boolean on, android.widget.CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        r.addView(Ui.tv(this, label, 14, Ui.TEXT), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        r.addView(sw);
        return r;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        CleanerAccessibilityService.setListener(() -> onServiceChanged());
        refreshState();
        if (CleanerAccessibilityService.STATE.running) {
            onServiceChanged();
        } else if (CleanerAccessibilityService.STATE.finished) {
            showResult();
        } else if (!loading && targets.isEmpty()) {
            load();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        CleanerAccessibilityService.setListener(null);
    }

    private static long sumCache(List<Apps.Item> l) {
        long s = 0L;
        for (Apps.Item it : l) if (it.cache > 0) s += it.cache;
        return s;
    }

    private static List<Apps.Item> pickTargets(Context c, List<Apps.Item> all, boolean sizes, boolean includeSystem) {
        Set<String> skip = new HashSet<String>(Prefs.getSet(c, Prefs.WHITELIST));
        skip.add(c.getPackageName());
        skip.add("android");
        skip.add("com.android.settings");
        skip.add("com.android.systemui");
        List<Apps.Item> out = new ArrayList<Apps.Item>();
        for (Apps.Item it : all) {
            if (skip.contains(it.pkg)) continue;
            if (!includeSystem && it.system && !it.launchable) continue;
            if (sizes && it.cache >= 0 && it.cache < 32L * 1024L) continue;
            out.add(it);
        }
        if (sizes) Collections.sort(out, (a, b) -> Long.compare(b.cache, a.cache));
        return out;
    }

    private void load() {
        if (loading) return;
        loading = true;
        statusTv.setText("Memindai aplikasi...");
        gauge.setCenter("...", "memindai");
        gauge.setSpinning(true);
        final Context app = getApplicationContext();
        final boolean incSys = Prefs.getBool(this, Prefs.CLEAN_SYSTEM, false);
        Bg.run(() -> {
            List<Apps.Item> all = Apps.loadAll(app);
            final boolean sizes = Apps.fillSizes(app, all);
            final List<Apps.Item> picked = pickTargets(app, all, sizes, incSys);
            final long total = sumCache(picked);
            Bg.ui(() -> {
                loading = false;
                if (!alive()) return;
                targets = picked;
                sizesKnown = sizes;
                totalCache = sizes ? total : -1L;
                beforeTotal = totalCache;
                initialPkgs = new HashSet<String>();
                for (Apps.Item it : picked) initialPkgs.add(it.pkg);
                renderLoaded();
                if (autostartPending) {
                    autostartPending = false;
                    startClean();
                }
            });
        });
    }

    private void renderLoaded() {
        gauge.setSpinning(false);
        usageBtn.setVisibility(sizesKnown ? View.GONE : View.VISIBLE);
        if (sizesKnown) {
            gauge.setCenter(Fmt.bytes(totalCache), "cache terdeteksi");
            gauge.setProgress(Math.min(1f, totalCache / (2f * 1024f * 1024f * 1024f)), true);
            statusTv.setText(targets.size() + " aplikasi memiliki cache");
        } else {
            gauge.setCenter(String.valueOf(targets.size()), "aplikasi");
            gauge.setProgress(0.35f, true);
            int mins = Math.max(1, Math.round(targets.size() * 2.5f / 60f));
            statusTv.setText("Ukuran cache tidak terbaca (butuh Akses Penggunaan). Perkiraan waktu \u00B1" + mins + " menit.");
        }
        renderList();
        refreshState();
    }

    private void renderList() {
        listBox.removeAllViews();
        if (targets.isEmpty()) {
            listBox.addView(Ui.tv(this, "Tidak ada aplikasi yang perlu dibersihkan.", 13, Ui.SUB));
            return;
        }
        int n = Math.min(30, targets.size());
        for (int i = 0; i < n; i++) {
            Apps.Item it = targets.get(i);
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            ImageView iv = new ImageView(this);
            r.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));
            IconLoader.load(this, it.pkg, iv);
            TextView name = Ui.tvb(this, it.label, 14, Ui.TEXT);
            name.setSingleLine(true);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
            np.setMargins(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
            r.addView(name, np);
            r.addView(Ui.tvb(this, it.cache >= 0 ? Fmt.bytes(it.cache) : "-", 13, Ui.CYAN));
            listBox.addView(r);
            if (i < n - 1) listBox.addView(Ui.divider(this));
        }
        if (targets.size() > n) {
            listBox.addView(Ui.tv(this, "+ " + (targets.size() - n) + " aplikasi lainnya", 12, Ui.SUB),
                    Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 8, 0, 0));
        }
    }

    private void refreshState() {
        boolean on = Perm.accessibilityOn(this);
        boolean run = CleanerAccessibilityService.STATE.running;
        int color = on ? Ui.MINT : Ui.EMBER;
        a11yChip.setText(on ? "Aktif" : "Belum aktif");
        a11yChip.setTextColor(color);
        a11yChip.setBackground(Ui.rect(this, Ui.alpha(color, 0x2A), 10));
        if (run || starting) {
            actionBtn.setText(run ? "Sedang membersihkan..." : "Menyiapkan...");
            actionBtn.setAlpha(0.6f);
        } else {
            actionBtn.setText(on ? "Bersihkan semua cache" : "Aktifkan Aksesibilitas");
            actionBtn.setAlpha(1f);
        }
    }

    private void onAction() {
        if (CleanerAccessibilityService.STATE.running || starting) return;
        startClean();
    }

    private void startClean() {
        if (CleanerAccessibilityService.STATE.running || starting) return;
        if (!Perm.accessibilityOn(this)) {
            Guides.a11y(this);
            return;
        }
        if (CleanerAccessibilityService.instance == null) {
            Ui.toast(this, "Layanan belum tersambung. Nyalakan Aksesibilitas Tein Booster, lalu kembali ke sini.");
            Guides.a11y(this);
            return;
        }
        if (loading) {
            autostartPending = true;
            return;
        }
        if (targets.isEmpty()) {
            Ui.toast(this, "Tidak ada aplikasi bercache untuk dibersihkan.");
            return;
        }
        starting = true;
        resultTv.setText("");
        refreshState();
        statusTv.setText("Menyiapkan: memangkas cache lewat sistem...");
        gauge.setCenter("...", "menyiapkan");
        gauge.setSpinning(true);
        final Context app = getApplicationContext();
        final boolean wasSizes = sizesKnown;
        final boolean incSys = Prefs.getBool(this, Prefs.CLEAN_SYSTEM, false);
        final List<Apps.Item> current = new ArrayList<Apps.Item>(targets);
        Bg.run(() -> {
            Optimizer.trimOwnCache(app);
            final long freedBySystem = Optimizer.trimSystemCaches(app);
            final List<Apps.Item> fresh;
            if (wasSizes) {
                List<Apps.Item> all = Apps.loadAll(app);
                Apps.fillSizes(app, all);
                fresh = pickTargets(app, all, true, incSys);
            } else {
                fresh = current;
            }
            Bg.ui(() -> {
                starting = false;
                if (!alive()) return;
                gauge.setSpinning(false);
                begin(fresh, freedBySystem);
            });
        });
    }

    private void begin(List<Apps.Item> list, long systemFreed) {
        sysFreed = systemFreed;
        CleanerAccessibilityService svc = CleanerAccessibilityService.instance;
        if (list.isEmpty()) {
            statusTv.setText("Cache sudah bersih");
            gauge.setCenter("\u2713", "bersih");
            gauge.setProgress(1f, true);
            resultTv.setText("Cache sudah bersih" + (systemFreed > 0 ? " \u2022 dipangkas sistem: " + Fmt.bytes(systemFreed) : ""));
            refreshState();
            return;
        }
        if (svc == null) {
            Ui.toast(this, "Layanan Aksesibilitas terputus. Nyalakan lagi lalu coba ulang.");
            refreshState();
            return;
        }
        List<String> pkgs = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        for (Apps.Item it : list) {
            pkgs.add(it.pkg);
            names.add(it.label);
        }
        CleanerAccessibilityService.STATE.startBytes = beforeTotal;
        boolean debug = Prefs.getBool(this, Prefs.CLEAN_DEBUG, false);
        gauge.setProgress(0f, false);
        gauge.setCenter("0%", "0/" + pkgs.size());
        statusTv.setText("Memulai pembersihan " + pkgs.size() + " aplikasi...");
        if (!svc.startClean(pkgs, names, !debug)) {
            Ui.toast(this, "Tidak bisa memulai pembersihan.");
        }
        refreshState();
    }

    private void onServiceChanged() {
        if (!alive()) return;
        CleanerAccessibilityService.State s = CleanerAccessibilityService.STATE;
        if (s.running) {
            gauge.setSpinning(false);
            gauge.setProgress(s.total > 0 ? (float) s.done / (float) s.total : 0f, true);
            gauge.setCenter(Math.round(100f * s.done / Math.max(1, s.total)) + "%", s.done + "/" + s.total);
            statusTv.setText("Membersihkan: " + s.current);
        } else if (s.finished) {
            showResult();
        }
        refreshState();
    }

    private void showResult() {
        final CleanerAccessibilityService.State s = CleanerAccessibilityService.STATE;
        if (!s.finished) return;
        s.finished = false;
        final int cleaned = s.cleaned;
        final int already = s.already;
        final int failed = s.failed;
        final String msg = s.message;
        statusTv.setText("Menghitung hasil...");
        gauge.setSpinning(true);
        refreshState();
        final Context app = getApplicationContext();
        final long before = beforeTotal;
        final Set<String> pk = new HashSet<String>(initialPkgs);
        final long sysBytes = sysFreed;
        Bg.run(() -> {
            long after = -1L;
            if (before >= 0 && Perm.usage(app)) {
                List<Apps.Item> all = Apps.loadAll(app);
                Apps.fillSizes(app, all);
                long sum = 0L;
                for (Apps.Item it : all) if (pk.contains(it.pkg) && it.cache > 0) sum += it.cache;
                after = sum;
            }
            final long freed = after >= 0 ? Math.max(0L, before - after) : -1L;
            Bg.ui(() -> {
                if (!alive()) return;
                gauge.setSpinning(false);
                gauge.setProgress(1f, true);
                gauge.setCenter("\u2713", "selesai");
                statusTv.setText(msg);
                String r = cleaned + " dibersihkan \u2022 " + already + " sudah bersih \u2022 " + failed + " gagal";
                if (freed >= 0) r += "\nDibebaskan: " + Fmt.bytes(freed);
                else if (sysBytes > 0) r += "\nDipangkas sistem: " + Fmt.bytes(sysBytes);
                if (failed > 0) r += "\nLihat log untuk detail yang gagal.";
                resultTv.setText(r);
                refreshState();
                load();
            });
        });
    }

    private void showLog() {
        String log = CleanerAccessibilityService.STATE.log.toString();
        if (log.isEmpty()) log = "(Belum ada log. Jalankan pembersihan dulu.)";
        final String text = log;
        TextView tv = Ui.tv(this, text, 12, Ui.TEXT);
        tv.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 4));
        tv.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("Log pembersihan")
                .setView(sv)
                .setPositiveButton("Salin", (d, w) -> {
                    Ui.copy(this, "log", text);
                    Ui.toast(this, "Log disalin");
                })
                .setNegativeButton("Tutup", null)
                .show();
    }
}
