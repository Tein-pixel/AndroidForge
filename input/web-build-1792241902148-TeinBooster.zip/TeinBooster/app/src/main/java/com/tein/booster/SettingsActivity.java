package com.tein.booster;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Pengaturan: Auto Boost terjadwal, daftar putih, tips ubin Quick Settings, tentang. */
public class SettingsActivity extends BaseActivity {
    private static final int[] HOURS = {0, 1, 3, 6, 12};
    private TextView wlInfo;
    private LinearLayout batteryHint;

    @Override
    protected String title() { return "Pengaturan"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();

        LinearLayout auto = Ui.card(this);
        auto.addView(Ui.tvb(this, "Auto Boost", 16, Ui.TEXT));
        auto.addView(Ui.tv(this, "Menutup proses latar & menghapus cache Tein Booster secara berkala di latar belakang.", 13, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        int cur = Prefs.getInt(this, Prefs.AUTO_HOURS, 0);
        int sel = 0;
        for (int i = 0; i < HOURS.length; i++) if (HOURS[i] == cur) sel = i;
        auto.addView(Ui.segment(this, new String[]{"Mati", "1 jam", "3 jam", "6 jam", "12 jam"}, sel, i -> {
            Prefs.putInt(this, Prefs.AUTO_HOURS, HOURS[i]);
            AutoBoostService.schedule(getApplicationContext(), HOURS[i]);
            Ui.toast(this, HOURS[i] == 0 ? "Auto Boost dimatikan" : "Auto Boost tiap " + HOURS[i] + " jam");
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        batteryHint = Ui.col(this);
        batteryHint.addView(Ui.tv(this, "Agar tidak dimatikan sistem, izinkan abaikan optimasi baterai.", 12, Ui.EMBER),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        batteryHint.addView(Ui.ghost(this, "Izinkan", v -> Perm.openBattery(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        auto.addView(batteryHint);
        col.addView(auto);

        LinearLayout wl = Ui.card(this);
        wl.addView(Ui.tvb(this, "Daftar putih", 16, Ui.TEXT));
        wlInfo = Ui.tv(this, "", 13, Ui.SUB);
        wl.addView(wlInfo, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        wl.addView(Ui.ghost(this, "Pilih aplikasi yang dilindungi", v -> {
            Intent i = new Intent(this, AppPickerActivity.class);
            i.putExtra(AppPickerActivity.EXTRA_MODE, "whitelist");
            startActivity(i);
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(wl, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout tile = Ui.card(this);
        tile.addView(Ui.tvb(this, "Akses cepat", 16, Ui.TEXT));
        tile.addView(Ui.tv(this, "\u2022 Ubin Quick Settings \"Boost\": tarik panel notifikasi \u2192 ikon pensil \u2192 seret ubin Boost.\n"
                + "\u2022 Tekan lama ikon Tein Booster di layar utama untuk pintasan Boost RAM, Cache Cleaner, dan Junk Cleaner.", 13, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(tile, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout about = Ui.card(this);
        about.addView(Ui.tvb(this, "Tentang Tein Booster", 16, Ui.TEXT));
        about.addView(Ui.tv(this, "Versi 1.0.0\nSemua booster memakai API resmi Android tanpa root. Layanan Aksesibilitas hanya dipakai untuk "
                + "menekan tombol \"Hapus cache\" di Pengaturan dan tidak membaca atau mengirim data pribadi. Tidak ada iklan, tidak ada pelacak.",
                13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        about.addView(Ui.ghost(this, "Pusat Izin", v -> startActivity(new Intent(this, PermissionsActivity.class))),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(about, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
    }

    @Override
    protected void onResume() {
        super.onResume();
        wlInfo.setText(Prefs.getSet(this, Prefs.WHITELIST).size() + " aplikasi tidak akan ditutup atau dibersihkan.");
        batteryHint.setVisibility(Perm.batteryWhitelist(this) ? View.GONE : View.VISIBLE);
    }
}
