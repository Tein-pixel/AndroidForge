package com.tein.booster;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Adapter daftar aplikasi (ikon + nama + info + centang opsional). View didaur ulang agar scroll mulus. */
public class AppAdapter extends BaseAdapter {
    private final Context ctx;
    private final boolean checkable;
    private final List<Apps.Item> items = new ArrayList<Apps.Item>();
    private final Set<String> checked = new HashSet<String>();

    private static final class Holder {
        ImageView icon;
        TextView name;
        TextView sub;
        TextView right;
        CheckBox check;
    }

    public AppAdapter(Context c, boolean checkable) {
        this.ctx = c;
        this.checkable = checkable;
    }

    public void setItems(List<Apps.Item> l) {
        items.clear();
        items.addAll(l);
        notifyDataSetChanged();
    }

    public Set<String> checked() { return checked; }

    public void setChecked(Set<String> s) {
        checked.clear();
        checked.addAll(s);
        notifyDataSetChanged();
    }

    public boolean toggle(String pkg) {
        boolean now;
        if (checked.contains(pkg)) {
            checked.remove(pkg);
            now = false;
        } else {
            checked.add(pkg);
            now = true;
        }
        notifyDataSetChanged();
        return now;
    }

    @Override
    public int getCount() { return items.size(); }

    @Override
    public Apps.Item getItem(int i) { return items.get(i); }

    @Override
    public long getItemId(int i) { return i; }

    @Override
    public View getView(int pos, View convert, ViewGroup parent) {
        Holder h;
        if (convert == null) {
            h = new Holder();
            LinearLayout row = Ui.row(ctx);
            row.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 10), Ui.dp(ctx, 16), Ui.dp(ctx, 10));
            row.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            row.setBackground(Ui.ripple(ctx, Ui.rect(ctx, 0x00000000, 0), 0));
            h.icon = new ImageView(ctx);
            h.icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            row.addView(h.icon, new LinearLayout.LayoutParams(Ui.dp(ctx, 44), Ui.dp(ctx, 44)));
            LinearLayout mid = Ui.col(ctx);
            h.name = Ui.tvb(ctx, "", 15, Ui.TEXT);
            h.name.setSingleLine(true);
            h.sub = Ui.tv(ctx, "", 12, Ui.SUB);
            h.sub.setSingleLine(true);
            mid.addView(h.name);
            mid.addView(h.sub);
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
            mp.setMargins(Ui.dp(ctx, 12), 0, Ui.dp(ctx, 8), 0);
            row.addView(mid, mp);
            h.right = Ui.tvb(ctx, "", 13, Ui.CYAN);
            row.addView(h.right);
            h.check = new CheckBox(ctx);
            h.check.setClickable(false);
            h.check.setFocusable(false);
            row.addView(h.check);
            row.setTag(h);
            convert = row;
        } else {
            h = (Holder) convert.getTag();
        }
        Apps.Item it = items.get(pos);
        h.name.setText(it.label);
        h.sub.setText(it.sub);
        h.right.setText(it.right);
        h.check.setVisibility(checkable ? View.VISIBLE : View.GONE);
        h.check.setChecked(checked.contains(it.pkg));
        IconLoader.load(ctx, it.pkg, h.icon);
        return convert;
    }
}
