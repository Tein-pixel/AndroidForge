# Tein Booster

Aplikasi Android (Java, tanpa dependensi pihak ketiga, tanpa root) berisi kumpulan booster + **1-Tap Cache Cleaner**
yang membersihkan cache semua aplikasi otomatis lewat Layanan Aksesibilitas.
Min Android 7.0 (API 24), target API 34.

## Cara membuat APK

**A. Android Studio (paling mudah)**
1. `File > Open` pilih folder `TeinBooster` (hasil ekstrak ZIP), tunggu Gradle sync selesai (butuh internet sekali).
2. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
3. APK ada di `app/build/outputs/apk/debug/app-debug.apk` (sudah bertanda tangan debug, langsung bisa di-install).

**B. Command line** (JDK 17 + Android SDK, `ANDROID_HOME` terisi)
```
./gradlew assembleDebug
```
`gradle/wrapper/gradle-wrapper.jar` di proyek ini adalah bootstrap sederhana buatan sendiri (bukan jar resmi Gradle):
ia mengunduh Gradle 8.7 sesuai `gradle-wrapper.properties`. Jika ingin jar resmi: `gradle wrapper --gradle-version 8.7`.

**C. GitHub Actions**: unggah proyek ke repo GitHub, workflow `.github/workflows/build-apk.yml` otomatis membuat APK
(menu *Actions > Build APK > Artifacts*).

## Izin yang harus diaktifkan (menu **Pusat Izin** di aplikasi)
| Izin | Dipakai untuk |
|---|---|
| Aksesibilitas | 1-Tap Cache Cleaner (menekan "Hapus cache" di Pengaturan) |
| Akses Penggunaan | ukuran cache per aplikasi, daftar pemakaian |
| Akses semua file | Junk Cleaner, file besar, duplikat |
| Ubah pengaturan sistem | Hemat Baterai / kecerahan & timeout layar |
| Jangan Ganggu | Game Booster |
| Abaikan optimasi baterai | Auto Boost terjadwal |
| WRITE_SECURE_SETTINGS (opsional, 1x via ADB) | Turbo UI (animasi) & Private DNS sekali tekan |

Android 13+ (APK dipasang manual): jika tombol Aksesibilitas abu-abu / "Setelan dibatasi", buka *Info aplikasi Tein Booster >
menu ⋮ > Izinkan setelan terbatas*, lalu aktifkan lagi.

## Isi booster (semua nyata, tanpa root)
- **1-Tap Cache Cleaner** – per aplikasi: Info aplikasi → Penyimpanan → *Hapus cache*; layar progres menutupi proses; tidak pernah
  menyentuh "Hapus data". Didahului pemangkasan cache via API resmi `StorageManager`. Ada tombol *Lihat log* dan *mode debug*.
- **RAM Booster** – menutup proses latar (`killBackgroundProcesses`), RAM sebelum/sesudah diukur nyata; ada daftar putih.
- **Junk Cleaner** – pindai file .tmp/.log/thumbnail/unduhan gagal/APK sisa/folder kosong/cache eksternal, hapus sungguhan.
- **Penyimpanan** – kategori, file besar, duplikat (hash MD5).
- **Hemat Baterai** – profil Hemat/Ultra (kecerahan, timeout layar, sinkronisasi) + pulihkan; aplikasi terlama dipakai.
- **Pendingin** – pantau suhu baterai live, tutup aplikasi latar, ukur suhu sebelum/sesudah.
- **Game Booster** – tutup aplikasi latar + Jangan Ganggu lalu luncurkan game; DND dipulihkan saat kembali.
- **Manajer Aplikasi** – ukuran, buka, info, bersihkan cache, cadangkan APK, hapus instalan.
- **Network Booster** – tes unduh, latensi DNS (UDP), ping TCP, atur Private DNS.
- **Turbo UI** – skala animasi sistem. **Info Perangkat**. **Auto Boost** (terjadwal), ubin Quick Settings, pintasan ikon.

Tidak ada: overclock CPU/GPU, RAM tambahan/swap, "pendingin CPU" palsu, dll. — itu butuh root atau hanya tampilan kosong.

## Jika Cache Cleaner gagal di HP tertentu
Tampilan Pengaturan tiap merek berbeda. Buka *1-Tap Cache Cleaner > Lihat log* (berisi alasan gagal + teks layar yang terbaca),
salin, dan kirim agar kamus label bisa disesuaikan. Aktifkan *mode debug* untuk melihat proses langsung.

## Struktur
`app/src/main/java/com/tein/booster/` — `CleanerAccessibilityService` (inti cleaner), `Optimizer`, `FileScan`, `Net`,
`Apps`, `Sys`, `Perm`, layar-layar `*Activity`, view kustom (`GaugeView`, `LogoView`, `BarView`).
