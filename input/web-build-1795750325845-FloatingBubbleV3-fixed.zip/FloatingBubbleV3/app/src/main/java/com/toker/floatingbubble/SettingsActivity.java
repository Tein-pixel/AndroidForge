// SettingsActivity.java : java, Android 29+, com.toker.floatingbubble
// v3: polished settings UI matching screenshot design.
//   • BENTUK BUBBLE  — 4 shape cards (Lingkaran, Kotak, Bulat, Segitiga) with shape preview
//   • WARNA BUBBLE   — color swatch + label + Reset button
//   • TRANSPARANSI   — seek 0–100%
//   • SKALA UKURAN   — seek 40–100 dp
//   • UKURAN MENU    — seek 28–56 dp
//   • Crop line settings (collapsed section)
// Colors: dark navy background, cyan/teal accents, section headers uppercase cyan
package com.toker.floatingbubble;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {

    // ── color presets ─────────────────────────────────────────────────────────
    private static final int[] BUBBLE_COLORS = {
            0xFF00BCD4, // cyan   (default — matches screenshot "Biru")
            0xFF7B2FF7, // purple
            0xFF4FC3F7, // sky
            0xFFF44336, // red
            0xFF4CAF50, // green
            0xFFFF9800, // orange
            0xFFE91E63, // pink
            0xFFFFFFFF, // white
    };
    private static final String[] BUBBLE_COLOR_NAMES = {
            "Biru (default)", "Ungu", "Langit", "Merah",
            "Hijau", "Oranye", "Pink", "Putih"
    };

    private static final int[] LINE_COLORS = {
            0xFFFFFFFF, 0xFFFFFF00, 0xFF00FFFF, 0xFFFF6600, 0xFFFF3366
    };

    // ── state ─────────────────────────────────────────────────────────────────
    private int   selBubbleColor;
    private int   selBubbleColorIdx;
    private int   selLineColor;
    private int   selShape;

    // ── live preview views ────────────────────────────────────────────────────
    private View  colorSwatchView;
    private TextView colorNameTv;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(0xFF0D1520);

        selBubbleColor    = SharedPrefHelper.getBubbleColor(this);
        selShape          = SharedPrefHelper.getBubbleShape(this);
        selLineColor      = SharedPrefHelper.getLineColor(this);
        selBubbleColorIdx = findColorIdx(BUBBLE_COLORS, selBubbleColor, 0);

        // ── scroll root ───────────────────────────────────────────────────────
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF0D1520);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(px(16), px(0), px(16), px(60));

        // ── title bar (like screenshot) ───────────────────────────────────────
        addTitleBar(root);

        // ═══ BENTUK BUBBLE ════════════════════════════════════════════════════
        addSectionHeader(root, "BENTUK BUBBLE");
        addShapePicker(root);

        // ═══ WARNA BUBBLE ═════════════════════════════════════════════════════
        addSectionHeader(root, "WARNA BUBBLE");
        addColorRow(root);

        // ═══ TRANSPARANSI ═════════════════════════════════════════════════════
        addSectionHeader(root, "TRANSPARANSI");
        int savedAlpha = SharedPrefHelper.getBubbleAlpha(this);
        int initAlphaPct = Math.round(savedAlpha / 255f * 100f);
        SeekBar alphaBar  = addSliderRow(root, 0, 100, initAlphaPct, initAlphaPct + "%");

        // ═══ SKALA UKURAN ═════════════════════════════════════════════════════
        addSectionHeader(root, "SKALA UKURAN");
        int savedSize = SharedPrefHelper.getBubbleSizeDp(this);
        SeekBar sizeBar = addSliderRow(root, 40, 100, savedSize, savedSize + " dp");

        // ═══ UKURAN MENU ══════════════════════════════════════════════════════
        addSectionHeader(root, "UKURAN MENU");
        int savedMenu = SharedPrefHelper.getMenuSizeDp(this);
        SeekBar menuBar = addSliderRow(root, 28, 56, savedMenu, savedMenu + " dp");

        // ═══ Crop overlay ═════════════════════════════════════════════════════
        addSectionHeader(root, "CROP OVERLAY");
        float savedThick = SharedPrefHelper.getLineThicknessDp(this);
        SeekBar thickBar  = addSliderRow(root, 10, 40, (int)(savedThick * 10), savedThick + " dp");
        addSmallLabel(root, "Warna Garis");
        View[] lineDots = dotRow(root, LINE_COLORS, selLineColor, c -> selLineColor = c);

        // ═══ Save button ══════════════════════════════════════════════════════
        Button saveBtn = saveButton();
        saveBtn.setOnClickListener(v -> {
            int alphaPct = alphaBar.getProgress();
            int alphaVal = Math.round(alphaPct / 100f * 255f);

            SharedPrefHelper.saveBubbleAlpha(this,     Math.max(10, alphaVal));
            SharedPrefHelper.saveBubbleSizeDp(this,    sizeBar.getProgress());
            SharedPrefHelper.saveBubbleColor(this,     selBubbleColor);
            SharedPrefHelper.saveBubbleShape(this,     selShape);
            SharedPrefHelper.saveMenuSizeDp(this,      menuBar.getProgress());
            SharedPrefHelper.saveLineThicknessDp(this, (thickBar.getProgress()) / 10f);
            SharedPrefHelper.saveLineColor(this,       selLineColor);

            sendBroadcast(new Intent(BubbleService.ACTION_SETTINGS_CHANGED));
            Toast.makeText(this, "✓  Disimpan", Toast.LENGTH_SHORT).show();
            finish();
        });
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, px(50));
        saveLp.setMargins(0, px(28), 0, 0);
        root.addView(saveBtn, saveLp);

        scroll.addView(root);
        setContentView(scroll);

        // wire live label updates
        alphaBar.setOnSeekBarChangeListener(simple(v ->
                updateSliderLabel(alphaBar, v + "%")));
        sizeBar.setOnSeekBarChangeListener(simple(v ->
                updateSliderLabel(sizeBar, v + " dp")));
        menuBar.setOnSeekBarChangeListener(simple(v ->
                updateSliderLabel(menuBar, v + " dp")));
        thickBar.setOnSeekBarChangeListener(simple(v ->
                updateSliderLabel(thickBar, (v / 10f) + " dp")));
    }

    // ── title bar ─────────────────────────────────────────────────────────────

    private void addTitleBar(LinearLayout p) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF0D1520);
        bar.setPadding(px(14), px(14), px(14), px(14));

        // blue dot
        View dot = new View(this);
        dot.setBackgroundColor(0xFF00BCD4);
        dot.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setOval(0,0,v.getWidth(),v.getHeight()); }
        });
        dot.setClipToOutline(true);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(px(10), px(10));
        dotLp.setMargins(0, 0, px(10), 0);
        bar.addView(dot, dotLp);

        TextView title = new TextView(this);
        title.setText("Pengaturan Bubble");
        title.setTextColor(Color.WHITE);
        title.setTextSize(16f);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // close button (X)
        Button closeBtn = iconBtn("×");
        closeBtn.setOnClickListener(v -> finish());
        bar.addView(closeBtn);

        p.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    // ── shape picker ──────────────────────────────────────────────────────────

    private void addShapePicker(LinearLayout p) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, px(8), 0, px(16));
        row.setLayoutParams(rowLp);

        int[] shapes = {
                SharedPrefHelper.SHAPE_CIRCLE,
                SharedPrefHelper.SHAPE_SQUARE,
                SharedPrefHelper.SHAPE_ROUNDED,
                SharedPrefHelper.SHAPE_TRIANGLE
        };
        String[] labels = {"Lingkaran", "Kotak", "Bulat", "Segitiga"};
        View[] cards = new View[shapes.length];

        for (int i = 0; i < shapes.length; i++) {
            final int shape = shapes[i];
            LinearLayout card = makeShapeCard(shape, labels[i], shape == selShape);
            cards[i] = card;
            int finalI = i;
            card.setOnClickListener(v -> {
                selShape = shape;
                for (int j = 0; j < cards.length; j++) {
                    setCardSelected(cards[j], j == finalI);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, px(96), 1f);
            lp.setMargins(px(4), 0, px(4), 0);
            row.addView(card, lp);
        }
        p.addView(row);
    }

    private LinearLayout makeShapeCard(int shape, String label, boolean selected) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        int bg = selected ? 0xFF162535 : 0xFF111C2A;
        card.setBackgroundColor(bg);
        card.setClipToOutline(true);
        card.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), px(10));
            }
        });
        if (selected) {
            card.setElevation(px(2));
        }

        // shape preview (mini canvas view)
        View preview = makeShapePreview(shape, selected);
        card.addView(preview, new LinearLayout.LayoutParams(px(36), px(36)));

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(selected ? 0xFF00BCD4 : 0xFF888888);
        lbl.setTextSize(11f);
        lbl.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lblLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lblLp.setMargins(0, px(6), 0, 0);
        card.addView(lbl, lblLp);

        // bottom teal border if selected
        View border = new View(this);
        border.setBackgroundColor(selected ? 0xFF00BCD4 : Color.TRANSPARENT);
        card.addView(border, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, px(3)));

        return card;
    }

    private View makeShapePreview(int shape, boolean selected) {
        int color = selected ? 0xFF00BCD4 : 0xFF44607A;
        return new View(this) {
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            final Path path = new Path();
            @Override protected void onDraw(Canvas c) {
                p.setColor(color);
                p.setStyle(Paint.Style.FILL);
                int w = getWidth(); int h = getHeight();
                float pad = w * 0.1f;
                switch (shape) {
                    case SharedPrefHelper.SHAPE_CIRCLE:
                        c.drawCircle(w/2f, h/2f, w/2f - pad, p); break;
                    case SharedPrefHelper.SHAPE_SQUARE:
                        c.drawRect(pad, pad, w-pad, h-pad, p); break;
                    case SharedPrefHelper.SHAPE_ROUNDED:
                        c.drawRoundRect(new RectF(pad, pad, w-pad, h-pad), w*0.28f, w*0.28f, p); break;
                    case SharedPrefHelper.SHAPE_TRIANGLE:
                        path.reset();
                        path.moveTo(w/2f, pad);
                        path.lineTo(w-pad, h-pad);
                        path.lineTo(pad, h-pad);
                        path.close();
                        c.drawPath(path, p); break;
                }
            }
        };
    }

    private void setCardSelected(View card, boolean selected) {
        if (!(card instanceof LinearLayout)) return;
        LinearLayout card2 = (LinearLayout) card;
        card2.setBackgroundColor(selected ? 0xFF162535 : 0xFF111C2A);
        // update label color and border
        for (int i = 0; i < card2.getChildCount(); i++) {
            View ch = card2.getChildAt(i);
            if (ch instanceof TextView) {
                ((TextView) ch).setTextColor(selected ? 0xFF00BCD4 : 0xFF888888);
            } else if (i == card2.getChildCount() - 1) { // last = border
                ch.setBackgroundColor(selected ? 0xFF00BCD4 : Color.TRANSPARENT);
            }
        }
        card2.invalidate();
    }

    // ── color row ─────────────────────────────────────────────────────────────

    private void addColorRow(LinearLayout p) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(0xFF111C2A);
        row.setClipToOutline(true);
        row.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), px(10));
            }
        });
        row.setPadding(px(14), px(12), px(14), px(12));

        // large swatch
        colorSwatchView = new View(this);
        colorSwatchView.setBackgroundColor(selBubbleColor);
        colorSwatchView.setClipToOutline(true);
        colorSwatchView.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), px(6));
            }
        });
        LinearLayout.LayoutParams swatchLp = new LinearLayout.LayoutParams(px(52), px(52));
        swatchLp.setMargins(0, 0, px(14), 0);
        row.addView(colorSwatchView, swatchLp);

        // name
        colorNameTv = new TextView(this);
        colorNameTv.setText(BUBBLE_COLOR_NAMES[selBubbleColorIdx]);
        colorNameTv.setTextColor(Color.WHITE);
        colorNameTv.setTextSize(14f);
        row.addView(colorNameTv, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // reset button
        Button resetBtn = new Button(this);
        resetBtn.setText("Reset");
        resetBtn.setTextColor(0xFF00BCD4);
        resetBtn.setBackground(null);
        resetBtn.setTextSize(13f);
        resetBtn.setAllCaps(false);
        resetBtn.setOnClickListener(v -> {
            selBubbleColor    = BUBBLE_COLORS[0];
            selBubbleColorIdx = 0;
            colorSwatchView.setBackgroundColor(selBubbleColor);
            colorNameTv.setText(BUBBLE_COLOR_NAMES[0]);
        });
        row.addView(resetBtn);

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, px(8), 0, px(8));
        p.addView(row, rowLp);

        // color dot row below
        addSmallLabel(p, "Pilih Warna");
        dotRow(p, BUBBLE_COLORS, selBubbleColor, c -> {
            selBubbleColor    = c;
            selBubbleColorIdx = findColorIdx(BUBBLE_COLORS, c, 0);
            colorSwatchView.setBackgroundColor(c);
            colorNameTv.setText(BUBBLE_COLOR_NAMES[selBubbleColorIdx]);
        });
    }

    // ── slider row ────────────────────────────────────────────────────────────

    private final java.util.Map<SeekBar, TextView> sliderLabels = new java.util.HashMap<>();

    private SeekBar addSliderRow(LinearLayout p, int min, int max, int current, String initialLabel) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);

        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(current - min, max - min)));
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF00BCD4));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFF00BCD4));
        wrap.addView(sb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView lbl = new TextView(this);
        lbl.setText(initialLabel);
        lbl.setTextColor(0xFF00BCD4);
        lbl.setTextSize(12f);
        lbl.setMinWidth(px(52));
        lbl.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lblLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lblLp.setMargins(px(10), 0, 0, 0);
        wrap.addView(lbl, lblLp);

        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wrapLp.setMargins(0, px(8), 0, px(16));
        p.addView(wrap, wrapLp);

        // Store mapping so seekbar listener can find its label
        sliderLabels.put(sb, lbl);

        // Override getProgress to include min offset
        sb.setTag(min); // store min as tag
        return sb;
    }

    private void updateSliderLabel(SeekBar sb, String text) {
        TextView lbl = sliderLabels.get(sb);
        if (lbl != null) lbl.setText(text);
    }

    // ── dot row ───────────────────────────────────────────────────────────────

    private View[] dotRow(LinearLayout p, int[] colors, int current, ColorCb cb) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, px(4), 0, px(12));

        View[] dots = new View[colors.length];
        for (int i = 0; i < colors.length; i++) {
            final int c = colors[i];
            View dot = new View(this);
            int sz = px(36);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sz, sz);
            lp.setMargins(px(4), 0, px(4), 0);
            dot.setLayoutParams(lp);
            dot.setBackgroundColor(c);
            dot.setClipToOutline(true);
            dot.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) {
                    o.setOval(0, 0, v.getWidth(), v.getHeight());
                }
            });
            if (c == current) { dot.setScaleX(1.3f); dot.setScaleY(1.3f); }
            dots[i] = dot;
            dot.setOnClickListener(v -> {
                for (View d : dots) { d.setScaleX(1f); d.setScaleY(1f); }
                dot.setScaleX(1.3f); dot.setScaleY(1.3f);
                cb.on(c);
            });
            row.addView(dot);
        }
        hsv.addView(row);
        p.addView(hsv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return dots;
    }

    // ── builder helpers ───────────────────────────────────────────────────────

    private void addSectionHeader(LinearLayout p, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(0xFF00BCD4);
        tv.setTextSize(12f);
        tv.setLetterSpacing(0.1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, px(22), 0, px(6));
        tv.setLayoutParams(lp);
        p.addView(tv);
    }

    private void addSmallLabel(LinearLayout p, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(0xFF666D80);
        tv.setTextSize(12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, px(8), 0, px(2));
        tv.setLayoutParams(lp);
        p.addView(tv);
    }

    private Button iconBtn(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(0xFF888888);
        btn.setBackground(null);
        btn.setTextSize(18f);
        btn.setAllCaps(false);
        btn.setPadding(px(8), 0, px(4), 0);
        return btn;
    }

    private Button saveButton() {
        Button btn = new Button(this);
        btn.setText("Simpan");
        btn.setTextColor(Color.WHITE);
        btn.setAllCaps(false);
        btn.setTextSize(15f);
        btn.setBackgroundColor(0xFF00BCD4);
        btn.setClipToOutline(true);
        btn.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), px(8));
            }
        });
        return btn;
    }

    // ── utils ─────────────────────────────────────────────────────────────────

    private interface ColorCb { void on(int color); }

    private interface ProgCb { void on(int v); }

    private SeekBar.OnSeekBarChangeListener simple(ProgCb cb) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean user) {
                int min = sb.getTag() instanceof Integer ? (int) sb.getTag() : 0;
                cb.on(v + min);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        };
    }

    private static int findColorIdx(int[] arr, int color, int def) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == color) return i;
        return def;
    }

    private int px(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
