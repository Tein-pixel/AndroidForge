// TextExtractorService.java : java, Android 29+, com.toker.floatingbubble
// AccessibilityService with two jobs:
//   1. Hides this app's task from the system recents screen (same as old RecentsHiderService).
//   2. On ACTION_CROP_CONFIRM broadcast (Rect extras) → walks the accessibility window tree,
//      collects visible node text whose bounding box intersects the crop rect, then broadcasts
//      ACTION_TEXT_EXTRACTED with the joined text back to BubbleService.
// canRetrieveWindowContent="true" required in accessibility_service_config.xml.
package com.toker.floatingbubble;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.Build;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

public class TextExtractorService extends AccessibilityService {

    // ── broadcast actions & extras ────────────────────────────────────────────

    /** Sent by BubbleService when user confirms the crop area. */
    public static final String ACTION_CROP_CONFIRM   = "com.toker.floatingbubble.CROP_CONFIRM";

    /** Sent by this service back to BubbleService with the extracted text. */
    public static final String ACTION_TEXT_EXTRACTED = "com.toker.floatingbubble.TEXT_EXTRACTED";

    public static final String EXTRA_RECT_LEFT   = "rect_left";
    public static final String EXTRA_RECT_TOP    = "rect_top";
    public static final String EXTRA_RECT_RIGHT  = "rect_right";
    public static final String EXTRA_RECT_BOTTOM = "rect_bottom";
    public static final String EXTRA_TEXT        = "text";

    // ── lifecycle ─────────────────────────────────────────────────────────────

    private BroadcastReceiver cropReceiver;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        cropReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (!ACTION_CROP_CONFIRM.equals(intent.getAction())) return;
                Rect rect = new Rect(
                        intent.getIntExtra(EXTRA_RECT_LEFT,   0),
                        intent.getIntExtra(EXTRA_RECT_TOP,    0),
                        intent.getIntExtra(EXTRA_RECT_RIGHT,  0),
                        intent.getIntExtra(EXTRA_RECT_BOTTOM, 0));
                String extracted = extractFromRect(rect);
                Intent reply = new Intent(ACTION_TEXT_EXTRACTED);
                reply.putExtra(EXTRA_TEXT, extracted);
                sendBroadcast(reply);
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_CROP_CONFIRM);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(cropReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(cropReceiver, filter);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cropReceiver != null) {
            try { unregisterReceiver(cropReceiver); } catch (Exception ignored) {}
        }
    }

    // ── text extraction ───────────────────────────────────────────────────────

    /**
     * Walks the accessibility tree of the currently active window.
     * Collects text from leaf nodes whose on-screen bounds intersect {@code sel}.
     * Returns joined text, or empty string if accessibility tree is unavailable.
     */
    private String extractFromRect(Rect sel) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "";
        List<String> pieces = new ArrayList<>();
        collectText(root, sel, pieces);
        root.recycle();
        return join(pieces);
    }

    private void collectText(AccessibilityNodeInfo node, Rect sel, List<String> out) {
        if (node == null) return;

        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);

        if (!Rect.intersects(bounds, sel)) {
            node.recycle();
            return;
        }

        // leaf node with text → collect
        if (node.getChildCount() == 0) {
            CharSequence text = node.getText();
            CharSequence desc = node.getContentDescription();
            String content = (text != null && text.length() > 0)
                    ? text.toString().trim()
                    : (desc != null ? desc.toString().trim() : "");
            if (!content.isEmpty()) out.add(content);
        } else {
            // recurse into children
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) collectText(child, sel, out);
            }
        }
        // do NOT recycle `node` here if it was the root; caller recycles root.
        // child nodes were already recycled inside the recursive call above via the
        // top-of-function recycle on early-exit, but NOT recycled on the happy-path
        // because we iterate their children next. Java finaliser handles unreachable
        // AccessibilityNodeInfo objects, so this is safe — but to be explicit:
        // only the root is recycled by the caller; intermediate nodes are recycled
        // as we traverse by passing ownership down.
    }

    private static String join(List<String> parts) {
        if (parts.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(p);
        }
        return sb.toString();
    }

    // ── recents hider (original RecentsHiderService behaviour) ───────────────

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (!getPackageName().equals(event.getPackageName())) return;
        hideOwnTask();
    }

    private void hideOwnTask() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return;
        for (ActivityManager.AppTask t : am.getAppTasks()) {
            try { t.setExcludeFromRecents(true); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onInterrupt() {}

    // ── static helper ─────────────────────────────────────────────────────────

    /**
     * Returns true when this service is listed in the system's enabled-accessibility-services
     * setting, meaning the user has granted access and the service is running.
     */
    public static boolean isEnabled(Context ctx) {
        String myComp = ctx.getPackageName() + "/" + TextExtractorService.class.getName();
        String enabled = Settings.Secure.getString(
                ctx.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.contains(myComp);
    }
}
