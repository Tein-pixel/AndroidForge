// SharedPrefHelper.java : java, Android 29+, com.toker.floatingbubble
// v3: added bubble shape + menu icon size
package com.toker.floatingbubble;

import android.content.Context;
import android.content.SharedPreferences;

public final class SharedPrefHelper {

    private static final String PREFS = "bubble_settings";

    // ── keys ──────────────────────────────────────────────────────────────────
    public static final String KEY_BUBBLE_ALPHA    = "bubble_alpha";       // int  50-255
    public static final String KEY_BUBBLE_SIZE_DP  = "bubble_size_dp";     // int  40-100
    public static final String KEY_BUBBLE_COLOR    = "bubble_color";       // int  ARGB
    public static final String KEY_BUBBLE_SHAPE    = "bubble_shape";       // int  0-3
    public static final String KEY_LINE_THICK_X10  = "line_thickness_x10"; // int  dp*10
    public static final String KEY_LINE_COLOR      = "line_color";         // int  ARGB
    public static final String KEY_MENU_SIZE_DP    = "menu_size_dp";       // int  28-56
    public static final String KEY_TEXT_DEST       = "text_dest";           // int  0=search,1=AI,2=translate
    public static final String KEY_IMAGE_DEST      = "image_dest";          // int  0=search,1=AI,2=translate

    // ── destination constants (Scan Setting) ──────────────────────────────────
    public static final int DEST_SEARCH    = 0;
    public static final int DEST_AI        = 1;
    public static final int DEST_TRANSLATE = 2;

    // ── shape constants ───────────────────────────────────────────────────────
    public static final int SHAPE_CIRCLE   = 0;
    public static final int SHAPE_SQUARE   = 1;
    public static final int SHAPE_ROUNDED  = 2;
    public static final int SHAPE_TRIANGLE = 3;

    // ── defaults ──────────────────────────────────────────────────────────────
    private static final int   DEF_ALPHA      = 255;
    private static final int   DEF_SIZE_DP    = 56;
    private static final int   DEF_COLOR      = 0xFF00BCD4;   // cyan (like screenshot)
    private static final int   DEF_SHAPE      = SHAPE_CIRCLE;
    private static final int   DEF_THICK_X10  = 15;           // 1.5 dp
    private static final int   DEF_LINE_CLR   = 0xFFFFFFFF;
    private static final int   DEF_MENU_SIZE  = 35;
    private static final int   DEF_TEXT_DEST  = DEST_SEARCH;   // text OCR → Google Search
    private static final int   DEF_IMAGE_DEST = DEST_AI;       // screenshot → Google AI

    private SharedPrefHelper() {}

    private static SharedPreferences sp(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ── getters ───────────────────────────────────────────────────────────────
    public static int   getBubbleAlpha(Context ctx)       { return sp(ctx).getInt(KEY_BUBBLE_ALPHA,   DEF_ALPHA);     }
    public static int   getBubbleSizeDp(Context ctx)      { return sp(ctx).getInt(KEY_BUBBLE_SIZE_DP, DEF_SIZE_DP);   }
    public static int   getBubbleColor(Context ctx)       { return sp(ctx).getInt(KEY_BUBBLE_COLOR,   DEF_COLOR);     }
    public static int   getBubbleShape(Context ctx)       { return sp(ctx).getInt(KEY_BUBBLE_SHAPE,   DEF_SHAPE);     }
    public static float getLineThicknessDp(Context ctx)   { return sp(ctx).getInt(KEY_LINE_THICK_X10, DEF_THICK_X10) / 10f; }
    public static int   getLineColor(Context ctx)         { return sp(ctx).getInt(KEY_LINE_COLOR,     DEF_LINE_CLR);  }
    public static int   getMenuSizeDp(Context ctx)        { return sp(ctx).getInt(KEY_MENU_SIZE_DP,   DEF_MENU_SIZE); }
    public static int   getTextDest(Context ctx)          { return sp(ctx).getInt(KEY_TEXT_DEST,      DEF_TEXT_DEST); }
    public static int   getImageDest(Context ctx)         { return sp(ctx).getInt(KEY_IMAGE_DEST,     DEF_IMAGE_DEST); }

    // ── setters ───────────────────────────────────────────────────────────────
    public static void saveBubbleAlpha(Context ctx, int v)       { sp(ctx).edit().putInt(KEY_BUBBLE_ALPHA,   v).apply(); }
    public static void saveBubbleSizeDp(Context ctx, int v)      { sp(ctx).edit().putInt(KEY_BUBBLE_SIZE_DP, v).apply(); }
    public static void saveBubbleColor(Context ctx, int v)       { sp(ctx).edit().putInt(KEY_BUBBLE_COLOR,   v).apply(); }
    public static void saveBubbleShape(Context ctx, int v)       { sp(ctx).edit().putInt(KEY_BUBBLE_SHAPE,   v).apply(); }
    public static void saveLineThicknessDp(Context ctx, float v) { sp(ctx).edit().putInt(KEY_LINE_THICK_X10, (int)(v * 10)).apply(); }
    public static void saveLineColor(Context ctx, int v)         { sp(ctx).edit().putInt(KEY_LINE_COLOR,     v).apply(); }
    public static void saveMenuSizeDp(Context ctx, int v)        { sp(ctx).edit().putInt(KEY_MENU_SIZE_DP,   v).apply(); }
    public static void saveTextDest(Context ctx, int v)          { sp(ctx).edit().putInt(KEY_TEXT_DEST,      v).apply(); }
    public static void saveImageDest(Context ctx, int v)         { sp(ctx).edit().putInt(KEY_IMAGE_DEST,     v).apply(); }
}
