// GeminiWebViewActivity.java : java, Android 29+, com.toker.floatingbubble
// v3: added image attachment support (Gemini Vision).
//   EXTRA_IMAGE_PATH → show image preview chip, intercept onShowFileChooser,
//                      auto-respond with our image so Gemini gets it without user interaction.
//   Also handles WebChromeClient file chooser for manual gallery selection.
package com.toker.floatingbubble;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;

public class GeminiWebViewActivity extends Activity {

    public static final String EXTRA_QUERY      = "query";
    public static final String EXTRA_IMAGE_PATH = "image_path";   // v3

    private static final String GEMINI_URL = "https://gemini.google.com/app";

    private static final String UA =
            "Mozilla/5.0 (Linux; Android 11; Pixel 5) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36";

    private static final int REQ_FILE = 3001;

    private WebView  webView;
    private String   query     = "";
    private String   imagePath = null;
    private boolean  injected  = false;

    // For WebChromeClient file chooser callback
    private ValueCallback<Uri[]> filePathCallback;
    private Uri                  pendingImageUri;

    // ── lifecycle ─────────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(0xFF1A1A2E);

        query     = getIntent().getStringExtra(EXTRA_QUERY);
        imagePath = getIntent().getStringExtra(EXTRA_IMAGE_PATH);
        if (query == null) query = "";

        // If we have an image, convert to URI immediately so it's ready when needed
        if (imagePath != null && !imagePath.isEmpty()) {
            pendingImageUri = uriFromPath(imagePath);
        }

        // ── root ──────────────────────────────────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        // ── top bar ───────────────────────────────────────────────────────────
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0xFF1A1A2E);
        topBar.setPadding(px(10), px(10), px(12), px(10));

        ImageButton closeBtn = new ImageButton(this);
        closeBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeBtn.setBackgroundColor(Color.TRANSPARENT);
        closeBtn.setColorFilter(Color.WHITE);
        closeBtn.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(px(36), px(36));
        closeLp.setMargins(0, 0, px(8), 0);
        topBar.addView(closeBtn, closeLp);

        TextView titleTv = new TextView(this);
        titleTv.setText(imagePath != null ? "Gemini Vision" : "Gemini AI");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(16f);
        topBar.addView(titleTv, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // ── image preview chip (when image path provided) ─────────────────────
        if (pendingImageUri != null) {
            LinearLayout imgChip = new LinearLayout(this);
            imgChip.setOrientation(LinearLayout.HORIZONTAL);
            imgChip.setGravity(Gravity.CENTER_VERTICAL);
            imgChip.setBackgroundColor(0xFF0D1117);
            imgChip.setPadding(px(10), px(8), px(8), px(8));

            // thumbnail
            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Bitmap bmp = loadThumbnail(imagePath);
            if (bmp != null) thumb.setImageBitmap(bmp);
            else thumb.setImageResource(android.R.drawable.ic_menu_camera);
            LinearLayout.LayoutParams thumbLp = new LinearLayout.LayoutParams(px(52), px(52));
            thumbLp.setMargins(0, 0, px(10), 0);
            imgChip.addView(thumb, thumbLp);

            // label
            TextView lbl = new TextView(this);
            lbl.setText("Gambar siap — klik ikon 📎 di Gemini\natau gunakan tombol Kirim →");
            lbl.setTextColor(0xFFCCCCCC);
            lbl.setTextSize(11.5f);
            imgChip.addView(lbl, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button sendImgBtn = new Button(this);
            sendImgBtn.setText("Kirim →");
            sendImgBtn.setBackgroundColor(0xFF7B2FF7);
            sendImgBtn.setTextColor(Color.WHITE);
            sendImgBtn.setTextSize(11.5f);
            sendImgBtn.setAllCaps(false);
            sendImgBtn.setPadding(px(12), px(6), px(12), px(6));
            sendImgBtn.setOnClickListener(v -> triggerImageAttach());
            imgChip.addView(sendImgBtn);

            root.addView(imgChip, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        // ── text query chip ───────────────────────────────────────────────────
        if (!query.isEmpty()) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setBackgroundColor(0xFF0A0A14);
            chip.setPadding(px(12), px(8), px(8), px(8));

            TextView queryTv = new TextView(this);
            String display = query.length() > 110 ? query.substring(0, 110) + "…" : query;
            queryTv.setText(display);
            queryTv.setTextColor(0xFFCCCCCC);
            queryTv.setTextSize(12f);
            queryTv.setMaxLines(2);
            chip.addView(queryTv, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button copyBtn = new Button(this);
            copyBtn.setText("Salin");
            copyBtn.setBackground(null);
            copyBtn.setTextColor(0xFF9B59FF);
            copyBtn.setTextSize(11.5f);
            copyBtn.setAllCaps(false);
            copyBtn.setOnClickListener(v -> copyToClipboard());
            chip.addView(copyBtn);

            Button sendBtn = new Button(this);
            sendBtn.setText("Kirim →");
            sendBtn.setBackgroundColor(0xFF7B2FF7);
            sendBtn.setTextColor(Color.WHITE);
            sendBtn.setTextSize(11.5f);
            sendBtn.setAllCaps(false);
            sendBtn.setPadding(px(14), px(6), px(14), px(6));
            sendBtn.setOnClickListener(v -> injectText());
            chip.addView(sendBtn);

            root.addView(chip, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        // ── webview ───────────────────────────────────────────────────────────
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setSupportZoom(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setUserAgentString(UA);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!query.isEmpty() && !injected) {
                    view.postDelayed(() -> injectText(), 2200);
                }
                // If image pending, try to auto-trigger attachment after page load
                if (pendingImageUri != null && !injected) {
                    view.postDelayed(() -> triggerImageAttach(), 2500);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv,
                    ValueCallback<Uri[]> fileCb,
                    FileChooserParams params) {
                // Cancel any pending callback
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = fileCb;

                if (pendingImageUri != null) {
                    // Auto-respond with our pre-captured image
                    Uri img = pendingImageUri;
                    pendingImageUri = null;
                    filePathCallback.onReceiveValue(new Uri[]{img});
                    filePathCallback = null;
                    injected = true;
                    return true;
                }

                // Otherwise open gallery manually
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Pilih Gambar"), REQ_FILE);
                return true;
            }
        });

        webView.loadUrl(GEMINI_URL);

        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    // ── image attachment trigger ───────────────────────────────────────────────

    /**
     * Tries to find and click Gemini's image/attachment input via JS.
     * Gemini's known file input selectors as of 2025–2026.
     * Falls back gracefully — user sees the chip and can click Gemini's button manually.
     */
    private void triggerImageAttach() {
        if (webView == null || pendingImageUri == null) return;
        String js =
            "(function(){"
            + "var selectors=["
            + "  'input[type=file]',"
            + "  'button[aria-label*=\"image\"]',"
            + "  'button[aria-label*=\"Upload\"]',"
            + "  'button[aria-label*=\"Attach\"]',"
            + "  '.upload-button',"
            + "  '[data-tooltip*=\"image\"]'"
            + "];"
            + "for(var i=0;i<selectors.length;i++){"
            + "  var el=document.querySelector(selectors[i]);"
            + "  if(el){el.click();return 'clicked';}"
            + "}"
            + "return 'not_found';"
            + "})()";
        webView.evaluateJavascript(js, result -> {});
    }

    // ── text injection ────────────────────────────────────────────────────────

    private void injectText() {
        if (webView == null || query.isEmpty()) return;
        injected = true;
        String safe = query
                .replace("\\", "\\\\")
                .replace("'",  "\\'")
                .replace("\n", "\\n")
                .replace("\r", "");
        String js =
            "(function(){"
            + "var selectors=["
            + "  '[aria-label=\"Enter a prompt here\"]',"
            + "  'p[data-placeholder]',"
            + "  '.ql-editor',"
            + "  '[contenteditable=true]',"
            + "  'textarea'"
            + "];"
            + "for(var i=0;i<selectors.length;i++){"
            + "  var el=document.querySelector(selectors[i]);"
            + "  if(el){"
            + "    el.focus();"
            + "    if(el.tagName==='TEXTAREA'){el.value='" + safe + "';}"
            + "    else{el.textContent='" + safe + "';}"
            + "    el.dispatchEvent(new Event('input',{bubbles:true}));"
            + "    el.dispatchEvent(new Event('change',{bubbles:true}));"
            + "    return 'ok';"
            + "  }"
            + "}"
            + "return 'miss';"
            + "})()";
        webView.evaluateJavascript(js, result -> runOnUiThread(() -> {
            if (!"\"ok\"".equals(result)) {
                copyToClipboard();
                Toast.makeText(this,
                        "Auto-inject gagal — teks sudah disalin, tempel manual",
                        Toast.LENGTH_LONG).show();
            }
        }));
    }

    private void copyToClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("gemini_query", query));
    }

    // ── utils ─────────────────────────────────────────────────────────────────

    private Uri uriFromPath(String path) {
        if (path == null) return null;
        try {
            File f = new File(path);
            if (!f.exists()) return null;
            // Try FileProvider first; fall back to plain URI
            try {
                return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            } catch (Exception ex) {
                return Uri.fromFile(f);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private Bitmap loadThumbnail(String path) {
        if (path == null) return null;
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 4;
            return BitmapFactory.decodeFile(path, opts);
        } catch (Exception e) {
            return null;
        }
    }

    private int px(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
