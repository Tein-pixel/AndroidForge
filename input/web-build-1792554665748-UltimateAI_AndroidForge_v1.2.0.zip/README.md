# ChatAI Ultimate — AndroidForge project

**Project type:** Android native · Kotlin · Jetpack Compose · Material 3  
**Minimum Android:** API 24 / Android 7.0  
**Target SDK:** 34
**Build toolchain:** Android Gradle Plugin 8.7.3 + Gradle 8.9 + JDK 17  
**Package:** `com.teinzz.aichat`
**Source revision:** 1.2.0 (UI cleanup + model catalog refresh)

This is a source project ZIP intended for an AndroidForge Gradle build. It is not an APK, and no API keys are included.

## Update 1.2.0

- Cleaner ChatGPT/Gemini-inspired composer: removed the distracting disclaimer and mode explanation under the input; shortened the mode chips.
- Simplified the top model selector to show only the active model name.
- Reworked the model sheet for scrolling on small screens, clearer contrast, one concise model description, and separate compact badges for price/access and image support.
- Updated the empty-chat heading and input placeholder to Indonesian; changed the missing-key banner to a neutral theme-aware surface.
- Refreshed the model catalogue using current official provider pages. Gemini 3.8 Flash is the default; Gemini 3.6 Flash is kept as a free-tier chat alternative, but Google Search grounding is unavailable on its Free Tier. Gemini 4 Argon is marked paid-only. OpenRouter's current Nemotron IDs are used, and text-only models are no longer labelled as vision-capable.
- Version bumped to 1.2.0 / versionCode 4. Existing chat history, attachments, camera, settings, provider keys, streaming, reasoning/research modes, and Artifacts are preserved.

## Main features in this build

- Chat-style layout with light/dark/system theme, model picker, welcome suggestions, streamed AI responses, basic Markdown and copyable code blocks.
- Room conversation history with grouped drawer, search, rename/delete, new chat and selected model stored per conversation.
- Settings for Gemini, Groq, and OpenRouter API keys using AndroidX EncryptedSharedPreferences; theme preference uses DataStore.
- Provider-key connection checks use provider model/auth endpoints (no text generation request), so the test itself does not consume output tokens.
- SSE response parsing for Gemini `streamGenerateContent` and OpenAI-compatible Groq/OpenRouter `chat/completions` endpoints.
- Gallery image attach and JPEG compression; PDF, TXT, CSV and DOCX text extraction; CameraX preview, touch-to-focus, pinch zoom, camera switch, flash mode and retake/use-photo flow.
- **Artifacts workspace:** AI-generated single-page HTML/CSS/JavaScript apps using the currently selected provider and model; Preview, Code and Split View; edit source; run updated source; copy code; import/export `.html`; rename and save projects locally; reopen and delete saved projects. Revision prompts include the current source so the model can update it instead of starting from scratch.
- Artifact previews run in a WebView with JavaScript enabled for the artifact, but file access and content-provider access are disabled, mixed content is blocked, multiple windows are disabled, and no JavaScript bridge into the host app is exposed. External HTTP(S) links open outside the preview. Do not paste secrets into an artifact, and review generated code before using it.
- Free-model filter and labels. The app does **not** claim that every account has a free quota; provider limits, billing and per-model eligibility can change.

## Build in AndroidForge

1. Upload this ZIP, then choose the Android/Gradle project option if the builder asks. The archive already places `settings.gradle`, `build.gradle`, and `app/` at its root.
2. If AndroidForge asks for a project folder instead of a ZIP, extract the archive and select the directory containing `settings.gradle`.
3. Let AndroidForge resolve Maven dependencies and run the Gradle build. Compile SDK 35 and JDK 17 are required; target SDK is 34. The root plugin version is pinned to Android Gradle Plugin 8.7.3, which is compatible with AndroidForge’s system Gradle 8.9. Do not let AndroidForge auto-upgrade AGP to 8.9.2 unless it also uses Gradle 8.11.1 or newer.
4. Install the generated APK, open **Settings**, enter your own provider API key, press **Save key**, then **Test connection**.

No Gradle wrapper JAR or Android SDK is bundled; this is intentional for AndroidForge legacy mode, which uses its system Gradle 8.9. This runtime did not have Gradle or Android SDK installed, so the project could not be compiled here. A successful AndroidForge build is not claimed until its build result is checked. If the builder reports a dependency, SDK, or Kotlin compile error, use the exact error log to patch the project rather than changing arbitrary versions.

## Current model catalogue notes (checked 21 October 2026)

- **Gemini:** `gemini-3.8-flash` is the default stable model. Google documents a free tier for this model, but Google Search grounding is unavailable on its free tier. `gemini-3.6-flash` is retained as a previous-generation chat alternative; its Free Tier also does not support Google Search grounding. Gemini 4 Argon is paid-only. `gemini-3.1-flash-lite` has a free tier but does not have free-tier Google Search grounding. Limits and account eligibility are controlled by Google.
- **Groq:** the catalog uses the currently listed `openai/gpt-oss-120b`, `openai/gpt-oss-20b`, and `qwen/qwen3.8-27b` text models. Access and pricing follow the active Groq account and catalog.
- **OpenRouter:** includes the dynamic `openrouter/free` router and current NVIDIA free endpoints. Free model IDs, limits, and provider availability can change. Paid/usage-based models remain hidden unless the user enables the paid-model switch.
- **Privacy:** OpenRouter's free Nemotron endpoint warns that submitted data may be logged and used to improve provider products. Do not submit sensitive or confidential data through a free endpoint unless its current terms are acceptable to you.

A provider cannot always be classified as “free key” versus “paid key” just by inspecting the string. The app labels its curated model catalogue and checks whether credentials are accepted; billing tier, remaining quota, and model entitlement are controlled by the provider dashboard.

## Artifacts usage

1. Tap the **code** icon in the chat top bar.
2. Describe the website, calculator, mini-tool or game, then choose **Generate artifact**. Generation uses the API key and selected model already configured in Settings.
3. Switch between **Preview**, **Code**, and **Split View**. Edit HTML/CSS/JavaScript, then tap the play icon to run the latest editor contents in Preview.
4. Save projects locally, reopen them from the folder icon, copy code, import an HTML file, or export the current document.
5. To revise a saved/current artifact, describe the change in the prompt and tap **Revisi dengan AI**. The current source is passed as context (up to 90,000 characters).

Artifacts are a client-side HTML workspace, not a full Node/npm build environment: projects requiring server-side code, package installation, native Android APIs, or backend credentials will need a separate implementation. Generated HTML uses the model currently selected in ChatAI; model quality, API quotas, output limits and provider support apply.

## Research sources

- Gemini model list and model lifecycle: https://ai.google.dev/gemini-api/docs/models and https://ai.google.dev/gemini-api/docs/deprecations/
- Gemini pricing / free-tier qualification: https://ai.google.dev/gemini-api/docs/pricing
- Gemini SSE streaming endpoint: https://ai.google.dev/api/generate-content
- Groq supported models and replacement notices: https://console.groq.com/docs/models and https://console.groq.com/docs/deprecations
- OpenRouter free-model catalogue and model details: https://openrouter.ai/collections/free-models and https://openrouter.ai/nvidia/nemotron-3.5-super-vl
- Compose drawer pattern: https://developer.android.com/develop/ui/compose/components/drawer
- CameraX focus, zoom and torch: https://developer.android.com/media/camera/camerax/configuration and https://developer.android.com/reference/androidx/camera/view/CameraController

## Important implementation limits

- “ChatAI Ultimate” is an independent client. It is not an official ChatGPT, Gemini, or Claude app, and it cannot inherit subscriptions from those apps. Each direct API has its own key, policy, limits and pricing.
- API keys are stored encrypted on-device, but API keys on a client device cannot be protected like secrets held on a private backend. Do not share the APK preloaded with personal keys.
- Free/paid labels are catalogue metadata, not a guarantee of quota, price, or access for an account. Recheck provider dashboards before heavy use.
- Image inputs are passed only when the selected catalogue entry is marked as vision-capable. The send control is disabled with an explanatory message if the current model is text-only; select a model labelled GAMBAR. Some free router endpoints can change their supported modalities.
- The model chooser has a working switch to reveal/hide paid or usage-based entries. Model rows use compact access and image-support badges, with no duplicated recommendation text.
- Offline requests show a recoverable connection error; automatic background/offline request queueing is not implemented in this initial source build.
- Markdown supports common formatting and fenced code blocks; it is a lightweight renderer, not a full CommonMark implementation.

## Reasoning & Deep Research modes (added in this revision)

- **Berpikir Lebih Keras:** Gemini 3 requests use `generationConfig.thinkingConfig.thinkingLevel = HIGH`; Groq uses `reasoning_effort = high` where the selected model supports it; OpenRouter uses `reasoning.effort = high`. These are real provider request parameters, not a fake loading animation. If a selected route rejects the parameter, the app reports the provider error instead of pretending the setting succeeded.
- **Riset Mendalam:** Gemini requests enable Google's native `google_search` grounding tool; OpenRouter requests enable its `openrouter:web_search` and `openrouter:web_fetch` server tools. This is real provider-side web search, not a prompt-only claim. The app deliberately disables this mode for Groq because this project does not implement a Groq web-search tool loop. Important distinction: this client currently provides search-grounded research responses, not the separate long-running Gemini Deep Research / OpenAI Deep Research agent APIs that plan and execute extended autonomous jobs. Model/tool availability still depends on provider access and route support.
- Gemini grounding metadata and OpenRouter URL annotations are converted into a source list where the provider exposes them. Markdown source links can be opened by tapping them. Tool-based answers may be slower and web-search calls can be separately metered or billed. Google Search grounding is unavailable on the Gemini 3.6/3.8 Flash Free Tiers; use a Gemini API account with paid-tier grounding access or an OpenRouter model that supports web tools.
- A model's “Paling direkomendasikan”, “Penalaran kuat”, or similar label is a product hint—not an independently measured benchmark ranking. Model availability, pricing, and free quotas should be verified in the provider's console.
- Full assistant replies can now be copied, in addition to code block copying.

Official API docs consulted for these controls:
- Gemini thinking controls: https://ai.google.dev/gemini-api/docs/thinking
- Gemini Google Search grounding and source metadata: https://ai.google.dev/gemini-api/docs/google-search
- Groq reasoning effort: https://console.groq.com/docs/reasoning
- OpenRouter server tools / web search: https://openrouter.ai/docs/guides/features/server-tools/overview and https://openrouter.ai/tool/web-search/


## Build and validation status

The source ZIP structure and archive integrity are checked locally. A full Gradle build has not been run in this environment because Gradle and the Android SDK are not installed here. Upload this ZIP to AndroidForge and verify the build result before installing it. If AndroidForge reports a compile error, use the exact log to patch the source rather than arbitrarily changing the dependency versions.
