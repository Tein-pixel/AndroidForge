package com.teinzz.aichat.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Provider(val title: String, val apiKeyLabel: String) {
    GEMINI("Gemini · Google", "GEMINI_API_KEY"), GROQ("Groq", "GROQ_API_KEY"), OPENROUTER("OpenRouter", "OPENROUTER_API_KEY")
}

/** These modes change provider request parameters/tools; they are not animation-only UI states. */
enum class ChatMode(val title: String, val description: String) {
    NORMAL("Normal", "Respons seimbang untuk penggunaan sehari-hari."),
    THINK_HARDER("Berpikir Lebih Keras", "Meminta effort penalaran tinggi dari model yang mendukungnya."),
    DEEP_RESEARCH("Riset Mendalam", "Mengaktifkan pencarian web nyata dan sintesis sumber; biaya pencarian dapat berlaku.")
}

data class AiModel(
    val id: String,
    val name: String,
    val provider: Provider,
    /** Short, honest label shown in the model picker; never a guarantee of quota. */
    val badge: String,
    val freeTier: Boolean,
    val vision: Boolean = false,
    val description: String = ""
)

object ModelCatalog {
    // IDs checked against current provider model catalogs on 21 October 2026.
    // Availability and any free quota are still determined by each provider account.
    val all = listOf(
        AiModel("gemini-3.8-flash", "Gemini 3.8 Flash", Provider.GEMINI, "GRATIS*", true, true, "Model stabil untuk chat, coding, penalaran, dan gambar. Google Search memerlukan tier berbayar."),
        AiModel("gemini-4-argon", "Gemini 4 Argon", Provider.GEMINI, "BERBAYAR", false, true, "Model reasoning unggulan; API tidak tersedia pada Free Tier."),
        AiModel("gemini-3.6-flash", "Gemini 3.6 Flash", Provider.GEMINI, "GRATIS*", true, true, "Model generasi sebelumnya dengan akses chat gratis terbatas; Google Search grounding tidak tersedia pada Free Tier."),
        AiModel("gemini-3.1-flash-lite", "Gemini 3.1 Flash-Lite", Provider.GEMINI, "GRATIS*", true, true, "Model ringan untuk chat dan gambar; Google Search grounding memerlukan tier berbayar."),
        AiModel("gemini-3.1-pro-preview", "Gemini 3.1 Pro Preview", Provider.GEMINI, "PREVIEW", false, true, "Untuk tugas kompleks; preview dan kuota API dapat berubah."),

        AiModel("openai/gpt-oss-120b", "GPT-OSS 120B", Provider.GROQ, "BERBAYAR", false, false, "Model teks untuk tugas kompleks; tarif token mengikuti harga resmi Groq."),
        AiModel("openai/gpt-oss-20b", "GPT-OSS 20B", Provider.GROQ, "BERBAYAR", false, false, "Alternatif teks yang lebih ringan; tarif token mengikuti harga resmi Groq."),
        AiModel("qwen/qwen3.8-27b", "Qwen 3.8 27B", Provider.GROQ, "BERBAYAR", false, false, "Model teks pada katalog Groq; tarif token mengikuti harga resmi Groq."),

        AiModel("openrouter/free", "OpenRouter Free Router", Provider.OPENROUTER, "GRATIS*", true, true, "Memilih model gratis yang sesuai dengan permintaan; model tujuan bisa berubah."),
        AiModel("nvidia/nemotron-3.5-super-vl:free", "Nemotron 3.5 Super VL", Provider.OPENROUTER, "GRATIS*", true, true, "Model multimodal untuk teks, gambar, dan dokumen. Endpoint gratis memiliki batas serta ketentuan data tersendiri."),
        AiModel("nvidia/nemotron-3-ultra-550b-a55b:free", "Nemotron 3 Ultra", Provider.OPENROUTER, "GRATIS*", true, false, "Model teks untuk penalaran dan tugas bertahap; endpoint gratis dibatasi."),
        AiModel("nvidia/nemotron-3.5-lightning:free", "Nemotron 3.5 Lightning", Provider.OPENROUTER, "GRATIS*", true, false, "Model teks ringan untuk tugas bertahap; endpoint gratis dibatasi dan bisa berubah."),
        AiModel("minimax/minimax-m3.1-flash", "MiniMax M3.1 Flash", Provider.OPENROUTER, "BERBAYAR", false, true, "Model multimodal untuk coding dan tugas multi-langkah; biaya penggunaan berlaku."),
        AiModel("deepseek/deepseek-v4.1-flash", "DeepSeek V4.1 Flash", Provider.OPENROUTER, "CEK AKSES", false, true, "Ketersediaan ID dan dukungan gambar bergantung pada katalog/rute OpenRouter."),
        AiModel("anthropic/claude-sonnet-4.5", "Claude Sonnet 4.5", Provider.OPENROUTER, "BERBAYAR", false, true, "Model premium melalui OpenRouter; biaya penggunaan berlaku."),
        AiModel("openai/gpt-5-mini", "GPT-5 mini", Provider.OPENROUTER, "BERBAYAR", false, true, "Model premium melalui OpenRouter; biaya penggunaan berlaku.")
    )

    fun default() = all.first()
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: default()
}

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val modelId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,
    val content: String,
    val imagePath: String? = null,
    val fileName: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
