package com.teinzz.aichat.network

import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Streaming
import retrofit2.http.Url

interface AiApi {
    @Streaming
    @POST
    suspend fun stream(
        @Url url: String,
        @Header("Authorization") authorization: String?,
        @Header("x-goog-api-key") googleApiKey: String?,
        @Header("HTTP-Referer") referer: String?,
        @Header("X-Title") title: String?,
        @Body body: RequestBody
    ): Response<ResponseBody>

    @GET
    suspend fun probe(
        @Url url: String,
        @Header("Authorization") authorization: String?,
        @Header("x-goog-api-key") googleApiKey: String?,
        @Header("HTTP-Referer") referer: String?,
        @Header("X-Title") title: String?
    ): Response<ResponseBody>

    companion object {
        fun create(): AiApi = Retrofit.Builder()
            .baseUrl("https://api.openai.com/")
            .build().create(AiApi::class.java)
    }
}
