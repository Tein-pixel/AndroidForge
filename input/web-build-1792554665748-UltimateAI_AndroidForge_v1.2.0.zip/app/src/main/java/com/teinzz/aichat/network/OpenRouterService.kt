package com.teinzz.aichat.network

/** OpenRouter OpenAI-compatible streaming API and non-generating key check. */
object OpenRouterService {
    const val STREAM_URL = "https://openrouter.ai/api/v1/chat/completions"
    const val KEY_CHECK_URL = "https://openrouter.ai/api/v1/auth/key"
    const val REFERER = "https://example.com/chat-ai-ultimate"
    const val APP_TITLE = "ChatAI Ultimate"
}
