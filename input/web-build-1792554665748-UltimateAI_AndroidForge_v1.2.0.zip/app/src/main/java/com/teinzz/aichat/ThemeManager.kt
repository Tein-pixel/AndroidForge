package com.teinzz.aichat

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.teinzz.aichat.data.ChatMode
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "chat_ai_settings")

enum class ThemeMode { LIGHT, DARK, SYSTEM }

class ThemeManager(private val context: Context) {
    private val key = stringPreferencesKey("theme_mode")
    val theme = context.settingsStore.data.map { prefs ->
        runCatching { ThemeMode.valueOf(prefs[key] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM)
    }
    suspend fun setTheme(mode: ThemeMode) {
        context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).edit().putString("theme_mode", mode.name).apply()
        context.settingsStore.edit { it[key] = mode.name }
    }
    fun getInitialTheme(): ThemeMode = runCatching {
        ThemeMode.valueOf(context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).getString("theme_mode", "SYSTEM") ?: "SYSTEM")
    }.getOrDefault(ThemeMode.SYSTEM)
    private val prefs by lazy {
        val master = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(context, "secure_api_keys", master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    fun getApiKey(provider: com.teinzz.aichat.data.Provider): String = runCatching { prefs.getString(provider.name, "").orEmpty() }.getOrDefault("")
    fun setApiKey(provider: com.teinzz.aichat.data.Provider, value: String) { runCatching { prefs.edit().putString(provider.name, value.trim()).apply() } }
    fun getLastModel(): String = context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).getString("last_model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
    fun setLastModel(id: String) { context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).edit().putString("last_model", id).apply() }
    fun getLastChatMode(): ChatMode = runCatching {
        ChatMode.valueOf(context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).getString("last_chat_mode", "NORMAL") ?: "NORMAL")
    }.getOrDefault(ChatMode.NORMAL)
    fun setLastChatMode(mode: ChatMode) { context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).edit().putString("last_chat_mode", mode.name).apply() }
}
