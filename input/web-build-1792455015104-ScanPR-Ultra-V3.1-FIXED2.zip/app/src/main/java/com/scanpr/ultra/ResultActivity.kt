// File: app/src/main/java/com/scanpr/ultra/ResultActivity.kt
package com.scanpr.ultra

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.scanpr.ultra.data.ScanHistory
import com.scanpr.ultra.databinding.ActivityResultBinding
import com.scanpr.ultra.repository.ScanRepository
import com.scanpr.ultra.utils.AiResult
import com.scanpr.ultra.utils.ImageUtils
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.viewmodel.ResultViewModel
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ResultActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_OCR = "ocr_text"; const val EXTRA_IMAGE_URI = "image_uri"; const val EXTRA_ANSWER = "answer"
        const val EXTRA_STEPS = "steps_json"; const val EXTRA_MAPEL = "mapel"; const val EXTRA_MODEL = "model_used"; const val EXTRA_ID = "history_id"
    }
    private lateinit var binding: ActivityResultBinding
    private val vm: ResultViewModel by viewModels()
    private lateinit var repository: ScanRepository
    private var imageUri = ""
    private var lastResult: AiResult? = null
    private var alreadySaved = false

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater); setContentView(binding.root)
        repository = ScanRepository(this)
        imageUri = intent.getStringExtra(EXTRA_IMAGE_URI).orEmpty()
        ImageUtils.show(this, runCatching { Uri.parse(imageUri).takeIf { imageUri.isNotBlank() } }.getOrNull(), binding.resultImage)
        binding.resultToolbar.setNavigationOnClickListener { finish() }
        binding.ocrEditText.setText(intent.getStringExtra(EXTRA_OCR).orEmpty())
        binding.editOcrButton.setOnClickListener { binding.ocrEditText.requestFocus(); binding.ocrEditText.setSelection(binding.ocrEditText.text.length) }
        binding.stepsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.solveButton.setOnClickListener { vm.solve(binding.ocrEditText.text.toString()) }
        binding.copyButton.setOnClickListener { copyResult() }
        binding.shareButton.setOnClickListener { shareResult() }
        binding.saveButton.setOnClickListener { saveResult() }
        lifecycleScope.launch { repeatOnLifecycle(Lifecycle.State.STARTED) {
            launch { vm.result.collect { result -> if (result != null) renderResult(result) } }
            launch { vm.loading.collect { binding.aiProgress.visibility = if (it) android.view.View.VISIBLE else android.view.View.GONE; binding.solveButton.isEnabled = !it; if (it) binding.modelChip.text = "AI: memproses…" } }
        } }
        val savedAnswer = intent.getStringExtra(EXTRA_ANSWER).orEmpty()
        if (savedAnswer.isNotBlank()) {
            val steps = runCatching { val a = JSONArray(intent.getStringExtra(EXTRA_STEPS).orEmpty()); (0 until a.length()).map { a.optString(it) } }.getOrDefault(emptyList())
            vm.setResult(AiResult(savedAnswer, steps, intent.getStringExtra(EXTRA_MAPEL).orEmpty().ifBlank { "Umum" }, intent.getStringExtra(EXTRA_MODEL).orEmpty().ifBlank { "Riwayat" }, emptyList()))
            alreadySaved = true
            binding.saveButton.isEnabled = false
        } else if (binding.ocrEditText.text.isNotBlank()) vm.solve(binding.ocrEditText.text.toString())
    }

    private fun renderResult(result: AiResult) {
        lastResult = result
        binding.subjectChip.text = result.mapel
        binding.modelChip.text = "AI: ${result.modelUsed}"
        binding.answerText.text = result.jawabanAkhir
        binding.stepsRecyclerView.adapter = StepsAdapter(result.langkah)
        binding.methodsText.text = if (result.metodeAlternatif.isEmpty()) "" else "Metode alternatif: " + result.metodeAlternatif.joinToString(" • ")
    }

    private fun resultText(): String {
        val result = lastResult
        return "Soal:\n${binding.ocrEditText.text}\n\nJawaban:\n${result?.jawabanAkhir.orEmpty()}\n\nLangkah:\n${result?.langkah?.joinToString("\n").orEmpty()}"
    }
    private fun copyResult() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Scan PR", resultText()))
        Toast.makeText(this, "Hasil disalin.", Toast.LENGTH_SHORT).show()
    }
    private fun shareResult() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, resultText()), "Bagikan hasil"))
    }
    private fun saveResult() {
        if (alreadySaved) {
            Toast.makeText(this, "Hasil ini sudah tersimpan di riwayat.", Toast.LENGTH_SHORT).show()
            return
        }
        val result = lastResult ?: run { Toast.makeText(this, "Tunggu sampai hasil tersedia.", Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            runCatching {
                repository.save(ScanHistory(ocrText = binding.ocrEditText.text.toString(), answer = result.jawabanAkhir,
                    stepsJson = JSONArray(result.langkah).toString(), mapel = result.mapel, modelUsed = result.modelUsed, imageUri = imageUri))
            }.onSuccess { alreadySaved = true; binding.saveButton.isEnabled = false; Toast.makeText(this@ResultActivity, "Hasil disimpan ke riwayat.", Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(this@ResultActivity, "Gagal menyimpan riwayat.", Toast.LENGTH_SHORT).show() }
        }
    }

    private class StepsAdapter(private val items: List<String>) : RecyclerView.Adapter<StepsAdapter.StepViewHolder>() {
        class StepViewHolder(val text: TextView, val number: TextView, val line: android.view.View) : RecyclerView.ViewHolder(text.parent as android.view.View)
        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): StepViewHolder {
            val view = android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_step, parent, false)
            return StepViewHolder(view.findViewById(R.id.step_text), view.findViewById(R.id.step_number), view.findViewById(R.id.step_line))
        }
        override fun onBindViewHolder(holder: StepViewHolder, position: Int) { holder.number.text = (position + 1).toString(); holder.text.text = items[position]; holder.line.visibility = if (position == items.lastIndex) android.view.View.INVISIBLE else android.view.View.VISIBLE }
        override fun getItemCount() = items.size
    }
}
