package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

class ManhwaScraper {

    // Daftar Sumber Tercepat & Terpopuler
    private val targetUrls = listOf(
        // --- Madara Theme (Kiryuu, Cosmic, dll) ---
        "https://kiryuu.id/manga/?m_orderby=latest" to "Kiryuu",
        "https://04.cosmicscans.to/manga/?m_orderby=latest" to "Cosmic",
        "https://komikcast.site/daftar-komik/?order=update" to "Komikcast",
        "https://bacamanga.co/manga/?m_orderby=latest" to "BacaManga",
        "https://shinigami.id/manga/?m_orderby=latest" to "Shinigami",
        "https://komikstation.site/manga/?m_orderby=latest" to "KomikStation",
        "https://westmanga.id/manga/?m_orderby=latest" to "WestManga",
        "https://sekaikomik.github.io/manga/?m_orderby=latest" to "SekaiKomik",

        // --- Asura & Fast Scans ---
        "https://asuracomic.net/series?order=update" to "Asura",
        "https://flamecomics.xyz/series?order=update" to "FlameComics",
        "https://demonic-scans.com/series?order=update" to "DemonicScans",
        "https://zeroscans.com/series?order=update" to "ZeroScans",
        "https://rizfables.com/series?order=update" to "RizFables",
        "https://manahwa.com/series?order=update" to "ManaPlus",

        // --- English Aggregators ---
        "https://mangapill.com/manga?order=latest" to "MangaPill",
        "https://mangahere.cc/latest" to "MangaHere",
        "https://weebcentral.com/latest" to "WeebCentral",
        "https://ravenscans.com/series?order=update" to "RavenScans",
        "https://vymanga.com/manga?order=latest" to "VyManga",
        "https://muscans.com/series?order=update" to "MuScans",
        "https://kaliscab.com/manga?order=latest" to "Kaliscab",
        "https://olympus.pages.dev/manga?order=latest" to "Olympus"
    )

    suspend fun fetchLatest(): List<Manhwa> = withContext(Dispatchers.IO) {
        val allManhwa = mutableListOf<Manhwa>()

        for ((url, sourceName) in targetUrls) {
            try {
                // Header lengkap biar nggak dianggap bot
                val doc = Jsoup.connect(url)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                    .header("Accept-Language", "en-US,en;q=0.5")
                    .header("Referer", "https://www.google.com/")
                    .timeout(10000) // Timeout 10 detik biar nggak nge-hang
                    .ignoreHttpErrors(true)
                    .get()

                // Selector Kompatibel (Madara, Asura, & Generic)
                val elements = doc.select(".page-item-detail, .manga__item, .listupd .bs, .bsx, .grid > div, .series-card, .manga-card")

                for (el in elements) {
                    val title = el.select(".post-title h3 a, .manga__item-title a, .tt h4 a, .tt h3 a, .text-white, .series-title a, .manga-title a").text().trim()
                    val link = el.select(".post-title h3 a, .manga__item-title a, .tt h4 a, .tt h3 a, .text-white, .series-title a, .manga-title a").attr("href")
                    
                    var imgUrl = el.select("img").attr("data-src")
                    if (imgUrl.isNullOrEmpty() || !imgUrl.startsWith("http")) {
                        imgUrl = el.select("img").attr("src")
                    }
                    
                    val latestChapter = el.select(".chapter-item .btn-link, .list-chapter .chapter-item a, .epxs, .chapter-item a, .latest-chapter, .chapter").first()?.text()?.trim() ?: "Chapter Baru"

                    // Validasi
                    if (title.isNotEmpty() && link.isNotEmpty() && imgUrl.isNotEmpty()) {
                        allManhwa.add(Manhwa(title, link, imgUrl, latestChapter, sourceName))
                    }
                }
            } catch (e: Exception) {
                // Kalau satu web error, lanjut ke web berikutnya
                e.printStackTrace()
            }
        }
        
        // Hilangkan duplikat dan acak urutan biar campur
        allManhwa.distinctBy { it.link }.shuffled()
    }
}