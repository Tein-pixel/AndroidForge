package com.chesshack

import android.graphics.PointF
import android.graphics.Rect

/**
 * Converts UCI square notation to on-screen tap coordinates.
 *
 * chess.com renders the board with:
 *   - White at bottom: file a=left col, rank 1=bottom row
 *   - Black at bottom: file a=right col, rank 1=top row (flipped both axes)
 *
 * Screen Y increases downward. So rank 8 (top of board visually when white)
 * maps to small Y, rank 1 maps to large Y.
 */
class CoordinateMapper(
    private val boardRect: Rect,
    private val playingAsWhite: Boolean
) {
    private val sqW = boardRect.width() / 8f
    private val sqH = boardRect.height() / 8f

    fun squareToScreen(notation: String): PointF? {
        if (notation.length < 2) return null
        val file = notation[0] - 'a'   // 0=a .. 7=h
        val rank = notation[1] - '1'   // 0=rank1 .. 7=rank8

        val colIndex: Int   // screen column 0=left
        val rowIndex: Int   // screen row 0=top

        if (playingAsWhite) {
            colIndex = file           // a-file is leftmost column
            rowIndex = 7 - rank       // rank 8 is top (rowIndex 0), rank 1 is bottom (rowIndex 7)
        } else {
            colIndex = 7 - file       // board is flipped: h-file is leftmost
            rowIndex = rank           // rank 1 is top (rowIndex 0), rank 8 is bottom (rowIndex 7)
        }

        val x = boardRect.left + colIndex * sqW + sqW / 2f
        val y = boardRect.top  + rowIndex * sqH + sqH / 2f
        return PointF(x, y)
    }

    // Returns (from, to) PointF pair for a UCI move like "e2e4"
    fun parseMove(uci: String): Pair<PointF, PointF>? {
        if (uci.length < 4) return null
        val from = squareToScreen(uci.substring(0, 2)) ?: return null
        val to   = squareToScreen(uci.substring(2, 4)) ?: return null
        return from to to
    }

    // Returns promotion char if present (5th char in UCI move)
    fun promotionPiece(uci: String): Char? = if (uci.length >= 5) uci[4] else null
}
