package com.chesshack

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*

class ChessAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "ChessA11y"
        const val PKG = "com.chess"
        var instance: ChessAccessibilityService? = null
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val board = ChessBoard()
    private var lastFen = ""
    private var moveCounter = 0
    private var engineJob: Job? = null

    override fun onServiceConnected() {
        instance = this
        SharedState.onStatusUpdate?.invoke("Accessibility connected.")
        Log.d(TAG, "Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != PKG) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // Debounce: cancel previous scan if still running
                engineJob?.cancel()
                engineJob = serviceScope.launch {
                    delay(120) // wait for DOM to settle
                    scanBoardState()
                }
            }
        }
    }

    private fun scanBoardState() {
        val root = rootInActiveWindow ?: return
        try {
            board.clear()
            val boardNode = findBoardContainer(root)
            if (boardNode == null) {
                Log.d(TAG, "No board node found")
                root.recycle()
                return
            }

            val rect = Rect()
            boardNode.getBoundsInScreen(rect)
            if (rect.isEmpty) {
                boardNode.recycle(); root.recycle()
                return
            }

            parsePieces(boardNode)
            detectTurn(root)
            boardNode.recycle()

            if (board.isEmpty() || board.pieceCount() < 4) {
                root.recycle()
                return
            }

            val fen = board.toFEN()
            if (fen == lastFen) { root.recycle(); return }
            lastFen = fen
            moveCounter++

            SharedState.boardState = SharedState.boardState.copy(
                fen = fen,
                boardRect = rect
            )
            SharedState.onBoardParsed?.invoke(fen)
            Log.d(TAG, "FEN[$moveCounter]: $fen")

            triggerAnalysis(fen)
        } catch (e: Exception) {
            Log.e(TAG, "Scan error: ${e.message}")
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    // Walk the accessibility tree to find the chess board container.
    // chess.com v4.10.x accessibility tree has pieces as direct children of a
    // container whose content description contains "board" or whose child count
    // is high and children describe chess pieces.
    private fun findBoardContainer(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        // Try resource ID first (most reliable, may change per APK version)
        for (id in listOf("com.chess:id/chess_board", "com.chess:id/game_board",
                          "com.chess:id/board_view")) {
            val nodes = root.findAccessibilityNodeInfosByViewId(id)
            if (!nodes.isNullOrEmpty()) return nodes[0].also { nodes.drop(1).forEach(AccessibilityNodeInfo::recycle) }
        }
        // Fallback: heuristic scan
        return findBoardByHeuristic(root, depth = 0)
    }

    private fun findBoardByHeuristic(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 10) return null
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val w = rect.width(); val h = rect.height()
        val ratio = if (h > 0) w.toFloat() / h else 0f

        if (w > 150 && h > 150 && ratio in 0.75f..1.30f) {
            var pieceKids = 0
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val desc = child.contentDescription?.toString()?.lowercase() ?: ""
                if (hasPieceName(desc)) pieceKids++
                child.recycle()
            }
            if (pieceKids >= 4) return node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findBoardByHeuristic(child, depth + 1)
            if (found != null && found !== child) { child.recycle(); return found }
            if (found == null) child.recycle()
            if (found != null) return found
        }
        return null
    }

    private fun hasPieceName(desc: String) =
        desc.contains("pawn") || desc.contains("rook") || desc.contains("knight") ||
        desc.contains("bishop") || desc.contains("queen") || desc.contains("king")

    private fun parsePieces(boardNode: AccessibilityNodeInfo) {
        for (i in 0 until boardNode.childCount) {
            val child = boardNode.getChild(i) ?: continue
            try {
                val desc = child.contentDescription?.toString() ?: continue
                val piece = Piece.fromContentDescription(desc)
                if (piece == Piece.EMPTY) continue
                val (file, rank) = Piece.parseSquare(desc) ?: continue
                if (file in 0..7 && rank in 0..7) board[file, rank] = piece
            } finally {
                child.recycle()
            }
        }
    }

    private fun detectTurn(root: AccessibilityNodeInfo) {
        // "Your turn" text in chess.com indicates it's our turn
        val nodes = root.findAccessibilityNodeInfosByText("Your turn")
        if (!nodes.isNullOrEmpty()) {
            board.whiteToMove = SharedState.boardState.playingAsWhite
            nodes.forEach { it.recycle() }
        }
    }

    private fun triggerAnalysis(fen: String) {
        serviceScope.launch {
            val engine = StockfishEngine(applicationContext)
            if (!engine.install() || !engine.start()) {
                SharedState.onStatusUpdate?.invoke("Engine failed to start")
                return@launch
            }
            SharedState.onStatusUpdate?.invoke("Analyzing depth ${SharedState.analysisDepth}...")
            val result = engine.analyze(fen, SharedState.analysisDepth)
            engine.stop()

            if (result.bestMove.isEmpty()) return@launch

            SharedState.bestMove = result.bestMove
            SharedState.evalCp   = result.evalCp
            SharedState.evalDepth = result.depth

            SharedState.onMoveFound?.invoke(result.bestMove, result.evalCp, result.depth)

            if (SharedState.autoPlayEnabled) {
                val delay = HumanizationEngine.computeDelay(
                    moveNumber = moveCounter,
                    baseDelayMs = SharedState.autoDelayMs,
                    evalCp = result.evalCp
                )
                delay(delay)
                playMove(result.bestMove)
            }
        }
    }

    // Public: plays a UCI move on screen via dispatchGesture
    fun playMove(uciMove: String) {
        val state = SharedState.boardState
        if (state.boardRect.isEmpty) {
            SharedState.onStatusUpdate?.invoke("Board rect unknown — open a game first")
            return
        }
        val mapper = CoordinateMapper(state.boardRect, state.playingAsWhite)
        val (from, to) = mapper.parseMove(uciMove) ?: run {
            SharedState.onStatusUpdate?.invoke("Cannot parse move: $uciMove")
            return
        }

        // Tap from-square, hover delay, tap to-square
        val hoverMs = HumanizationEngine.hoverDelay()
        val noise = HumanizationEngine.tapNoise()

        tapAt(from.x + noise, from.y + noise)
        Thread.sleep(hoverMs)
        tapAt(to.x + HumanizationEngine.tapNoise(), to.y + HumanizationEngine.tapNoise())

        SharedState.boardState = state.copy(lastMove = uciMove)
        SharedState.onStatusUpdate?.invoke("Played: ${uciMove.uppercase()}")
        Log.d(TAG, "Move dispatched: $uciMove  board=${state.boardRect}")
    }

    private fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription) = Log.v(TAG, "Tap OK ($x,$y)")
            override fun onCancelled(g: GestureDescription) = Log.w(TAG, "Tap cancelled ($x,$y)")
        }, null)
    }

    override fun onInterrupt() { Log.d(TAG, "Interrupted") }

    override fun onDestroy() {
        instance = null
        serviceScope.cancel()
        super.onDestroy()
    }
}
