package com.chesshack

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.concurrent.TimeUnit

class StockfishEngine(private val context: Context) {

    companion object {
        private const val TAG = "StockfishEngine"
        private const val BINARY = "stockfish"
    }

    private var process: Process? = null
    private var reader: BufferedReader? = null
    private var writer: PrintWriter? = null

    private val engineFile: File
        get() = File(context.filesDir, BINARY)

    fun install(): Boolean = try {
        if (!engineFile.exists() || engineFile.length() < 50_000L) {
            context.assets.open(BINARY).use { input ->
                FileOutputStream(engineFile).use { input.copyTo(it) }
            }
            engineFile.setExecutable(true, false)
            Log.d(TAG, "Stockfish installed at ${engineFile.absolutePath}")
        }
        true
    } catch (e: Exception) {
        Log.e(TAG, "Install failed: ${e.message}")
        false
    }

    fun start(): Boolean {
        return try {
            if (!engineFile.exists()) return false
            process = ProcessBuilder(engineFile.absolutePath)
                .redirectErrorStream(true)
                .start()
            reader = BufferedReader(InputStreamReader(process!!.inputStream))
            writer = PrintWriter(process!!.outputStream, true)

            send("uci")
            if (!waitFor("uciok", 3000)) return false

            send("setoption name Threads value 2")
            send("setoption name Hash value 32")
            send("setoption name Move Overhead value 50")
            send("isready")
            waitFor("readyok", 3000)
        } catch (e: Exception) {
            Log.e(TAG, "Start failed: ${e.message}")
            false
        }
    }

    data class AnalysisResult(
        var bestMove: String = "",
        var ponderMove: String = "",
        var evalCp: Int = 0,
        var mateIn: Int = 0,
        var depth: Int = 0,
        var pv: String = ""
    ) {
        val isMate get() = mateIn != 0
        fun evalString(): String = if (isMate) "#$mateIn" else "%.2f".format(evalCp / 100.0)
    }

    fun analyze(fen: String, depth: Int = 15): AnalysisResult {
        val result = AnalysisResult()
        return try {
            send("stop")
            Thread.sleep(30)
            send("position fen $fen")
            send("go depth $depth")

            val deadline = System.currentTimeMillis() + 20_000L
            while (System.currentTimeMillis() < deadline) {
                val line = reader?.readLine() ?: break
                when {
                    line.startsWith("info") -> parseInfo(line, result)
                    line.startsWith("bestmove") -> {
                        val parts = line.split(" ")
                        result.bestMove = parts.getOrNull(1) ?: ""
                        result.ponderMove = parts.getOrNull(3) ?: ""
                        break
                    }
                }
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "Analyze error: ${e.message}")
            result
        }
    }

    private fun parseInfo(line: String, r: AnalysisResult) {
        val p = line.split(" ")
        var i = 0
        while (i < p.size) {
            when (p[i]) {
                "depth" -> r.depth = p.getOrNull(i + 1)?.toIntOrNull() ?: r.depth
                "score" -> when (p.getOrNull(i + 1)) {
                    "cp"   -> r.evalCp = p.getOrNull(i + 2)?.toIntOrNull() ?: 0
                    "mate" -> r.mateIn = p.getOrNull(i + 2)?.toIntOrNull() ?: 0
                }
                "pv" -> r.pv = p.drop(i + 1).joinToString(" ")
            }
            i++
        }
    }

    private fun send(cmd: String) { writer?.println(cmd) }

    private fun waitFor(token: String, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val line = reader?.readLine() ?: return false
            if (line.contains(token)) return true
        }
        return false
    }

    fun stop() {
        try {
            send("quit")
            process?.waitFor(500, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {}
        process?.destroyForcibly()
        process = null; reader = null; writer = null
    }
}
