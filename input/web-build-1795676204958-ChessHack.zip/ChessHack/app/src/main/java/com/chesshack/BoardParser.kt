package com.chesshack

object Piece {
    const val EMPTY        = '.'
    const val WHITE_PAWN   = 'P'
    const val WHITE_KNIGHT = 'N'
    const val WHITE_BISHOP = 'B'
    const val WHITE_ROOK   = 'R'
    const val WHITE_QUEEN  = 'Q'
    const val WHITE_KING   = 'K'
    const val BLACK_PAWN   = 'p'
    const val BLACK_KNIGHT = 'n'
    const val BLACK_BISHOP = 'b'
    const val BLACK_ROOK   = 'r'
    const val BLACK_QUEEN  = 'q'
    const val BLACK_KING   = 'k'

    fun fromContentDescription(desc: String): Char {
        val d = desc.lowercase()
        val white = d.contains("white")
        return when {
            d.contains("king")   -> if (white) WHITE_KING   else BLACK_KING
            d.contains("queen")  -> if (white) WHITE_QUEEN  else BLACK_QUEEN
            d.contains("rook")   -> if (white) WHITE_ROOK   else BLACK_ROOK
            d.contains("bishop") -> if (white) WHITE_BISHOP else BLACK_BISHOP
            d.contains("knight") -> if (white) WHITE_KNIGHT else BLACK_KNIGHT
            d.contains("pawn")   -> if (white) WHITE_PAWN   else BLACK_PAWN
            else -> EMPTY
        }
    }

    // Extracts file (0-7) and rank (0-7) from content descriptions like
    // "White Rook on e1", "black pawn e-5", "d4 White Bishop"
    fun parseSquare(desc: String): Pair<Int, Int>? {
        val m = Regex("([a-h])[^0-9]?([1-8])").find(desc.lowercase()) ?: return null
        val file = m.groupValues[1][0] - 'a'
        val rank = m.groupValues[2][0] - '1'
        return file to rank
    }
}

class ChessBoard {
    // squares[file][rank], file 0=a, rank 0=1
    val squares = Array(8) { Array(8) { Piece.EMPTY } }
    var whiteToMove = true
    var castlingRights = "KQkq"
    var enPassantSquare = "-"

    operator fun get(file: Int, rank: Int): Char = squares[file][rank]
    operator fun set(file: Int, rank: Int, p: Char) { squares[file][rank] = p }

    fun clear() = squares.forEach { col -> col.fill(Piece.EMPTY) }

    fun isEmpty(): Boolean = squares.all { col -> col.all { it == Piece.EMPTY } }

    fun pieceCount(): Int = squares.sumOf { col -> col.count { it != Piece.EMPTY } }

    fun toFEN(): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val p = squares[file][rank]
                if (p == Piece.EMPTY) {
                    empty++
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(p)
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        sb.append(' ')
        sb.append(if (whiteToMove) 'w' else 'b')
        sb.append(' ')
        sb.append(castlingRights)
        sb.append(' ')
        sb.append(enPassantSquare)
        sb.append(" 0 1")
        return sb.toString()
    }
}
