package com.chesshack

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class FloatingMenuService : Service() {

    companion object {
        private const val CHANNEL_ID = "chesshack_ch"
        private const val NOTIF_ID   = 1001
    }

    private lateinit var wm: WindowManager
    private lateinit var root: View
    private lateinit var params: WindowManager.LayoutParams
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var panelVisible = true
    private var autoPlay = false
    private var depth = 12
    private var delayMs = 1200L

    // UI refs
    private lateinit var tvBestMove: TextView
    private lateinit var tvEval: TextView
    private lateinit var tvLog: TextView
    private lateinit var tvDepth: TextView
    private lateinit var tvDelay: TextView
    private lateinit var btnAutoPlay: Button
    private lateinit var panelContent: View

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        setupOverlay()
        hookCallbacks()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "ChessHack", NotificationManager.IMPORTANCE_LOW)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ChessHack Active")
            .setContentText("Overlay running — open Chess.com")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun setupOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        root = LayoutInflater.from(this).inflate(R.layout.overlay_menu, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16; y = 100
        }

        wm.addView(root, params)

        // Bind views
        tvBestMove  = root.findViewById(R.id.tvBestMove)
        tvEval      = root.findViewById(R.id.tvEval)
        tvLog       = root.findViewById(R.id.tvLog)
        tvDepth     = root.findViewById(R.id.tvDepth)
        tvDelay     = root.findViewById(R.id.tvDelay)
        panelContent = root.findViewById(R.id.panelContent)

        setupDrag()
        setupButtons()
    }

    private fun setupDrag() {
        val handle = root.findViewById<View>(R.id.dragHandle)
        var dX = 0; var dY = 0

        handle.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { dX = params.x - ev.rawX.toInt(); dY = params.y - ev.rawY.toInt(); true }
                MotionEvent.ACTION_MOVE -> { params.x = ev.rawX.toInt() + dX; params.y = ev.rawY.toInt() + dY; wm.updateViewLayout(root, params); true }
                else -> false
            }
        }
        root.findViewById<Button>(R.id.btnMinimize).setOnClickListener {
            panelVisible = !panelVisible
            panelContent.visibility = if (panelVisible) View.VISIBLE else View.GONE
        }
    }

    private fun setupButtons() {
        // Side selector
        root.findViewById<Button>(R.id.btnSideWhite).setOnClickListener {
            SharedState.boardState = SharedState.boardState.copy(playingAsWhite = true)
            setLog("Side: White")
        }
        root.findViewById<Button>(R.id.btnSideBlack).setOnClickListener {
            SharedState.boardState = SharedState.boardState.copy(playingAsWhite = false)
            setLog("Side: Black")
        }

        // Depth seekbar
        root.findViewById<SeekBar>(R.id.seekDepth).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    depth = progress.coerceAtLeast(1)
                    tvDepth.text = depth.toString()
                    SharedState.analysisDepth = depth
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }

        // Delay seekbar (0 - 5000ms)
        root.findViewById<SeekBar>(R.id.seekDelay).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    delayMs = progress.toLong()
                    SharedState.autoDelayMs = delayMs
                    tvDelay.text = "%.1fs".format(delayMs / 1000.0)
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }

        // Manual analyze
        root.findViewById<Button>(R.id.btnAnalyze).setOnClickListener {
            val fen = SharedState.boardState.fen
            if (fen.isEmpty()) { setLog("No board detected yet. Open a game."); return@setOnClickListener }
            setLog("Analyzing...")
            scope.launch(Dispatchers.IO) {
                val engine = StockfishEngine(applicationContext)
                if (engine.install() && engine.start()) {
                    val r = engine.analyze(fen, SharedState.analysisDepth)
                    engine.stop()
                    withContext(Dispatchers.Main) {
                        updateDisplay(r.bestMove, r.evalCp, r.depth)
                    }
                }
            }
        }

        // Manual play
        root.findViewById<Button>(R.id.btnPlayMove).setOnClickListener {
            val mv = SharedState.bestMove
            if (mv.isEmpty()) { setLog("Analyze first."); return@setOnClickListener }
            ChessAccessibilityService.instance?.playMove(mv) ?: setLog("Accessibility not connected.")
        }

        // Auto-play toggle
        root.findViewById<Button>(R.id.btnAutoPlay).setOnClickListener {
            autoPlay = !autoPlay
            SharedState.autoPlayEnabled = autoPlay
            (it as Button).text = if (autoPlay) "Auto: ON" else "Auto: OFF"
            it.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (autoPlay) 0xFF2E7D32.toInt() else 0xFFB71C1C.toInt()
            )
            setLog("Auto-play: ${if (autoPlay) "ON" else "OFF"}")
        }
    }

    private fun hookCallbacks() {
        SharedState.onMoveFound = { move, eval, dep ->
            root.post { updateDisplay(move, eval, dep) }
        }
        SharedState.onBoardParsed = { _ ->
            root.post { setLog("Board parsed.") }
        }
        SharedState.onStatusUpdate = { msg ->
            root.post { setLog(msg) }
        }
    }

    private fun updateDisplay(move: String, evalCp: Int, dep: Int) {
        if (move.isEmpty()) return
        val from = move.take(2).uppercase()
        val to   = move.drop(2).take(2).uppercase()
        val promo = if (move.length >= 5) " =${move[4].uppercaseChar()}" else ""
        tvBestMove.text = "▶ $from → $to$promo"
        val evalStr = if (evalCp > 29999 || evalCp < -29999) "#" else "%.2f".format(evalCp / 100.0)
        tvEval.text = "Eval: ${if (evalCp >= 0) "+$evalStr" else evalStr}  |  Depth: $dep"
        setLog("Ready.")
    }

    private fun setLog(msg: String) { tvLog.text = msg }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        SharedState.onMoveFound = null
        SharedState.onBoardParsed = null
        SharedState.onStatusUpdate = null
        if (::root.isInitialized) try { wm.removeView(root) } catch (_: Exception) {}
    }
}
