package com.chesshack

import android.graphics.Rect

data class BoardState(
    val fen: String = "",
    val boardRect: Rect = Rect(),
    val playingAsWhite: Boolean = true,
    val lastMove: String = ""
)

object SharedState {
    @Volatile var boardState: BoardState = BoardState()
    @Volatile var bestMove: String = ""
    @Volatile var evalCp: Int = 0
    @Volatile var evalDepth: Int = 0
    @Volatile var autoPlayEnabled: Boolean = false
    @Volatile var analysisDepth: Int = 12
    @Volatile var autoDelayMs: Long = 1200L   // base delay before auto-tap

    var onMoveFound: ((String, Int, Int) -> Unit)? = null   // move, evalCp, depth
    var onBoardParsed: ((String) -> Unit)? = null
    var onStatusUpdate: ((String) -> Unit)? = null
}
