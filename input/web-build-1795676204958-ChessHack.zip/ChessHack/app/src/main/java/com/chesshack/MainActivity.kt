package com.chesshack

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnA11y: Button
    private lateinit var btnLaunch: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus  = findViewById(R.id.tvStatus)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnA11y    = findViewById(R.id.btnAccessibility)
        btnLaunch  = findViewById(R.id.btnLaunch)

        btnOverlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }

        btnA11y.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnLaunch.setOnClickListener {
            startForegroundService(Intent(this, FloatingMenuService::class.java))
            tvStatus.text = "Overlay launched!\nOpen Chess.com and start a game.\nSet your side (White/Black) in the floating menu."
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }

    private fun checkPermissions() {
        val hasOverlay = Settings.canDrawOverlays(this)
        val hasA11y    = isA11yEnabled()

        btnOverlay.isEnabled = !hasOverlay
        btnA11y.isEnabled    = !hasA11y
        btnLaunch.isEnabled  = hasOverlay && hasA11y

        tvStatus.text = when {
            !hasOverlay && !hasA11y -> "Step 1: Grant overlay\nStep 2: Enable accessibility"
            !hasOverlay -> "Need: Overlay permission (Step 1)"
            !hasA11y    -> "Need: Enable ChessHack in Accessibility (Step 2)"
            else        -> "✓ All permissions granted.\nTap Launch to start overlay."
        }
    }

    private fun isA11yEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
            .any { it.id.contains("chesshack", ignoreCase = true) }
    }
}
