package com.chesshack

import kotlin.math.abs
import kotlin.random.Random

/**
 * Generates human-like timing for move execution.
 *
 * chess.com fair play detection flags:
 *   - Uniform move times (all moves same speed = bot pattern)
 *   - Very high CPL accuracy (100% best-move rate = obvious engine)
 *   - No clock pressure response (humans think less in blitz when low on time)
 *
 * This engine:
 *   - Applies bell-curve timing peaking at moves 10-25 (critical middlegame)
 *   - Adds noise to simulate "mouse hover" hesitation
 *   - Optionally introduces deliberate sub-optimal moves based on "weakness profile"
 *   - Caps best-move rate at ~82% (mimics strong human, not engine)
 */
object HumanizationEngine {

    private val random = Random.Default

    // Base delay range per game phase (ms)
    private object Phase {
        val OPENING    = 400L to 1800L    // moves 1-10: quick book moves
        val MIDDLEGAME = 800L to 4500L    // moves 11-30: critical, think more
        val ENDGAME    = 300L to 2000L    // moves 31+: simpler positions
    }

    /**
     * Calculate humanized delay before playing a move.
     *
     * @param moveNumber    Current move number (1-indexed)
     * @param baseDelayMs   User-configured base delay
     * @param evalCp        Position evaluation in centipawns (+= white advantage)
     * @param isCapture     Whether the move is a capture (think less, more forcing)
     * @param clockRemainingMs Remaining clock time (think faster when low)
     */
    fun computeDelay(
        moveNumber: Int,
        baseDelayMs: Long,
        evalCp: Int = 0,
        isCapture: Boolean = false,
        clockRemainingMs: Long = Long.MAX_VALUE
    ): Long {
        val (minMs, maxMs) = when {
            moveNumber <= 10 -> Phase.OPENING
            moveNumber <= 30 -> Phase.MIDDLEGAME
            else             -> Phase.ENDGAME
        }

        // Bell-curve weight: peak at move ~20
        val phaseFactor = bellCurve(moveNumber.toDouble(), mu = 20.0, sigma = 10.0)

        // Base: interpolate between min and max using phase factor
        var delay = minMs + ((maxMs - minMs) * phaseFactor).toLong()

        // User base delay scales the whole range
        delay = (delay * baseDelayMs / 1200L).coerceIn(200L, 8000L)

        // Captures: forced/obvious moves, play faster
        if (isCapture) delay = (delay * 0.55).toLong()

        // High evaluation (winning big): play faster, less thinking needed
        val evalBias = abs(evalCp) / 500.0   // 0=equal, 1=totally winning
        delay = (delay * (1.0 - evalBias * 0.3)).toLong()

        // Clock pressure: scale down when < 10 seconds
        if (clockRemainingMs < 10_000) {
            val urgency = 1.0 - (clockRemainingMs / 10_000.0)
            delay = (delay * (1.0 - urgency * 0.7)).toLong()
        }

        // Add uniform jitter ±25% of delay
        val jitter = (delay * 0.25 * (random.nextDouble() * 2 - 1)).toLong()
        delay += jitter

        return delay.coerceIn(150L, 10_000L)
    }

    /**
     * Decides whether to play the engine's best move or a second-best move.
     *
     * Target ~82% best-move rate across a session (strong human benchmark).
     * Falls to ~70% in clearly winning positions (humans get sloppy).
     */
    fun shouldPlayBestMove(evalCp: Int, moveNumber: Int): Boolean {
        val baseRate = 0.82
        // In winning positions, allow more inaccuracies
        val winBias = if (evalCp > 300) 0.10 else 0.0
        // Late opening/early middlegame: play better
        val phaseBias = if (moveNumber in 8..20) 0.05 else 0.0
        val finalRate = (baseRate - winBias + phaseBias).coerceIn(0.65, 0.95)
        return random.nextDouble() < finalRate
    }

    // Gaussian bell curve, normalized to [0,1]
    private fun bellCurve(x: Double, mu: Double, sigma: Double): Double {
        val exponent = -0.5 * ((x - mu) / sigma) * ((x - mu) / sigma)
        return Math.exp(exponent)
    }

    // Simulate "hover then click" for move from-square: extra pause on source tap
    fun hoverDelay(): Long = random.nextLong(80L, 220L)

    // Slight position noise on tap point (humans don't click exact center)
    fun tapNoise(): Float = (random.nextFloat() - 0.5f) * 6f   // ±3px
}
