# ChessHack v1.0
**Android overlay cheat untuk chess.com — accessibility reader + Stockfish + auto-tap**

---

## Status APK Chess.com (November 2026)

| Channel | Version | Size | Tanggal |
|---|---|---|---|
| **Latest (Play Store)** | **4.10.27-googleplay** | ~148 MB | Nov 4, 2026 |
| Stable sebelumnya | 4.10.25-googleplay | ~142 MB | Oct 29, 2026 |
| Stable lama | 4.10.13-googleplay | ~145 MB | Sep 8, 2026 |

Target package: `com.chess` — sudah di-hardcode di `accessibility_service_config.xml`.

---

## Winrate & Detection Reality

### Winrate Stockfish depth 12-20 vs human:
| Depth | Approx ELO engine | Winrate vs <1500 | Winrate vs <2000 | Ban risk |
|---|---|---|---|---|
| 8 | ~2300 | ~95% | ~88% | Rendah (less obvious) |
| 12 | ~2700 | ~98% | ~94% | Medium |
| 15 | ~3100 | ~99% | ~97% | Tinggi |
| 20 | ~3500+ | ~99.9% | ~99% | Sangat tinggi |
| **Recommended** | **~2500** | **~96%** | **~90%** | **Medium-low** |

**Rekomendasi: depth 10-12, delay 1.5-2.5s** — mirip GM human, belum full engine.

### Chess.com Fair Play Detection (dari official blog mereka):
- Menutup **314.000 akun** di Q1 2025, 85% automated
- Detection factors: CPL (centipawn loss), accuracy vs rating, move timing, top-move rate
- **Yang langsung di-flag**: 100% best-move rate, uniform timing, sudden rating spike
- **Yang lebih aman**: depth rendah, humanized timing, deliberate occasional error

### Perbandingan dengan tools existing:
| Tool | Platform | Auto-play | Humanization | Detection evasion |
|---|---|---|---|---|
| **ChessHack (ini)** | Android native | ✓ | Bell-curve timing, tap noise, ~82% best-move | Medium |
| ChessMod (Zalve-68) | Android native | ✓ | Clock-aware timing | Good |
| REXXX.MENU v16 | Browser (Tampermonkey) | ✓ | Sangat advanced (streak limiter, CPL clustering, 52% winrate target) | Best |
| Chess Assist (GreasyFork) | Browser/Kiwi | ✓ | Move delay config | Medium |
| Chesscheat (Firefox addon) | Browser | ✗ (show only) | None | Low |

**ChessHack keunggulan**: native Android tanpa butuh browser — langsung di Chess.com app.
**Kelemahan vs REXXX.MENU**: humanization kurang advanced (browser scripts bisa inject JS langsung, lebih granular).

---

## Cara Anti-Ban (pakai akal)

1. **Jangan full auto** — gunakan "Play Move" manual untuk moves penting, auto untuk yang obvious
2. **Depth 10-12** bukan 20 — engine masih jauh lebih kuat dari player manapun
3. **Delay 1.5-3s base** — manusia butuh waktu berpikir
4. **Jangan spike rating** — kalah sesekali di game tidak penting
5. **Pakai di akun baru** — akun lama dengan history punya baseline yang dimonitor
6. **Jangan di tournament** — Fair Play team manual review lebih ketat di events

---

## Build Instructions

### Prerequisites
- Android Studio Hedgehog atau lebih baru
- JDK 17
- Android SDK API 34
- HP Android 9+ (arm64)

### Stockfish Binary
Download binary Stockfish untuk Android arm64:
```
https://github.com/official-stockfish/Stockfish/releases
```
Atau dari Chessmod yang sudah bundle:
```
https://github.com/Zalve-68/Chessmod
```

Taruh binary di: `app/src/main/assets/stockfish`
(bukan .zip, bukan .apk — raw ELF binary, ~3-6MB)

### Build
```bash
cd ChessHack
# Di Android Studio: Build > Make Project
# Atau via command line:
./gradlew assembleDebug
# APK output: app/build/outputs/apk/debug/app-debug.apk
```

### Install ke HP
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Setup di HP
1. Buka ChessHack app
2. Tap **"1. Grant Overlay Permission"** → allow
3. Tap **"2. Enable Accessibility Service"** → cari ChessHack → enable
4. Kembali ke app → Tap **"3. Launch Floating Menu"**
5. Buka Chess.com → mulai game
6. Set side (White/Black) di floating menu
7. Auto-play otomatis atau manual via "▶ Play"

---

## Architecture

```
chess.com app
    ↓ accessibility events (view tree)
ChessAccessibilityService
    ↓ parse content descriptions
ChessBoard (FEN builder)
    ↓ position FEN
StockfishEngine (native binary via Process)
    ↓ UCI bestmove
HumanizationEngine (timing + noise)
    ↓ PointF coordinates
CoordinateMapper (square → pixels)
    ↓ dispatchGesture()
chess.com board (tapped)
    ↓
FloatingMenuService (overlay UI)
```

---

## Troubleshooting

**"Board not detected"**
→ chess.com update mengubah view IDs. Edit `findBoardContainer()` di `ChessAccessibilityService.kt`:
tambahkan resource ID baru atau turunkan sensitivity threshold.

**Move tap meleset**
→ Board rect salah. Ini terjadi kalau chess.com pakai FLAG_SECURE (screenshot block) yang prevent rect detection.
Fix: Di `ChessAccessibilityService.scanBoardState()`, fallback ke manual rect calculation dari piece node positions.

**Engine tidak start**
→ Binary stockfish tidak ditemukan atau tidak executable. Cek logcat: `adb logcat -s StockfishEngine`.
Pastikan file ada di `assets/stockfish` dan setelah install di `context.filesDir/stockfish`.

**Auto-play tidak jalan**
→ Pastikan "Your turn" text muncul di UI chess.com (detectTurn() trigger dari ini).
Kalau chess.com ganti UI string, edit `detectTurn()` di `ChessAccessibilityService.kt`.
