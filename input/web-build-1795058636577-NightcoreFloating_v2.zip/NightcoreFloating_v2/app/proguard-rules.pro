# Keep entry points that Android system needs to find by name
-keep public class com.nightcore.floating.MainActivity extends android.app.Activity
-keep public class com.nightcore.floating.ScreenBridgeService extends android.accessibilityservice.AccessibilityService

# Keep R class
-keepclassmembers class **.R$* {
    public static <fields>;
}

# Obfuscate everything else — renames classes/methods in APK
# sehingga reverse-engineering lebih susah
-dontskipnonpubliclibraryclasses
-optimizationpasses 5
-overloadaggressively
-repackageclasses 'a'

# MLKit perlu nama aslinya
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.** { *; }

# WebView JavaScript interface (kalau ada)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
