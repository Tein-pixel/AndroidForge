# Yomikaze

Native Android reader for manga, manhwa, manhua, comics, and web novels.

## Included sources

- **Comick** — manga/manhwa/manhua/comic catalog, chapter list, and reader images.
- **MangaDex** — public JSON API, with Indonesian translations prioritized.
- **NovelFire** — HTML-parsed web novels; listings without readable genre metadata are excluded, and adult/mature-tagged titles are blocked. Site availability can vary because the provider may apply bot protection or change its HTML.

Only catalog entries explicitly rated safe are displayed for sources that expose a content rating. Unknown ratings are excluded.

## Build with AndroidForge or GitHub Actions

Build toolchain configured for AndroidForge compatibility:

- JDK 17
- Android Gradle Plugin 8.7.2
- Gradle 8.9
- Android SDK 35 (minimum supported Android version: API 24)

The repository includes `.github/workflows/android.yml`. Push the project to GitHub and run **Android APK** from the Actions tab, or let it run after a push to `main`/`master`. The generated APK is uploaded as the `yomikaze-debug-apk` artifact.

For a local/hosted builder that already has Gradle 8.9 and Android SDK 35 installed, run from the project root:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

A release build requires a signing configuration before distribution. Debug builds are automatically signed for testing.

## Architecture

- `ContentSource` — common contract for search, catalog details, chapters, and reader content.
- `SourceRegistry` — source adapter registry.
- `CatalogRepository` — parallel multi-source search and safe-rating filter.
- Room — library, reading progress, and download state.
- WorkManager — chapter downloads in the app-private `files/downloads/` directory.
- Jetpack Compose — browse, search, title details, manga reader, novel reader, library, and settings.

## Notes

- No API key is required for MangaDex's public catalog API or Comick's basic catalog endpoints.
- API availability, rate limits, and source HTML are controlled by their providers; a successful APK build does not guarantee every source is reachable at all times.
- This ZIP contains the Android project and build configuration, not a prebuilt APK.
