package app.yomikaze.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.ui.BrowseViewModel
import app.yomikaze.ui.components.ContentCard
import app.yomikaze.ui.components.EmptyState
import app.yomikaze.ui.components.LoadingState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    onOpen: (String, String) -> Unit,
    onSearch: () -> Unit,
    viewModel: BrowseViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val sources = viewModel.sources()
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Yomikaze") },
            actions = {
                IconButton(onClick = onSearch) { Icon(Icons.Default.Search, null) }
            },
        )
        ScrollableTabRow(
            selectedTabIndex = sources.indexOfFirst { it.id == state.sourceId }.coerceAtLeast(0),
        ) {
            sources.forEach { source ->
                Tab(
                    selected = source.id == state.sourceId,
                    onClick = { viewModel.load(source.id) },
                    text = { Text(source.name) },
                )
            }
        }
        when {
            state.loading -> LoadingState()
            state.error != null -> EmptyState(state.error!!)
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(140.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(state.items) { item ->
                    ContentCard(item = item, onClick = { onOpen(item.sourceId, item.id) })
                }
            }
        }
    }
}
