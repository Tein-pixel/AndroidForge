package app.yomikaze.core

enum class MediaType { MANGA, MANHWA, MANHUA, COMIC, NOVEL }

enum class PublicationStatus { ONGOING, COMPLETED, HIATUS, CANCELLED, UNKNOWN }

enum class ReadingMode { PAGED, WEBTOON, TEXT }

enum class ContentRating { SAFE, SUGGESTIVE, EROTICA, PORNOGRAPHIC, UNKNOWN }

data class ContentSummary(
    val id: String,
    val sourceId: String,
    val title: String,
    val altTitles: List<String> = emptyList(),
    val description: String = "",
    val coverUrl: String? = null,
    val mediaType: MediaType = MediaType.MANGA,
    val status: PublicationStatus = PublicationStatus.UNKNOWN,
    val year: Int? = null,
    val tags: List<String> = emptyList(),
    val originalLanguage: String = "en",
    val readingMode: ReadingMode = ReadingMode.PAGED,
    val contentRating: ContentRating = ContentRating.UNKNOWN,
)

data class ContentDetails(
    val summary: ContentSummary,
    val authors: List<String> = emptyList(),
    val artists: List<String> = emptyList(),
    val chapters: List<Chapter> = emptyList(),
)

data class Chapter(
    val id: String,
    val contentId: String,
    val sourceId: String,
    val number: String,
    val volume: String? = null,
    val title: String? = null,
    val language: String = "en",
    val pageCount: Int = 0,
    val publishedAt: Long = 0L,
    val url: String? = null,
)

sealed interface ChapterContent {
    data class Images(val pages: List<Page>) : ChapterContent

    data class Text(
        val title: String,
        val paragraphs: List<String>,
        val previousUrl: String? = null,
        val nextUrl: String? = null,
    ) : ChapterContent
}

data class Page(
    val index: Int,
    val url: String,
    val width: Int? = null,
    val height: Int? = null,
)
