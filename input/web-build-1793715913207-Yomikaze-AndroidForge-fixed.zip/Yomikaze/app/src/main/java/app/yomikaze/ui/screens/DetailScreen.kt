package app.yomikaze.ui.screens

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import app.yomikaze.ui.DetailViewModel
import app.yomikaze.ui.components.EmptyState
import app.yomikaze.ui.components.LoadingState
import app.yomikaze.work.ChapterDownloadWorker
import coil3.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    onBack: () -> Unit,
    onRead: (String, String, String, Boolean) -> Unit,
    viewModel: DetailViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val details = state.details
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopAppBar(
            title = { Text(details?.summary?.title ?: "Detail", maxLines = 1) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
        )
        if (state.loading) LoadingState()
        else if (state.error != null) EmptyState(state.error!!)
        else if (details != null) {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                AsyncImage(
                    model = details.summary.coverUrl,
                    contentDescription = details.summary.title,
                    modifier = Modifier.width(120.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                )
                Column(Modifier.weight(1f)) {
                    Text(details.summary.title, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "${details.summary.mediaType.name} · ${details.summary.status.name}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    details.summary.year?.let { Text("Tahun: $it", style = MaterialTheme.typography.bodySmall) }
                    if (details.authors.isNotEmpty()) {
                        Text("Penulis: ${details.authors.joinToString()}", style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = viewModel::toggleLibrary) {
                        Text(if (state.inLibrary) "Hapus dari koleksi" else "Tambah ke koleksi")
                    }
                }
            }
            if (details.summary.description.isNotBlank()) {
                Text(
                    details.summary.description,
                    modifier = Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("Daftar Bab", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleMedium)
            details.chapters.forEach { chapter ->
                ListItem(
                    headlineContent = { Text("Bab ${chapter.number}${chapter.title?.let { " — $it" } ?: ""}") },
                    supportingContent = {
                        Text("${chapter.language} · ${chapter.pageCount} halaman")
                    },
                    trailingContent = {
                        IconButton(onClick = { enqueueDownload(context, chapter.sourceId, chapter.contentId, chapter.id) }) {
                            Icon(Icons.Default.Download, contentDescription = "Unduh")
                        }
                    },
                    modifier = Modifier.clickable {
                        onRead(chapter.sourceId, chapter.contentId, chapter.id, viewModel.isNovel())
                    },
                )
            }
        }
    }
}

private fun enqueueDownload(context: Context, sourceId: String, contentId: String, chapterId: String) {
    val request = OneTimeWorkRequestBuilder<ChapterDownloadWorker>()
        .setInputData(
            Data.Builder()
                .putString(ChapterDownloadWorker.KEY_SOURCE, sourceId)
                .putString(ChapterDownloadWorker.KEY_CONTENT, contentId)
                .putString(ChapterDownloadWorker.KEY_CHAPTER, chapterId)
                .build()
        )
        .build()
    WorkManager.getInstance(context).enqueue(request)
}
