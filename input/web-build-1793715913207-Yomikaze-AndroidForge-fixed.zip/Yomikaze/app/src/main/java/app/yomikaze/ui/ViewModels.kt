package app.yomikaze.ui

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.yomikaze.core.*
import app.yomikaze.data.*
import app.yomikaze.sources.SourceRegistry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class BrowseState(
    val loading: Boolean = true,
    val sourceId: String = "comick",
    val items: List<ContentSummary> = emptyList(),
    val error: String? = null,
)

@HiltViewModel
class BrowseViewModel @Inject constructor(
    private val catalog: CatalogRepository,
    private val registry: SourceRegistry,
) : ViewModel() {
    private val _state = MutableStateFlow(BrowseState())
    val state: StateFlow<BrowseState> = _state.asStateFlow()

    init { load("comick") }

    fun load(sourceId: String) {
        _state.update { it.copy(loading = true, sourceId = sourceId, error = null) }
        viewModelScope.launch {
            val result = runCatching { catalog.popular(sourceId, 1, 24) }
            _state.update {
                it.copy(
                    loading = false,
                    items = result.getOrDefault(emptyList()),
                    error = result.exceptionOrNull()?.message,
                )
            }
        }
    }

    fun sources(): List<ContentSource> = registry.all()
}

data class SearchState(
    val query: String = "",
    val sourceId: String? = null,
    val loading: Boolean = false,
    val results: List<ContentSummary> = emptyList(),
    val error: String? = null,
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val catalog: CatalogRepository,
    private val registry: SourceRegistry,
) : ViewModel() {
    private val _state = MutableStateFlow(SearchState())
    val state: StateFlow<SearchState> = _state.asStateFlow()

    fun setQuery(value: String) { _state.update { it.copy(query = value) } }
    fun setSource(value: String?) { _state.update { it.copy(sourceId = value) } }

    fun submit() {
        val current = _state.value
        if (current.query.trim().length < 2) return
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val result = runCatching { catalog.search(current.query.trim(), current.sourceId) }
            _state.update {
                it.copy(
                    loading = false,
                    results = result.getOrDefault(emptyList()),
                    error = result.exceptionOrNull()?.message,
                )
            }
        }
    }

    fun sources(): List<ContentSource> = registry.all()
}

data class DetailState(
    val loading: Boolean = true,
    val details: ContentDetails? = null,
    val inLibrary: Boolean = false,
    val progress: ProgressEntity? = null,
    val error: String? = null,
)

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val catalog: CatalogRepository,
    private val library: LibraryRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val sourceId: String = savedStateHandle["sourceId"] ?: error("sourceId missing")
    private val contentId: String = savedStateHandle["contentId"] ?: error("contentId missing")
    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            library.observeProgress(contentId).collect { progress ->
                _state.update { it.copy(progress = progress) }
            }
        }
        viewModelScope.launch {
            _state.update { it.copy(inLibrary = library.find(contentId) != null) }
        }
        refresh()
    }

    fun refresh() {
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val result = runCatching { catalog.details(sourceId, contentId) }
            _state.update {
                it.copy(
                    loading = false,
                    details = result.getOrNull(),
                    error = result.exceptionOrNull()?.message,
                )
            }
        }
    }

    fun toggleLibrary() {
        val details = _state.value.details ?: return
        viewModelScope.launch {
            if (_state.value.inLibrary) {
                library.remove(contentId)
                _state.update { it.copy(inLibrary = false) }
            } else {
                library.add(details.summary)
                _state.update { it.copy(inLibrary = true) }
            }
        }
    }

    fun isNovel(): Boolean = _state.value.details?.summary?.mediaType == MediaType.NOVEL
}

data class ReaderState(
    val loading: Boolean = true,
    val content: ChapterContent? = null,
    val chapter: Chapter? = null,
    val chapters: List<Chapter> = emptyList(),
    val page: Int = 0,
    val error: String? = null,
)

@HiltViewModel
class ReaderViewModel @Inject constructor(
    private val catalog: CatalogRepository,
    private val library: LibraryRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    val sourceId: String = savedStateHandle["sourceId"] ?: error("sourceId missing")
    val contentId: String = savedStateHandle["contentId"] ?: error("contentId missing")
    val chapterId: String = savedStateHandle["chapterId"] ?: error("chapterId missing")

    private var activeChapterId: String = chapterId
    private val _state = MutableStateFlow(ReaderState())
    val state: StateFlow<ReaderState> = _state.asStateFlow()

    init { load(chapterId) }

    fun load(chapterId: String) {
        activeChapterId = chapterId
        _state.update { it.copy(loading = true, error = null, page = 0) }
        viewModelScope.launch {
            val result = runCatching {
                val chapters = _state.value.chapters.ifEmpty { catalog.chapters(sourceId, contentId) }
                val chapter = chapters.firstOrNull { it.id == chapterId }
                    ?: error("Chapter is not present in the selected source.")
                val content = catalog.chapterContent(sourceId, chapterId)
                Triple(chapters, chapter, content)
            }
            val triple = result.getOrNull()
            _state.update {
                it.copy(
                    loading = false,
                    chapters = triple?.first ?: it.chapters,
                    chapter = triple?.second,
                    content = triple?.third,
                    error = result.exceptionOrNull()?.message,
                )
            }
            triple?.let { (_, chapter, content) ->
                val total = when (content) {
                    is ChapterContent.Images -> content.pages.size
                    is ChapterContent.Text -> 1
                }
                library.saveProgress(contentId, chapter.id, 0, total)
            }
        }
    }

    fun onPageChanged(page: Int, total: Int) {
        _state.update { it.copy(page = page) }
        viewModelScope.launch {
            library.saveProgress(contentId, activeChapterId, page, total)
        }
    }

    fun nextChapter(): Chapter? {
        val chapters = _state.value.chapters
        val index = chapters.indexOfFirst { it.id == activeChapterId }
        return chapters.getOrNull(index + 1)
    }

    fun previousChapter(): Chapter? {
        val chapters = _state.value.chapters
        val index = chapters.indexOfFirst { it.id == activeChapterId }
        return chapters.getOrNull(index - 1)
    }
}

@HiltViewModel
class LibraryViewModel @Inject constructor(
    repository: LibraryRepository,
) : ViewModel() {
    val library: StateFlow<List<LibraryEntity>> =
        repository.observeLibrary()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    registry: SourceRegistry,
) : ViewModel() {
    val sources: List<ContentSource> = registry.all()
}
