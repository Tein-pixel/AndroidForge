package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ComickSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "comick"
    override val name = "Comick"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA, MediaType.COMIC)

    private val base = "https://api.comick.dev"
    private val imageBase = "https://meo.comick.pictures"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val url = "$base/v1.0/search?q=${encode(query)}&limit=${limit.coerceIn(1, 50)}&page=${page.coerceAtLeast(1)}&content_rating=safe"
        return parseSearch(http.get(url))
    }

    override suspend fun popular(page: Int, limit: Int): List<ContentSummary> {
        val url = "$base/v1.0/search?q=&limit=${limit.coerceIn(1, 50)}&page=${page.coerceAtLeast(1)}&sort=follow&content_rating=safe"
        return parseSearch(http.get(url))
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val url = "$base/v1.0/search?q=&limit=${limit.coerceIn(1, 50)}&page=${page.coerceAtLeast(1)}&sort=uploaded&content_rating=safe"
        return parseSearch(http.get(url))
    }

    override suspend fun details(contentId: String): ContentDetails {
        val root = Json.parseToJsonElement(http.get("$base/comic/$contentId")).jsonObject
        val comic = root["comic"]?.jsonObject ?: root
        val summary = toSummary(comic)
        val authors = readNames(comic["authors"])
        val artists = readNames(comic["artists"])
        return ContentDetails(summary, authors, artists, chapters(contentId, null))
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> {
        val lang = language ?: "id"
        val all = mutableListOf<Chapter>()
        var page = 1
        while (true) {
            val root = Json.parseToJsonElement(
                http.get("$base/comic/$contentId/chapters?limit=100&page=$page&lang=$lang")
            ).jsonObject
            val array = root["chapters"]?.jsonArray ?: break
            if (array.isEmpty()) break
            array.forEach { element ->
                val c = element.jsonObject
                all += Chapter(
                    id = c["hid"]?.jsonPrimitive?.contentOrNull ?: return@forEach,
                    contentId = contentId,
                    sourceId = id,
                    number = c["chap"]?.jsonPrimitive?.contentOrNull ?: "?",
                    volume = c["vol"]?.jsonPrimitive?.contentOrNull,
                    title = c["title"]?.jsonPrimitive?.contentOrNull,
                    language = c["lang"]?.jsonPrimitive?.contentOrNull ?: lang,
                    publishedAt = parseIso(c["created_at"]?.jsonPrimitive?.contentOrNull),
                )
            }
            page += 1
            if (array.size < 100) break
        }
        return all.sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }
    }

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val root = Json.parseToJsonElement(http.get("$base/chapter/$chapterId/get_images")).jsonObject
        val chapter = root["chapter"]?.jsonObject ?: error("Comick response missing chapter")
        val pages = chapter["images"]?.jsonArray.orEmpty().mapIndexedNotNull { index, element ->
            val key = element.jsonObject["b2key"]?.jsonPrimitive?.contentOrNull ?: return@mapIndexedNotNull null
            Page(
                index = index,
                url = "$imageBase/$key",
                width = element.jsonObject["w"]?.jsonPrimitive?.intOrNull,
                height = element.jsonObject["h"]?.jsonPrimitive?.intOrNull,
            )
        }
        return ChapterContent.Images(pages)
    }

    private fun parseSearch(json: String): List<ContentSummary> {
        val element = Json.parseToJsonElement(json)
        val array = when (element) {
            is JsonArray -> element
            is JsonObject -> element["result"]?.jsonArray ?: element["data"]?.jsonArray
            else -> null
        } ?: return emptyList()
        return array.mapNotNull { runCatching { toSummary(it.jsonObject) }.getOrNull() }
            .filter { it.contentRating == ContentRating.SAFE }
    }

    private fun toSummary(obj: JsonObject): ContentSummary {
        val hid = obj["hid"]?.jsonPrimitive?.contentOrNull
            ?: obj["slug"]?.jsonPrimitive?.contentOrNull
            ?: error("Comick result missing hid")
        val titleRows = obj["md_titles"]?.jsonArray.orEmpty()
        val indonesianTitle = titleRows.firstNotNullOfOrNull { row ->
            val titleRow = row.jsonObject
            val lang = titleRow["lang"]?.jsonPrimitive?.contentOrNull
            if (lang == "id") titleRow["title"]?.jsonPrimitive?.contentOrNull else null
        }
        val title = indonesianTitle
            ?: obj["title"]?.jsonPrimitive?.contentOrNull
            ?: titleRows.firstOrNull()?.jsonObject?.get("title")?.jsonPrimitive?.contentOrNull
            ?: "Untitled"
        val country = obj["country"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val mediaType = when (country.lowercase()) {
            "kr" -> MediaType.MANHWA
            "cn" -> MediaType.MANHUA
            "jp" -> MediaType.MANGA
            else -> MediaType.COMIC
        }
        val status = when (obj["status"]?.jsonPrimitive?.contentOrNull?.lowercase()) {
            "1", "ongoing" -> PublicationStatus.ONGOING
            "2", "completed" -> PublicationStatus.COMPLETED
            "3", "cancelled", "canceled" -> PublicationStatus.CANCELLED
            "4", "hiatus" -> PublicationStatus.HIATUS
            else -> PublicationStatus.UNKNOWN
        }
        val tags = obj["genres"]?.jsonArray.orEmpty().mapNotNull { genre ->
            when (genre) {
                is JsonPrimitive -> genre.contentOrNull
                is JsonObject -> genre["name"]?.jsonPrimitive?.contentOrNull
                else -> null
            }
        }
        val cover = obj["cover_url"]?.jsonPrimitive?.contentOrNull
            ?: obj["md_covers"]?.jsonArray?.firstOrNull()?.jsonObject?.get("b2key")?.jsonPrimitive?.contentOrNull
                ?.let { "$imageBase/$it" }
        return ContentSummary(
            id = hid,
            sourceId = id,
            title = title,
            altTitles = obj["md_titles"]?.jsonArray.orEmpty().mapNotNull {
                it.jsonObject["title"]?.jsonPrimitive?.contentOrNull
            },
            description = obj["desc"]?.jsonPrimitive?.contentOrNull.orEmpty(),
            coverUrl = cover,
            mediaType = mediaType,
            status = status,
            year = obj["year"]?.jsonPrimitive?.intOrNull,
            tags = tags,
            originalLanguage = country.lowercase(),
            readingMode = if (mediaType == MediaType.MANHWA) ReadingMode.WEBTOON else ReadingMode.PAGED,
            contentRating = when (obj["content_rating"]?.jsonPrimitive?.contentOrNull?.lowercase()) {
                "safe" -> ContentRating.SAFE
                "suggestive" -> ContentRating.SUGGESTIVE
                "erotica" -> ContentRating.EROTICA
                "pornographic" -> ContentRating.PORNOGRAPHIC
                else -> ContentRating.UNKNOWN
            },
        )
    }

    private fun readNames(element: JsonElement?): List<String> = element?.jsonArray.orEmpty()
        .mapNotNull { item ->
            when (item) {
                is JsonPrimitive -> item.contentOrNull
                is JsonObject -> item["name"]?.jsonPrimitive?.contentOrNull
                    ?: item["title"]?.jsonPrimitive?.contentOrNull
                else -> null
            }
        }
        .map { it.trim() }
        .filter { it.isNotEmpty() }

    private fun parseIso(value: String?): Long {
        if (value == null) return 0L
        return runCatching { java.time.Instant.parse(value).toEpochMilli() }.getOrDefault(0L)
    }

    private fun encode(value: String): String =
        java.net.URLEncoder.encode(value, "UTF-8")
}
