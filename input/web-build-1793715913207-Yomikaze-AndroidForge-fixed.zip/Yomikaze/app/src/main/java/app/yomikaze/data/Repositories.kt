package app.yomikaze.data

import app.yomikaze.core.*
import app.yomikaze.sources.SourceRegistry
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CatalogRepository @Inject constructor(
    private val registry: SourceRegistry,
) {
    suspend fun search(query: String, sourceId: String?, page: Int = 1, limit: Int = 24): List<ContentSummary> =
        coroutineScope {
            val sources = sourceId?.let { listOf(registry.get(it)) } ?: registry.all()
            sources.map { source ->
                async {
                    runCatching { source.search(query, page, limit) }
                        .getOrDefault(emptyList())
                        .filter { it.contentRating == ContentRating.SAFE }
                }
            }.flatMap { it.await() }
        }

    suspend fun popular(sourceId: String, page: Int = 1, limit: Int = 24): List<ContentSummary> =
        registry.get(sourceId).popular(page, limit).filter { it.contentRating == ContentRating.SAFE }

    suspend fun latest(sourceId: String, page: Int = 1, limit: Int = 24): List<ContentSummary> =
        registry.get(sourceId).latest(page, limit).filter { it.contentRating == ContentRating.SAFE }

    suspend fun details(sourceId: String, contentId: String): ContentDetails =
        registry.get(sourceId).details(contentId).also {
            require(it.summary.contentRating == ContentRating.SAFE) { "This title is not verified for safe reading." }
        }

    suspend fun chapters(sourceId: String, contentId: String): List<Chapter> =
        registry.get(sourceId).chapters(contentId)

    suspend fun chapterContent(sourceId: String, chapterId: String): ChapterContent =
        registry.get(sourceId).loadChapter(chapterId)
}

@Singleton
class LibraryRepository @Inject constructor(
    private val libraryDao: LibraryDao,
    private val progressDao: ProgressDao,
) {
    fun observeLibrary(): Flow<List<LibraryEntity>> = libraryDao.observeAll()

    fun observeProgress(contentId: String): Flow<ProgressEntity?> = progressDao.observe(contentId)

    suspend fun find(contentId: String): LibraryEntity? = libraryDao.find(contentId)

    suspend fun add(summary: ContentSummary) {
        libraryDao.upsert(
            LibraryEntity(
                contentId = summary.id,
                sourceId = summary.sourceId,
                title = summary.title,
                coverUrl = summary.coverUrl,
                mediaType = summary.mediaType.name,
                readingMode = summary.readingMode.name,
                addedAt = System.currentTimeMillis(),
                lastReadAt = null,
            )
        )
    }

    suspend fun remove(contentId: String) = libraryDao.delete(contentId)

    suspend fun saveProgress(contentId: String, chapterId: String, page: Int, totalPages: Int) {
        val now = System.currentTimeMillis()
        progressDao.upsert(ProgressEntity(contentId, chapterId, page, totalPages, now))
        libraryDao.touch(contentId, now)
    }
}

@Singleton
class DownloadRepository @Inject constructor(
    private val downloadDao: DownloadDao,
) {
    fun observeAll(): Flow<List<DownloadEntity>> = downloadDao.observeAll()

    fun observeForContent(contentId: String): Flow<List<DownloadEntity>> =
        downloadDao.observeForContent(contentId)

    suspend fun find(chapterId: String): DownloadEntity? = downloadDao.find(chapterId)

    suspend fun markQueued(chapter: Chapter, directory: String) {
        downloadDao.upsert(
            DownloadEntity(
                chapterId = chapter.id,
                contentId = chapter.contentId,
                sourceId = chapter.sourceId,
                state = "QUEUED",
                totalPages = chapter.pageCount,
                completedPages = 0,
                directory = directory,
            )
        )
    }

    suspend fun update(entity: DownloadEntity) = downloadDao.upsert(entity)

    suspend fun remove(chapterId: String) = downloadDao.delete(chapterId)
}
