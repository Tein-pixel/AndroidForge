package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NovelFireSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "novelfire"
    override val name = "NovelFire"
    override val mediaTypes = setOf(MediaType.NOVEL)

    private val base = "https://novelfire.net"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/search?keyword=${URLEncoder.encode(query, "UTF-8")}&page=${page.coerceAtLeast(1)}")
        return doc.select("div.novel-item, div.book-item, li.novel-item")
            .take(limit)
            .mapNotNull { runCatching { searchItemToSummary(it) }.getOrNull() }
    }

    override suspend fun popular(page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/genre-all/sort-popular?page=$page")
        return doc.select("div.novel-item, div.book-item, li.novel-item")
            .take(limit)
            .mapNotNull { runCatching { searchItemToSummary(it) }.getOrNull() }
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/genre-all/sort-new?page=$page")
        return doc.select("div.novel-item, div.book-item, li.novel-item")
            .take(limit)
            .mapNotNull { runCatching { searchItemToSummary(it) }.getOrNull() }
    }

    override suspend fun details(contentId: String): ContentDetails {
        val slug = contentId.trim('/')
        val doc = parse("$base/book/$slug")
        val title = doc.selectFirst("h1.novel-title, .novel-title, h1")?.text()?.trim().orEmpty()
        val cover = doc.selectFirst(".novel-cover img, .book-cover img, img[alt]")
            ?.absUrl("src")?.takeIf { it.startsWith("http") }
        val description = doc.selectFirst(".summary, .description, div.summary")
            ?.text()?.trim().orEmpty()
        val author = doc.select("a[href*=/author/]").map { it.text().trim() }.filter { it.isNotBlank() }
        val genres = doc.select("a[href*=/genre/]").map { it.text().trim() }.filter { it.isNotBlank() }
        require(isSafeGenres(genres)) { "Novel genre is not verified for safe reading." }
        val summary = ContentSummary(
            id = slug,
            sourceId = id,
            title = title.ifBlank { slug.replace('-', ' ') },
            description = description,
            coverUrl = cover,
            mediaType = MediaType.NOVEL,
            status = PublicationStatus.UNKNOWN,
            tags = genres,
            originalLanguage = "en",
            readingMode = ReadingMode.TEXT,
            contentRating = ContentRating.SAFE,
        )
        return ContentDetails(summary, authors = author, chapters = chapters(slug, null))
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> {
        val slug = contentId.trim('/')
        val all = mutableListOf<Chapter>()
        var page = 1
        while (true) {
            val doc = parse("$base/book/$slug/chapters?page=$page")
            val anchors = doc.select("ul.chapter-list li a, .chapter-list a, a[href*=/chapter-]")
            if (anchors.isEmpty()) break
            anchors.forEach { anchor ->
                val href = anchor.absUrl("href").ifBlank { "$base${anchor.attr("href")}" }
                val number = extractChapterNumber(href) ?: return@forEach
                all += Chapter(
                    id = href,
                    contentId = slug,
                    sourceId = id,
                    number = number,
                    title = anchor.text().trim().takeIf { it.isNotBlank() },
                    language = "en",
                    publishedAt = 0L,
                    url = href,
                )
            }
            val hasNext = doc.selectFirst("a[rel=next], .pagination a:contains(Next)") != null
            if (!hasNext) break
            page += 1
        }
        return all.distinctBy { it.id }.sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }
    }

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val doc = parse(chapterId)
        val title = doc.selectFirst("h1, .chapter-title")?.text()?.trim().orEmpty()
        val content = doc.selectFirst("#content, #chapter-content, .chapter-content, div.text-left")
            ?: error("NovelFire chapter content container missing")
        val paragraphs = content.select("p").map { it.text().trim() }.filter { it.isNotBlank() }
            .ifEmpty { content.text().split("\n").map { it.trim() }.filter { it.isNotBlank() } }
        val prev = doc.selectFirst("a[rel=prev], a:contains(Previous)")?.absUrl("href")
            ?.takeIf { it.startsWith("http") }
        val next = doc.selectFirst("a[rel=next], a:contains(Next)")?.absUrl("href")
            ?.takeIf { it.startsWith("http") }
        return ChapterContent.Text(title, paragraphs, prev, next)
    }

    private suspend fun parse(url: String): Document = withContext(Dispatchers.IO) {
        Jsoup.parse(http.get(url, mapOf("Referer" to "$base/")), url)
    }

    private fun searchItemToSummary(element: Element): ContentSummary {
        val anchor = element.selectFirst("h3 a, .novel-title a, a[href*=/book/]")
            ?: error("NovelFire search item missing anchor")
        val href = anchor.absUrl("href").ifBlank { "$base${anchor.attr("href")}" }
        val slug = href.substringAfter("/book/").substringBefore("/").substringBefore("?")
        val title = anchor.text().trim().ifBlank { slug.replace('-', ' ') }
        val cover = element.selectFirst("img")?.let { img ->
            img.absUrl("src").ifBlank { img.absUrl("data-src") }.ifBlank { img.attr("data-src") }
        }?.takeIf { it.startsWith("http") }
        val genres = element.select("a[href*=/genre/]").map { it.text().trim() }.filter { it.isNotBlank() }
        require(isSafeGenres(genres)) { "Novel genre is not verified for safe reading." }
        return ContentSummary(
            id = slug,
            sourceId = id,
            title = title,
            coverUrl = cover,
            mediaType = MediaType.NOVEL,
            tags = genres,
            readingMode = ReadingMode.TEXT,
            originalLanguage = "en",
            contentRating = ContentRating.SAFE,
        )
    }

    private fun isSafeGenres(genres: List<String>): Boolean {
        if (genres.isEmpty()) return false
        val blockedMarkers = listOf("adult", "mature", "explicit", "nsfw", "smut", "erotic", "sexual", "ecchi", "lewd", "porn")
        return genres.none { genre ->
            val normalized = genre.lowercase().trim()
            blockedMarkers.any(normalized::contains)
        }
    }

    private fun extractChapterNumber(url: String): String? =
        Regex("/chapter-(\\d+(?:\\.\\d+)?)").find(url)?.groupValues?.get(1)
}
