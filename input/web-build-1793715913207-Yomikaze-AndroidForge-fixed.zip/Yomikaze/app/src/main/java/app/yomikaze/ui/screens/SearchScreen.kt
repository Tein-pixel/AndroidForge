package app.yomikaze.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.ui.SearchViewModel
import app.yomikaze.ui.components.ContentCard
import app.yomikaze.ui.components.EmptyState
import app.yomikaze.ui.components.LoadingState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onOpen: (String, String) -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val sources = viewModel.sources()
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Pencarian") })
        OutlinedTextField(
            value = state.query,
            onValueChange = viewModel::setQuery,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            placeholder = { Text("Judul, penulis, kata kunci") },
            trailingIcon = {
                IconButton(onClick = viewModel::submit) { Icon(Icons.Default.Search, null) }
            },
            singleLine = true,
        )
        ScrollableTabRow(
            selectedTabIndex = sources.indexOfFirst { it.id == state.sourceId }.let { if (it < 0) 0 else it + 1 },
        ) {
            Tab(
                selected = state.sourceId == null,
                onClick = { viewModel.setSource(null) },
                text = { Text("Semua") },
            )
            sources.forEach { source ->
                Tab(
                    selected = source.id == state.sourceId,
                    onClick = { viewModel.setSource(source.id) },
                    text = { Text(source.name) },
                )
            }
        }
        when {
            state.loading -> LoadingState()
            state.error != null -> EmptyState(state.error!!)
            state.results.isEmpty() -> EmptyState("Belum ada hasil.")
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(140.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(state.results) { item ->
                    ContentCard(item = item, onClick = { onOpen(item.sourceId, item.id) })
                }
            }
        }
    }
}
