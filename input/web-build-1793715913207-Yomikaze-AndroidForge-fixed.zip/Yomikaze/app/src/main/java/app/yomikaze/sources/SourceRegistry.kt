package app.yomikaze.sources

import app.yomikaze.core.ContentSource
import app.yomikaze.core.MediaType
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SourceRegistry @Inject constructor(
    mangaDex: MangaDexSource,
    comick: ComickSource,
    novelFire: NovelFireSource,
) {
    private val sources: Map<String, ContentSource> =
        listOf(comick, mangaDex, novelFire).associateBy { it.id }

    fun all(): List<ContentSource> = sources.values.toList()

    fun get(sourceId: String): ContentSource =
        sources[sourceId] ?: error("Unknown source: $sourceId")

    fun forMedia(type: MediaType): List<ContentSource> =
        sources.values.filter { type in it.mediaTypes }
}
