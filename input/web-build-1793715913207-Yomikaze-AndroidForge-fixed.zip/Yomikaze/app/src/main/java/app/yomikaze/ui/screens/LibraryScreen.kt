package app.yomikaze.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.core.ContentSummary
import app.yomikaze.core.MediaType
import app.yomikaze.core.ReadingMode
import app.yomikaze.ui.LibraryViewModel
import app.yomikaze.ui.components.ContentCard
import app.yomikaze.ui.components.EmptyState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    onOpen: (String, String) -> Unit,
    viewModel: LibraryViewModel = hiltViewModel(),
) {
    val items by viewModel.library.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Koleksi") })
        if (items.isEmpty()) EmptyState("Koleksi masih kosong.")
        else LazyVerticalGrid(
            columns = GridCells.Adaptive(140.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(items) { item ->
                ContentCard(
                    item = ContentSummary(
                        id = item.contentId,
                        sourceId = item.sourceId,
                        title = item.title,
                        coverUrl = item.coverUrl,
                        mediaType = runCatching { MediaType.valueOf(item.mediaType) }.getOrDefault(MediaType.MANGA),
                        readingMode = runCatching { ReadingMode.valueOf(item.readingMode) }.getOrDefault(ReadingMode.PAGED),
                    ),
                    onClick = { onOpen(item.sourceId, item.contentId) },
                )
            }
        }
    }
}
