// MainActivity.java : java, Android 29+, com.media.access
// Entry point: checks overlay permission, starts BubbleService.
// v5: Pure black/white minimalist UI — no coloured accents.
//     Pill-shaped buttons, reduced padding, clean type hierarchy.
package com.media.access;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    // ── pure black / white palette ────────────────────────────────────────────
    private static final int BG              = 0xFF000000; // pure black
    private static final int BTN_PRIMARY_BG  = 0xFFFFFFFF; // white
    private static final int BTN_PRIMARY_FG  = 0xFF000000; // black text
    private static final int BTN_SECONDARY_BG= 0xFF111111; // near-black
    private static final int BTN_SECONDARY_FG= 0xFFEEEEEE; // near-white text
    private static final int TEXT_TITLE      = 0xFFFFFFFF;
    private static final int TEXT_SUB        = 0xFF888888;
    private static final int DIVIDER_COLOR   = 0xFF1C1C1C;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        setContentView(buildUI());
    }

    // ── UI ────────────────────────────────────────────────────────────────────

    private View buildUI() {
        // Outer scroll in case device is very small
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(px(32), px(72), px(32), px(48));

        // ── title ──────────────────────────────────────────────────────────────
        TextView title = new TextView(this);
        title.setText("System Display");
        title.setTextColor(TEXT_TITLE);
        title.setTextSize(28f);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        root.addView(title, titleLp);

        // version tag
        TextView ver = new TextView(this);
        ver.setText("v5.0  ·  stealth + OCR");
        ver.setTextColor(TEXT_SUB);
        ver.setTextSize(12f);
        ver.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams verLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        verLp.setMargins(0, px(6), 0, px(52));
        root.addView(ver, verLp);

        // ── primary actions ───────────────────────────────────────────────────
        Button startBtn = pillBtn("▶  Mulai", BTN_PRIMARY_BG, BTN_PRIMARY_FG, false);
        startBtn.setOnClickListener(v -> handleStart());
        root.addView(startBtn, btnLp(0, px(52)));

        Button stopBtn = pillBtn("■  Stop", BTN_SECONDARY_BG, BTN_SECONDARY_FG, true);
        stopBtn.setOnClickListener(v -> handleStop());
        root.addView(stopBtn, btnLp(px(12), px(52)));

        // ── divider ───────────────────────────────────────────────────────────
        View div = new View(this);
        div.setBackgroundColor(DIVIDER_COLOR);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        divLp.setMargins(0, px(32), 0, px(32));
        root.addView(div, divLp);

        // ── secondary actions ─────────────────────────────────────────────────
        Button settingsBtn = pillBtn("Pengaturan", BTN_SECONDARY_BG, BTN_SECONDARY_FG, true);
        settingsBtn.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        root.addView(settingsBtn, btnLp(0, px(48)));

        Button accBtn = pillBtn("Aksesibilitas", BTN_SECONDARY_BG, BTN_SECONDARY_FG, true);
        accBtn.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accBtn, btnLp(px(12), px(48)));

        // ── hint ──────────────────────────────────────────────────────────────
        TextView note = new TextView(this);
        note.setText("Aktifkan Overlay + Aksesibilitas agar berfungsi penuh.");
        note.setTextColor(TEXT_SUB);
        note.setTextSize(11f);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        noteLp.setMargins(0, px(36), 0, 0);
        root.addView(note, noteLp);

        scroll.addView(root);
        return scroll;
    }

    // ── actions ───────────────────────────────────────────────────────────────

    private void handleStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        startForegroundService(new Intent(this, BubbleService.class));
        Toast.makeText(this, "Bubble aktif", Toast.LENGTH_SHORT).show();
    }

    private void handleStop() {
        stopService(new Intent(this, BubbleService.class));
        Toast.makeText(this, "Bubble dihentikan", Toast.LENGTH_SHORT).show();
    }

    // ── builder helpers ───────────────────────────────────────────────────────

    /**
     * Fully pill-shaped button via GradientDrawable.
     * cornerRadius of 999dp collapses to half the height → perfect pill.
     * @param withBorder draw a subtle 1px white/dark border on secondary buttons
     */
    private Button pillBtn(String text, int bgColor, int textColor, boolean withBorder) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(textColor);
        btn.setTextSize(14.5f);
        btn.setAllCaps(false);
        btn.setPadding(px(20), 0, px(20), 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(px(999));
        if (withBorder) {
            bg.setStroke(1, 0xFF2A2A2A);
        }
        btn.setBackground(bg);
        return btn;
    }

    private LinearLayout.LayoutParams btnLp(int topMargin, int height) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height);
        lp.setMargins(0, topMargin, 0, 0);
        return lp;
    }

    private int px(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
