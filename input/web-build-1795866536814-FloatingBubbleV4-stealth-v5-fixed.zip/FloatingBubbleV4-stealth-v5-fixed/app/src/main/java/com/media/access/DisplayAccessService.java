// DisplayAccessService.java : java, Android 29+, com.media.access
// Renamed from TextExtractorService. Generic name in Accessibility settings.
//
// Two jobs:
//   1. Hide this app's task from system recents on window-state change.
//   2. On CROP_CONFIRM (LocalBroadcast) → extract text from crop rect.
//      Path A (all API): walk accessibility node tree → collect text from nodes in rect.
//      Path B (API 30+ only, fallback when A is empty): takeScreenshot() → crop bitmap
//        → ML Kit OCR → result. Handles canvas/image content that has no accessible nodes.
//      Path C (auto-camera): triggered when both A and B fail to get text, OR when
//        the screenshot is a black frame (FLAG_SECURE from foreground app), OR on API 29
//        where Path B is not available. EXTRA_NEEDS_CAMERA=true signals BubbleService
//        to automatically launch the camera as fallback.
//
// All broadcasts use LocalBroadcastManager — completely invisible to other apps.
package com.media.access;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.ArrayList;
import java.util.List;

public class DisplayAccessService extends AccessibilityService {

    // ── broadcast actions (intra-process only via LocalBroadcastManager) ─────

    /** BubbleService → this service: user confirmed crop area. */
    public static final String ACTION_CROP_CONFIRM   = "da.CROP_CONFIRM";
    /** This service → BubbleService: extracted text ready. */
    public static final String ACTION_TEXT_EXTRACTED = "da.TEXT_EXTRACTED";

    public static final String EXTRA_RECT_LEFT   = "rl";
    public static final String EXTRA_RECT_TOP    = "rt";
    public static final String EXTRA_RECT_RIGHT  = "rr";
    public static final String EXTRA_RECT_BOTTOM = "rb";
    public static final String EXTRA_TEXT        = "tx";

    /**
     * Boolean extra on ACTION_TEXT_EXTRACTED.
     * true  → text extraction failed because content is pixel-rendered (image/PDF/canvas),
     *         OR the screenshot came back as a black frame (FLAG_SECURE from other app),
     *         OR this device is API 29 where takeScreenshot() is unavailable.
     *         BubbleService should auto-launch the camera as a seamless fallback.
     * false → normal result; text may be empty if there is genuinely no text in the area.
     */
    public static final String EXTRA_NEEDS_CAMERA = "nc";

    // Average brightness threshold (per-channel 0–255) below which a bitmap
    // is classified as a black frame produced by FLAG_SECURE window masking.
    // A fully-black frame has average = 0; real dark-mode UI typically averages 20–80.
    private static final int BLACK_FRAME_THRESHOLD = 12;

    // ── lifecycle ─────────────────────────────────────────────────────────────

    private BroadcastReceiver cropReceiver;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        cropReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (!ACTION_CROP_CONFIRM.equals(intent.getAction())) return;
                Rect rect = new Rect(
                        intent.getIntExtra(EXTRA_RECT_LEFT,   0),
                        intent.getIntExtra(EXTRA_RECT_TOP,    0),
                        intent.getIntExtra(EXTRA_RECT_RIGHT,  0),
                        intent.getIntExtra(EXTRA_RECT_BOTTOM, 0));
                handleCrop(rect);
            }
        };
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(cropReceiver, new IntentFilter(ACTION_CROP_CONFIRM));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cropReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(cropReceiver);
        }
    }

    // ── crop handling ─────────────────────────────────────────────────────────

    private void handleCrop(Rect rect) {
        // Path A: accessibility tree (works for any text rendered as UI nodes)
        String accessText = extractFromRect(rect);
        if (!accessText.isEmpty()) {
            broadcastResult(accessText, false);
            return;
        }

        // Path B: pixel-level OCR via takeScreenshot (API 30+ only)
        // Handles canvas renders, PDF views, games, exam portals drawing to Canvas.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY,
                    getMainExecutor(),
                    new TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(ScreenshotResult result) {
                            Bitmap full    = null;
                            Bitmap cropped = null;
                            try {
                                // ScreenshotResult has no getBitmap(). The public API
                                // (API 30+) only exposes getHardwareBuffer() + getColorSpace().
                                // Wrap HardwareBuffer → hardware-backed Bitmap, then copy to
                                // software ARGB_8888 so we can read pixels and pass to ML Kit.
                                android.hardware.HardwareBuffer hb = result.getHardwareBuffer();
                                Bitmap hwBitmap = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
                                hb.close();
                                if (hwBitmap == null) {
                                    broadcastResult("", true); // Path C: needs camera
                                    return;
                                }
                                full = hwBitmap.copy(Bitmap.Config.ARGB_8888, false);
                                hwBitmap.recycle();

                                // Clamp rect to bitmap bounds
                                int bw = full.getWidth();
                                int bh = full.getHeight();
                                int l = Math.max(0, Math.min(rect.left,   bw - 1));
                                int t = Math.max(0, Math.min(rect.top,    bh - 1));
                                int r = Math.max(1, Math.min(rect.right,  bw));
                                int b = Math.max(1, Math.min(rect.bottom, bh));
                                if (r <= l || b <= t) {
                                    broadcastResult("", true);
                                    return;
                                }

                                cropped = Bitmap.createBitmap(full, l, t, r - l, b - t);

                                // Detect black frame: foreground app uses FLAG_SECURE →
                                // the screenshot masks that app's content to pure black.
                                // No point running OCR on a solid black rectangle.
                                if (isMostlyBlack(cropped)) {
                                    if (cropped != null && !cropped.isRecycled()) cropped.recycle();
                                    broadcastResult("", true); // Path C: needs camera
                                    return;
                                }

                                final Bitmap ocrInput = cropped;
                                ScreenOcrHelper.runOcr(ocrInput, text -> {
                                    ocrInput.recycle();
                                    if (text.isEmpty()) {
                                        // OCR ran on a valid, non-black frame but found nothing.
                                        // Could be an image with text that the Latin model missed
                                        // (e.g. very small font, skewed, non-Latin mixed in).
                                        // Offer camera as fallback rather than showing a dead end.
                                        broadcastResult("", true);
                                    } else {
                                        broadcastResult(text, false);
                                    }
                                });
                            } catch (Exception e) {
                                if (cropped != null && !cropped.isRecycled()) cropped.recycle();
                                broadcastResult("", true); // Path C on any exception
                            } finally {
                                if (full != null && !full.isRecycled()) full.recycle();
                            }
                        }

                        @Override
                        public void onFailure(int errorCode) {
                            // takeScreenshot() reported failure — treat as image content.
                            broadcastResult("", true);
                        }
                    });
        } else {
            // Android 10 (API 29): takeScreenshot() not available.
            // Accessibility tree was empty → content is pixel-rendered.
            // Signal BubbleService to auto-open camera.
            broadcastResult("", true);
        }
    }

    private void broadcastResult(String text, boolean needsCamera) {
        Intent reply = new Intent(ACTION_TEXT_EXTRACTED);
        reply.putExtra(EXTRA_TEXT, text);
        reply.putExtra(EXTRA_NEEDS_CAMERA, needsCamera);
        LocalBroadcastManager.getInstance(this).sendBroadcast(reply);
    }

    // ── black-frame detection ─────────────────────────────────────────────────

    /**
     * Returns true when {@code bmp} is overwhelmingly dark (average per-channel
     * brightness below BLACK_FRAME_THRESHOLD). Samples a 16×16 grid for speed.
     * Hardware bitmaps must be converted to ARGB_8888 before calling this method.
     */
    private static boolean isMostlyBlack(Bitmap bmp) {
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        if (w == 0 || h == 0) return true;

        int stepX = Math.max(1, w / 16);
        int stepY = Math.max(1, h / 16);
        long sum = 0;
        int  count = 0;

        for (int y = 0; y < h; y += stepY) {
            for (int x = 0; x < w; x += stepX) {
                int px = bmp.getPixel(x, y);
                // Sum of R, G, B channels (each 0–255). Average = sum / (count * 3).
                sum += ((px >> 16) & 0xFF)
                     + ((px >>  8) & 0xFF)
                     +  (px        & 0xFF);
                count++;
            }
        }
        if (count == 0) return true;
        // Average per channel: sum / (count * 3)
        return (sum / (count * 3)) < BLACK_FRAME_THRESHOLD;
    }

    // ── accessibility tree extraction ─────────────────────────────────────────

    private String extractFromRect(Rect sel) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "";
        List<String> pieces = new ArrayList<>();
        collectText(root, sel, pieces);
        root.recycle();
        return join(pieces);
    }

    private void collectText(AccessibilityNodeInfo node, Rect sel, List<String> out) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (!Rect.intersects(bounds, sel)) {
            node.recycle();
            return;
        }
        if (node.getChildCount() == 0) {
            CharSequence text = node.getText();
            CharSequence desc = node.getContentDescription();
            String content = (text != null && text.length() > 0)
                    ? text.toString().trim()
                    : (desc != null ? desc.toString().trim() : "");
            if (!content.isEmpty()) out.add(content);
        } else {
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) collectText(child, sel, out);
            }
        }
    }

    private static String join(List<String> parts) {
        if (parts.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(p);
        }
        return sb.toString();
    }

    // ── recents hider ─────────────────────────────────────────────────────────

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (!getPackageName().equals(event.getPackageName())) return;
        hideOwnTask();
    }

    private void hideOwnTask() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return;
        for (ActivityManager.AppTask t : am.getAppTasks()) {
            try { t.setExcludeFromRecents(true); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onInterrupt() {}

    // ── static helper ─────────────────────────────────────────────────────────

    /**
     * Returns true when this service is active in system accessibility settings.
     */
    public static boolean isEnabled(Context ctx) {
        String myComp = ctx.getPackageName() + "/" + DisplayAccessService.class.getName();
        String enabled = Settings.Secure.getString(
                ctx.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.contains(myComp);
    }
}
