// ScreenOcrHelper.java : java, Android 29+, com.media.access
// Wraps ML Kit bundled Latin text recognition.
// runOcr(Bitmap, OcrCallback) → asynchronous, callback on main thread.
// v5: scale-up preprocessing — ML Kit accuracy improves significantly when
//     the shortest image dimension is at least 480 px. For tiny crops
//     (e.g. a single question line or a narrow column), this can be the
//     difference between extracting text and returning empty.
// Caller owns the Bitmap; recycle it in onResult if no longer needed.
// No Play Services required. Latin model bundled in APK (~1.4 MB).
package com.media.access;

import android.graphics.Bitmap;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public final class ScreenOcrHelper {

    private ScreenOcrHelper() {}

    // Min shortest-dimension for reliable ML Kit Latin recognition.
    // Below this, character strokes become < 2px thick and accuracy drops sharply.
    private static final int MIN_DIM_PX = 480;

    public interface OcrCallback {
        /** Called on the main thread. text is empty string on failure or no text found. */
        void onResult(String text);
    }

    /**
     * Run ML Kit OCR on {@code bitmap}.
     * Applies scale-up preprocessing if the image is smaller than MIN_DIM_PX
     * on its shortest side. The preprocessed bitmap is recycled internally;
     * {@code bitmap} itself is never recycled here — caller decides lifecycle.
     */
    public static void runOcr(Bitmap bitmap, OcrCallback cb) {
        if (bitmap == null || bitmap.isRecycled()) {
            cb.onResult("");
            return;
        }

        final Bitmap input = scaledUp(bitmap);   // may be bitmap itself if already large enough
        InputImage image   = InputImage.fromBitmap(input, 0);
        TextRecognizer recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    recycleIfNew(input, bitmap);
                    String text = result.getText().trim();
                    cb.onResult(text);
                    recognizer.close();
                })
                .addOnFailureListener(e -> {
                    recycleIfNew(input, bitmap);
                    cb.onResult("");
                    recognizer.close();
                });
    }

    // ── preprocessing ─────────────────────────────────────────────────────────

    /**
     * Returns a scaled-up copy of {@code src} if its shortest dimension is
     * below MIN_DIM_PX, otherwise returns {@code src} unchanged (no copy).
     * The caller is responsible for recycling the returned bitmap when it
     * differs from src.
     */
    private static Bitmap scaledUp(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        int minDim = Math.min(w, h);
        if (minDim == 0 || minDim >= MIN_DIM_PX) return src;

        float scale = (float) MIN_DIM_PX / minDim;
        int newW = Math.round(w * scale);
        int newH = Math.round(h * scale);
        // createScaledBitmap with filter=true uses bilinear interpolation,
        // which keeps text strokes smooth rather than pixelated.
        return Bitmap.createScaledBitmap(src, newW, newH, true);
    }

    /** Recycles {@code scaled} only if it is a different object from {@code original}. */
    private static void recycleIfNew(Bitmap scaled, Bitmap original) {
        if (scaled != original && !scaled.isRecycled()) {
            scaled.recycle();
        }
    }
}
