
package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Best-effort page parser for source detail/chapter pages. Existing catalog endpoints stay untouched. */
object ManhwaPageRepository {
    private const val PROXY_BASE = "https://api.allorigins.win/raw?url="

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(18, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    data class PageDetails(
        val description: String,
        val genres: List<String>,
        val status: String,
        val chapters: List<Chapter>
    )

    data class Chapter(
        val title: String,
        val url: String
    )

    suspend fun fetchDetails(pageUrl: String): PageDetails =
        withContext(Dispatchers.IO) {
            val mangaDexId = mangaDexTitleId(pageUrl)

            if (mangaDexId != null) {
                return@withContext fetchMangaDexDetails(mangaDexId)
            }

            val html = fetchHtml(pageUrl)
            val doc = Jsoup.parse(html, pageUrl)

            val description = doc.select(
                ".entry-content, .description-summary, .manga-excerpt, .summary__content, .desc, .synopsis, [itemprop=description]"
            ).firstOrNull()?.text()?.trim().orEmpty()

            val genres = doc.select(
                ".manga-genres a, .seriestugenre a, .genres a, .mgen a, .tag-links a"
            ).map {
                it.text().trim()
            }.filter {
                it.isNotBlank()
            }.distinct().take(12)

            val status = doc.select(
                ".post-status .summary-content, .summary-content, .status, .manga-status"
            ).firstOrNull()?.text()?.trim().orEmpty()

            val chapters = doc.select(
                ".eplister a, .listing-chapters_wrap a, .wp-manga-chapter a, .chapter-list a, .chapter-item a, .chbox a, .eph-num a, a[href*='chapter'], a[href*='/ch-']"
            ).mapNotNull { anchor ->
                val url = anchor.absUrl("href")
                    .ifBlank { anchor.attr("href") }

                val title = anchor.text()
                    .trim()
                    .ifBlank { anchor.attr("title").trim() }

                if (url.startsWith("http") && title.isNotBlank()) {
                    Chapter(title, url)
                } else {
                    null
                }
            }.distinctBy {
                it.url
            }.take(250)

            PageDetails(description, genres, status, chapters)
        }

    suspend fun fetchReaderImages(chapterUrl: String): List<String> =
        withContext(Dispatchers.IO) {
            val mangaDexChapterId = mangaDexChapterId(chapterUrl)

            if (mangaDexChapterId != null) {
                return@withContext fetchMangaDexReaderImages(mangaDexChapterId)
            }

            val html = fetchHtml(chapterUrl)
            val doc = Jsoup.parse(html, chapterUrl)

            doc.select(
                "#readerarea img, .reading-content img, .reader-area img, .chapter-content img, .rdminimal img, .chapter-images img, .reading-area img"
            ).mapNotNull { image ->
                val candidate = listOf(
                    "data-src",
                    "data-lazy-src",
                    "data-original",
                    "data-cfsrc",
                    "src"
                ).firstNotNullOfOrNull { key ->
                    image.attr(key).takeIf {
                        it.isNotBlank() && !it.startsWith("data:")
                    }
                }

                val absolute = candidate?.let { raw ->
                    image.absUrl("src").takeIf {
                        it == raw
                    } ?: resolveUrl(chapterUrl, raw)
                }

                absolute?.takeIf {
                    it.startsWith("http")
                }
            }.distinct()
        }

    private fun mangaDexTitleId(pageUrl: String): String? =
        try {
            val uri = java.net.URI(pageUrl)
            val parts = uri.path.split('/').filter { it.isNotBlank() }

            if (
                uri.host?.endsWith("mangadex.org") == true &&
                parts.size >= 2 &&
                parts[0] == "title"
            ) {
                parts[1]
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }

    private fun mangaDexChapterId(chapterUrl: String): String? =
        try {
            val uri = java.net.URI(chapterUrl)
            val parts = uri.path.split('/').filter { it.isNotBlank() }

            if (
                uri.host?.endsWith("mangadex.org") == true &&
                parts.size >= 2 &&
                parts[0] == "chapter"
            ) {
                parts[1]
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }

    private suspend fun fetchMangaDexDetails(
        mangaId: String
    ): PageDetails {

        val mangaUrl = MangaDexApiSource.apiUrl("manga", mangaId)
            .addQueryParameter("includes[]", "cover_art")
            .build()

        val mangaJson = MangaDexApiSource.getJson(mangaUrl)

        val manga = mangaJson.optJSONObject("data")
            ?: throw IllegalStateException("Detail MangaDex tidak ditemukan")

        val attributes = manga.optJSONObject("attributes")
            ?: throw IllegalStateException("Metadata MangaDex kosong")

        val description =
            MangaDexApiSource.preferredLocalizedValue(
                attributes.optJSONObject("description")
            )

        val status = when (attributes.optString("status")) {
            "ongoing" -> "Ongoing"
            "completed" -> "Completed"
            "hiatus" -> "Hiatus"
            "cancelled" -> "Cancelled"
            else -> "Status tidak tersedia"
        }

        val genres = mutableListOf<String>()
        val tags = attributes.optJSONArray("tags")

        if (tags != null) {
            for (index in 0 until tags.length()) {
                val tag = tags.optJSONObject(index) ?: continue

                if (
                    tag.optJSONObject("attributes")
                        ?.optString("group") == "genre"
                ) {
                    val name =
                        MangaDexApiSource.preferredLocalizedValue(
                            tag.optJSONObject("attributes")
                                ?.optJSONObject("name")
                        )

                    if (name.isNotBlank()) {
                        genres.add(name)
                    }
                }
            }
        }

        val chapterUrl = MangaDexApiSource.apiUrl("chapter")
            .addQueryParameter("manga", mangaId)
            .addQueryParameter("limit", "100")
            .addQueryParameter("order[chapter]", "desc")
            .addQueryParameter("translatedLanguage[]", "id")
            .addQueryParameter("translatedLanguage[]", "en")
            .addQueryParameter("includes[]", "scanlation_group")
            .build()

        val chapterJson = MangaDexApiSource.getJson(chapterUrl)
        val chapterData = chapterJson.optJSONArray("data")

        val chapters = mutableListOf<Chapter>()

        if (chapterData != null) {
            for (index in 0 until chapterData.length()) {
                val chapter = chapterData.optJSONObject(index) ?: continue

                val id = chapter.optString("id")
                    .takeIf { it.isNotBlank() } ?: continue

                val chapterAttributes =
                    chapter.optJSONObject("attributes") ?: continue

                val number =
                    chapterAttributes.optString("chapter").ifBlank { "?" }

                val volume = chapterAttributes.optString("volume")
                val title = chapterAttributes.optString("title").trim()

                val group = chapter.optJSONArray("relationships")
                    ?.let { relationships ->
                        (0 until relationships.length())
                            .firstNotNullOfOrNull { relIndex ->
                                val relation =
                                    relationships.optJSONObject(relIndex)
                                        ?: return@firstNotNullOfOrNull null

                                if (relation.optString("type") == "scanlation_group") {
                                    relation.optJSONObject("attributes")
                                        ?.optString("name")
                                        ?.takeIf { it.isNotBlank() }
                                } else {
                                    null
                                }
                            }
                    }.orEmpty()

                val label = buildString {
                    append("Chapter ").append(number)

                    if (volume.isNotBlank()) {
                        append(" · Vol. ").append(volume)
                    }

                    if (title.isNotBlank()) {
                        append(" · ").append(title)
                    }

                    // MangaDex attribution requirement.
                    if (group.isNotBlank()) {
                        append(" · Scanlation: ").append(group)
                    }
                }

                chapters.add(
                    Chapter(
                        label,
                        "https://mangadex.org/chapter/$id"
                    )
                )
            }
        }

        // FIX: Explicit return required for block-body function.
        return PageDetails(
            description,
            genres.distinct(),
            status,
            chapters.distinctBy { it.url }
        )
    }

    private suspend fun fetchMangaDexReaderImages(
        chapterId: String
    ): List<String> {

        val url = MangaDexApiSource.apiUrl(
            "at-home",
            "server",
            chapterId
        ).build()

        val json = MangaDexApiSource.getJson(url)

        val baseUrl = json.optString("baseUrl").trimEnd('/')
        val chapter = json.optJSONObject("chapter") ?: return emptyList()

        val hash = chapter.optString("hash")
        val files = chapter.optJSONArray("data") ?: return emptyList()

        if (baseUrl.isBlank() || hash.isBlank()) {
            return emptyList()
        }

        return (0 until files.length()).mapNotNull { index ->
            val file = files.optString(index)

            if (file.isBlank()) {
                null
            } else {
                "$baseUrl/data/$hash/${
                    java.net.URLEncoder.encode(file, "UTF-8")
                        .replace("+", "%20")
                }"
            }
        }
    }

    private fun fetchHtml(url: String): String {
        val proxiedUrl =
            PROXY_BASE + URLEncoder.encode(url, "UTF-8")

        val request = Request.Builder()
            .url(proxiedUrl)
            .header(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36"
            )
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException(
                    "Server sumber merespons ${response.code}"
                )
            }

            return response.body?.string().orEmpty()
        }
    }

    private fun resolveUrl(base: String, value: String): String =
        try {
            java.net.URI(base).resolve(value).toString()
        } catch (_: Exception) {
            value
        }
}
