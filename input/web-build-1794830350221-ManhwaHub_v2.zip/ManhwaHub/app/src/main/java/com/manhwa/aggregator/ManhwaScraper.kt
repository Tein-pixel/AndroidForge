package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ManhwaScraper {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> = withContext(Dispatchers.IO) {
        val list = mutableListOf<Manhwa>()
        try {
            var url = "https://api.comick.fun/v1.0/search?limit=30&page=1&order=new"

            if (query.isNotEmpty()) {
                val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
                url = "https://api.comick.fun/v1.0/search?q=$encodedQuery&limit=30"
            } else if (genre.isNotEmpty() && genre != "Semua") {
                url += "&genres=${genre.lowercase()}"
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("User-Agent", "ManhwaHubApp/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val json = JSONObject(response.body?.string() ?: "")
                    val data = json.optJSONArray("data")

                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val item = data.getJSONObject(i)
                            val title = item.optString("title")
                            val slug = item.optString("slug")

                            var imageUrl = ""
                            val covers = item.optJSONArray("md_covers")
                            if (covers != null && covers.length() > 0) {
                                val b2key = covers.getJSONObject(0).optString("b2key")
                                imageUrl = "https://meo.comick.pictures/$b2key"
                            }

                            var latestChapter = "Terbaru"
                            if (item.has("last_chapter") && !item.isNull("last_chapter")) {
                                latestChapter = "Ch. ${item.optString("last_chapter")}"
                            }

                            if (title.isNotEmpty() && slug.isNotEmpty()) {
                                list.add(
                                    Manhwa(
                                        title = title,
                                        link = "https://comick.io/comic/$slug",
                                        imageUrl = imageUrl,
                                        latestChapter = latestChapter,
                                        source = "Comick"
                                    )
                                )
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (list.isEmpty()) {
            list.add(
                Manhwa(
                    title = "Gagal Memuat Data",
                    link = "https://google.com",
                    imageUrl = "",
                    latestChapter = "Periksa koneksi Anda",
                    source = "System"
                )
            )
        }

        list
    }
}
