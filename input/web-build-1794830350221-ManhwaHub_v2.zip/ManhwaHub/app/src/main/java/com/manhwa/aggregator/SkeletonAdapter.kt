package com.manhwa.aggregator

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.recyclerview.widget.RecyclerView

class SkeletonAdapter : RecyclerView.Adapter<SkeletonAdapter.ViewHolder>() {

    private val animators = mutableMapOf<Int, ObjectAnimator>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_skeleton, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        animators[position]?.cancel()

        // Stagger each card's pulse so they breathe at different phases
        val delay = (position * 120L)

        val anim = ObjectAnimator.ofFloat(holder.itemView, "alpha", 0.35f, 0.85f).apply {
            duration = 850
            startDelay = delay % 600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        anim.start()
        animators[position] = anim

        // Entrance: slide up into view
        holder.itemView.translationY = 24f
        holder.itemView.animate()
            .translationY(0f)
            .setDuration(260)
            .setStartDelay(position * 40L)
            .start()
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        animators[holder.bindingAdapterPosition]?.cancel()
        holder.itemView.alpha = 1f
    }

    override fun getItemCount() = 6

    fun cancelAll() {
        animators.values.forEach { it.cancel() }
        animators.clear()
    }
}
