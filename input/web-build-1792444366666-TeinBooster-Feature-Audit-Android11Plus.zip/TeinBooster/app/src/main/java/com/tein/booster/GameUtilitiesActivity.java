package com.tein.booster;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Lightweight timer/cooldown utility and screenshot picker. It never runs a hidden background service. */
public class GameUtilitiesActivity extends BaseActivity {
    private static final String PREF = "game_utility_timer";
    private static final long[] PRESETS = {30_000L, 60_000L, 180_000L, 300_000L, 600_000L};
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private TextView timerText, stateText, startButton, reticleStatus;
    private boolean requestedReticlePermission;
    private long duration = 60_000L;
    private long endAt;
    private long pausedRemaining = 60_000L;
    private boolean running;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!alive() || timerText == null) return;
            long remain = endAt - System.currentTimeMillis();
            if (running && remain <= 0) {
                running = false;
                pausedRemaining = 0;
                saveState();
                updateDisplay(0);
                stateText.setText("Selesai · timer mencapai nol");
                startButton.setText("Mulai lagi");
                getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                Toast.makeText(GameUtilitiesActivity.this, "Timer game selesai", Toast.LENGTH_SHORT).show();
                return;
            }
            updateDisplay(running ? remain : pausedRemaining);
            handler.postDelayed(this, 250L);
        }
    };

    @Override protected String title() { return "Utilitas Gaming"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        android.content.SharedPreferences prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        duration = prefs.getLong("duration", 60_000L);
        pausedRemaining = prefs.getLong("remaining", duration);
        running = prefs.getBoolean("running", false);
        endAt = prefs.getLong("end_at", 0L);
        if (running && endAt > 0) pausedRemaining = Math.max(0, endAt - System.currentTimeMillis());
        if (running && pausedRemaining <= 0) running = false;

        LinearLayout col = scrollBody();
        LinearLayout timerCard = Ui.card(this);
        timerCard.addView(Ui.tvb(this, "TIMER / COOLDOWN", 13, Ui.CYAN));
        timerText = Ui.num(this, "01:00", 40, Ui.TEXT);
        timerText.setGravity(Gravity.CENTER);
        timerCard.addView(timerText, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        stateText = Ui.tv(this, "Pilih durasi, lalu mulai. Timer menghitung waktu nyata.", 11, Ui.SUB);
        stateText.setGravity(Gravity.CENTER);
        timerCard.addView(stateText, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        timerCard.addView(Ui.segment(this, new String[]{"30 dtk", "1 mnt", "3 mnt", "5 mnt", "10 mnt"}, indexFor(duration), index -> {
            if (running) { Toast.makeText(this, "Jeda timer sebelum mengganti durasi.", Toast.LENGTH_SHORT).show(); return; }
            duration = PRESETS[index]; pausedRemaining = duration; saveState(); updateDisplay(pausedRemaining);
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        LinearLayout buttons = Ui.row(this);
        startButton = Ui.button(this, running ? "Jeda" : "Mulai", v -> toggleTimer());
        buttons.addView(startButton, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        buttons.addView(Ui.ghost(this, "Reset", v -> resetTimer()), Ui.lp(this, 0, Ui.WRAP, 8, 0, 0, 0));
        buttons.getChildAt(1).setLayoutParams(new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        timerCard.addView(buttons, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        timerCard.addView(Ui.tv(this, "Catatan: biarkan halaman ini terbuka agar alarm visual selesai muncul. Timer tidak berjalan sebagai alarm latar ketika proses aplikasi dihentikan.", 10, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(timerCard, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout gallery = Ui.card(this);
        gallery.addView(Ui.tvb(this, "Screenshot & galeri", 15, Ui.TEXT));
        gallery.addView(Ui.tv(this, "Buka pemilih gambar Android untuk memilih screenshot atau gambar gameplay. TeinBooster tidak memindahkan atau menghapus berkas.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        gallery.addView(Ui.button(this, "Buka galeri screenshot", v -> openGallery()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(gallery, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout reticle = Ui.card(this);
        reticle.addView(Ui.tvb(this, "Retikel / crosshair visual", 15, Ui.TEXT));
        reticle.addView(Ui.tv(this, "Retikel statis di tengah layar untuk game. Memerlukan izin overlay dan tidak menyentuh input. Beberapa game atau sistem anti-cheat mungkin melarang overlay; matikan jika game memberi peringatan.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        reticleStatus = Ui.tvb(this, "Status: " + (CrosshairService.running ? "aktif" : "mati"), 12, Ui.CYAN);
        reticle.addView(reticleStatus, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        LinearLayout reticleButtons = Ui.row(this);
        reticleButtons.addView(Ui.button(this, "Aktifkan", v -> enableReticle()), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        reticleButtons.addView(Ui.ghost(this, "Matikan", v -> stopReticle()), Ui.lp(this, 0, Ui.WRAP, 8, 0, 0, 0));
        reticleButtons.getChildAt(1).setLayoutParams(new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        reticle.addView(reticleButtons, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(reticle, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout info = Ui.card(this);
        info.addView(Ui.tvb(this, "Pelacakan waktu game", 15, Ui.TEXT));
        info.addView(Ui.tv(this, "Daftar Game Saya melacak durasi ketika kamu membuka game lewat tombol BUKA GAME, lalu kembali ke TeinBooster. Ini bukan data penuh dari sistem dan tidak menghitung sesi yang dibuka di luar aplikasi.", 11, Ui.SUB));
        info.addView(Ui.button(this, "Lihat perpustakaan game", v -> startActivity(new Intent(this, GameLibraryActivity.class))), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(info);
        updateDisplay(pausedRemaining);
        if (running) stateText.setText("Berjalan · halaman tetap aktif");
        else if (pausedRemaining <= 0) stateText.setText("Selesai");
        startButton.setText(running ? "Jeda" : "Mulai");
    }

    private void enableReticle() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            requestedReticlePermission = true;
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) { requestedReticlePermission = false; Toast.makeText(this, "Beri izin Tampil di atas aplikasi lain melalui Pengaturan Android.", Toast.LENGTH_LONG).show(); }
            return;
        }
        startReticleService();
    }

    private void startReticleService() {
        requestedReticlePermission = false;
        try {
            Intent i = new Intent(this, CrosshairService.class).setAction(CrosshairService.ACTION_START);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Perintah aktivasi retikel dikirim.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "Retikel gagal diaktifkan pada perangkat ini.", Toast.LENGTH_LONG).show(); }
    }

    private void stopReticle() {
        try { startService(new Intent(this, CrosshairService.class).setAction(CrosshairService.ACTION_STOP)); }
        catch (Exception e) { stopService(new Intent(this, CrosshairService.class)); }
        Toast.makeText(this, "Perintah mematikan retikel dikirim.", Toast.LENGTH_SHORT).show();
    }

    private int indexFor(long d) {
        for (int i = 0; i < PRESETS.length; i++) if (PRESETS[i] == d) return i;
        return 1;
    }

    private void toggleTimer() {
        if (!running) {
            if (pausedRemaining <= 0) pausedRemaining = duration;
            endAt = System.currentTimeMillis() + pausedRemaining;
            running = true;
            stateText.setText("Berjalan · halaman tetap aktif");
            startButton.setText("Jeda");
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            saveState();
            handler.removeCallbacks(ticker);
            handler.post(ticker);
        } else {
            pausedRemaining = Math.max(0, endAt - System.currentTimeMillis());
            running = false;
            getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            stateText.setText("Dijeda");
            startButton.setText("Lanjutkan");
            saveState();
            handler.removeCallbacks(ticker);
            updateDisplay(pausedRemaining);
        }
    }

    private void resetTimer() {
        running = false; endAt = 0; pausedRemaining = duration;
        handler.removeCallbacks(ticker);
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        stateText.setText("Siap"); startButton.setText("Mulai"); saveState(); updateDisplay(pausedRemaining);
    }

    private void updateDisplay(long ms) {
        if (timerText == null) return;
        long totalSeconds = Math.max(0L, (ms + 999L) / 1000L);
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        timerText.setText(String.format(Locale.US, "%02d:%02d", minutes, seconds));
    }

    private void saveState() {
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putLong("duration", duration).putLong("remaining", pausedRemaining)
                .putLong("end_at", endAt).putBoolean("running", running).apply();
    }

    private void openGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
            startActivity(intent);
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("content://media/external/images/media"))); }
            catch (Exception ignored) { Toast.makeText(this, "Tidak ada aplikasi galeri yang tersedia.", Toast.LENGTH_LONG).show(); }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (requestedReticlePermission && (android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this))) startReticleService();
        if (reticleStatus != null) reticleStatus.setText("Status: " + (CrosshairService.running ? "aktif" : "mati"));
        if (running) {
            pausedRemaining = Math.max(0, endAt - System.currentTimeMillis());
            if (pausedRemaining <= 0) { running = false; pausedRemaining = 0; saveState(); startButton.setText("Mulai lagi"); stateText.setText("Selesai"); }
            else { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); handler.removeCallbacks(ticker); handler.post(ticker); }
            updateDisplay(pausedRemaining);
        }
    }

    @Override protected void onPause() {
        handler.removeCallbacks(ticker);
        if (running) pausedRemaining = Math.max(0, endAt - System.currentTimeMillis());
        saveState();
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }
}
