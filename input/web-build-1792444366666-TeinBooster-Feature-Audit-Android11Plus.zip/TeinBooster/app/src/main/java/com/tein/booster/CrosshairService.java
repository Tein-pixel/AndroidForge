package com.tein.booster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/** Static visual reticle overlay only; no input capture, touch interception, or game modification. */
public class CrosshairService extends Service {
    public static final String ACTION_START = "com.tein.booster.crosshair.START";
    public static final String ACTION_STOP = "com.tein.booster.crosshair.STOP";
    private static final String CHANNEL = "tein_crosshair";
    private static final int NOTIFICATION_ID = 7302;
    public static volatile boolean running = false;
    private WindowManager wm;
    private View reticle;

    @Override public void onCreate() {
        super.onCreate();
        Ui.applyTheme(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Game reticle", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Status reticle visual overlay TeinBooster");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopReticle(); return START_NOT_STICKY; }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        try {
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
            Notification notification = builder.setContentTitle("TeinBooster • Reticle")
                    .setContentText("Retikel visual aktif di tengah layar")
                    .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            createOverlay();
            running = true;
        } catch (Exception e) {
            stopReticle();
        }
        return START_NOT_STICKY;
    }

    private void createOverlay() {
        if (reticle != null) { try { wm.removeView(reticle); } catch (Exception ignored) { } reticle = null; }
        reticle = new ReticleView(this);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        wm.addView(reticle, p);
    }

    private void stopReticle() {
        running = false;
        if (wm != null && reticle != null) { try { wm.removeView(reticle); } catch (Exception ignored) { } }
        reticle = null;
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        running = false;
        if (wm != null && reticle != null) { try { wm.removeView(reticle); } catch (Exception ignored) { } }
        reticle = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static final class ReticleView extends View {
        private final Paint outline = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density;
        ReticleView(Context context) {
            super(context);
            density = context.getResources().getDisplayMetrics().density;
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            outline.setColor(0xFF000000); outline.setStrokeWidth(3.2f * density); outline.setStyle(Paint.Style.STROKE);
            line.setColor(Prefs.getInt(context, "crosshair_color", Ui.MINT));
            line.setStrokeWidth(1.7f * density); line.setStyle(Paint.Style.STROKE);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float x = getWidth() / 2f, y = getHeight() / 2f;
            float gap = 5f * density, reach = 13f * density, radius = 3.5f * density;
            drawParts(canvas, outline, x, y, gap, reach, radius);
            drawParts(canvas, line, x, y, gap, reach, radius);
        }
        private void drawParts(Canvas c, Paint p, float x, float y, float gap, float reach, float r) {
            c.drawLine(x - reach, y, x - gap, y, p); c.drawLine(x + gap, y, x + reach, y, p);
            c.drawLine(x, y - reach, x, y - gap, p); c.drawLine(x, y + gap, x, y + reach, p);
            c.drawCircle(x, y, r, p);
        }
    }
}
