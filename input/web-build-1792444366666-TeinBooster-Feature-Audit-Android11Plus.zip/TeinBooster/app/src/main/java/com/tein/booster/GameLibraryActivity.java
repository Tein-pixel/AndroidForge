package com.tein.booster;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Launcher library for games. No app is launched or changed without a tap. */
public class GameLibraryActivity extends BaseActivity {
    private static final String PREFS = "game_library";
    private static final String FAVS = "favorite_packages";
    private static final String MAIN_GAME = "main_game_package";
    private final List<Game> allGames = new ArrayList<>();
    private LinearLayout list;
    private TextView count;
    private EditText search;
    private boolean favoritesOnly;
    private boolean loading;
    private Set<String> favorites = new HashSet<>();
    private String mainGame = "";
    private TextView totalPlaytime;

    private static final class Game {
        final String label, pkg;
        final Drawable icon;
        Game(String label, String pkg, Drawable icon) { this.label = label; this.pkg = pkg; this.icon = icon; }
    }

    @Override protected String title() { return "Game Saya"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> saved = sp.getStringSet(FAVS, null);
        favorites = saved == null ? new HashSet<String>() : new HashSet<>(saved);
        mainGame = sp.getString(MAIN_GAME, "");

        LinearLayout col = scrollBody();
        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.tvb(this, "PERPUSTAKAAN GAME", 15, Ui.MINT));
        intro.addView(Ui.tv(this, "Pilih game yang terpasang, buka langsung, tandai favorit, atau simpan sebagai game utama. Waktu dicatat jika game dibuka dari sini lalu kembali ke TeinBooster.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        totalPlaytime = Ui.tv(this, "Total waktu game dilacak: 0 mnt", 11, Ui.CYAN);
        intro.addView(totalPlaytime, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(intro, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 12));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(Ui.SUB);
        search.setHint("Cari nama game atau paket…");
        search.setTextSize(14);
        search.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        search.setBackground(Ui.outline(this, Ui.PANEL, Ui.LINE, 12));
        col.addView(search, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));

        LinearLayout filters = Ui.row(this);
        filters.addView(Ui.button2(this, "Semua aplikasi", Ui.CYAN, Ui.BLUE, v -> { favoritesOnly = false; render(); }), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        filters.addView(Ui.ghost(this, "Favorit", v -> { favoritesOnly = true; render(); }), Ui.lp(this, 0, Ui.WRAP, 8, 0, 0, 0));
        filters.getChildAt(1).setLayoutParams(new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        col.addView(filters, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));

        count = Ui.tv(this, "Memuat daftar aplikasi…", 12, Ui.SUB);
        col.addView(count, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        list = Ui.col(this);
        col.addView(list);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { render(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        loadGames();
        render();
    }

    private void loadGames() {
        loading = true;
        if (count != null) count.setText("Memuat aplikasi yang bisa dibuka…");
        Bg.run(() -> {
            final List<Game> found = new ArrayList<>();
            final String[] error = new String[1];
            PackageManager pm = getPackageManager();
            try {
                List<ApplicationInfo> installed = pm.getInstalledApplications(0);
                for (ApplicationInfo ai : installed) {
                    if (ai == null || getPackageName().equals(ai.packageName)) continue;
                    Intent launch = pm.getLaunchIntentForPackage(ai.packageName);
                    if (launch == null) continue;
                    String label;
                    Drawable icon;
                    try { label = String.valueOf(pm.getApplicationLabel(ai)); } catch (Exception e) { label = ai.packageName; }
                    try { icon = pm.getApplicationIcon(ai); } catch (Exception e) { icon = null; }
                    found.add(new Game(label, ai.packageName, icon));
                }
            } catch (Exception e) {
                error[0] = "Daftar aplikasi tidak dapat dibaca: " + e.getClass().getSimpleName();
            }
            final Collator collator = Collator.getInstance(new Locale("id", "ID"));
            Collections.sort(found, new Comparator<Game>() {
                @Override public int compare(Game a, Game b) { return collator.compare(a.label, b.label); }
            });
            Bg.ui(() -> {
                if (!alive()) return;
                allGames.clear(); allGames.addAll(found); loading = false;
                if (error[0] != null) Toast.makeText(this, error[0], Toast.LENGTH_LONG).show();
                render();
            });
        });
    }

    private void saveFavorites() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet(FAVS, new HashSet<>(favorites)).apply();
    }

    private void render() {
        if (list == null || count == null) return;
        list.removeAllViews();
        if (loading) { count.setText("Memuat aplikasi yang bisa dibuka…"); return; }
        String query = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        for (final Game game : allGames) {
            if (favoritesOnly && !favorites.contains(game.pkg)) continue;
            if (!query.isEmpty() && !game.label.toLowerCase(Locale.ROOT).contains(query) && !game.pkg.toLowerCase(Locale.ROOT).contains(query)) continue;
            shown++;
            LinearLayout card = Ui.card(this);
            card.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
            LinearLayout row = Ui.row(this);
            ImageView icon = new ImageView(this);
            if (game.icon != null) icon.setImageDrawable(game.icon);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            row.addView(icon, Ui.lp(this, Ui.dp(this, 44), Ui.dp(this, 44), 0, 0, 10, 0));
            LinearLayout titles = Ui.col(this);
            titles.addView(Ui.tvb(this, game.label, 14, Ui.TEXT));
            TextView pkg = Ui.tv(this, game.pkg, 10, Ui.SUB);
            pkg.setMaxLines(2);
            titles.addView(pkg, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
            long tracked = GamePlaytime.totalMillis(this, game.pkg);
            long sessions = GamePlaytime.sessions(this, game.pkg);
            titles.addView(Ui.tv(this, "Dilacak: " + GamePlaytime.format(tracked) + "  ·  " + sessions + " sesi", 10, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
            if (game.pkg.equals(mainGame)) titles.addView(Ui.chip(this, "GAME UTAMA", Ui.CYAN), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 5, 0, 0));
            row.addView(titles, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            card.addView(row);

            LinearLayout actions = Ui.row(this);
            TextView fav = Ui.ghost(this, favorites.contains(game.pkg) ? "★ Favorit" : "☆ Favorit", v -> {
                if (favorites.contains(game.pkg)) favorites.remove(game.pkg); else favorites.add(game.pkg);
                saveFavorites(); render();
            });
            fav.setTextSize(12);
            actions.addView(fav, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            TextView setMain = Ui.ghost(this, game.pkg.equals(mainGame) ? "Game utama ✓" : "Jadikan utama", v -> {
                mainGame = game.pkg;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(MAIN_GAME, mainGame).apply();
                // Keep the existing Game Booster's selected-game list in sync rather than creating a disconnected duplicate.
                Set<String> configuredGames = Prefs.getSet(this, Prefs.GAMES);
                configuredGames.add(game.pkg);
                Prefs.putSet(this, Prefs.GAMES, configuredGames);
                Toast.makeText(this, game.label + " disimpan sebagai game utama dan ditambahkan ke Game Booster", Toast.LENGTH_SHORT).show(); render();
            });
            setMain.setTextSize(12);
            actions.addView(setMain, Ui.lp(this, 0, Ui.WRAP, 6, 0, 0, 0));
            actions.getChildAt(0).setLayoutParams(new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            actions.getChildAt(1).setLayoutParams(new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            card.addView(actions, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
            card.addView(Ui.button(this, "BUKA GAME", v -> launch(game)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
            list.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        }
        count.setText(shown + " aplikasi ditampilkan dari " + allGames.size() + " aplikasi yang bisa dibuka" + (favoritesOnly ? " • mode favorit" : ""));
        if (shown == 0) {
            TextView empty = Ui.tv(this, favoritesOnly ? "Belum ada favorit. Tandai aplikasi dengan ☆ Favorit dari tab Semua." : "Tidak ada aplikasi yang cocok dengan pencarian.", 13, Ui.SUB);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, Ui.dp(this, 22), 0, Ui.dp(this, 22));
            list.addView(empty);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        GamePlaytime.finishPending(this);
        if (totalPlaytime != null) totalPlaytime.setText("Total waktu game dilacak: " + GamePlaytime.format(GamePlaytime.totalAllMillis(this)));
        if (list != null && !loading) render();
    }

    private void launch(Game game) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(game.pkg);
            if (i == null) { Toast.makeText(this, "Game tidak dapat dibuka dari launcher.", Toast.LENGTH_SHORT).show(); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            GamePlaytime.begin(this, game.pkg);
            startActivity(i);
        } catch (ActivityNotFoundException | SecurityException e) {
            GamePlaytime.cancelPending(this);
            Toast.makeText(this, "Tidak dapat membuka aplikasi ini.", Toast.LENGTH_SHORT).show();
        }
    }
}
