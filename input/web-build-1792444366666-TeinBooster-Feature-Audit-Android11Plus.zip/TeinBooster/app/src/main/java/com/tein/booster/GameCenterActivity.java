package com.tein.booster;

import android.content.Intent;
import android.net.TrafficStats;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Pusat fitur gaming tambahan; data monitor diambil dari API sistem Android. */
public class GameCenterActivity extends BaseActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView ramValue, batteryValue, tempValue, pingValue, trafficValue, connectionValue, pingButton;
    private long lastTraffic = -1L;
    private long lastTrafficAt = 0L;
    private boolean pinging;
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            if (!alive()) return;
            refreshStats();
            handler.postDelayed(this, 2000L);
        }
    };

    @Override protected String title() { return "Pusat Gaming"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = scrollBody();
        col.addView(Ui.tv(this, "Alat gaming tambahan untuk panduan grafis, monitor, uji input, dan latihan refleks.", 14, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));

        LinearLayout status = Ui.card(this);
        status.addView(Ui.tvb(this, "KONDISI PERANGKAT", 13, Ui.MINT));
        LinearLayout stats = Ui.row(this);
        ramValue = metric(stats, "RAM", "-");
        batteryValue = metric(stats, "BATERAI", "-");
        tempValue = metric(stats, "SUHU", "-");
        status.addView(stats, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        connectionValue = Ui.tv(this, "Jaringan: membaca…", 12, Ui.SUB);
        status.addView(connectionValue, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(status, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));

        LinearLayout monitor = Ui.card(this);
        LinearLayout heading = Ui.row(this);
        heading.addView(Ui.tvb(this, "MONITOR LANGSUNG", 14, Ui.MINT), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        pingValue = Ui.tvb(this, "PING --", 14, Ui.TEXT);
        heading.addView(pingValue);
        monitor.addView(heading);
        trafficValue = Ui.tv(this, "Lalu lintas perangkat: menghitung…", 13, Ui.SUB);
        monitor.addView(trafficValue, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        pingButton = Ui.button(this, "Uji ping ke 1.1.1.1", v -> runPing());
        monitor.addView(pingButton, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        monitor.addView(Ui.tv(this, "Ping menggunakan koneksi TCP ke layanan publik; hasil dapat berbeda dari ping server game.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(monitor, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        col.addView(Ui.sectionTitle(this, "ALAT GAMING"));
        LinearLayout r1 = Ui.row(this);
        r1.addView(tile("GFX GUIDE", "Panduan grafis", "FPS, resolusi, efek", GfxGuideActivity.class), weight());
        r1.addView(tile("GAME HUD", "HUD mengambang", "RAM, baterai, suhu", GameHudActivity.class), weight());
        col.addView(r1, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout r2 = Ui.row(this);
        r2.addView(tile("MONITOR", "Monitor performa", "Statistik real-time", PerformanceMonitorActivity.class), weight());
        r2.addView(tile("ALAT UJI", "Tes sentuhan", "Layar & kontroler", TouchTestActivity.class), weight());
        col.addView(r2, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout r3 = Ui.row(this);
        r3.addView(tile("LATIHAN", "Latihan gamer", "Tes reaksi dan akurasi", GamerTrainingActivity.class), weight());
        r3.addView(tile("COACH", "Game Coach", "Rekomendasi manual", GameCoachActivity.class), weight());
        col.addView(r3, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout r4 = Ui.row(this);
        r4.addView(tile("ULTRA MODE", "Hemat daya", "Profil baterai yang tersedia", BatteryActivity.class), weight());
        r4.addView(tile("JARINGAN", "Cek jaringan", "DNS, ping dan kecepatan", NetworkActivity.class), weight());
        col.addView(r4, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout r5 = Ui.row(this);
        r5.addView(tile("GAME SAYA", "Perpustakaan game", "Cari, favoritkan, dan buka game", GameLibraryActivity.class), weight());
        r5.addView(tile("GAME PANEL", "Kontrol cepat", "Volume, kecerahan panel, getar", GamePanelActivity.class), weight());
        col.addView(r5, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout r6 = Ui.row(this);
        r6.addView(tile("RECORDER", "Perekam layar", "Simpan gameplay ke MP4", ScreenRecorderActivity.class), weight());
        r6.addView(tile("AUDIO METER", "Visualisasi suara", "Tes mikrofon saat dibutuhkan", SoundVisualizerActivity.class), weight());
        col.addView(r6, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout extra = Ui.card(this);
        extra.addView(Ui.tvb(this, "UTILITAS & AKSES ADB", 13, Ui.CYAN));
        extra.addView(Ui.button(this, "Timer cooldown & galeri screenshot", v -> startActivity(new Intent(this, GameUtilitiesActivity.class))), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        extra.addView(Ui.ghost(this, "Shizuku / Brevent / refresh rate", v -> startActivity(new Intent(this, CompanionAccessActivity.class))), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        col.addView(extra, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 12));
        col.addView(Ui.button2(this, "Pilih dan jalankan game", Ui.CYAN, Ui.BLUE, v -> startActivity(new Intent(this, GameBoosterActivity.class))), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(Ui.tv(this, "Catatan: aplikasi tidak dapat memaksa FPS, mengubah grafis internal game, atau menambah kemampuan perangkat. Terapkan rekomendasi lewat pengaturan game.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        refreshStats();
    }

    private TextView metric(LinearLayout parent, String label, String initial) {
        LinearLayout box = Ui.col(this);
        box.setPadding(Ui.dp(this, 5), 0, Ui.dp(this, 5), 0);
        box.addView(Ui.tv(this, label, 10, Ui.SUB));
        TextView value = Ui.tvb(this, initial, 17, Ui.TEXT);
        box.addView(value, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        parent.addView(box, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        if ("RAM".equals(label)) ramValue = value;
        if ("BATERAI".equals(label)) batteryValue = value;
        if ("SUHU".equals(label)) tempValue = value;
        return value;
    }

    private LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0, Ui.WRAP, 1f); }

    private View tile(String eyebrow, String name, String detail, Class<?> target) {
        LinearLayout card = Ui.col(this);
        card.setBackground(Ui.ripple(this, Ui.outline(this, Ui.PANEL, Ui.LINE, 16), 16));
        int p = Ui.dp(this, 12); card.setPadding(p, p, p, p);
        card.addView(Ui.tvb(this, eyebrow, 11, Ui.MINT));
        card.addView(Ui.tvb(this, name, 14, Ui.TEXT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        card.addView(Ui.tv(this, detail, 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        card.setClickable(true);
        card.setOnClickListener(v -> startActivity(new Intent(this, target)));
        Ui.pressable(card);
        return card;
    }

    private void refreshStats() {
        float used = Sys.ramUsed(this) * 100f;
        Sys.Batt b = Sys.battery(this);
        if (ramValue != null) ramValue.setText(String.format(Locale.US, "%.0f%%", used));
        if (batteryValue != null) batteryValue.setText(b.level + "%");
        if (tempValue != null) tempValue.setText(String.format(Locale.US, "%.1f°C", b.tempC));
        if (connectionValue != null) {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            android.net.NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            String s = ni != null && ni.isConnected() ? (ni.getType() == android.net.ConnectivityManager.TYPE_WIFI ? "Wi-Fi" : "Data seluler") : "Tidak terhubung";
            connectionValue.setText("Jaringan: " + s);
        }
        long now = android.os.SystemClock.elapsedRealtime();
        long rx = TrafficStats.getTotalRxBytes();
        long tx = TrafficStats.getTotalTxBytes();
        long total = (rx < 0 || tx < 0) ? -1L : rx + tx;
        if (trafficValue != null) {
            if (total >= 0 && lastTraffic >= 0 && now > lastTrafficAt) {
                double kb = Math.max(0L, total - lastTraffic) / 1024.0 / ((now - lastTrafficAt) / 1000.0);
                trafficValue.setText(String.format(Locale.US, "Lalu lintas seluruh perangkat: %.1f KB/detik", kb));
            } else {
                trafficValue.setText(total >= 0 ? "Mengukur lalu lintas seluruh perangkat…" : "Lalu lintas tidak tersedia pada perangkat ini");
            }
        }
        lastTraffic = total; lastTrafficAt = now;
    }

    private void runPing() {
        if (pinging) return;
        pinging = true;
        pingButton.setText("Menguji koneksi…");
        Bg.run(() -> {
            double[] result = Net.tcpPing("1.1.1.1", 443, 3);
            Bg.ui(() -> {
                pinging = false;
                if (!alive()) return;
                pingButton.setText("Uji ulang ping");
                if (result[0] < 0) {
                    pingValue.setText("PING gagal");
                    Toast.makeText(this, "Tes gagal. Periksa koneksi internet.", Toast.LENGTH_SHORT).show();
                } else {
                    pingValue.setText(String.format(Locale.US, "PING %.0f ms", result[0]));
                    Toast.makeText(this, String.format(Locale.US, "Rata-rata %.0f ms • jitter %.0f ms • loss %.0f%%", result[0], result[1], result[2]), Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    @Override protected void onResume() { super.onResume(); handler.removeCallbacks(refresh); handler.post(refresh); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(refresh); }
}
