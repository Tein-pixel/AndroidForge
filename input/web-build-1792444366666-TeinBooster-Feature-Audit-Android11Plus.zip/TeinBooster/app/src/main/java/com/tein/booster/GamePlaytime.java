package com.tein.booster;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/** Tracks only games launched from TeinBooster's own game library. */
public final class GamePlaytime {
    private static final String PREF = "game_playtime_local";
    private static final String SESSION_PACKAGE = "active_package";
    private static final String SESSION_START = "active_start";
    private GamePlaytime() { }

    private static SharedPreferences prefs(Context c) { return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public static void begin(Context c, String packageName) {
        prefs(c).edit().putString(SESSION_PACKAGE, packageName).putLong(SESSION_START, System.currentTimeMillis()).apply();
    }

    public static void cancelPending(Context c) { prefs(c).edit().remove(SESSION_PACKAGE).remove(SESSION_START).apply(); }

    public static void finishPending(Context c) {
        SharedPreferences p = prefs(c);
        String pkg = p.getString(SESSION_PACKAGE, "");
        long start = p.getLong(SESSION_START, 0L);
        if (pkg == null || pkg.isEmpty() || start <= 0L) return;
        long elapsed = System.currentTimeMillis() - start;
        SharedPreferences.Editor edit = p.edit().remove(SESSION_PACKAGE).remove(SESSION_START);
        if (elapsed >= 5_000L && elapsed <= 12L * 60L * 60L * 1000L) {
            String key = "total_" + pkg;
            edit.putLong(key, p.getLong(key, 0L) + elapsed);
            edit.putLong("total_all", p.getLong("total_all", 0L) + elapsed);
            edit.putLong("sessions_" + pkg, p.getLong("sessions_" + pkg, 0L) + 1L);
        }
        edit.apply();
    }

    public static long totalMillis(Context c, String packageName) { return prefs(c).getLong("total_" + packageName, 0L); }
    public static long totalAllMillis(Context c) { return prefs(c).getLong("total_all", 0L); }
    public static long sessions(Context c, String packageName) { return prefs(c).getLong("sessions_" + packageName, 0L); }

    public static String format(long millis) {
        long mins = Math.max(0L, millis / 60_000L);
        if (mins < 60) return mins + " mnt";
        return String.format(Locale.US, "%dj %02dm", mins / 60L, mins % 60L);
    }
}
