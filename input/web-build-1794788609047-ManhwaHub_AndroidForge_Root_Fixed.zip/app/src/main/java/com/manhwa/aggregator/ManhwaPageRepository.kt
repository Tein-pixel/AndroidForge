package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Best-effort page parser for source detail/chapter pages. Existing catalog endpoints stay untouched. */
object ManhwaPageRepository {
    private const val PROXY_BASE = "https://api.allorigins.win/raw?url="
    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(18, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    data class PageDetails(val description: String, val genres: List<String>, val status: String, val chapters: List<Chapter>)
    data class Chapter(val title: String, val url: String)

    suspend fun fetchDetails(pageUrl: String): PageDetails = withContext(Dispatchers.IO) {
        val html = fetchHtml(pageUrl)
        val doc = Jsoup.parse(html, pageUrl)
        val description = doc.select(
            ".entry-content, .description-summary, .manga-excerpt, .summary__content, .desc, .synopsis, [itemprop=description]"
        ).firstOrNull()?.text()?.trim().orEmpty()
        val genres = doc.select(
            ".manga-genres a, .seriestugenre a, .genres a, .mgen a, .tag-links a"
        ).map { it.text().trim() }.filter { it.isNotBlank() }.distinct().take(12)
        val status = doc.select(
            ".post-status .summary-content, .summary-content, .status, .manga-status"
        ).firstOrNull()?.text()?.trim().orEmpty()
        val chapters = doc.select(
            ".eplister a, .listing-chapters_wrap a, .wp-manga-chapter a, .chapter-list a, .chapter-item a, .chbox a, .eph-num a, a[href*='chapter'], a[href*='/ch-']"
        ).mapNotNull { anchor ->
            val url = anchor.absUrl("href").ifBlank { anchor.attr("href") }
            val title = anchor.text().trim().ifBlank { anchor.attr("title").trim() }
            if (url.startsWith("http") && title.isNotBlank()) Chapter(title, url) else null
        }.distinctBy { it.url }.take(250)
        PageDetails(description, genres, status, chapters)
    }

    suspend fun fetchReaderImages(chapterUrl: String): List<String> = withContext(Dispatchers.IO) {
        val html = fetchHtml(chapterUrl)
        val doc = Jsoup.parse(html, chapterUrl)
        doc.select(
            "#readerarea img, .reading-content img, .reader-area img, .chapter-content img, .rdminimal img, .chapter-images img, .reading-area img"
        ).mapNotNull { image ->
            val candidate = listOf("data-src", "data-lazy-src", "data-original", "data-cfsrc", "src")
                .firstNotNullOfOrNull { key -> image.attr(key).takeIf { it.isNotBlank() && !it.startsWith("data:") } }
            val absolute = candidate?.let { raw -> image.absUrl("src").takeIf { it == raw } ?: resolveUrl(chapterUrl, raw) }
            absolute?.takeIf { it.startsWith("http") }
        }.distinct()
    }

    private fun fetchHtml(url: String): String {
        val proxiedUrl = PROXY_BASE + URLEncoder.encode(url, "UTF-8")
        val request = Request.Builder()
            .url(proxiedUrl)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Server sumber merespons ${response.code}")
            return response.body?.string().orEmpty()
        }
    }

    private fun resolveUrl(base: String, value: String): String = try {
        java.net.URI(base).resolve(value).toString()
    } catch (_: Exception) { value }
}
