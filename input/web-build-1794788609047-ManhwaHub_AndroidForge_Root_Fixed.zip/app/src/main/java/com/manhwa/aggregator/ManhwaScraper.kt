package com.manhwa.aggregator

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URI
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

class ManhwaScraper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // CorsProxy is attempted first. Keep the existing AllOrigins URL as a fallback
    // so the old proxy integration is retained rather than removed.
    private val proxyBase = "https://corsproxy.io/?url="
    private val legacyProxyBase = "https://api.allorigins.win/raw?url="

    // Keep all configured source endpoints unchanged.
    private val domains = listOf(
        "https://kiryuu.to/manga/?m_orderby=latest" to "Kiryuu",
        "https://komikcast.mom/daftar-komik/?order=update" to "Komikcast",
        "https://asuracomic.net/series?order=update" to "Asura"
    )

    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> =
        withContext(Dispatchers.IO) {
            supervisorScope {
                val requests = domains.map { (baseUrl, sourceName) ->
                    async {
                        try {
                            fetchFromSource(baseUrl, sourceName, query, genre)
                        } catch (cancelled: CancellationException) {
                            // Cancellation is lifecycle/navigation control, not a source failure.
                            throw cancelled
                        } catch (_: Exception) {
                            // One failing source must not prevent other sources from returning data.
                            emptyList()
                        }
                    }
                }
                requests.awaitAll().flatten().distinctBy { it.link }
            }
        }

    private suspend fun fetchFromSource(
        baseUrl: String,
        sourceName: String,
        query: String,
        genre: String
    ): List<Manhwa> {
        val targetUrl = when {
            query.isNotBlank() -> {
                // Build a clean search URL from the same source host. Do not append
                // a search parameter after an existing query string.
                val uri = URI(baseUrl)
                val sourceRoot = "${uri.scheme}://${uri.host}/"
                sourceRoot + "?s=" + URLEncoder.encode(query.trim(), "UTF-8")
            }
            genre.isNotBlank() && genre != "Semua" -> {
                val root = baseUrl.substringBefore("?").substringBeforeLast("/")
                "$root/genre/${genre.lowercase().replace(" ", "-")}/?m_orderby=latest"
            }
            else -> baseUrl
        }

        val html = fetchHtmlWithFallback(targetUrl)
        val doc = Jsoup.parse(html, targetUrl)
        val elements = doc.select(
            ".listupd .bs, .bsx, .page-item-detail, .manga__item, .grid > div"
        )

        return elements.mapNotNull { element ->
            val anchor = element.select(
                ".tt h3 a, .tt h4 a, .post-title h3 a, .manga__item-title a, .text-white"
            ).firstOrNull() ?: element.selectFirst("a[href]")
            val title = anchor?.text()?.trim().orEmpty()
            val link = if (anchor == null) "" else anchor.absUrl("href")
                .ifBlank { anchor.attr("href") }

            val image = element.selectFirst("img")
            val rawImage = image?.let {
                listOf("data-src", "data-lazy-src", "data-original", "src")
                    .firstNotNullOfOrNull { key -> it.attr(key).takeIf(String::isNotBlank) }
            }.orEmpty()
            val imageUrl = if (rawImage.isBlank()) "" else try {
                URI(targetUrl).resolve(rawImage).toString()
            } catch (_: Exception) {
                rawImage
            }
            val latestChapter = element.select(
                ".epxs, .chapter-item .btn-link, .chapter-item a"
            ).firstOrNull()?.text()?.trim() ?: "Chapter Baru"

            if (title.isBlank() || !link.startsWith("http") || !imageUrl.startsWith("http")) null
            else Manhwa(title, link, imageUrl, latestChapter, sourceName)
        }
    }

    /** Try the requested proxy, retain the prior proxy, then try the source directly. */
    private suspend fun fetchHtmlWithFallback(targetUrl: String): String {
        val encodedTarget = URLEncoder.encode(targetUrl, "UTF-8")
        val candidates = listOf(
            proxyBase + encodedTarget,
            legacyProxyBase + encodedTarget,
            targetUrl
        )

        var lastError: Exception? = null
        for (candidate in candidates) {
            try {
                return executeRequest(candidate)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                lastError = error
            }
        }
        throw IllegalStateException(
            "Proxy dan sumber tidak merespons: ${lastError?.localizedMessage ?: "koneksi gagal"}",
            lastError
        )
    }

    private suspend fun executeRequest(url: String): String = suspendCancellableCoroutine { continuation ->
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .build()
        val call = client.newCall(request)

        // Cancelling the coroutine now cancels the actual network call as well.
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, error: java.io.IOException) {
                if (continuation.isActive) continuation.resumeWithException(error)
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.use {
                    if (!continuation.isActive) return
                    if (!response.isSuccessful) {
                        continuation.resumeWithException(IllegalStateException("HTTP ${response.code}"))
                        return
                    }
                    try {
                        continuation.resume(response.body?.string().orEmpty())
                    } catch (error: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(error)
                    }
                }
            }
        })
    }
}
