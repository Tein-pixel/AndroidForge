# Yomikaze

Aplikasi Android Compose untuk membaca manga, manhwa, manhua, dan komik. Katalog aktif memakai MangaDex API dengan filter rating **SAFE** dan prioritas chapter Bahasa Indonesia (fallback Bahasa Inggris bila terjemahan Indonesia tidak tersedia).

## Build APK

- JDK: 17
- Android Gradle Plugin: 8.7.2
- Gradle: 8.9
- Kotlin: 2.1.10
- compileSdk: 35 · minSdk: 24 · targetSdk: 35

Perintah build:

```bash
gradle --no-daemon :app:assembleDebug
```

APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

Di AndroidForge, buka repository pada root proyek lalu jalankan **Build Android APK**. Jika wrapper belum tersedia, gunakan mekanisme regenerasi wrapper dari AndroidForge; versi wrapper yang disiapkan adalah Gradle 8.9.

## GitHub Actions

Workflow `Android APK` tersedia melalui tab **Actions** dan dapat dijalankan manual (`workflow_dispatch`). Hasil APK akan disimpan sebagai artifact `Yomikaze-debug-apk`.

## Fitur

- Browse, kategori, dan pencarian katalog.
- Halaman detail, daftar chapter, dan pembaca halaman.
- Koleksi lokal, progres baca, serta unduhan chapter melalui WorkManager.
- Tema mengikuti pengaturan sistem.

## Sumber dan atribusi

Katalog aktif menggunakan API publik MangaDex (`https://api.mangadex.org`). Aplikasi tidak menyertakan iklan atau fitur berbayar. Hormati attribution/credit scanlation group serta permintaan penghapusan konten dari pemilik atau group terkait sesuai kebijakan MangaDex.
