package app.yomikaze.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.core.ChapterContent
import app.yomikaze.ui.ReaderViewModel
import app.yomikaze.ui.components.EmptyState
import app.yomikaze.ui.components.LoadingState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovelReaderScreen(
    onBack: () -> Unit,
    viewModel: ReaderViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val content = state.content
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(state.chapter?.title ?: "Bab", maxLines = 1) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
        )
        when {
            state.loading -> LoadingState()
            state.error != null -> EmptyState(state.error!!)
            content is ChapterContent.Text -> {
                LazyColumn(
                    modifier = Modifier.weight(1f).padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 16.dp),
                ) {
                    item { Text(content.title, style = MaterialTheme.typography.titleLarge) }
                    items(content.paragraphs) { paragraph ->
                        Text(
                            paragraph,
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * 1.5f,
                        )
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            val previous = viewModel.previousChapter()
                            TextButton(
                                onClick = { previous?.let { viewModel.load(it.id) } },
                                enabled = previous != null,
                            ) { Text("Sebelumnya") }
                            val next = viewModel.nextChapter()
                            TextButton(
                                onClick = { next?.let { viewModel.load(it.id) } },
                                enabled = next != null,
                            ) { Text("Berikutnya") }
                        }
                    }
                }
            }
        }
    }
}
