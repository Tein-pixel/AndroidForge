package app.yomikaze.data

import app.yomikaze.core.*
import app.yomikaze.sources.SourceRegistry
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CatalogRepository @Inject constructor(
    private val registry: SourceRegistry,
) {
    suspend fun search(query: String, sourceId: String?, page: Int = 1, limit: Int = 24): List<ContentSummary> =
        coroutineScope {
            val sources = sourceId?.let { listOf(registry.get(it)) } ?: registry.all()
            sources.map { source ->
                async { runCatching { source.search(query, page, limit) }.getOrDefault(emptyList()) }
            }.flatMap { it.await() }
        }

    suspend fun popular(category: MediaCategory, page: Int = 1, limit: Int = 24): List<ContentSummary> {
        if (category == MediaCategory.ALL) return browseAll(page, 10)
        return coroutineScope {
            registry.forCategory(category).map { source ->
                async {
                    runCatching { source.popular(category, page, limit) }.getOrDefault(emptyList())
                }
            }.flatMap { it.await() }
        }
    }

    suspend fun browseAll(page: Int = 1, perSource: Int = 10): List<ContentSummary> = coroutineScope {
        registry.all().map { source ->
            async {
                runCatching { source.popular(null, page, perSource) }.getOrDefault(emptyList())
            }
        }.flatMap { it.await() }.shuffled()
    }

    suspend fun details(sourceId: String, contentId: String): ContentDetails =
        registry.get(sourceId).details(contentId)

    suspend fun chapterContent(sourceId: String, chapterId: String): ChapterContent =
        registry.get(sourceId).loadChapter(chapterId)
}

@Singleton
class LibraryRepository @Inject constructor(
    private val libraryDao: LibraryDao,
    private val progressDao: ProgressDao,
) {
    fun observeLibrary(): Flow<List<LibraryEntity>> = libraryDao.observeAll()

    fun observeProgress(contentId: String): Flow<ProgressEntity?> = progressDao.observe(contentId)

    suspend fun find(contentId: String): LibraryEntity? = libraryDao.find(contentId)

    suspend fun add(summary: ContentSummary) {
        libraryDao.upsert(
            LibraryEntity(
                contentId = summary.id,
                sourceId = summary.sourceId,
                title = summary.title,
                coverUrl = summary.coverUrl,
                mediaType = summary.mediaType.name,
                readingMode = summary.readingMode.name,
                addedAt = System.currentTimeMillis(),
                lastReadAt = null,
            )
        )
    }

    suspend fun remove(contentId: String) = libraryDao.delete(contentId)

    suspend fun saveProgress(contentId: String, chapterId: String, page: Int, totalPages: Int) {
        val now = System.currentTimeMillis()
        progressDao.upsert(ProgressEntity(contentId, chapterId, page, totalPages, now))
        libraryDao.touch(contentId, now)
    }
}

@Singleton
class DownloadRepository @Inject constructor(
    private val downloadDao: DownloadDao,
) {
    fun observeAll(): Flow<List<DownloadEntity>> = downloadDao.observeAll()

    fun observeForContent(contentId: String): Flow<List<DownloadEntity>> =
        downloadDao.observeForContent(contentId)

    suspend fun find(chapterId: String): DownloadEntity? = downloadDao.find(chapterId)

    suspend fun update(entity: DownloadEntity) = downloadDao.upsert(entity)

    suspend fun remove(chapterId: String) = downloadDao.delete(chapterId)
}
