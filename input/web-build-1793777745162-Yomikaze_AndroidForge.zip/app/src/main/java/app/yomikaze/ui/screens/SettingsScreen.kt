package app.yomikaze.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import app.yomikaze.ui.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Pengaturan") })
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text("Sumber Aktif", style = MaterialTheme.typography.titleMedium) }
            items(viewModel.sources) { source ->
                ListItem(
                    headlineContent = { Text(source.name) },
                    supportingContent = {
                        Text(source.mediaTypes.joinToString { it.name.lowercase() })
                    },
                )
            }
            item { Text("Penyimpanan Unduhan", style = MaterialTheme.typography.titleMedium) }
            item {
                Text(
                    "Bab tersimpan di files/downloads/<sumber>/<konten>/<bab>/",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
