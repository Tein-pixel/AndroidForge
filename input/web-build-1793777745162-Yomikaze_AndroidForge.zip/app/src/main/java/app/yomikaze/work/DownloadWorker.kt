package app.yomikaze.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import app.yomikaze.core.ChapterContent
import app.yomikaze.core.HttpClient
import app.yomikaze.data.DownloadEntity
import app.yomikaze.data.DownloadRepository
import app.yomikaze.sources.SourceRegistry
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@HiltWorker
class ChapterDownloadWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val registry: SourceRegistry,
    private val downloads: DownloadRepository,
    private val http: HttpClient,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val sourceId = inputData.getString(KEY_SOURCE) ?: return@withContext Result.failure()
        val contentId = inputData.getString(KEY_CONTENT) ?: return@withContext Result.failure()
        val chapterId = inputData.getString(KEY_CHAPTER) ?: return@withContext Result.failure()
        val source = runCatching { registry.get(sourceId) }.getOrNull()
            ?: return@withContext Result.failure()

        val safeId = chapterId.hashCode().toString()
        val root = File(applicationContext.filesDir, "downloads/$sourceId/$contentId/$safeId")
        if (!root.exists()) root.mkdirs()

        val content = runCatching { source.loadChapter(chapterId) }.getOrNull()
            ?: return@withContext Result.retry()

        when (content) {
            is ChapterContent.Images -> {
                var completed = 0
                content.pages.forEach { page ->
                    val target = File(root, "%04d.img".format(page.index))
                    if (!target.exists()) {
                        val response = runCatching { http.getResponse(page.url) }.getOrNull()
                            ?: return@withContext Result.retry()
                        response.use { r ->
                            if (!r.isSuccessful) return@withContext Result.retry()
                            r.body?.byteStream()?.use { input ->
                                target.outputStream().use { output -> input.copyTo(output) }
                            } ?: return@withContext Result.retry()
                        }
                    }
                    completed += 1
                    downloads.update(
                        DownloadEntity(
                            chapterId = chapterId,
                            contentId = contentId,
                            sourceId = sourceId,
                            state = "DOWNLOADING",
                            totalPages = content.pages.size,
                            completedPages = completed,
                            directory = root.absolutePath,
                        )
                    )
                }
            }
            is ChapterContent.Text -> {
                File(root, "chapter.txt").writeText(
                    buildString {
                        appendLine(content.title)
                        appendLine()
                        content.paragraphs.forEach { appendLine(it); appendLine() }
                    }
                )
            }
        }

        downloads.update(
            DownloadEntity(
                chapterId = chapterId,
                contentId = contentId,
                sourceId = sourceId,
                state = "COMPLETE",
                totalPages = when (content) {
                    is ChapterContent.Images -> content.pages.size
                    is ChapterContent.Text -> 1
                },
                completedPages = when (content) {
                    is ChapterContent.Images -> content.pages.size
                    is ChapterContent.Text -> 1
                },
                directory = root.absolutePath,
            )
        )
        Result.success()
    }

    companion object {
        const val KEY_SOURCE = "source"
        const val KEY_CONTENT = "content"
        const val KEY_CHAPTER = "chapter"
    }
}
