package app.yomikaze.di

import android.content.Context
import androidx.room.Room
import app.yomikaze.core.HttpClient
import app.yomikaze.core.RateLimiter
import app.yomikaze.core.defaultOkHttpClient
import app.yomikaze.data.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideOkHttp(): OkHttpClient = defaultOkHttpClient()

    @Provides @Singleton
    fun provideRateLimiter(): RateLimiter = RateLimiter(4.0)

    @Provides @Singleton
    fun provideHttpClient(client: OkHttpClient, rateLimiter: RateLimiter): HttpClient =
        HttpClient(client, rateLimiter)

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): YomikazeDatabase =
        Room.databaseBuilder(context, YomikazeDatabase::class.java, "yomikaze.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideLibraryDao(db: YomikazeDatabase): LibraryDao = db.libraryDao()
    @Provides fun provideProgressDao(db: YomikazeDatabase): ProgressDao = db.progressDao()
    @Provides fun provideDownloadDao(db: YomikazeDatabase): DownloadDao = db.downloadDao()
}
