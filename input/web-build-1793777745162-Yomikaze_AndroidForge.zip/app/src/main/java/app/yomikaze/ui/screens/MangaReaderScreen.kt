package app.yomikaze.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.core.ChapterContent
import app.yomikaze.ui.ReaderViewModel
import coil3.compose.AsyncImage

@Composable
fun MangaReaderScreen(
    onBack: () -> Unit,
    viewModel: ReaderViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val content = state.content
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            state.error != null -> Text(
                state.error!!,
                color = Color.White,
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
            )
            content is ChapterContent.Images -> {
                val pages = content.pages
                if (pages.isEmpty()) {
                    Text("Tidak ada halaman.", color = Color.White, modifier = Modifier.align(Alignment.Center))
                } else {
                    val pagerState = rememberPagerState(pageCount = { pages.size })
                    HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { index ->
                        AsyncImage(
                            model = pages[index].url,
                            contentDescription = "Halaman ${index + 1}",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit,
                        )
                    }
                    LaunchedEffect(pagerState.currentPage) {
                        viewModel.onPageChanged(pagerState.currentPage, pages.size)
                    }
                    Row(
                        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                        Text("${pagerState.currentPage + 1} / ${pages.size}", color = Color.White)
                        Row {
                            val previous = viewModel.previousChapter()
                            IconButton(
                                onClick = { previous?.let { viewModel.load(it.id) } },
                                enabled = previous != null,
                            ) {
                                Icon(
                                    Icons.Default.NavigateBefore, null,
                                    tint = if (previous != null) Color.White else Color.Gray,
                                )
                            }
                            val next = viewModel.nextChapter()
                            IconButton(
                                onClick = { next?.let { viewModel.load(it.id) } },
                                enabled = next != null,
                            ) {
                                Icon(
                                    Icons.Default.NavigateNext, null,
                                    tint = if (next != null) Color.White else Color.Gray,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
