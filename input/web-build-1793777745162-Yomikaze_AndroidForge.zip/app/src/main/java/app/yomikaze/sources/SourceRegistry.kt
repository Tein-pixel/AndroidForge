package app.yomikaze.sources

import app.yomikaze.core.ContentSource
import app.yomikaze.core.MediaCategory
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SourceRegistry @Inject constructor(
    mangaDex: MangaDexSource,
) {
    private val sources: Map<String, ContentSource> = listOf(mangaDex).associateBy { it.id }

    fun all(): List<ContentSource> = sources.values.toList()

    fun get(sourceId: String): ContentSource =
        sources[sourceId] ?: error("Unknown source: $sourceId")

    fun forCategory(category: MediaCategory): List<ContentSource> = all()
}
