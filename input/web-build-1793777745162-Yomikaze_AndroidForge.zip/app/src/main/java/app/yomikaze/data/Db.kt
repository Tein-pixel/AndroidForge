package app.yomikaze.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "library")
data class LibraryEntity(
    @PrimaryKey val contentId: String,
    val sourceId: String,
    val title: String,
    val coverUrl: String?,
    val mediaType: String,
    val readingMode: String,
    val addedAt: Long,
    val lastReadAt: Long?,
)

@Entity(tableName = "progress")
data class ProgressEntity(
    @PrimaryKey val contentId: String,
    val chapterId: String,
    val page: Int,
    val totalPages: Int,
    val updatedAt: Long,
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val chapterId: String,
    val contentId: String,
    val sourceId: String,
    val state: String,
    val totalPages: Int,
    val completedPages: Int,
    val directory: String,
)

@Dao
interface LibraryDao {
    @Query("SELECT * FROM library ORDER BY COALESCE(lastReadAt, addedAt) DESC")
    fun observeAll(): Flow<List<LibraryEntity>>

    @Query("SELECT * FROM library WHERE contentId = :contentId")
    suspend fun find(contentId: String): LibraryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: LibraryEntity)

    @Query("DELETE FROM library WHERE contentId = :contentId")
    suspend fun delete(contentId: String)

    @Query("UPDATE library SET lastReadAt = :time WHERE contentId = :contentId")
    suspend fun touch(contentId: String, time: Long)
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM progress WHERE contentId = :contentId")
    fun observe(contentId: String): Flow<ProgressEntity?>

    @Query("SELECT * FROM progress WHERE contentId = :contentId")
    suspend fun find(contentId: String): ProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ProgressEntity)
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY chapterId")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE contentId = :contentId ORDER BY chapterId")
    fun observeForContent(contentId: String): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE chapterId = :chapterId")
    suspend fun find(chapterId: String): DownloadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DownloadEntity)

    @Query("DELETE FROM downloads WHERE chapterId = :chapterId")
    suspend fun delete(chapterId: String)
}

@Database(
    entities = [LibraryEntity::class, ProgressEntity::class, DownloadEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class YomikazeDatabase : RoomDatabase() {
    abstract fun libraryDao(): LibraryDao
    abstract fun progressDao(): ProgressDao
    abstract fun downloadDao(): DownloadDao
}
