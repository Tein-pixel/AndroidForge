package app.yomikaze.core

interface ContentSource {
    val id: String
    val name: String
    val mediaTypes: Set<MediaType>

    suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary>
    suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary>
    suspend fun latest(page: Int, limit: Int): List<ContentSummary>
    suspend fun details(contentId: String): ContentDetails
    suspend fun chapters(contentId: String, language: String? = null): List<Chapter>
    suspend fun loadChapter(chapterId: String): ChapterContent
}
