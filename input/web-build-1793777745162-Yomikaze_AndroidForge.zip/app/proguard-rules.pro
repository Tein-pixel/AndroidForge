-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class app.yomikaze.**$$serializer { *; }
-keepclassmembers class app.yomikaze.** {
    *** Companion;
}
-keepclasseswithmembers class app.yomikaze.** {
    kotlinx.serialization.KSerializer serializer(...);
}
