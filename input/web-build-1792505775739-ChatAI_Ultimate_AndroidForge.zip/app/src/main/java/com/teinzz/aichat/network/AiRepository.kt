package com.teinzz.aichat.network

import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.teinzz.aichat.ThemeManager
import com.teinzz.aichat.data.AiModel
import com.teinzz.aichat.data.ChatMode
import com.teinzz.aichat.data.MessageEntity
import com.teinzz.aichat.data.Provider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class ProviderException(val httpCode: Int, message: String) : Exception(message)

/**
 * Provider-specific request adapter. THINK_HARDER adds native reasoning controls where supported.
 * DEEP_RESEARCH enables actual provider-hosted web tools; it is never simulated with prompt text alone.
 */
class AiRepository(private val keys: ThemeManager) {
    private val api = AiApi.create()
    private val gson = Gson()

    fun stream(
        model: AiModel,
        conversation: List<MessageEntity>,
        userText: String,
        imagePath: String?,
        mode: ChatMode = ChatMode.NORMAL
    ): Flow<String> = flow {
        val key = keys.getApiKey(model.provider)
        if (key.isBlank()) throw ProviderException(0, "API key ${model.provider.apiKeyLabel} belum diatur. Buka Settings untuk memasukkannya.")
        if (imagePath != null && !model.vision) throw ProviderException(0, "Model ini tidak mendukung gambar pada konfigurasi aplikasi. Pilih model vision seperti Gemini atau Qwen 3.8 27B.")
        if (mode == ChatMode.DEEP_RESEARCH && model.provider == Provider.GROQ) {
            throw ProviderException(0, "Riset Mendalam tidak tersedia untuk konfigurasi Groq ini karena endpoint yang digunakan tidak menyediakan alat web search yang sama. Pilih Gemini atau OpenRouter.")
        }

        val payload = if (model.provider == Provider.GEMINI) {
            geminiPayload(conversation, userText, imagePath, mode)
        } else {
            openAiPayload(model, conversation, userText, imagePath, mode)
        }
        val url = if (model.provider == Provider.GEMINI) GeminiService.streamUrl(model.id) else when (model.provider) {
            Provider.GROQ -> GroqService.STREAM_URL
            Provider.OPENROUTER -> OpenRouterService.STREAM_URL
            else -> error("Unsupported provider")
        }
        val response = api.stream(
            url,
            if (model.provider == Provider.GEMINI) null else "Bearer $key",
            if (model.provider == Provider.GEMINI) key else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.REFERER else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.APP_TITLE else null,
            gson.toJson(payload).toRequestBody("application/json; charset=utf-8".toMediaType())
        )
        val body = response.body()
        if (!response.isSuccessful || body == null) {
            val details = runCatching { response.errorBody()?.string()?.take(800) }.getOrNull().orEmpty()
            val friendly = when (response.code()) {
                401, 403 -> "API key salah atau akses ke model ditolak. Periksa key, izin, dan saldo provider."
                429 -> "Batas penggunaan tercapai (429). Tunggu, periksa kuota, atau pilih provider lain."
                400 -> when (mode) {
                    ChatMode.DEEP_RESEARCH -> "Provider menolak konfigurasi alat Riset Mendalam untuk model ini. Coba Gemini atau model OpenRouter yang mendukung tool calling. Detail: ${details.take(220)}"
                    ChatMode.THINK_HARDER -> "Provider/model menolak parameter reasoning tinggi. Coba model reasoning lain atau mode Normal. Detail: ${details.take(220)}"
                    else -> "Permintaan tidak diterima oleh provider. Periksa model ID dan dukungan parameternya. Detail: ${details.take(220)}"
                }
                else -> "Provider mengembalikan HTTP ${response.code()}. ${details.take(350)}"
            }
            throw ProviderException(response.code(), friendly)
        }

        val sources = linkedMapOf<String, String>()
        val closeOnCancel = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) body.close()
        }
        try {
            body.charStream().buffered().use { reader ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.removePrefix("data:").trim()
                    if (data.isBlank() || data == "[DONE]") continue
                    val root = runCatching { JsonParser.parseString(data).asJsonObject }.getOrNull() ?: continue
                    collectSources(root, model.provider, sources)
                    val chunk = runCatching { responseText(root, model.provider) }.getOrDefault("")
                    if (chunk.isNotEmpty()) emit(chunk)
                }
            }
        } finally {
            closeOnCancel?.dispose()
            body.close()
        }
        // Gemini returns grounding metadata separately from the streamed answer. Preserve those citations.
        // OpenRouter may also return structured URL annotations; model-provided citation links are retained too.
        if (sources.isNotEmpty()) {
            val sourceBlock = sources.entries.take(10).joinToString("\n") { (url, title) ->
                "- [${title.replace("[", "(").replace("]", ")").take(140)}]($url)"
            }
            emit("\n\n**Sumber web**\n$sourceBlock")
        }
    }.flowOn(Dispatchers.IO)

    suspend fun test(model: AiModel): String {
        val key = keys.getApiKey(model.provider)
        if (key.isBlank()) throw ProviderException(0, "API key belum diatur.")
        val url = when (model.provider) {
            Provider.GEMINI -> GeminiService.KEY_CHECK_URL
            Provider.GROQ -> GroqService.KEY_CHECK_URL
            Provider.OPENROUTER -> OpenRouterService.KEY_CHECK_URL
        }
        val response = api.probe(
            url,
            if (model.provider == Provider.GEMINI) null else "Bearer $key",
            if (model.provider == Provider.GEMINI) key else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.REFERER else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.APP_TITLE else null
        )
        if (!response.isSuccessful) {
            val message = when (response.code()) {
                401, 403 -> "API key salah atau akses ditolak (HTTP ${response.code()})."
                429 -> "Rate limit provider tercapai (HTTP 429)."
                else -> "Provider mengembalikan HTTP ${response.code()}."
            }
            response.errorBody()?.close()
            throw ProviderException(response.code(), message)
        }
        response.body()?.close()
        return "Koneksi berhasil (HTTP ${response.code()}). Tes ini tidak menghasilkan teks AI atau token output. Ini belum menjamin model tertentu tersedia atau gratis; cek katalog dan dashboard provider."
    }

    private fun geminiPayload(history: List<MessageEntity>, text: String, imagePath: String?, mode: ChatMode): JsonObject {
        val contents = JsonArray()
        history.filter { it.role == "user" || it.role == "assistant" }.takeLast(18).forEach { msg ->
            val content = JsonObject()
            content.addProperty("role", if (msg.role == "assistant") "model" else "user")
            val parts = JsonArray()
            parts.add(JsonObject().apply { addProperty("text", msg.content) })
            content.add("parts", parts)
            contents.add(content)
        }
        val currentContent = JsonObject().apply { addProperty("role", "user") }
        val parts = JsonArray()
        parts.add(JsonObject().apply { addProperty("text", text.ifBlank { "Tolong analisis gambar yang aku kirim." }) })
        imagePath?.let { path ->
            val part = imagePart(path) ?: throw ProviderException(0, "Gambar tidak dapat dibaca atau terlalu besar. Pilih ulang gambar agar dikompresi sebelum dikirim.")
            parts.add(part)
        }
        currentContent.add("parts", parts)
        contents.add(currentContent)

        val generationConfig = JsonObject().apply {
            addProperty("temperature", 1.0)
            addProperty("maxOutputTokens", if (mode == ChatMode.DEEP_RESEARCH) 8192 else 6144)
            if (mode == ChatMode.THINK_HARDER || mode == ChatMode.DEEP_RESEARCH) {
                add("thinkingConfig", JsonObject().apply { addProperty("thinkingLevel", "HIGH") })
            }
        }
        val request = JsonObject().apply {
            add("contents", contents)
            add("generationConfig", generationConfig)
            add("systemInstruction", JsonObject().apply {
                add("parts", JsonArray().apply {
                    add(JsonObject().apply { addProperty("text", systemInstructions(mode)) })
                })
            })
        }
        if (mode == ChatMode.DEEP_RESEARCH) {
            request.add("tools", JsonArray().apply {
                add(JsonObject().apply { add("google_search", JsonObject()) })
            })
        }
        return request
    }

    private fun openAiPayload(model: AiModel, history: List<MessageEntity>, text: String, imagePath: String?, mode: ChatMode): JsonObject {
        val messages = JsonArray()
        messages.add(JsonObject().apply {
            addProperty("role", "system")
            addProperty("content", systemInstructions(mode))
        })
        history.filter { it.role == "user" || it.role == "assistant" }.takeLast(18).forEach { msg ->
            messages.add(JsonObject().apply { addProperty("role", msg.role); addProperty("content", msg.content) })
        }
        val user = JsonObject().apply { addProperty("role", "user") }
        if (imagePath != null) {
            val blocks = JsonArray()
            blocks.add(JsonObject().apply { addProperty("type", "text"); addProperty("text", text.ifBlank { "Please analyze the image I attached." }) })
            val dataUrl = imageDataUrl(imagePath)
                ?: throw ProviderException(0, "Gambar tidak bisa dibaca atau terlalu besar. Pilih ulang gambar agar dikompresi sebelum dikirim.")
            blocks.add(JsonObject().apply {
                addProperty("type", "image_url")
                add("image_url", JsonObject().apply { addProperty("url", dataUrl) })
            })
            user.add("content", blocks)
        } else {
            user.addProperty("content", text)
        }
        messages.add(user)

        val request = JsonObject().apply {
            addProperty("model", model.id)
            addProperty("stream", true)
            addProperty("temperature", 0.7)
            addProperty(if (model.provider == Provider.GROQ) "max_completion_tokens" else "max_tokens", if (mode == ChatMode.DEEP_RESEARCH) 8192 else 6144)
            add("messages", messages)
        }
        if (mode == ChatMode.THINK_HARDER || mode == ChatMode.DEEP_RESEARCH) {
            // OpenRouter exposes a standardized reasoning effort for supported model/provider routes.
            if (model.provider == Provider.OPENROUTER) {
                request.add("reasoning", JsonObject().apply { addProperty("effort", "high"); addProperty("summary", "concise") })
            } else if (model.provider == Provider.GROQ) {
                request.addProperty("reasoning_effort", "high")
            }
        }
        if (mode == ChatMode.DEEP_RESEARCH && model.provider == Provider.OPENROUTER) {
            request.add("tools", JsonArray().apply {
                add(JsonObject().apply { addProperty("type", "openrouter:web_search") })
                add(JsonObject().apply { addProperty("type", "openrouter:web_fetch") })
            })
        }
        return request
    }

    private fun systemInstructions(mode: ChatMode): String {
        val base = "Kamu adalah asisten AI yang akurat, langsung, dan membantu. Gunakan bahasa pengguna. Jangan mengaku sebagai ChatGPT, Gemini, atau Claude. Jangan tampilkan rantai pemikiran privat; berikan ringkasan metode, asumsi, perhitungan, dan pemeriksaan yang relevan bila membantu."
        return when (mode) {
            ChatMode.NORMAL -> base
            ChatMode.THINK_HARDER -> "$base\n\nMODE BERPIKIR LEBIH KERAS: alokasikan upaya penalaran tinggi yang didukung provider. Periksa asumsi, alternatif, edge case, konsistensi angka, dan kemungkinan kesalahan sebelum menjawab. Untuk tugas kompleks, berikan kesimpulan, ringkasan metode/validasi yang dapat diperiksa, risiko, dan tingkat kepastian. Jangan mengungkapkan chain-of-thought privat."
            ChatMode.DEEP_RESEARCH -> "$base\n\nMODE RISET WEB MENDALAM: alat web provider harus aktif pada request ini; jangan hanya menjawab dari ingatan model. Pecah topik menjadi subpertanyaan, cari sumber yang beragam dan terbaru, utamakan dokumentasi primer, situs resmi, jurnal atau sumber institusional. Bandingkan setidaknya beberapa temuan yang relevan jika alat menyediakan hasil yang cukup; bedakan fakta terverifikasi, interpretasi, dan ketidakpastian. Cantumkan sitasi/URL yang benar-benar dikembalikan alat, serta tanggal bila tersedia. Jangan mengarang jumlah sumber atau menyatakan telah membuka halaman yang tidak dikembalikan alat. Jika alat pencarian gagal atau model/provider tidak mendukungnya, jelaskan bahwa riset web tidak berhasil dan jangan menyamarkannya sebagai riset selesai."
        }
    }

    private fun responseText(root: JsonObject, provider: Provider): String {
        if (provider == Provider.GEMINI) {
            val candidates = root.get("candidates")?.takeIf { it.isJsonArray }?.asJsonArray ?: return ""
            val candidate = candidates.firstOrNull()?.takeIf { it.isJsonObject }?.asJsonObject ?: return ""
            val parts = candidate.getAsJsonObject("content")?.get("parts")?.takeIf { it.isJsonArray }?.asJsonArray ?: return ""
            return parts.mapNotNull { part ->
                if (!part.isJsonObject) return@mapNotNull null
                val obj = part.asJsonObject
                // Never surface provider-marked private thought parts as visible assistant text.
                if (obj.get("thought")?.takeIf { it.isJsonPrimitive }?.asBoolean == true) return@mapNotNull null
                obj.get("text")?.takeIf { it.isJsonPrimitive }?.asString
            }.joinToString("")
        }
        val choices = root.get("choices")?.takeIf { it.isJsonArray }?.asJsonArray ?: return ""
        val delta = choices.firstOrNull()?.takeIf { it.isJsonObject }?.asJsonObject?.getAsJsonObject("delta") ?: return ""
        val content = delta.get("content") ?: return ""
        if (content.isJsonNull || !content.isJsonPrimitive) return ""
        return runCatching { content.asString }.getOrDefault("")
    }

    private fun collectSources(root: JsonObject, provider: Provider, target: LinkedHashMap<String, String>) {
        fun add(urlElement: JsonElement?, titleElement: JsonElement?) {
            val url = urlElement?.takeIf { it.isJsonPrimitive }?.asString?.trim().orEmpty()
            if (!url.startsWith("https://") && !url.startsWith("http://")) return
            val title = titleElement?.takeIf { it.isJsonPrimitive }?.asString?.trim().orEmpty().ifBlank { url }
            target.putIfAbsent(url, title)
        }
        if (provider == Provider.GEMINI) {
            val candidates = root.get("candidates")?.takeIf { it.isJsonArray }?.asJsonArray ?: return
            candidates.filter { it.isJsonObject }.forEach { element ->
                val metadata = element.asJsonObject.getAsJsonObject("groundingMetadata") ?: return@forEach
                val chunks = metadata.get("groundingChunks")?.takeIf { it.isJsonArray }?.asJsonArray ?: return@forEach
                chunks.filter { it.isJsonObject }.forEach { chunk ->
                    val web = chunk.asJsonObject.getAsJsonObject("web") ?: return@forEach
                    add(web.get("uri"), web.get("title"))
                }
            }
        } else if (provider == Provider.OPENROUTER) {
            // OpenRouter's server tools may emit URL annotations on the streamed message or final payload.
            root.get("citations")?.takeIf { it.isJsonArray }?.asJsonArray?.forEach { citation ->
                if (citation.isJsonPrimitive) add(citation, null)
                else if (citation.isJsonObject) add(citation.asJsonObject.get("url"), citation.asJsonObject.get("title"))
            }
            root.get("choices")?.takeIf { it.isJsonArray }?.asJsonArray?.filter { it.isJsonObject }?.forEach { choice ->
                val choiceObject = choice.asJsonObject
                val message = choiceObject.getAsJsonObject("message") ?: choiceObject.getAsJsonObject("delta") ?: return@forEach
                message.get("annotations")?.takeIf { it.isJsonArray }?.asJsonArray?.filter { it.isJsonObject }?.forEach { annotation ->
                    val obj = annotation.asJsonObject
                    val nested = obj.getAsJsonObject("url_citation")
                    add(nested?.get("url") ?: obj.get("url"), nested?.get("title") ?: obj.get("title"))
                }
            }
        }
    }

    private fun imagePart(path: String): JsonObject? = runCatching {
        val file = File(path)
        if (!file.exists() || file.length() > 12L * 1024 * 1024) return null
        val data = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        JsonObject().apply { add("inline_data", JsonObject().apply { addProperty("mime_type", "image/jpeg"); addProperty("data", data) }) }
    }.getOrNull()

    private fun imageDataUrl(path: String): String? = runCatching {
        val file = File(path)
        if (!file.exists() || file.length() > 12L * 1024 * 1024) return null
        "data:image/jpeg;base64," + Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
    }.getOrNull()
}
