package com.teinzz.aichat.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Provider(val title: String, val apiKeyLabel: String) {
    GEMINI("Gemini · Google", "GEMINI_API_KEY"), GROQ("Groq", "GROQ_API_KEY"), OPENROUTER("OpenRouter", "OPENROUTER_API_KEY")
}

/** These modes change provider request parameters/tools; they are not animation-only UI states. */
enum class ChatMode(val title: String, val description: String) {
    NORMAL("Normal", "Respons seimbang untuk penggunaan sehari-hari."),
    THINK_HARDER("Berpikir Lebih Keras", "Meminta effort penalaran tinggi dari model yang mendukungnya."),
    DEEP_RESEARCH("Riset Mendalam", "Mengaktifkan pencarian web nyata dan sintesis sumber; biaya pencarian dapat berlaku.")
}

data class AiModel(
    val id: String,
    val name: String,
    val provider: Provider,
    val badge: String,
    val freeTier: Boolean,
    val vision: Boolean = false,
    val description: String = ""
) {
    /** A grounded product label, not an objective benchmark ranking. */
    val recommendation: String
        get() = when {
            id == "gemini-3-flash-preview" -> "Rekomendasi utama · cepat & kuat"
            id == "gemini-3.1-pro-preview" || id.contains("deepseek-v4") || id == "openai/gpt-oss-120b" -> "Penalaran kuat"
            id.contains("flash-lite") || id.contains("20b") -> "Ringan & cepat"
            id.contains("qwen3.8") -> "Reasoning + vision"
            id.contains("sonnet") || id.contains("gpt-5") -> "Model premium"
            vision -> "Mendukung gambar"
            else -> "Penggunaan umum"
        }
}

object ModelCatalog {
    val all = listOf(
        AiModel("gemini-3-flash-preview", "Gemini 3 Flash Preview", Provider.GEMINI, "FREE TIER · CHECK QUOTA", true, true, "Model Gemini 3 yang tercantum pada dokumentasi API; preview, kuota gratis dan ketersediaan bergantung akun."),
        AiModel("gemini-3.1-flash-lite", "Gemini 3.1 Flash-Lite", Provider.GEMINI, "CHECK BILLING", false, true, "Model hemat untuk tugas cepat; cek harga dan ketersediaan di AI Studio sebelum digunakan."),
        AiModel("gemini-3.1-pro-preview", "Gemini 3.1 Pro Preview", Provider.GEMINI, "PAID · CHECK QUOTA", false, true, "Untuk tugas kompleks dan reasoning; free tier API tidak dijamin."),
        AiModel("openai/gpt-oss-120b", "GPT-OSS 120B", Provider.GROQ, "CHECK GROQ LIMITS", false, false, "Model teks; ketersediaan, limit gratis, dan harga mengikuti akun Groq."),
        AiModel("openai/gpt-oss-20b", "GPT-OSS 20B", Provider.GROQ, "CHECK GROQ LIMITS", false, false, "Model teks ringan; ketersediaan, limit gratis, dan harga mengikuti akun Groq."),
        AiModel("qwen/qwen3-32b", "Qwen3 32B", Provider.GROQ, "CHECK GROQ LIMITS", false, false, "Model teks; jangan pilih untuk gambar. Cek model yang tersedia pada akun Groq."),
        AiModel("openrouter/free", "OpenRouter Free Router", Provider.OPENROUTER, "FREE ROUTER", true, true, "Memilih model gratis yang tersedia secara otomatis."),
        AiModel("nvidia/nemotron-3.5-super-vl:free", "Nemotron 3.5 Super VL", Provider.OPENROUTER, "FREE · VISION", true, true, "Model multimodal gratis; kapasitas dan uptime dapat berubah."),
        AiModel("deepseek/deepseek-r1:free", "DeepSeek R1 (Free route)", Provider.OPENROUTER, "FREE ROUTE · CHECK", true, false, "Ketersediaan dan limit free route berubah; model ini teks saja."),
        AiModel("nvidia/nemotron-3-ultra:free", "Nemotron 3 Ultra", Provider.OPENROUTER, "FREE", true, false, "Model teks gratis; limit provider berlaku."),
        AiModel("deepseek/deepseek-v4.1-flash", "DeepSeek V4.1 Flash", Provider.OPENROUTER, "PAID / CHECK ROUTE", false, true, "ID model terbaru yang terlihat di katalog OpenRouter."),
        AiModel("anthropic/claude-sonnet-4.5", "Claude Sonnet 4.5", Provider.OPENROUTER, "PAID", false, true, "Model Anthropic via OpenRouter; biaya berlaku."),
        AiModel("openai/gpt-5-mini", "GPT-5 mini", Provider.OPENROUTER, "PAID", false, true, "Model OpenAI via OpenRouter; biaya berlaku.")
    )
    fun default() = all.first()
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: default()
}

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val modelId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,
    val content: String,
    val imagePath: String? = null,
    val fileName: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
