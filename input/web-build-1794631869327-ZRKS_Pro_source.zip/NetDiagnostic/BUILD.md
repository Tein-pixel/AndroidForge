# ZRKS Pro — Build Instructions

## Cara build APK

### Opsi 1: Android Studio (paling mudah)
1. Buka Android Studio
2. File > Open > pilih folder ini (NetDiagnostic)
3. Tunggu Gradle sync
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. APK ada di: app/build/outputs/apk/debug/app-debug.apk

### Opsi 2: Command line (perlu Android SDK)
```bash
export ANDROID_HOME=/path/to/android/sdk
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

### Requirements
- Android Studio Hedgehog (2023.1.1) atau lebih baru
- JDK 17+
- Android SDK 34
- Gradle 8.2

## Struktur
- package: com.diag.tool
- minSdk: 24 (Android 7.0)
- targetSdk: 34 (Android 14)
