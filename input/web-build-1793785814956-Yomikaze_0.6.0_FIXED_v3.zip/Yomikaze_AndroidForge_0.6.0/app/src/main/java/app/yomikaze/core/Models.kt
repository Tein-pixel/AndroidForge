package app.yomikaze.core

enum class MediaType { MANGA, MANHWA, MANHUA, COMIC, NOVEL }

enum class PublicationStatus { ONGOING, COMPLETED, HIATUS, CANCELLED, UNKNOWN }

enum class ReadingMode { PAGED, WEBTOON, TEXT }

enum class ContentRating { SAFE, RESTRICTED }

enum class MediaCategory(val label: String, val lang: String?) {
    ALL("Semua", null),
    MANGA_JP("Manga Jepang", "ja"),
    MANHWA_KR("Manhwa Korea", "ko"),
    MANHUA_CN("Manhua China", "zh"),
    WEBTOON("Webtoon", "ko"),
    COMIC("Comic", "en"),
    OEL("OEL", "en"),
    LIGHT_NOVEL("Light Novel", null),
    NOVEL("Novel", null)
}

data class ContentSummary(
    val id: String,
    val sourceId: String,
    val title: String,
    val altTitles: List<String> = emptyList(),
    val description: String = "",
    val coverUrl: String? = null,
    val mediaType: MediaType = MediaType.MANGA,
    val category: MediaCategory? = null,
    val status: PublicationStatus = PublicationStatus.UNKNOWN,
    val year: Int? = null,
    val tags: List<String> = emptyList(),
    val originalLanguage: String = "en",
    val readingMode: ReadingMode = ReadingMode.PAGED,
    val contentRating: ContentRating = ContentRating.SAFE,
)

data class ContentDetails(
    val summary: ContentSummary,
    val authors: List<String> = emptyList(),
    val artists: List<String> = emptyList(),
    val chapters: List<Chapter> = emptyList(),
)

data class Chapter(
    val id: String,
    val contentId: String,
    val sourceId: String,
    val number: String,
    val volume: String? = null,
    val title: String? = null,
    val language: String = "en",
    val pageCount: Int = 0,
    val publishedAt: Long = 0L,
    val url: String? = null,
    val scanlationGroups: List<String> = emptyList(),
    val externalUrl: String? = null,
)

sealed interface ChapterContent {
    data class Images(val pages: List<Page>) : ChapterContent
    data class Text(
        val title: String,
        val paragraphs: List<String>,
        val previousUrl: String? = null,
        val nextUrl: String? = null,
    ) : ChapterContent
}

data class Page(
    val index: Int,
    val url: String,
    val width: Int? = null,
    val height: Int? = null,
)


/** Removes common Markdown/HTML decoration while keeping readable description text. */
fun String.stripMarkdown(): String = this
    .replace(Regex("""!\[([^\]]*)\]\([^)]*\)"""), "$1")
    .replace(Regex("""\[([^\]]+)\]\([^)]*\)"""), "$1")
    .replace(Regex("""(?m)^\s{0,3}#{1,6}\s*"""), "")
    .replace(Regex("""(?m)^\s{0,3}>\s?"""), "")
    .replace(Regex("""\*\*(.+?)\*\*|__(.+?)__"""), "$1$2")
    .replace(Regex("""(?<!\*)\*([^*]+)\*(?!\*)"""), "$1")
    .replace(Regex("""(?<!_)_([^_]+)_(?!_)"""), "$1")
    .replace(Regex("""`{1,3}([^`]+)`{1,3}"""), "$1")
    .replace(Regex("""(?m)^\s*[-*+]\s+"""), "• ")
    .replace(Regex("""<[^>]+>"""), "")
    .replace(Regex("""https?://\S+"""), "")
    .replace(Regex("""[ \t]+\n"""), "\n")
    .replace(Regex("""\n{3,}"""), "\n\n")
    .trim()
