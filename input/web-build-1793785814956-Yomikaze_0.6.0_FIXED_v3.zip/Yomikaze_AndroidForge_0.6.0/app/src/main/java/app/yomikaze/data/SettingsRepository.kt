package app.yomikaze.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val isRestrictedModeKey = booleanPreferencesKey("is_restricted_mode")

    val isRestrictedModeEnabled: Flow<Boolean> = context.dataStore.data
        .map { it[isRestrictedModeKey] ?: false }

    suspend fun setRestrictedMode(enabled: Boolean) {
        context.dataStore.edit { it[isRestrictedModeKey] = enabled }
    }
}