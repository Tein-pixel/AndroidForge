package com.tein.booster;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Gravity;
import android.view.Display;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

import rikka.shizuku.Shizuku;

/** Optional non-root ADB integrations. Privileged actions are disabled unless Shizuku UID is shell (2000). */
public class CompanionAccessActivity extends BaseActivity {
    private static final int SHIZUKU_PERMISSION = 214;
    private TextView shizukuStatus, refreshStatus, breventStatus, dnsStatus;
    private LinearLayout refreshButtons, refreshCard, dnsCard;
    private boolean listenerAdded;

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) ->
            runOnUiThread(() -> { updateShizukuStatus(); updateRefreshControls(); });
    private final Shizuku.OnBinderReceivedListener binderReceivedListener = () -> {
        updateShizukuStatus(); updateRefreshControls(); updateDnsStatus();
    };
    private final Shizuku.OnBinderDeadListener binderDeadListener = () -> {
        updateShizukuStatus(); updateRefreshControls(); updateDnsStatus();
    };

    @Override protected String title() { return "Integrasi ADB"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = scrollBody();
        col.addView(Ui.tv(this, "Kompatibilitas minimum Android 10 (API 29). Fitur dasar berjalan sendiri; kontrol sistem lanjutan memerlukan Shizuku aktif dalam mode ADB (UID 2000) dan izin TeinBooster. Pada Android 11+ Shizuku dapat mulai lewat Wireless debugging; Android 10 umumnya membutuhkan bantuan komputer/ADB. Brevent tidak memberikan akses ADB kepada aplikasi lain. Root tidak digunakan.", 12, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 12));

        LinearLayout shizuku = Ui.card(this);
        LinearLayout heading = Ui.row(this);
        heading.addView(Ui.tvb(this, "Shizuku / ADB", 16, Ui.TEXT), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        heading.addView(Ui.chip(this, "OPSIONAL", Ui.CYAN));
        shizuku.addView(heading);
        shizukuStatus = Ui.tv(this, "Memeriksa layanan Shizuku…", 12, Ui.SUB);
        shizuku.addView(shizukuStatus, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        shizuku.addView(Ui.button(this, "Buka Shizuku", v -> openShizuku()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        shizuku.addView(Ui.ghost(this, "Minta izin ADB untuk TeinBooster", v -> requestShizukuPermission()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        shizuku.addView(Ui.tv(this, "Android 11+: Shizuku non-root bisa dimulai lewat Wireless debugging di HP. Android 10 tidak punya alur Wireless debugging bawaan yang sama, jadi biasanya perlu komputer/ADB untuk memulai server. Setelah reboot, server umumnya harus dimulai lagi. Izin Shizuku bukan root; fitur ADB hanya aktif jika UID layanan 2000 (shell/ADB).", 11, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(shizuku, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        refreshCard = Ui.card(this);
        refreshCard.addView(Ui.tvb(this, "Refresh rate manual", 15, Ui.TEXT));
        refreshCard.addView(Ui.tv(this, "Mengirim preferensi min/max refresh rate melalui ADB. Efek bergantung dukungan Android/OEM; bukan overclock. FPS game tidak dijamin berubah.", 11, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        refreshStatus = Ui.tv(this, "Refresh rate: membaca…", 12, Ui.CYAN);
        refreshCard.addView(refreshStatus, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        refreshButtons = Ui.col(this);
        refreshCard.addView(refreshButtons, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        refreshCard.addView(Ui.ghost(this, "Pulihkan nilai sebelum perubahan", v -> restoreRefreshRate()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(refreshCard, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout brevent = Ui.card(this);
        LinearLayout bh = Ui.row(this);
        bh.addView(Ui.tvb(this, "Brevent", 15, Ui.TEXT), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        breventStatus = Ui.chip(this, "MEMERIKSA", Ui.SUB);
        bh.addView(breventStatus);
        brevent.addView(bh);
        brevent.addView(Ui.tv(this, "Brevent mengelola aplikasi latar melalui layanan ADB-nya sendiri. TeinBooster tidak mematikan aplikasi lewat Brevent secara otomatis karena tidak menemukan API publik stabil untuk kontrol jarak jauh.", 11, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        brevent.addView(Ui.button(this, "Buka Brevent", v -> openBrevent()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        brevent.addView(Ui.ghost(this, "Panduan resmi Brevent", v -> openUrl("https://brevent.sh")), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        brevent.addView(Ui.tv(this, "Brevent berjalan sebagai layanan ADB terpisah. Status aktifnya tidak menggantikan izin Shizuku untuk fitur ADB TeinBooster. Kelola aplikasi latar langsung di Brevent; jangan batasi aplikasi pesan penting.", 11, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(brevent, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        dnsCard = Ui.card(this);
        dnsCard.addView(Ui.tvb(this, "DNS Pribadi (opsional)", 15, Ui.TEXT));
        dnsCard.addView(Ui.tv(this, "Mengubah DNS Pribadi Android melalui Shizuku ADB. Hanya gunakan jika Shizuku aktif dengan UID 2000 dan izin diberikan. VPN atau kebijakan OEM dapat mengabaikan perubahan. Nilai awal disimpan untuk pemulihan.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        dnsStatus = Ui.tv(this, "Status DNS: belum dibaca", 12, Ui.CYAN);
        dnsCard.addView(dnsStatus, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        dnsCard.addView(Ui.button(this, "DNS Cloudflare", v -> applyPrivateDns("one.one.one.one")), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        dnsCard.addView(Ui.ghost(this, "DNS Google", v -> applyPrivateDns("dns.google")), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        dnsCard.addView(Ui.ghost(this, "Pulihkan DNS sebelumnya", v -> restorePrivateDns()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(dnsCard, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout shortcuts = Ui.card(this);
        shortcuts.addView(Ui.tvb(this, "Utilitas tambahan", 15, Ui.TEXT));
        shortcuts.addView(Ui.button(this, "Timer game & galeri screenshot", v -> startActivity(new Intent(this, GameUtilitiesActivity.class))),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 9, 0, 0));
        shortcuts.addView(Ui.ghost(this, "Pengaturan Opsi Pengembang", v -> openDeveloperSettings()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        col.addView(shortcuts);

        Shizuku.addRequestPermissionResultListener(permissionListener);
        Shizuku.addBinderReceivedListener(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        listenerAdded = true;
        updateShizukuStatus();
        updateRefreshControls();
        updateBreventStatus();
        updateDnsStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        updateShizukuStatus();
        updateRefreshControls();
        updateBreventStatus();
        updateDnsStatus();
    }

    @Override protected void onDestroy() {
        if (listenerAdded) {
            try { Shizuku.removeRequestPermissionResultListener(permissionListener); } catch (Exception ignored) { }
            try { Shizuku.removeBinderReceivedListener(binderReceivedListener); } catch (Exception ignored) { }
            try { Shizuku.removeBinderDeadListener(binderDeadListener); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    private void updateShizukuStatus() {
        if (shizukuStatus == null) return;
        try {
            if (!Shizuku.pingBinder()) {
                shizukuStatus.setText("Shizuku belum aktif atau server belum berjalan.");
            } else {
                int uid = Shizuku.getUid();
                if (uid != 2000) {
                    shizukuStatus.setText("Server Shizuku terhubung, tetapi UID bukan ADB/shell (2000). TeinBooster sengaja menonaktifkan perintah ADB jika layanan berjalan sebagai root.");
                } else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    shizukuStatus.setText("Terhubung • izin diberikan • UID 2000 (ADB). Fitur non-root tersedia jika perangkat mendukung.");
                } else {
                    shizukuStatus.setText("Server ADB terhubung, tetapi izin TeinBooster belum diberikan.");
                }
            }
        } catch (Exception e) {
            shizukuStatus.setText("Status tidak dapat dibaca. Buka Shizuku dan periksa koneksi server.");
        }
    }

    private boolean hasAdbPermission() {
        try { return Shizuku.pingBinder() && Shizuku.getUid() == 2000 && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED; }
        catch (Exception e) { return false; }
    }

    private void requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Jalankan server Shizuku terlebih dahulu.", Toast.LENGTH_LONG).show();
                openShizuku();
                return;
            }
            if (Shizuku.getUid() != 2000) {
                Toast.makeText(this, "Dibatalkan: mode root tidak digunakan oleh TeinBooster.", Toast.LENGTH_LONG).show();
                return;
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Izin ADB sudah diberikan.", Toast.LENGTH_SHORT).show();
                return;
            }
            Shizuku.requestPermission(SHIZUKU_PERMISSION);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak dapat meminta izin. Perbarui/jalankan Shizuku lalu coba lagi.", Toast.LENGTH_LONG).show();
        }
    }

    private void updateRefreshControls() {
        if (refreshStatus == null || refreshButtons == null) return;
        boolean adbReady = hasAdbPermission();
        if (refreshCard != null) refreshCard.setVisibility(adbReady ? View.VISIBLE : View.GONE);
        if (dnsCard != null) dnsCard.setVisibility(adbReady ? View.VISIBLE : View.GONE);
        if (!adbReady) return;
        refreshStatus.setText(String.format(Locale.US, "Mode layar saat ini: %.1f Hz", getCurrentRefreshRate()));
        refreshButtons.removeAllViews();
        Set<Integer> supported = new TreeSet<>();
        try {
            Display display = getWindowManager().getDefaultDisplay();
            for (Display.Mode mode : display.getSupportedModes()) {
                float hz = mode.getRefreshRate();
                int rounded = Math.round(hz);
                if (hz >= 50f && rounded >= 50 && rounded <= 240) supported.add(rounded);
            }
        } catch (Exception ignored) { }
        if (supported.isEmpty()) supported.add(Math.max(60, Math.round(getCurrentRefreshRate())));
        for (final int hz : supported) {
            if (hz != 60 && hz != 75 && hz != 90 && hz != 120 && hz != 144 && hz != 165 && hz != 180 && hz != 240) continue;
            TextView button = Ui.ghost(this, "Batasi ke " + hz + " Hz", v -> setRefreshRate(hz));
            button.setEnabled(adbReady);
            button.setAlpha(adbReady ? 1f : 0.45f);
            refreshButtons.addView(button, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
        }
        if (refreshButtons.getChildCount() == 0) {
            refreshButtons.addView(Ui.tv(this, "Mode refresh rate yang dikenali belum tersedia.", 11, Ui.SUB));
        }
    }

    private float getCurrentRefreshRate() {
        try { return getWindowManager().getDefaultDisplay().getRefreshRate(); }
        catch (Exception e) { return 0f; }
    }

    private void setRefreshRate(final int hz) {
        if (!hasAdbPermission()) { Toast.makeText(this, "Aktifkan Shizuku dengan UID ADB 2000 dan beri izin dahulu.", Toast.LENGTH_LONG).show(); return; }
        if (hz < 50 || hz > 240) return;
        final android.content.SharedPreferences backup = getSharedPreferences("adb_refresh_backup", MODE_PRIVATE);
        Bg.run(() -> {
            try {
                if (!backup.getBoolean("saved", false)) {
                    String before = runShell("settings get system min_refresh_rate; settings get system peak_refresh_rate");
                    String[] lines = before.trim().split("\\R");
                    String min = lines.length > 0 ? lines[0].trim() : "null";
                    String peak = lines.length > 1 ? lines[1].trim() : "null";
                    backup.edit().putString("min", min).putString("peak", peak).putBoolean("saved", true).apply();
                }
                String value = String.format(Locale.US, "%d.0", hz);
                String out = runShell("settings put system min_refresh_rate " + value + "; settings put system peak_refresh_rate " + value + "; settings get system min_refresh_rate; settings get system peak_refresh_rate");
                String[] values = out.trim().split("\\R");
                boolean match = values.length >= 2 && values[values.length - 1].trim().equals(value) && values[values.length - 2].trim().equals(value);
                runOnUiThread(() -> {
                    if (!alive()) return;
                    Toast.makeText(this, match ? "Preferensi " + hz + " Hz tersimpan. Efek aktual bergantung dukungan OEM." : "Perintah dikirim, tetapi nilai tidak terverifikasi. Perangkat mungkin tidak mendukungnya.", Toast.LENGTH_LONG).show();
                    updateRefreshControls();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Gagal menerapkan refresh rate. Periksa izin Shizuku dan dukungan perangkat.", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void restoreRefreshRate() {
        if (!hasAdbPermission()) { Toast.makeText(this, "Fitur pemulihan perlu Shizuku ADB dengan izin.", Toast.LENGTH_LONG).show(); return; }
        final android.content.SharedPreferences backup = getSharedPreferences("adb_refresh_backup", MODE_PRIVATE);
        if (!backup.getBoolean("saved", false)) { Toast.makeText(this, "Belum ada perubahan dari TeinBooster untuk dipulihkan.", Toast.LENGTH_SHORT).show(); return; }
        final String min = safeSetting(backup.getString("min", "null"));
        final String peak = safeSetting(backup.getString("peak", "null"));
        Bg.run(() -> {
            try {
                String a = "null".equals(min) ? "settings delete system min_refresh_rate" : "settings put system min_refresh_rate " + min;
                String b = "null".equals(peak) ? "settings delete system peak_refresh_rate" : "settings put system peak_refresh_rate " + peak;
                runShell(a + "; " + b);
                backup.edit().clear().apply();
                runOnUiThread(() -> { if (alive()) { Toast.makeText(this, "Nilai refresh rate sebelumnya dipulihkan bila didukung perangkat.", Toast.LENGTH_LONG).show(); updateRefreshControls(); } });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Pemulihan gagal. Buka pengaturan layar untuk memeriksa nilai.", Toast.LENGTH_LONG).show());
            }
        });
    }

    private String safeSetting(String value) {
        if (value == null || "null".equals(value)) return "null";
        return value.matches("[0-9]+(\\.[0-9]+)?") ? value : "null";
    }

    private String runShell(String command) throws Exception {
        // command strings are fixed internally; hz/settings are strictly whitelisted before interpolation.
        java.lang.Process process = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line).append('\n');
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line).append('\n');
        }
        int exit = process.waitFor();
        if (exit != 0) throw new IllegalStateException("ADB shell exited " + exit + ": " + result);
        return result.toString();
    }

    private void updateDnsStatus() {
        if (dnsStatus == null) return;
        dnsStatus.setText("Shizuku ADB: " + (hasAdbPermission() ? "siap" : "belum siap") + " • DNS Pribadi memerlukan dukungan sistem");
    }

    private void applyPrivateDns(final String hostname) {
        if (!hasAdbPermission()) {
            Toast.makeText(this, "Jalankan Shizuku mode ADB (UID 2000), lalu beri izin TeinBooster. Brevent saja tidak cukup.", Toast.LENGTH_LONG).show();
            return;
        }
        Bg.run(() -> {
            try {
                android.content.SharedPreferences b = getSharedPreferences("private_dns_backup", MODE_PRIVATE);
                if (!b.getBoolean("saved", false)) {
                    String before = runShell("settings get global private_dns_mode; settings get global private_dns_specifier");
                    String[] lines = before.trim().split("\\R");
                    String mode = lines.length > 0 ? lines[0].trim() : "null";
                    String spec = lines.length > 1 ? lines[1].trim() : "null";
                    b.edit().putString("mode", safeDnsValue(mode)).putString("specifier", safeDnsValue(spec)).putBoolean("saved", true).apply();
                }
                runShell("settings put global private_dns_mode hostname; settings put global private_dns_specifier " + hostname);
                String verify = runShell("settings get global private_dns_mode; settings get global private_dns_specifier");
                boolean ok = verify.contains("hostname") && verify.contains(hostname);
                runOnUiThread(() -> { if (alive()) { Toast.makeText(this, ok ? "DNS tersimpan. Uji koneksi; jika bermasalah, pulihkan DNS." : "Perintah dikirim tetapi DNS belum terverifikasi pada perangkat ini.", Toast.LENGTH_LONG).show(); updateDnsStatus(); } });
            } catch (Exception e) {
                runOnUiThread(() -> { if (alive()) Toast.makeText(this, "Gagal mengubah DNS. Perangkat/OEM mungkin menolak pengaturan ini.", Toast.LENGTH_LONG).show(); });
            }
        });
    }

    private void restorePrivateDns() {
        if (!hasAdbPermission()) { Toast.makeText(this, "Pemulihan perlu Shizuku ADB dengan izin.", Toast.LENGTH_LONG).show(); return; }
        android.content.SharedPreferences b = getSharedPreferences("private_dns_backup", MODE_PRIVATE);
        if (!b.getBoolean("saved", false)) { Toast.makeText(this, "Belum ada DNS yang diubah oleh TeinBooster.", Toast.LENGTH_SHORT).show(); return; }
        String mode = safeDnsValue(b.getString("mode", "null"));
        String spec = safeDnsValue(b.getString("specifier", "null"));
        Bg.run(() -> {
            try {
                String a = "null".equals(mode) ? "settings delete global private_dns_mode" : "settings put global private_dns_mode " + mode;
                String c = "null".equals(spec) ? "settings delete global private_dns_specifier" : "settings put global private_dns_specifier " + spec;
                runShell(a + "; " + c);
                b.edit().clear().apply();
                runOnUiThread(() -> { if (alive()) Toast.makeText(this, "Nilai DNS sebelumnya dipulihkan jika didukung OEM.", Toast.LENGTH_LONG).show(); });
            } catch (Exception e) { runOnUiThread(() -> { if (alive()) Toast.makeText(this, "Pemulihan DNS gagal. Periksa Pengaturan > Jaringan > DNS Pribadi.", Toast.LENGTH_LONG).show(); }); }
        });
    }

    private String safeDnsValue(String value) {
        if (value == null || "null".equals(value) || value.isEmpty()) return "null";
        return value.matches("[A-Za-z0-9._:-]{1,253}") ? value : "null";
    }

    private void updateBreventStatus() {
        if (breventStatus == null) return;
        boolean installed = isInstalled("me.piebridge.brevent");
        breventStatus.setText(installed ? "TERPASANG" : "BELUM ADA");
        breventStatus.setTextColor(installed ? Ui.MINT : Ui.SUB);
    }

    private boolean isInstalled(String pkg) {
        try { getPackageManager().getPackageInfo(pkg, 0); return true; }
        catch (Exception e) { return false; }
    }

    private void openShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (i != null) startActivity(i); else openUrl("https://shizuku.rikka.app/download/");
        } catch (Exception e) { openUrl("https://shizuku.rikka.app/download/"); }
    }

    private void openBrevent() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("me.piebridge.brevent");
            if (i != null) startActivity(i); else openUrl("https://play.google.com/store/apps/details?id=me.piebridge.brevent");
        } catch (Exception e) { openUrl("https://brevent.sh"); }
    }

    private void openDeveloperSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Exception e) { Toast.makeText(this, "Opsi Pengembang tidak tersedia. Buka Pengaturan Android secara manual.", Toast.LENGTH_LONG).show(); }
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Tidak ada aplikasi yang dapat membuka tautan.", Toast.LENGTH_SHORT).show(); }
    }
}
