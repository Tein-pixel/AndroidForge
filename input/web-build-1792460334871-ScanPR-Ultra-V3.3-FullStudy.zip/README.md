# Scan PR Ultra 3.3.0

Aplikasi Android Kotlin/XML untuk memindai atau mengetik soal sekolah, mengolah jawaban dengan provider AI yang dikonfigurasi pengguna, dan menyediakan fallback solver lokal yang terbatas.

## Fitur yang disertakan

- Kamera CameraX dan pilihan gambar galeri; foto dibuka di editor crop sebelum OCR.
- OCR lokal ML Kit Text Recognition (teks cetak Latin). Teks hasil OCR dapat dikoreksi manual sebelum dikirim.
- Jika internet dan API tersedia, gambar hasil crop juga dicoba langsung ke Gemini/OpenRouter vision untuk mengecek OCR, rumus, dan susunan soal; gambar dikompres dan dikirim dalam memori saja. Jika provider tidak mendukung gambar/gagal, aplikasi fallback ke teks OCR.
- Kolom mengetik soal seperti chat dan input suara melalui layanan speech recognition Android yang tersedia di perangkat.
- Pendeteksian koneksi internet tervalidasi; status online/offline diperbarui secara otomatis.
- Rantai provider AI: Gemini free-tier models yang diizinkan secara eksplisit, model OpenRouter yang ditandai `:free`, serta model open-weight dari Groq/Cerebras berdasarkan katalog API. Katalog model yang berubah dibaca saat runtime.
- Pemilihan prioritas provider: otomatis, Gemini, OpenRouter, Groq, atau Cerebras; provider gagal/kuota habis dicoba berikutnya.
- Prompt tutor lintas mapel yang meminta penjelasan langkah, alasan pilihan ganda, pemeriksaan hitungan, asumsi, dan catatan bila soal ambigu.
- Fallback solver lokal untuk operasi aritmetika dasar, persen, dan persamaan linear satu variabel yang dikenali. Solver menyatakan keterbatasannya alih-alih mengarang jawaban.
- Tutor lanjutan: jawaban ringkas/rinci, petunjuk, penjelasan sederhana, contoh sejenis, rangkuman, audit ulang jawaban, pertanyaan teks/suara lanjutan.
- Kuis pilihan ganda interaktif yang memeriksa pilihan, memberi skor, serta menampilkan jawaban dan penjelasan setelah latihan; flashcard dengan sisi depan/belakang dan navigasi kartu.
- Riwayat dengan folder default/custom, filter mapel/folder/favorit, pencarian teks, opsi per entri, ekspor TXT/PDF sesuai filter aktif.
- Bacakan jawaban dengan Text-to-Speech Android, salin/bagikan jawaban, ekspor PDF hasil, dan grafik fungsi linear `y = mx + b`.
- Riwayat lokal berbasis Room: pencarian, filter mata pelajaran, favorit, folder kustom, membuka kembali jawaban, menghapus entri, dan ekspor teks/PDF.
- Tema sistem/terang/gelap, pengaturan prioritas provider, dan penyimpanan API key terenkripsi di perangkat.

## Setup API

Tidak ada API key pribadi yang ditanam di source atau APK. Pengguna memasukkan key miliknya melalui Pengaturan.

- Gemini: https://aistudio.google.com/app/apikey
- OpenRouter: https://openrouter.ai/keys
- Groq: https://console.groq.com/keys
- Cerebras: https://cloud.cerebras.ai

Dokumentasi resmi untuk memeriksa perubahan model/kuota (ditinjau 20 Oktober 2026): [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing), [Gemini model list](https://ai.google.dev/gemini-api/docs/models), [OpenRouter free models](https://openrouter.ai/collections/free-models/), [Groq free-plan limits](https://console.groq.com/docs/rate-limits), [Cerebras pricing](https://inference-docs.cerebras.ai/support/pricing), dan [Anthropic API pricing](https://docs.anthropic.com/en/docs/about-claude/pricing).

Kuota gratis, rate limit, ketersediaan model, dan syarat provider bisa berubah. Gemini dibatasi ke model yang dokumentasi saat ini cantumkan pada free tier. OpenRouter dibatasi pada model dengan varian `:free`. Groq/Cerebras dapat memiliki syarat harga berbeda bergantung paket/akun; periksa dashboard akun sebelum digunakan. Claude Haiku 4.5 tidak dimasukkan dalam rantai default karena API Claude merupakan layanan proprietari berbayar, bukan model open-source gratis. Jangan menganggap semua model yang bisa dipanggil otomatis gratis.

## Batasan / kejujuran fitur

- “Semua mata pelajaran” berarti AI online dapat mencoba menjawab banyak jenis soal, bukan jaminan benar. Cocokkan angka, teks, satuan, dan fakta dengan buku/guru.
- Tidak ada sistem AI yang dapat menjamin akurasi 100%. Tombol Cek ulang meminta audit independen, tetapi model yang sama masih dapat mengulang kesalahan. Gunakan buku/guru untuk verifikasi akhir.
- Mode offline bukan LLM penuh. Ia hanya menyelesaikan operasi dan persamaan sederhana yang didukung; soal cerita dan sebagian besar mapel memerlukan provider online.
- Crop dilakukan secara manual. OCR lokal terutama ditujukan untuk teks cetak Latin. Vision AI dapat membantu membaca tulisan tangan, tabel, rumus, dan tata letak jika provider/model menerima gambar, tetapi tidak menjamin semuanya terbaca. Periksa dan edit OCR; bila permintaan gambar gagal, proses kembali menggunakan teks OCR saja.
- Grafik saat ini hanya untuk fungsi linear `y = mx + b`, bukan semua jenis grafik matematika. Pencarian sumber membuka halaman hasil pencarian di browser; aplikasi tidak mengklaim bahwa sumber tersebut telah diverifikasi otomatis atau menampilkan kutipan sumber terverifikasi di dalam jawaban.
- Input suara memakai speech service yang tersedia pada perangkat; apabila tidak ada service, gunakan keyboard.
- Provider key disimpan terenkripsi secara lokal, tetapi setiap permintaan online tetap dikirim ke provider yang dipilih sesuai kebijakan layanan tersebut.

## Build melalui AndroidForge

1. Unggah ZIP source ini ke AndroidForge.
2. Jalankan build Gradle untuk menghasilkan APK.
3. Jika build gagal, simpan log build lengkap. Source ini telah diperiksa statis, tetapi belum dapat dibuktikan bebas error melalui build Gradle penuh di lingkungan pembuatan ini.

## Toolchain

- Versi source: 3.3.0
- Kotlin 1.9.20 / JDK 17
- Android Gradle Plugin 8.3.2 / Gradle 8.4
- compileSdk 34, targetSdk 34, minSdk 24
- CameraX, ML Kit Text Recognition, Room, DataStore, AndroidX Security Crypto, OkHttp, Glide, CanHub Image Cropper
