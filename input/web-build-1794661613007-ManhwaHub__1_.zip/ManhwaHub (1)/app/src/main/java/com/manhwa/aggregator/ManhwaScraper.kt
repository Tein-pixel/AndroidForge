package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.TimeUnit

class ManhwaScraper {

    // Klien OkHttp dengan konfigurasi untuk menembus proteksi dasar
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val targetUrls = listOf(
        "https://asuracomic.net/series?order=update" to "Asura",
        "https://kiryuu.id/manga/?m_orderby=latest" to "Kiryuu",
        "https://cosmic1.co/manga/?m_orderby=latest" to "Cosmic" // Domain terbaru
    )

    suspend fun fetchLatest(): List<Manhwa> = withContext(Dispatchers.IO) {
        val allManhwa = mutableListOf<Manhwa>()

        for ((url, sourceName) in targetUrls) {
            try {
                // LAPISAN 1: Request dengan OkHttp + Header "Manusiawi"
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Referer", "https://www.google.com/")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val html = response.body?.string() ?: ""
                        val doc = Jsoup.parse(html, url)

                        // Selector yang diperluas untuk berbagai theme
                        val elements = doc.select(".listupd .bs, .bsx, .page-item-detail, .manga__item, .series-card, .manga-card")

                        for (el in elements) {
                            val title = el.select(".tt h3 a, .tt h4 a, .post-title h3 a, .manga__item-title a, .text-white, .series-title a").text().trim()
                            val link = el.select(".tt h3 a, .tt h4 a, .post-title h3 a, .manga__item-title a, .text-white, .series-title a").attr("href")
                            var imgUrl = el.select("img").attr("data-src")
                            if (imgUrl.isNullOrEmpty()) imgUrl = el.select("img").attr("src")
                            val latestChapter = el.select(".epxs, .chapter-item .btn-link, .list-chapter .chapter-item a").first()?.text()?.trim() ?: "Chapter Baru"

                            if (title.isNotEmpty() && link.isNotEmpty() && imgUrl.isNotEmpty()) {
                                allManhwa.add(Manhwa(title, link, imgUrl, latestChapter, sourceName))
                            }
                        }
                    } else {
                        // LAPISAN 2: Jika gagal (misal 403), coba lagi dengan referer berbeda
                        val fallbackRequest = request.newBuilder()
                            .header("Referer", "https://www.bing.com/")
                            .build()
                        client.newCall(fallbackRequest).execute().use { fallbackResponse ->
                            if (fallbackResponse.isSuccessful) {
                                val fallbackHtml = fallbackResponse.body?.string() ?: ""
                                val doc = Jsoup.parse(fallbackHtml, url)
                                val elements = doc.select(".listupd .bs, .bsx, .page-item-detail")
                                for (el in elements) {
                                    val title = el.select("a").text().trim()
                                    val link = el.select("a").attr("href")
                                    val imgUrl = el.select("img").attr("src")
                                    if (title.isNotEmpty() && link.isNotEmpty()) {
                                        allManhwa.add(Manhwa(title, link, imgUrl, "Update", sourceName))
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        
        // Jika kosong, beri dummy agar UI tidak crash
        if (allManhwa.isEmpty()) {
            allManhwa.add(Manhwa("Gagal Terhubung / Diblokir", "https://google.com", "https://via.placeholder.com/300x400?text=Blocked", "Cek Koneksi", "System"))
        }

        allManhwa.distinctBy { it.link }
    }
}