# Scan PR Ultra 3.8.0

Android homework helper using CameraX, ML Kit OCR, crop selection, and online multimodal AI.

## Accuracy-focused scan pipeline
- Capture or select image, crop it, and run local OCR only as a secondary reference.
- The original cropped image is always attached to a vision-capable AI provider when answering a photo question.
- OCR text is explicitly treated as potentially incorrect; direct visual interpretation takes precedence.
- Photo answers are audited by a second configured vision provider when another provider key is available.
- If no vision model is reachable, the app shows an error instead of silently answering from OCR alone or inventing an offline answer.
- EXIF rotation is normalized and image compression preserves more detail for handwriting, fractions, roots, superscripts, and division bars.

## Multi-model chat (carried forward into v3.8.0)
- Added a compact model selector in the Result toolbar and a status indicator above the chat input.
- One normalized conversation history is reused across Gemini, Groq, and OpenRouter: switching models does not clear prior text or image turns.
- The chat input can attach another gallery image. The existing scan/camera path remains available for the first image.
- On a model error/quota response, up to three alternate live-listed candidates may be tried; vision context only falls back to image-capable choices.
- The selector loads catalogs dynamically from the user-supplied keys. It intentionally avoids retired Gemini 1.5/2.0 IDs and old fixed model names instead of advertising IDs that may no longer work.

## AI providers / changing models
- Gemini API: the key’s live model catalog is checked against current Flash/Flash-Lite candidates with documented Standard free-tier input/output. The API’s ListModels response does not expose billing flags, so a project with billing enabled may incur charges under Google’s terms; free quotas/access vary by account and region. Retired Gemini 1.5/2.0 IDs and Gemini 2.5 Flash/Pro (no standard free tier) are not advertised as free.
- OpenRouter: the free router (`openrouter/free`) can route image requests to compatible free vision models; the live catalog checks zero prompt/completion pricing and image input modality for each `:free` variant.
- Groq: current documented Free-plan chat candidates are matched against the key’s live `/models` response, including Qwen vision. Groq documents Qwen 3.8 vision for the Chat Completions endpoint; access and quota still depend on the account and can change.
- The Result-screen chat selector currently uses Gemini, Groq, and OpenRouter. It discovers models through each provider API and does not claim that every model exposed by a provider is free. Check provider account limits and pricing before use.
- Provider/model can be chosen in Settings or from the Result toolbar. In the Result-screen chat, automatic fallback may try another configured Gemini/Groq/OpenRouter candidate after a quota or model error; for conversations containing images, fallback is restricted to models marked as vision-capable. The separate Auto provider flow does not use Cerebras unless selected in Settings. Quotas, access, model names, free limits, and regional availability can change. API keys are supplied by the user and saved through encrypted preferences; no shared secrets are shipped in the APK.
- The app does not claim OpenAI or xAI/Grok direct APIs are free. Those can charge separately even if their consumer apps have free plans.

## Offline study tools (not answer-generation)
- Calculator for +, -, ×, ÷, parentheses, exponent, square root, percentage, π, and e.
- Multiple saved notes, editable on device.
- Unit converter for length, mass, time, volume, and temperature.
- Searchable formula/reference list for math, physics, chemistry, statistics, and economics.
- Quick element reference and focus timer.

## Build
- Android Gradle Plugin 8.3.2, Gradle 8.4, JDK 17, compile/target SDK 34, min SDK 24.
- AndroidForge can regenerate the wrapper if it is absent. Build `:app:assembleDebug`.
- Do not put personal API keys in Gradle or BuildConfig. Add provider API keys in the app Settings.

## Limitations
No image/OCR model can guarantee 99% accuracy for every handwritten photo. Strong blur, glare, shadows, cropped symbols, and very small handwriting can remain ambiguous. The application is designed to ask for a clearer image rather than silently fabricate uncertain digits or symbols.


## Model catalogue references
- Google Gemini API model catalogue and lifecycle: https://ai.google.dev/gemini-api/docs/models and https://ai.google.dev/gemini-api/docs/deprecations
- OpenRouter live model metadata (pricing and input modalities): https://openrouter.ai/docs/api/api-reference/models/get-models and free models: https://openrouter.ai/collections/free-models
- Groq current supported models and free-plan rate limits: https://console.groq.com/docs/models and https://console.groq.com/docs/rate-limits


## v3.8 update notes
- Version code/name advanced to 9 / 3.8.0.
- The top-bar model selector uses live catalogs rather than assuming old IDs still work. Gemini 2.0 and 1.5 models are excluded because their API IDs are retired; Gemini 2.5 Flash/Pro are excluded from the free-only picker because the current standard pricing table does not mark them as free-tier models.
- Chat history is normalized once and reused across Gemini, Groq, and OpenRouter requests. User image turns remain attached in the shared in-memory history for follow-up/context switching.
- `gradlew.bat` fallback bootstrap was corrected. This container did not have Gradle/Android SDK dependencies and network DNS was unavailable, so a full Gradle APK build could not be verified here; run `:app:assembleDebug` in AndroidForge/Android Studio to confirm the environment-specific build.
