Gradle wrapper note

The official binary gradle-wrapper.jar could not be fetched in this source-generation environment. The included gradlew/gradlew.bat therefore use a bootstrap fallback: they download Gradle 8.4 and invoke it directly if the wrapper JAR is absent. The first build needs network access.

To generate the standard Gradle wrapper files on a machine that already has Gradle installed, run:
  gradle wrapper --gradle-version 8.4

Then commit the generated gradle/wrapper/gradle-wrapper.jar and the generated wrapper scripts if desired.
