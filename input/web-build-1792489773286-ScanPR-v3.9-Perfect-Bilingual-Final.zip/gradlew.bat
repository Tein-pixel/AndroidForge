@echo off
setlocal
set "APP_HOME=%~dp0"
if exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  java -Dorg.gradle.appname=gradlew -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %ERRORLEVEL%
)
set "VERSION=8.4"
set "BASE=%USERPROFILE%\.gradle\manual-distributions"
set "DIST=%BASE%\gradle-%VERSION%"
set "ZIP=%BASE%\gradle-%VERSION%-bin.zip"
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '%BASE%' -Force"
)
call "%DIST%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
