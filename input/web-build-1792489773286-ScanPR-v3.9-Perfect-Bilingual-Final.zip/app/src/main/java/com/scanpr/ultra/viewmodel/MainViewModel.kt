// File: app/src/main/java/com/scanpr/ultra/viewmodel/MainViewModel.kt
package com.scanpr.ultra.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class MainViewModel : ViewModel() {
    suspend fun recognize(context: Context, uri: Uri): String = suspendCancellableCoroutine { cont ->
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        runCatching { InputImage.fromFilePath(context, uri) }.onFailure { if (cont.isActive) cont.resume("") }
            .onSuccess { image -> recognizer.process(image).addOnSuccessListener { result -> if (cont.isActive) cont.resume(result.text) }
                .addOnFailureListener { if (cont.isActive) cont.resume("") }
                .addOnCompleteListener { recognizer.close() } }
    }
}
