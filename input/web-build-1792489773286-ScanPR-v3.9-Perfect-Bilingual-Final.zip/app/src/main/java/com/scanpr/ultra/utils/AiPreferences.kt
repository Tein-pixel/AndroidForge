package com.scanpr.ultra.utils

import android.content.Context

object AiPreferences {
    const val AUTO = "AUTO"
    const val GEMINI = "GEMINI"
    const val OPENROUTER = "OPENROUTER"
    const val GROQ = "GROQ"
    const val CEREBRAS = "CEREBRAS"
    const val MODEL_AUTO = "__AUTO_MODEL__"
    private const val PREFS = "scanpr_ai_options"
    private const val PRIORITY = "provider_priority"
    private fun modelKey(provider: String) = "selected_model_$provider"

    fun getPriority(context: Context): String = context.applicationContext
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(PRIORITY, AUTO) ?: AUTO

    fun setPriority(context: Context, value: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PRIORITY, value).apply()
    }

    fun getSelectedModel(context: Context, provider: String): String = context.applicationContext
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(modelKey(provider), MODEL_AUTO) ?: MODEL_AUTO

    fun setSelectedModel(context: Context, provider: String, model: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(modelKey(provider), model).apply()
    }

    /** Auto mode only uses sources explicitly routed as free; paid/other providers require deliberate selection. */
    fun providerOrder(context: Context): List<String> = when (getPriority(context)) {
        GROQ -> listOf(GROQ, GEMINI, OPENROUTER)
        CEREBRAS -> listOf(CEREBRAS, GEMINI, OPENROUTER)
        OPENROUTER -> listOf(OPENROUTER, GEMINI)
        GEMINI -> listOf(GEMINI, OPENROUTER)
        else -> listOf(GEMINI, OPENROUTER)
    }
}
