// File: app/src/main/java/com/scanpr/ultra/viewmodel/ResultViewModel.kt
package com.scanpr.ultra.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scanpr.ultra.utils.AiProvider
import com.scanpr.ultra.utils.AiResult
import com.scanpr.ultra.utils.ChatModelChoice
import com.scanpr.ultra.utils.ChatTurn
import com.scanpr.ultra.utils.ConversationSession
import com.scanpr.ultra.utils.ImageUtils
import com.scanpr.ultra.utils.MultiModelChatApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ResultViewModel : ViewModel() {
    private val _result = MutableStateFlow<AiResult?>(null)
    val result: StateFlow<AiResult?> = _result
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    private val conversation = ConversationSession.turns

    /** Sends one user turn through the selected model without clearing the shared conversation. */
    fun send(context: Context, model: ChatModelChoice, text: String, imageUri: Uri? = null, fallbackModels: List<ChatModelChoice> = listOf(model)) {
        if (_loading.value) return
        val cleanText = text.trim().ifBlank { if (imageUri != null) "Baca dan bantu kerjakan soal dari foto yang saya kirim." else "" }
        if (cleanText.isBlank() && imageUri == null) {
            _result.value = AiResult("Tulis pertanyaan terlebih dahulu.", emptyList(), "Umum", "Belum dikirim", emptyList(), "")
            return
        }
        // Clear the previous response before the new request so observers cannot mistake it for the result of this turn.
        _result.value = null
        viewModelScope.launch {
            _loading.value = true
            try {
                val photo = imageUri?.let { uri -> withContext(Dispatchers.IO) { ImageUtils.encodeForAi(context.applicationContext, uri) } }
                if (imageUri != null && photo == null) throw IllegalStateException("Gambar tidak bisa dibaca untuk AI. Pilih ulang atau crop gambar tersebut.")
                if (photo != null && !model.supportsVision) throw IllegalStateException("Model ini tidak mendukung foto. Pilih model dengan label Foto.")
                val previousTurns = conversation.toList()
                val photoContext = photo != null || previousTurns.any { it.image != null }
                val alternatives = fallbackModels.filter { it.value != model.value }
                    .filter { !photoContext || it.supportsVision }
                    .distinctBy { it.value }
                val firstByProvider = alternatives.groupBy { it.provider }.values.mapNotNull { it.firstOrNull() }
                    .sortedBy { it.provider }
                val firstPass = firstByProvider + alternatives.filterNot { option -> firstByProvider.any { it.value == option.value } }
                val candidates = (listOf(model) + firstPass).distinctBy { it.value }.take(4)
                var answer: AiResult? = null
                var lastFailure: String? = null
                var winningModel: ChatModelChoice? = null
                for (candidate in candidates) {
                    try {
                        answer = MultiModelChatApi().send(context.applicationContext, candidate, previousTurns, cleanText, photo)
                        winningModel = candidate
                        break
                    } catch (failure: Exception) {
                        lastFailure = failure.message
                    }
                }
                val finalAnswer = answer ?: throw IllegalStateException(lastFailure ?: "Semua model yang tersedia gagal atau kuotanya habis.")
                // Only successful exchanges enter the shared history. The same turns are reused when the model changes.
                conversation += ChatTurn("user", cleanText, photo)
                val assistantContext = buildString {
                    append(finalAnswer.jawabanAkhir)
                }.trim()
                conversation += ChatTurn("assistant", assistantContext.take(12000))
                // Keep complete user/assistant pairs and prevent unbounded image/text memory consumption.
                while (conversation.size > 18) {
                    if (conversation.size >= 2) { conversation.removeAt(0); conversation.removeAt(0) } else conversation.clear()
                }
                val usedModel = winningModel
                _result.value = if (usedModel != null && usedModel.value != model.value) {
                    finalAnswer.copy(modelUsed = "${usedModel.label} (fallback otomatis)")
                } else finalAnswer
            } catch (e: Exception) {
                _result.value = AiResult(
                    jawabanAkhir = "AI belum berhasil menjawab. Periksa koneksi internet, API key, kuota, atau pilih model lain.",
                    langkah = listOf("Riwayat chat tidak dihapus. Pesan yang gagal tidak ditambahkan sebagai jawaban."),
                    mapel = "Umum", modelUsed = "AI gagal", metodeAlternatif = emptyList(),
                    catatan = e.message ?: "Provider AI tidak tersedia."
                )
            } finally {
                _loading.value = false
            }
        }
    }

    fun solve(context: Context, text: String, imageUri: Uri? = null) {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            _result.value = try {
                AiProvider(context.applicationContext).solveAuto(text, imageUri)
            } catch (e: Exception) {
                AiResult(
                    jawabanAkhir = "AI online belum berhasil menjawab. Periksa koneksi internet, API key, kuota, atau coba model lain di Pengaturan.",
                    langkah = listOf("Tidak ada jawaban yang dibuat. Periksa internet, API key, kuota, atau ganti model/provider."),
                    mapel = "Umum", modelUsed = "AI online gagal", metodeAlternatif = emptyList(),
                    catatan = e.message ?: "Provider AI tidak tersedia."
                )
            }
            _loading.value = false
        }
    }

    fun setResult(value: AiResult) { _result.value = value }
    fun seedConversation(question: String, answer: String, image: ImageUtils.EncodedImage? = null) {
        if (conversation.isEmpty()) {
            if (question.isNotBlank() || image != null) conversation += ChatTurn("user", question.take(10000), image)
            if (answer.isNotBlank()) conversation += ChatTurn("assistant", answer.take(12000))
        }
    }
    fun hasImageInHistory(): Boolean = conversation.any { it.image != null }
    fun hasConversation(): Boolean = conversation.isNotEmpty()
    fun conversationSnapshot(): List<ChatTurn> = conversation.toList()
    fun previousConversationDisplay(): String {
        val previous = conversation.dropLast(2).takeLast(8)
        if (previous.isEmpty()) return ""
        return previous.joinToString("\n\n") { turn ->
            val prefix = if (turn.role == "assistant") "AI" else "Kamu"
            "$prefix: ${turn.text.take(900)}" + if (turn.image != null) "\n[Foto terlampir]" else ""
        }.take(5000)
    }
}
