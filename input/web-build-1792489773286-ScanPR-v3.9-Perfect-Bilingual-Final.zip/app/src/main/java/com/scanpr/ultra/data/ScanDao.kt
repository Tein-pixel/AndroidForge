// File: app/src/main/java/com/scanpr/ultra/data/ScanDao.kt
package com.scanpr.ultra.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanDao {
    @Insert suspend fun insert(item: ScanHistory): Long
    @Query("SELECT * FROM scan_history ORDER BY createdAt DESC") fun observeAll(): Flow<List<ScanHistory>>
    @Query("SELECT * FROM scan_history WHERE ocrText LIKE '%' || :query || '%' OR answer LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun search(query: String): Flow<List<ScanHistory>>
    @Query("SELECT * FROM scan_history WHERE id = :id LIMIT 1") suspend fun getById(id: Long): ScanHistory?
    @Query("DELETE FROM scan_history WHERE id = :id") suspend fun deleteById(id: Long)
}
