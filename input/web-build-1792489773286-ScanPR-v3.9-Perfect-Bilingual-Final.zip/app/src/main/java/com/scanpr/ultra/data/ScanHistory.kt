// File: app/src/main/java/com/scanpr/ultra/data/ScanHistory.kt
package com.scanpr.ultra.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scan_history")
data class ScanHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ocrText: String,
    val answer: String,
    val stepsJson: String,
    val mapel: String,
    val modelUsed: String,
    val imageUri: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
