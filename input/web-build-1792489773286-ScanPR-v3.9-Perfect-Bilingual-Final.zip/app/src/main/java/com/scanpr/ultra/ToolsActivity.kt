package com.scanpr.ultra

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat
import kotlin.math.pow
import kotlin.math.sqrt

/** Lightweight offline utilities. No network, login, or API key is used here. */
class ToolsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("study_notes_v2", MODE_PRIVATE) }
    private var timer: CountDownTimer? = null
    private var timerRemainingMs = 25L * 60L * 1000L
    private var timerRunning = false
    private var timerDisplay: TextView? = null
    private var currentNoteId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    override fun onDestroy() { timer?.cancel(); super.onDestroy() }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun label(value: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
    }
    private fun base(title: String): LinearLayout {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(12)); setBackgroundColor(Color.rgb(12, 12, 12)) }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(8)) }
        toolbar.addView(TextView(this).apply {
            text = "‹"; textSize = 34f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); contentDescription = "Kembali"
            setPadding(dp(4), 0, dp(18), 0); setOnClickListener { if (title == "Alat offline") finish() else showHome() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        toolbar.addView(label(title, 20f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        outer.addView(toolbar)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(16)) }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(outer)
        return content
    }

    private fun button(root: LinearLayout, labelText: String, action: () -> Unit) {
        val button = Button(this).apply { text = labelText; isAllCaps = false; setOnClickListener { action() } }
        root.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    private fun input(hintText: String, multiline: Boolean = false): EditText = EditText(this).apply {
        hint = hintText; textSize = 16f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        setSingleLine(!multiline); if (multiline) { minLines = 5; gravity = Gravity.TOP or Gravity.START } else minLines = 1
        setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(Color.rgb(31,31,31))
    }

    private data class Tool(val symbol: String, val title: String, val run: () -> Unit)
    private fun showHome() {
        val r = base("Alat offline")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val items = listOf(
            Tool("∑", "Kalkulator") { calculator() }, Tool("✎", "Catatan") { notes() },
            Tool("⇄", "Konversi") { converter() }, Tool("√", "Rumus") { formulas() },
            Tool("⚛", "Unsur") { elements() }, Tool("◷", "Timer") { timerTool() }
        )
        items.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { item ->
                val card = MaterialCardView(this).apply {
                    radius = dp(18).toFloat(); cardElevation = 0f; strokeWidth = dp(1)
                    setCardBackgroundColor(Color.rgb(27,27,27)); strokeColor = Color.rgb(54,54,54)
                    isClickable = true; isFocusable = true; setOnClickListener { item.run() }
                }
                val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(14), dp(8), dp(14)) }
                inner.addView(label(item.symbol, 34f), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
                inner.addView(label(item.title, 12f, Color.LTGRAY))
                card.addView(inner)
                row.addView(card, LinearLayout.LayoutParams(0, dp(112), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(8)) })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, dp(112), 1f))
            grid.addView(row)
        }
        r.addView(grid)
        r.addView(label("Tersedia tanpa internet", 12f, Color.GRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
    }

    private fun calculator() {
        val r = base("∑")
        val expr = input("(12 + 8) × 3 ÷ 4")
        r.addView(expr, fullWidth())
        val result = label("—", 28f).apply { setPadding(dp(6), dp(20), dp(6), dp(20)) }
        r.addView(result)
        button(r, "Hitung") {
            try { result.text = DecimalFormat("0.##########").format(SafeCalculator.eval(expr.text.toString())) }
            catch (_: Exception) { result.text = "Ekspresi tidak valid" }
        }
        button(r, "Salin hasil") {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Hasil", result.text)); Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
        }
        button(r, "Hapus") { expr.setText(""); result.text = "—" }
        r.addView(label("Dukung + − × ÷, kurung, pangkat ^, akar √(...), %, π dan e.", 11f, Color.GRAY).apply { setPadding(dp(4), dp(10), dp(4), 0) })
    }

    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }

    private data class Note(val id: String, val title: String, val body: String, val updated: Long)
    private fun readNotes(): MutableList<Note> {
        val raw = prefs.getString("notes_json", null)
        if (raw == null) {
            val old = getSharedPreferences("study_notes", MODE_PRIVATE).getString("body", "").orEmpty()
            val migrated = mutableListOf<Note>()
            if (old.isNotBlank()) migrated.add(Note("legacy", "Catatan lama", old, System.currentTimeMillis()))
            if (migrated.isNotEmpty()) writeNotes(migrated)
            return migrated
        }
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { Note(it.optString("id"), it.optString("title"), it.optString("body"), it.optLong("updated")) } }.toMutableList()
        }.getOrDefault(mutableListOf())
    }
    private fun writeNotes(notes: List<Note>) {
        val arr = JSONArray()
        notes.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updated", it.updated)) }
        prefs.edit().putString("notes_json", arr.toString()).apply()
    }
    private fun notes() {
        val r = base("✎")
        button(r, "＋ Catatan baru") { editNote(null) }
        val existing = readNotes().sortedByDescending { it.updated }
        if (existing.isEmpty()) r.addView(label("Belum ada catatan", 13f, Color.GRAY).apply { setPadding(4, dp(16), 4, dp(8)) })
        existing.forEach { note ->
            val card = MaterialCardView(this).apply { radius = dp(14).toFloat(); cardElevation = 0f; setCardBackgroundColor(Color.rgb(27,27,27)); strokeColor = Color.rgb(54,54,54); strokeWidth = dp(1) }
            val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
            content.addView(label(note.title.ifBlank { "Tanpa judul" }, 16f))
            content.addView(label(note.body.replace('\n',' ').take(100), 12f, Color.LTGRAY).apply { setPadding(0, dp(5), 0, 0) })
            card.addView(content); card.setOnClickListener { editNote(note.id) }
            r.addView(card, fullWidth())
        }
    }
    private fun editNote(id: String?) {
        val notes = readNotes()
        val old = notes.firstOrNull { it.id == id }
        currentNoteId = id ?: System.currentTimeMillis().toString()
        val r = base("✎")
        val title = input("Judul")
        title.setText(old?.title.orEmpty())
        r.addView(title, fullWidth())
        val body = input("Catatan belajar…", true)
        body.setText(old?.body.orEmpty())
        r.addView(body, fullWidth())
        button(r, "Simpan") {
            val all = readNotes().filterNot { it.id == currentNoteId }.toMutableList()
            all.add(Note(currentNoteId!!, title.text.toString().trim().ifBlank { "Catatan" }, body.text.toString(), System.currentTimeMillis()))
            writeNotes(all); Toast.makeText(this, "Tersimpan di perangkat", Toast.LENGTH_SHORT).show(); notes()
        }
        if (old != null) button(r, "Hapus") { writeNotes(readNotes().filterNot { it.id == old.id }); notes() }
    }

    private fun converter() {
        val r = base("⇄")
        val categories = listOf("Panjang", "Massa", "Waktu", "Volume", "Suhu")
        val category = Spinner(this).apply { adapter = ArrayAdapter(this@ToolsActivity, android.R.layout.simple_spinner_dropdown_item, categories) }
        val amount = input("Nilai")
        val from = Spinner(this); val to = Spinner(this)
        val result = label("—", 24f).apply { setPadding(0, dp(16), 0, dp(16)) }
        fun loadUnits() {
            val units = when (categories[category.selectedItemPosition]) {
                "Panjang" -> listOf("m", "km", "cm", "mm", "inci", "kaki")
                "Massa" -> listOf("kg", "g", "mg", "lb")
                "Waktu" -> listOf("detik", "menit", "jam", "hari")
                "Volume" -> listOf("L", "mL", "m³")
                else -> listOf("°C", "°F", "K")
            }
            from.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, units)
            to.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, units)
            if (units.size > 1) to.setSelection(1)
            result.text = "—"
        }
        r.addView(category, fullWidth()); r.addView(amount, fullWidth()); r.addView(label("Dari")); r.addView(from, fullWidth()); r.addView(label("Ke")); r.addView(to, fullWidth()); r.addView(result)
        category.onItemSelectedListener = simpleListener { loadUnits() }
        loadUnits()
        button(r, "Konversi") {
            val n = amount.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (n == null || !n.isFinite()) { result.text = "Masukkan angka yang valid"; return@button }
            try { result.text = DecimalFormat("0.##########").format(convertValue(n, categories[category.selectedItemPosition], from.selectedItem.toString(), to.selectedItem.toString())) }
            catch (_: Exception) { result.text = "Unit tidak didukung" }
        }
    }
    private fun convertValue(n: Double, category: String, from: String, to: String): Double {
        if (from == to) return n
        if (category == "Suhu") {
            val c = when (from) { "°C" -> n; "°F" -> (n - 32) * 5 / 9; "K" -> n - 273.15; else -> n }
            return when (to) { "°C" -> c; "°F" -> c * 9 / 5 + 32; "K" -> c + 273.15; else -> c }
        }
        val factor = when (category) {
            "Panjang" -> mapOf("m" to 1.0, "km" to 1000.0, "cm" to .01, "mm" to .001, "inci" to .0254, "kaki" to .3048)
            "Massa" -> mapOf("kg" to 1.0, "g" to .001, "mg" to .000001, "lb" to .45359237)
            "Waktu" -> mapOf("detik" to 1.0, "menit" to 60.0, "jam" to 3600.0, "hari" to 86400.0)
            else -> mapOf("L" to 1.0, "mL" to .001, "m³" to 1000.0)
        }
        return n * (factor[from] ?: error("from")) / (factor[to] ?: error("to"))
    }
    private fun simpleListener(action: () -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action()
    }

    private data class Ref(val subject: String, val title: String, val formula: String)
    private val reference = listOf(
        Ref("Matematika", "Luas persegi", "L = s²"), Ref("Matematika", "Luas persegi panjang", "L = p × l"), Ref("Matematika", "Luas segitiga", "L = ½ × alas × tinggi"),
        Ref("Matematika", "Luas lingkaran", "L = πr²"), Ref("Matematika", "Keliling lingkaran", "K = 2πr"), Ref("Matematika", "Pythagoras", "c² = a² + b²"),
        Ref("Matematika", "Persen", "persen = (bagian / total) × 100%"), Ref("Matematika", "Kecepatan", "v = s / t"), Ref("Matematika", "Persamaan garis", "y = mx + c"),
        Ref("Fisika", "Gaya", "F = m × a"), Ref("Fisika", "Berat", "w = m × g"), Ref("Fisika", "Usaha", "W = F × s"), Ref("Fisika", "Daya", "P = W / t"),
        Ref("Fisika", "Massa jenis", "ρ = m / V"), Ref("Fisika", "Tekanan", "p = F / A"), Ref("Fisika", "Energi kinetik", "Ek = ½mv²"), Ref("Fisika", "Energi potensial", "Ep = mgh"),
        Ref("Fisika", "Hukum Ohm", "V = I × R"), Ref("Fisika", "Kalor", "Q = m × c × ΔT"), Ref("Kimia", "Mol", "n = massa / Mr"),
        Ref("Kimia", "Konsentrasi molar", "M = mol zat terlarut / volume (L)"), Ref("Kimia", "pH", "pH = −log[H⁺]"),
        Ref("Ekonomi", "Keuntungan", "untung = harga jual − harga beli"), Ref("Ekonomi", "Bunga sederhana", "I = P × r × t"),
        Ref("Statistika", "Rata-rata", "mean = jumlah data / banyak data"), Ref("Statistika", "Peluang", "P(A) = kejadian yang diinginkan / seluruh kemungkinan")
    )
    private fun formulas() {
        val r = base("√")
        val search = input("Cari rumus")
        r.addView(search, fullWidth())
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(list, fullWidth())
        fun render(query: String) {
            list.removeAllViews()
            reference.filter { (it.title + " " + it.subject + " " + it.formula).contains(query, true) }.forEach { item ->
                list.addView(label(item.subject.uppercase(), 10f, Color.GRAY).apply { setPadding(2, dp(9), 2, 0) })
                list.addView(label(item.title, 15f).apply { setPadding(2, dp(3), 2, 0) })
                list.addView(label(item.formula, 17f, Color.rgb(190,230,210)).apply { setPadding(2, dp(2), 2, dp(7)) })
                val line = View(this).apply { setBackgroundColor(Color.rgb(46,46,46)) }
                list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
            }
        }
        search.addTextChangedListener(SimpleTextWatcher { render(it) })
        render("")
    }

    private data class Element(val z: Int, val symbol: String, val name: String, val mass: String)
    private val elementsData = listOf(
        Element(1,"H","Hidrogen","1.008"),Element(2,"He","Helium","4.003"),Element(3,"Li","Litium","6.94"),Element(4,"Be","Berilium","9.012"),Element(5,"B","Boron","10.81"),Element(6,"C","Karbon","12.011"),Element(7,"N","Nitrogen","14.007"),Element(8,"O","Oksigen","15.999"),Element(9,"F","Fluorin","18.998"),Element(10,"Ne","Neon","20.180"),
        Element(11,"Na","Natrium","22.990"),Element(12,"Mg","Magnesium","24.305"),Element(13,"Al","Aluminium","26.982"),Element(14,"Si","Silikon","28.085"),Element(15,"P","Fosfor","30.974"),Element(16,"S","Sulfur","32.06"),Element(17,"Cl","Klor","35.45"),Element(18,"Ar","Argon","39.948"),Element(19,"K","Kalium","39.098"),Element(20,"Ca","Kalsium","40.078"),
        Element(21,"Sc","Skandium","44.956"),Element(22,"Ti","Titanium","47.867"),Element(23,"V","Vanadium","50.942"),Element(24,"Cr","Kromium","51.996"),Element(25,"Mn","Mangan","54.938"),Element(26,"Fe","Besi","55.845"),Element(27,"Co","Kobalt","58.933"),Element(28,"Ni","Nikel","58.693"),Element(29,"Cu","Tembaga","63.546"),Element(30,"Zn","Seng","65.38"),Element(35,"Br","Bromin","79.904"),Element(47,"Ag","Perak","107.868"),Element(50,"Sn","Timah","118.710"),Element(53,"I","Iodin","126.904"),Element(79,"Au","Emas","196.967"),Element(80,"Hg","Raksa","200.592"),Element(82,"Pb","Timbal","207.2"),Element(92,"U","Uranium","238.029")
    )
    private fun elements() {
        val r = base("⚛")
        val search = input("Cari unsur / simbol")
        r.addView(search, fullWidth())
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(list, fullWidth())
        fun render(query: String) {
            list.removeAllViews()
            elementsData.filter { (it.name + it.symbol + it.z.toString()).contains(query, true) }.forEach { e ->
                list.addView(label("${e.z}   ${e.symbol}   ${e.name}     ${e.mass}", 14f).apply { setPadding(dp(10), dp(10), dp(10), dp(10)); setBackgroundColor(Color.rgb(26,26,26)) }, fullWidth())
            }
        }
        search.addTextChangedListener(SimpleTextWatcher { render(it) }); render("")
    }

    private fun timerTool() {
        val r = base("◷")
        val minutes = input("Durasi menit", false).apply { setText("25"); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        r.addView(minutes, fullWidth())
        val display = label("25:00", 36f).apply { gravity = Gravity.CENTER; setPadding(0, dp(30), 0, dp(30)) }
        timerDisplay = display; r.addView(display, fullWidth())
        button(r, "Mulai / Jeda") {
            if (timerRunning) { timer?.cancel(); timerRunning = false }
            else {
                if (timerRemainingMs <= 0L || display.text == "25:00") {
                    val mins = minutes.text.toString().toLongOrNull()?.coerceIn(1, 180) ?: 25L
                    timerRemainingMs = mins * 60_000L
                }
                timerRunning = true
                timer = object : CountDownTimer(timerRemainingMs, 1000L) {
                    override fun onTick(ms: Long) { timerRemainingMs = ms; display.text = formatTime(ms) }
                    override fun onFinish() { timerRunning = false; timerRemainingMs = 0; display.text = "00:00"; Toast.makeText(this@ToolsActivity, "Waktu selesai", Toast.LENGTH_LONG).show() }
                }.start()
            }
        }
        button(r, "Reset") { timer?.cancel(); timerRunning = false; val mins = minutes.text.toString().toLongOrNull()?.coerceIn(1,180) ?: 25L; timerRemainingMs = mins*60_000L; display.text = formatTime(timerRemainingMs) }
    }
    private fun formatTime(ms: Long): String { val total = (ms / 1000L).coerceAtLeast(0); return String.format("%02d:%02d", total / 60L, total % 60L) }

    private class SimpleTextWatcher(private val changed: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: android.text.Editable?) = Unit
    }
}

private object SafeCalculator {
    fun eval(source: String): Double {
        val cleaned = source.trim().replace('×', '*').replace('÷', '/').replace('−', '-').replace(',', '.')
        require(cleaned.isNotBlank() && cleaned.length <= 160)
        val parser = Parser(cleaned)
        val result = parser.expression()
        parser.skip()
        require(parser.i == cleaned.length && result.isFinite())
        return result
    }
    private class Parser(private val s: String) {
        var i = 0
        fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun expression(): Double { var v = term(); while (true) { skip(); if (i >= s.length) return v; when (s[i]) { '+' -> { i++; v += term() }; '-' -> { i++; v -= term() }; else -> return v } } }
        fun term(): Double { var v = factor(); while (true) { skip(); if (i >= s.length) return v; when (s[i]) { '*', '×' -> { i++; v *= factor() }; '/', '÷' -> { i++; val d = factor(); require(d != 0.0); v /= d }; else -> return v } } }
        fun factor(): Double {
            skip()
            if (i < s.length && (s[i] == '+' || s[i] == '-')) { val sign = s[i++]; val n = factor(); return if (sign == '-') -n else n }
            var v = primary()
            skip()
            if (i < s.length && s[i] == '^') { i++; v = v.pow(factor()) }
            skip()
            if (i < s.length && s[i] == '%') { i++; v /= 100.0 }
            require(v.isFinite())
            return v
        }
        private fun primary(): Double {
            skip()
            if (s.startsWith("sqrt(", i, true)) { i += 5; val n = expression(); skip(); require(i < s.length && s[i] == ')'); i++; require(n >= 0); return sqrt(n) }
            if (i < s.length && s[i] == '√') { i++; return sqrt(factor()) }
            if (i < s.length && s[i] == '(') { i++; val n = expression(); skip(); require(i < s.length && s[i] == ')'); i++; return n }
            if (s.startsWith("pi", i, true) || (i < s.length && s[i] == 'π')) { if (s[i] == 'π') i++ else i += 2; return Math.PI }
            if (i < s.length && s[i].equals('e', true)) { i++; return Math.E }
            val start = i
            var dot = false
            while (i < s.length && (s[i].isDigit() || (s[i] == '.' && !dot))) { if (s[i] == '.') dot = true; i++ }
            require(i > start)
            return s.substring(start, i).toDouble()
        }
    }
}
