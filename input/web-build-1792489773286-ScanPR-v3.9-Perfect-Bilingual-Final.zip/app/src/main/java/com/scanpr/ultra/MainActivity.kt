// File: app/src/main/java/com/scanpr/ultra/MainActivity.kt
package com.scanpr.ultra

import android.Manifest
import android.content.Intent
import android.net.Uri as AndroidUri
import android.provider.Settings
import android.view.MotionEvent
import androidx.appcompat.app.AlertDialog
import android.speech.RecognizerIntent
import android.view.inputmethod.EditorInfo
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.view.PreviewView
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageContractOptions
import com.canhub.cropper.CropImageOptions
import com.canhub.cropper.CropImageView.Guidelines
import com.scanpr.ultra.databinding.ActivityMainBinding
import com.scanpr.ultra.utils.AiKeyStore
import com.scanpr.ultra.utils.NetworkUtils
import com.scanpr.ultra.utils.PermissionUtils
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null
    private var activeCamera: Camera? = null
    private var cameraStarting = false
    private var torchOn = false
    private var cameraPermissionWasFirstRequest = false
    private var callbackRegistered = false
    private val mainViewModel: MainViewModel by viewModels()
    private val connectivityManager by lazy { getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = runOnUiThread { updateNetworkStatus() }
        override fun onLost(network: Network) = runOnUiThread { updateNetworkStatus() }
        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) = runOnUiThread { updateNetworkStatus() }
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            binding.cameraStatusMessage.visibility = android.view.View.GONE
            startCamera()
        } else {
            binding.cameraStatusMessage.visibility = android.view.View.VISIBLE
            binding.cameraStatusMessage.text = "Izin kamera belum diberikan\nKamu tetap bisa memilih gambar dari galeri."
            showCameraPermissionHelp()
        }
    }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) launchCrop(uri) }
    private val speechInput = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) binding.questionInput.setText(spoken)
        }
    }
    private val cropImage = registerForActivityResult(CropImageContract()) { result ->
        if (result.isSuccessful) {
            val croppedUri = result.uriContent
            if (croppedUri != null) processCroppedImage(croppedUri)
            else Toast.makeText(this, "Gambar hasil crop tidak ditemukan. Coba pilih gambar lagi.", Toast.LENGTH_LONG).show()
        } else if (result.error != null) {
            Toast.makeText(this, "Gagal memotong gambar: ${result.error?.localizedMessage ?: "coba ulangi"}", Toast.LENGTH_LONG).show()
        }
        // If the user presses Cancel, remain on the camera screen without starting OCR.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        binding.previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        binding.shutterOuter.setOnClickListener { capture() }
        binding.galleryButton.setOnClickListener { pickImage.launch("image/*") }
        binding.flashButton.setOnClickListener { toggleTorch() }
        binding.previewView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) focusAt(event.x, event.y)
            true
        }
        binding.sendQuestionButton.setOnClickListener { submitTypedQuestion() }
        binding.questionInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitTypedQuestion(); true } else false
        }
        binding.voiceInputButton.setOnClickListener { startVoiceInput() }
        binding.historyButton.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        binding.chatButton.setOnClickListener { startActivity(Intent(this, ChatActivity::class.java)) }
        binding.settingsButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.toolsButton.setOnClickListener { startActivity(Intent(this, ToolsActivity::class.java)) }
        updateNetworkStatus()
        // Ask on first launch so scanning is ready without requiring the user to tap the shutter first.
        if (PermissionUtils.hasCamera(this)) {
            startCamera()
        } else {
            requestCameraAccess()
        }
    }

    override fun onStart() {
        super.onStart()
        if (!callbackRegistered) {
            runCatching {
                connectivityManager.registerDefaultNetworkCallback(networkCallback)
                callbackRegistered = true
            }
        }
        updateNetworkStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && PermissionUtils.hasCamera(this) && activeCamera == null && !cameraStarting) {
            startCamera()
        }
    }

    override fun onStop() {
        if (callbackRegistered) {
            runCatching { connectivityManager.unregisterNetworkCallback(networkCallback) }
            callbackRegistered = false
        }
        // Do not leave the torch on when the app moves to the background/crop editor.
        setTorch(false, notify = false)
        super.onStop()
    }

    private fun updateNetworkStatus() {
        if (!::binding.isInitialized) return
        val online = NetworkUtils.isOnline(this)
        if (!online) {
            binding.networkStatusChip.text = "OFFLINE · AI membutuhkan internet"
            binding.networkStatusChip.contentDescription = binding.networkStatusChip.text
            return
        }
        binding.networkStatusChip.text = "ONLINE · Memeriksa konfigurasi AI…"
        binding.networkStatusChip.contentDescription = binding.networkStatusChip.text
        // Credential-store initialization can touch Android Keystore, so do it off the UI thread.
        lifecycleScope.launch {
            val hasKeys = withContext(Dispatchers.IO) { AiKeyStore.hasAnyKey(this@MainActivity) }
            if (NetworkUtils.isOnline(this@MainActivity) && ::binding.isInitialized) {
                binding.networkStatusChip.text = if (hasKeys) {
                    "ONLINE · AI siap dicoba"
                } else {
                    "ONLINE · Atur API AI di Pengaturan"
                }
                binding.networkStatusChip.contentDescription = binding.networkStatusChip.text
            }
        }
    }

    private fun submitTypedQuestion() {
        val question = binding.questionInput.text?.toString()?.trim().orEmpty()
        if (question.isBlank()) {
            Toast.makeText(this, "Ketik soal terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, ResultActivity::class.java).putExtra(ResultActivity.EXTRA_OCR, question)
        startActivity(intent)
        binding.questionInput.setText("")
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan soal atau pertanyaan")
        runCatching { speechInput.launch(intent) }.onFailure {
            Toast.makeText(this, "Input suara tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show()
        }
    }

    private fun startCamera() {
        if (cameraStarting || !PermissionUtils.hasCamera(this)) return
        cameraStarting = true
        binding.cameraStatusMessage.visibility = android.view.View.VISIBLE
        binding.cameraStatusMessage.text = "Menyiapkan kamera…"
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraStarting = false
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setFlashMode(ImageCapture.FLASH_MODE_OFF)
                    .build()
                provider.unbindAll()
                activeCamera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                imageCapture = capture
                binding.cameraStatusMessage.visibility = android.view.View.GONE
                updateFlashButton()
            }.onFailure {
                activeCamera = null
                imageCapture = null
                binding.cameraStatusMessage.visibility = android.view.View.VISIBLE
                binding.cameraStatusMessage.text = "Kamera tidak bisa dibuka\nPeriksa izin atau tutup aplikasi kamera lain."
                updateFlashButton()
                Toast.makeText(this, "Kamera tidak dapat dibuka: ${it.localizedMessage ?: "error"}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun requestCameraAccess() {
        val prefs = getSharedPreferences("scanpr_permissions", MODE_PRIVATE)
        val alreadyRequested = prefs.getBoolean("camera_permission_requested", false)
        cameraPermissionWasFirstRequest = !alreadyRequested
        prefs.edit().putBoolean("camera_permission_requested", true).apply()
        cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun showCameraPermissionHelp() {
        val permanentlyDenied = !cameraPermissionWasFirstRequest && !shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
        AlertDialog.Builder(this)
            .setTitle("Izin kamera diperlukan")
            .setMessage("Izinkan kamera agar bisa memotret soal langsung. Kamu masih dapat memakai tombol galeri atau mengetik soal.")
            .setPositiveButton(if (permanentlyDenied) "Buka pengaturan" else "Coba lagi") { _, _ ->
                if (permanentlyDenied) {
                    val settingsIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, AndroidUri.parse("package:$packageName"))
                    runCatching { startActivity(settingsIntent) }.onFailure {
                        Toast.makeText(this, "Buka Pengaturan Android → Aplikasi → Scan PR → Izin.", Toast.LENGTH_LONG).show()
                    }
                } else {
                    requestCameraAccess()
                }
            }
            .setNegativeButton("Nanti / galeri", null)
            .show()
    }

    private fun toggleTorch() {
        val camera = activeCamera
        if (camera == null) {
            if (!PermissionUtils.hasCamera(this)) requestCameraAccess()
            else Toast.makeText(this, "Kamera belum siap. Tunggu sebentar lalu coba lagi.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!camera.cameraInfo.hasFlashUnit()) {
            Toast.makeText(this, "Flashlight tidak tersedia pada kamera perangkat ini.", Toast.LENGTH_SHORT).show()
            updateFlashButton()
            return
        }
        setTorch(!torchOn, notify = true)
    }

    private fun setTorch(enabled: Boolean, notify: Boolean) {
        val camera = activeCamera
        if (camera == null || !camera.cameraInfo.hasFlashUnit()) {
            torchOn = false
            updateFlashButton()
            return
        }
        val torchFuture = camera.cameraControl.enableTorch(enabled)
        torchOn = enabled
        updateFlashButton()
        torchFuture.addListener({
            torchOn = runCatching { torchFuture.get(); enabled }.getOrElse { !enabled }
            updateFlashButton()
        }, ContextCompat.getMainExecutor(this))
        if (notify) Toast.makeText(this, if (enabled) "Flashlight aktif" else "Flashlight mati", Toast.LENGTH_SHORT).show()
    }

    private fun updateFlashButton() {
        if (!::binding.isInitialized) return
        val hasFlash = activeCamera?.cameraInfo?.hasFlashUnit() == true
        binding.flashButton.isEnabled = hasFlash || !PermissionUtils.hasCamera(this)
        // Minimal icon-only toggle; accessible description still explains its state.
        binding.flashButton.text = ""
        binding.flashButton.contentDescription = when {
            !hasFlash && activeCamera != null -> "Flashlight tidak tersedia"
            torchOn -> "Matikan flashlight"
            else -> "Nyalakan flashlight"
        }
        binding.flashButton.alpha = if (hasFlash || !PermissionUtils.hasCamera(this)) 1f else 0.65f
    }

    private fun focusAt(x: Float, y: Float) {
        val camera = activeCamera ?: return
        val factory = binding.previewView.meteringPointFactory
        val point = factory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        runCatching { camera.cameraControl.startFocusAndMetering(action) }
        val ring = binding.focusIndicator
        ring.animate().cancel()
        ring.alpha = 1f
        ring.visibility = android.view.View.VISIBLE
        ring.post {
            ring.x = (x - ring.width / 2f).coerceIn(0f, (binding.root.width - ring.width).toFloat())
            ring.y = (y - ring.height / 2f).coerceIn(0f, (binding.root.height - ring.height).toFloat())
            ring.animate().alpha(0f).setStartDelay(500L).setDuration(350L).withEndAction {
                ring.visibility = android.view.View.GONE
                ring.alpha = 1f
            }.start()
        }
    }

    private fun capture() {
        if (!PermissionUtils.hasCamera(this)) { requestCameraAccess(); return }
        val capture = imageCapture ?: run { Toast.makeText(this, "Kamera sedang disiapkan. Coba lagi sebentar.", Toast.LENGTH_SHORT).show(); startCamera(); return }
        val dir = File(cacheDir, "scans").apply { mkdirs() }
        val file = File(dir, "scan_${System.currentTimeMillis()}.jpg")
        binding.cameraProgress.visibility = android.view.View.VISIBLE
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                binding.cameraProgress.visibility = android.view.View.GONE
                launchCrop(Uri.fromFile(file))
            }
            override fun onError(exception: ImageCaptureException) {
                binding.cameraProgress.visibility = android.view.View.GONE
                Toast.makeText(this@MainActivity, "Gagal memotret: ${exception.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    /** Both captured and gallery images go through crop selection before OCR. */
    private fun launchCrop(uri: Uri) {
        runCatching {
            cropImage.launch(
                CropImageContractOptions(
                    uri = uri,
                    cropImageOptions = CropImageOptions().apply {
                        guidelines = Guidelines.ON
                        activityTitle = "Pilih bagian soal"
                        cropMenuCropButtonTitle = "Pakai foto"
                        cropMenuCropButtonIcon = R.drawable.ic_crop_done
                        activityMenuIconColor = ContextCompat.getColor(this@MainActivity, R.color.white)
                        outputCompressFormat = Bitmap.CompressFormat.JPEG
                        outputCompressQuality = 92
                    }
                )
            )
        }.onFailure {
            Toast.makeText(this, "Editor crop tidak dapat dibuka: ${it.localizedMessage ?: "error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun processCroppedImage(uri: Uri) {
        binding.cameraProgress.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val text = runCatching { mainViewModel.recognize(this@MainActivity, uri) }.getOrDefault("")
            binding.cameraProgress.visibility = android.view.View.GONE
            startActivity(
                Intent(this@MainActivity, ResultActivity::class.java)
                    .putExtra(ResultActivity.EXTRA_OCR, text)
                    .putExtra(ResultActivity.EXTRA_IMAGE_URI, uri.toString())
            )
        }
    }
}
