package com.scanpr.ultra

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.scanpr.ultra.databinding.ActivitySettingsBinding
import com.scanpr.ultra.utils.AiKeyStore
import com.scanpr.ultra.utils.AiPreferences
import com.scanpr.ultra.utils.GeminiApi
import com.scanpr.ultra.utils.NetworkUtils
import com.scanpr.ultra.utils.OpenAiCompatibleApi
import com.scanpr.ultra.utils.OpenRouterApi
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.utils.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private var updating = false
    private var loadingModelCatalog = false
    private val providerValues = listOf(AiPreferences.AUTO, AiPreferences.GEMINI, AiPreferences.OPENROUTER, AiPreferences.GROQ, AiPreferences.CEREBRAS)
    private var modelValues: List<String> = listOf(AiPreferences.MODEL_AUTO)

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.settingsToolbar.setNavigationOnClickListener { finish() }

        lifecycleScope.launch {
            val mode = ThemeManager.getMode(this@SettingsActivity).first()
            updating = true
            binding.themeRadioGroup.check(when (mode) { ThemeMode.LIGHT -> R.id.radio_light; ThemeMode.DARK -> R.id.radio_dark; ThemeMode.SYSTEM -> R.id.radio_system })
            updating = false
        }
        binding.themeRadioGroup.setOnCheckedChangeListener { _, checked ->
            if (updating || checked == -1) return@setOnCheckedChangeListener
            val mode = when (checked) { R.id.radio_light -> ThemeMode.LIGHT; R.id.radio_dark -> ThemeMode.DARK; else -> ThemeMode.SYSTEM }
            lifecycleScope.launch { ThemeManager.saveMode(this@SettingsActivity, mode); ThemeManager.applyTheme(mode); recreate() }
        }
        val priorityLabels = listOf("Auto · AI gratis", "Gemini · free tier", "OpenRouter · model gratis", "Groq · kuota akun; cek biaya", "Cerebras · teks; cek biaya")
        binding.aiProviderPrioritySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, priorityLabels)
        val initialPriority = AiPreferences.getPriority(this)
        binding.aiProviderPrioritySpinner.setSelection(providerValues.indexOf(initialPriority).coerceAtLeast(0), false)
        binding.aiProviderPrioritySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (loadingModelCatalog) return
                AiPreferences.setPriority(this@SettingsActivity, providerValues[position])
                loadModelCatalog(showStatus = false)
            }
        }
        binding.aiModelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (loadingModelCatalog || modelValues.isEmpty()) return
                val provider = selectedProvider()
                if (provider != AiPreferences.AUTO && position in modelValues.indices) {
                    AiPreferences.setSelectedModel(this@SettingsActivity, provider, modelValues[position])
                }
            }
        }
        binding.refreshModelsButton.setOnClickListener { loadModelCatalog(showStatus = true) }
        lifecycleScope.launch {
            val keys = withContext(Dispatchers.IO) {
                listOf(AiKeyStore.geminiKey(this@SettingsActivity), AiKeyStore.openRouterKey(this@SettingsActivity), AiKeyStore.groqKey(this@SettingsActivity), AiKeyStore.cerebrasKey(this@SettingsActivity))
            }
            binding.editGeminiKey.setText(keys[0]); binding.editOpenrouterKey.setText(keys[1]); binding.editGroqKey.setText(keys[2]); binding.editCerebrasKey.setText(keys[3])
        }
        binding.saveAiKeysButton.setOnClickListener { saveKeys() }
        binding.testAiKeysButton.setOnClickListener { testProviders() }
        loadModelCatalog(showStatus = false)
    }

    private fun selectedProvider(): String = providerValues.getOrElse(binding.aiProviderPrioritySpinner.selectedItemPosition) { AiPreferences.AUTO }

    private fun loadModelCatalog(showStatus: Boolean) {
        if (!NetworkUtils.isOnline(this)) {
            setModelOptions(listOf(AiPreferences.MODEL_AUTO), listOf("Auto · hubungkan internet untuk daftar model"))
            if (showStatus) showStatus("Daftar model memerlukan internet.")
            return
        }
        loadingModelCatalog = true
        binding.refreshModelsButton.isEnabled = false
        if (showStatus) showStatus("Memuat model aktif…")
        val provider = selectedProvider()
        lifecycleScope.launch {
            val discovered = withContext(Dispatchers.IO) {
                runCatching {
                    when (provider) {
                        AiPreferences.AUTO -> listOf(AiPreferences.MODEL_AUTO)
                        AiPreferences.GEMINI -> {
                            val key = AiKeyStore.geminiKey(this@SettingsActivity)
                            if (key.isBlank()) emptyList() else GeminiApi().listModels(key)
                        }
                        AiPreferences.OPENROUTER -> {
                            val key = AiKeyStore.openRouterKey(this@SettingsActivity)
                            if (key.isBlank()) emptyList() else listOf("openrouter/free") + OpenRouterApi().listFreeVisionModels(key)
                        }
                        AiPreferences.GROQ -> {
                            val key = AiKeyStore.groqKey(this@SettingsActivity)
                            if (key.isBlank()) emptyList() else OpenAiCompatibleApi("https://api.groq.com/openai/v1").listModels(key).sorted()
                        }
                        AiPreferences.CEREBRAS -> {
                            val key = AiKeyStore.cerebrasKey(this@SettingsActivity)
                            if (key.isBlank()) emptyList() else OpenAiCompatibleApi("https://api.cerebras.ai/v1").listModels(key).sorted()
                        }
                        else -> emptyList()
                    }
                }.getOrDefault(emptyList())
            }
            val valid = if (provider == AiPreferences.AUTO) listOf(AiPreferences.MODEL_AUTO) else discovered.distinct()
            val values = if (provider == AiPreferences.AUTO) listOf(AiPreferences.MODEL_AUTO) else listOf(AiPreferences.MODEL_AUTO) + valid
            val labels = if (provider == AiPreferences.AUTO) listOf("Otomatis · pilih AI gratis yang tersedia") else listOf("Otomatis · model tersedia") + valid
            val saved = AiPreferences.getSelectedModel(this@SettingsActivity, provider)
            setModelOptions(values, labels, saved) 
            loadingModelCatalog = false
            binding.refreshModelsButton.isEnabled = true
            if (showStatus) showStatus(if (valid.isEmpty()) "Tidak ada model ditemukan. Periksa API key provider." else "${valid.size} model ditemukan. Pilih model dari daftar.")
        }
    }

    private fun setModelOptions(values: List<String>, labels: List<String>, savedModel: String? = null) {
        loadingModelCatalog = true
        modelValues = values
        binding.aiModelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val selectedIndex = savedModel?.let { values.indexOf(it) }?.takeIf { it >= 0 } ?: 0
        binding.aiModelSpinner.setSelection(selectedIndex, false)
        binding.aiModelSpinner.isEnabled = selectedProvider() != AiPreferences.AUTO && values.size > 1
        loadingModelCatalog = false
    }

    private fun showStatus(message: String) {
        binding.aiKeysStatus.visibility = View.VISIBLE
        binding.aiKeysStatus.text = message
    }

    private fun saveKeys() {
        val gemini = binding.editGeminiKey.text?.toString().orEmpty()
        val openRouter = binding.editOpenrouterKey.text?.toString().orEmpty()
        val groq = binding.editGroqKey.text?.toString().orEmpty()
        val cerebras = binding.editCerebrasKey.text?.toString().orEmpty()
        binding.saveAiKeysButton.isEnabled = false
        showStatus("Menyimpan kunci secara terenkripsi…")
        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) { runCatching { AiKeyStore.save(this@SettingsActivity, gemini, openRouter, groq, cerebras) } }
            binding.saveAiKeysButton.isEnabled = true
            showStatus(if (saved.isSuccess) {
                if (listOf(gemini, openRouter, groq, cerebras).all { it.isBlank() }) "API key kosong. AI online belum dikonfigurasi; alat offline tetap tersedia." else "Kunci tersimpan. Muat daftar model aktif atau tes koneksi."
            } else "Gagal menyimpan kunci terenkripsi. Periksa dukungan keamanan perangkat dan coba lagi.")
            loadModelCatalog(showStatus = false)
        }
    }

    private fun testProviders() {
        binding.testAiKeysButton.isEnabled = false
        showStatus(if (NetworkUtils.isOnline(this)) "Memeriksa provider dan katalog model…" else "Perangkat offline. Hubungkan internet untuk menguji API.")
        if (!NetworkUtils.isOnline(this)) { binding.testAiKeysButton.isEnabled = true; return }
        lifecycleScope.launch {
            val report = withContext(Dispatchers.IO) {
                val lines = mutableListOf<String>()
                val g = AiKeyStore.geminiKey(this@SettingsActivity)
                if (g.isNotBlank()) lines.add("Gemini vision/free-tier: ${runCatching { GeminiApi().listModels(g).size }.getOrDefault(0)} model")
                val gr = AiKeyStore.groqKey(this@SettingsActivity)
                if (gr.isNotBlank()) {
                    val models = runCatching { OpenAiCompatibleApi("https://api.groq.com/openai/v1").listModels(gr) }.getOrDefault(emptyList())
                    lines.add("Groq: ${models.size} model; vision Qwen tersedia: ${models.any { it == "qwen/qwen3.8-27b" }}")
                }
                val ce = AiKeyStore.cerebrasKey(this@SettingsActivity)
                if (ce.isNotBlank()) lines.add("Cerebras: ${runCatching { OpenAiCompatibleApi("https://api.cerebras.ai/v1").listModels(ce).size }.getOrDefault(0)} model; teks saja untuk jalur ini")
                val o = AiKeyStore.openRouterKey(this@SettingsActivity)
                if (o.isNotBlank()) {
                    val api = OpenRouterApi()
                    val free = runCatching { api.listFreeModels(o).size }.getOrDefault(0)
                    val vision = runCatching { api.listFreeVisionModels(o).size }.getOrDefault(0)
                    lines.add("OpenRouter: $free model gratis, $vision model gratis vision + router vision")
                }
                if (lines.isEmpty()) lines.add("Belum ada kunci yang disimpan.")
                lines.joinToString("\n")
            }
            showStatus(report + "\n\nKuota gratis berubah. Provider yang memerlukan billing tidak otomatis gratis; periksa akun sebelum dipakai.")
            binding.testAiKeysButton.isEnabled = true
            loadModelCatalog(showStatus = false)
        }
    }
}
