package com.scanpr.ultra

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.InputType
import android.widget.EditText
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.scanpr.ultra.data.ScanHistory
import com.scanpr.ultra.databinding.ActivityHistoryBinding
import com.scanpr.ultra.repository.ScanRepository
import com.scanpr.ultra.utils.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Date
import java.text.SimpleDateFormat
import java.util.Locale

class HistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryBinding
    private lateinit var repo: ScanRepository
    private val prefs by lazy { getSharedPreferences("scanpr_history_ui", MODE_PRIVATE) }
    private var allItems: List<ScanHistory> = emptyList()
    private var queryText = ""
    private var selectedSubject = "Semua mapel"
    private var selectedFolder = "Semua folder"
    private val defaultFolders = setOf("Sekolah", "PR", "Ujian", "Ulangan")
    private var favoritesOnly = false
    private var updatingSpinner = false
    private val favorites: MutableSet<String> get() = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    private val adapter = HistoryAdapter(
        onClick = { openItem(it) },
        onLongClick = { item -> showItemOptions(item) }
    )
    private val exportDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) exportVisibleItems(uri)
    }
    private val exportPdfDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportVisiblePdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = ScanRepository(this)
        binding.historyToolbar.setNavigationOnClickListener { finish() }
        binding.historyRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.historyRecyclerView.adapter = adapter
        binding.historySearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean { queryText = query.orEmpty(); renderFiltered(); binding.historySearch.clearFocus(); return true }
            override fun onQueryTextChange(newText: String?): Boolean { queryText = newText.orEmpty(); renderFiltered(); return true }
        })
        val subjects = listOf("Semua mapel", "Matematika", "Fisika", "Kimia", "Biologi", "Bahasa Indonesia", "Bahasa Inggris", "Sejarah", "Geografi", "Ekonomi", "PPKn", "Informatika", "Umum")
        binding.historySubjectFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, subjects)
        binding.historySubjectFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!updatingSpinner) { selectedSubject = subjects[position]; renderFiltered() }
            }
        }
        binding.historyFolderFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val value = parent?.getItemAtPosition(position)?.toString() ?: "Semua folder"
                selectedFolder = value
                renderFiltered()
            }
        }
        updateFolderOptions()
        updateFavoriteButton()
        binding.favoritesFilterButton.setOnClickListener { favoritesOnly = !favoritesOnly; updateFavoriteButton(); renderFiltered() }
        binding.exportHistoryButton.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Ekspor riwayat")
                .setItems(arrayOf("Teks (.txt)", "PDF (.pdf)")) { _, which ->
                    if (which == 0) exportDocument.launch("ScanPR-Riwayat.txt") else exportPdfDocument.launch("ScanPR-Riwayat.pdf")
                }.show()
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.observeAll().collect { items -> allItems = items; updateSpinnerOptions(items, subjects); updateFolderOptions(); renderFiltered() }
            }
        }
    }

    private fun updateSpinnerOptions(items: List<ScanHistory>, fixed: List<String>) {
        val available = (fixed.drop(1).filter { it == "Umum" } + items.map { it.mapel }.distinct().filter { it.isNotBlank() }).distinct()
        val options = listOf("Semua mapel") + available
        val selected = if (selectedSubject in options) selectedSubject else "Semua mapel"
        updatingSpinner = true
        binding.historySubjectFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        binding.historySubjectFilter.setSelection(options.indexOf(selected).coerceAtLeast(0), false)
        selectedSubject = selected
        updatingSpinner = false
    }

    private fun folderNames(): MutableSet<String> = (prefs.getStringSet("folder_names", defaultFolders)?.toMutableSet() ?: defaultFolders.toMutableSet())

    private fun folderOf(item: ScanHistory): String = prefs.getString("folder_${item.id}", "Belum difolder") ?: "Belum difolder"

    private fun updateFolderOptions() {
        if (!::binding.isInitialized) return
        val options = listOf("Semua folder", "Belum difolder") + folderNames().filter { it.isNotBlank() }.sorted()
        val selected = if (selectedFolder in options) selectedFolder else "Semua folder"
        val current = binding.historyFolderFilter.adapter
        val currentValues = (0 until (current?.count ?: 0)).map { current?.getItem(it)?.toString().orEmpty() }
        if (currentValues != options) {
            binding.historyFolderFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        }
        val target = options.indexOf(selected).coerceAtLeast(0)
        if (binding.historyFolderFilter.selectedItemPosition != target) binding.historyFolderFilter.setSelection(target, false)
        selectedFolder = selected
    }

    private fun renderFiltered() {
        if (!::binding.isInitialized) return
        val q = queryText.trim().lowercase(Locale.ROOT)
        val fav = favorites
        val visible = allItems.filter { item ->
            val matchesQuery = q.isBlank() || item.ocrText.lowercase(Locale.ROOT).contains(q) || item.answer.lowercase(Locale.ROOT).contains(q) || item.mapel.lowercase(Locale.ROOT).contains(q)
            val matchesSubject = selectedSubject == "Semua mapel" || item.mapel.equals(selectedSubject, ignoreCase = true)
            val matchesFavorite = !favoritesOnly || item.id.toString() in fav
            val matchesFolder = selectedFolder == "Semua folder" || folderOf(item).equals(selectedFolder, ignoreCase = true)
            matchesQuery && matchesSubject && matchesFavorite && matchesFolder
        }
        adapter.submit(visible, fav)
        binding.emptyView.visibility = if (visible.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun updateFavoriteButton() {
        binding.favoritesFilterButton.text = if (favoritesOnly) "Favorit saja" else "Semua riwayat"
    }

    private fun openItem(item: ScanHistory) {
        startActivity(Intent(this, ResultActivity::class.java)
            .putExtra(ResultActivity.EXTRA_OCR, item.ocrText)
            .putExtra(ResultActivity.EXTRA_IMAGE_URI, item.imageUri)
            .putExtra(ResultActivity.EXTRA_ANSWER, item.answer)
            .putExtra(ResultActivity.EXTRA_STEPS, item.stepsJson)
            .putExtra(ResultActivity.EXTRA_MAPEL, item.mapel)
            .putExtra(ResultActivity.EXTRA_MODEL, item.modelUsed)
            .putExtra(ResultActivity.EXTRA_ID, item.id))
    }

    private fun showItemOptions(item: ScanHistory) {
        val currentFavorites = favorites
        val isFav = item.id.toString() in currentFavorites
        val options = arrayOf("Buka hasil", if (isFav) "Hapus dari favorit" else "Tandai favorit", "Pindahkan ke folder…", "Hapus dari riwayat")
        AlertDialog.Builder(this).setTitle(item.mapel.ifBlank { "Soal tersimpan" }).setItems(options) { _, which ->
            when (which) {
                0 -> openItem(item)
                1 -> {
                    val next = favorites
                    if (isFav) next.remove(item.id.toString()) else next.add(item.id.toString())
                    prefs.edit().putStringSet("favorites", next).apply()
                    renderFiltered()
                    Toast.makeText(this, if (isFav) "Dihapus dari favorit." else "Ditandai sebagai favorit.", Toast.LENGTH_SHORT).show()
                }
                2 -> showFolderPicker(item)
                3 -> AlertDialog.Builder(this).setMessage("Hapus soal ini dari riwayat?").setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus") { _, _ -> lifecycleScope.launch { repo.delete(item.id); val next = favorites; next.remove(item.id.toString()); prefs.edit().putStringSet("favorites", next).remove("folder_${item.id}").apply() } }.show()
            }
        }.show()
    }

    private fun showFolderPicker(item: ScanHistory) {
        val names = folderNames().toList().sorted()
        val choices = listOf("Belum difolder") + names + "Buat folder baru…"
        AlertDialog.Builder(this).setTitle("Pindahkan soal")
            .setItems(choices.toTypedArray()) { _, which ->
                if (which == choices.lastIndex) {
                    val input = EditText(this).apply { hint = "Nama folder"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
                    AlertDialog.Builder(this).setTitle("Folder baru").setView(input)
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Simpan") { _, _ ->
                            val name = input.text?.toString()?.trim().orEmpty().take(40)
                            if (name.isBlank() || name.equals("Semua folder", true) || name.equals("Belum difolder", true)) {
                                Toast.makeText(this, "Nama folder tidak valid.", Toast.LENGTH_SHORT).show()
                            } else {
                                val next = folderNames().apply { add(name) }
                                prefs.edit().putStringSet("folder_names", next).putString("folder_${item.id}", name).apply()
                                updateFolderOptions(); renderFiltered()
                            }
                        }.show()
                } else {
                    val folder = choices[which]
                    prefs.edit().putString("folder_${item.id}", folder).apply()
                    renderFiltered()
                    Toast.makeText(this, "Folder diperbarui: $folder", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun exportVisibleItems(uri: Uri) {
        lifecycleScope.launch {
            val text = allItems.filter { item ->
                val q = queryText.trim().lowercase(Locale.ROOT)
                (!favoritesOnly || item.id.toString() in favorites) && (selectedFolder == "Semua folder" || folderOf(item).equals(selectedFolder, true)) && (selectedSubject == "Semua mapel" || item.mapel.equals(selectedSubject, true)) &&
                    (q.isBlank() || item.ocrText.lowercase(Locale.ROOT).contains(q) || item.answer.lowercase(Locale.ROOT).contains(q) || item.mapel.lowercase(Locale.ROOT).contains(q))
            }.joinToString("\n\n----------------------------------------\n\n") { formatHistoryText(it) }
            val result = withContext(Dispatchers.IO) { runCatching { contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: error("Lokasi ekspor tidak dapat dibuka") } }
            Toast.makeText(this@HistoryActivity, if (result.isSuccess) "Riwayat diekspor." else "Gagal mengekspor riwayat.", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportVisiblePdf(uri: Uri) {
        lifecycleScope.launch {
            val visible = allItems.filter { item ->
                val q = queryText.trim().lowercase(Locale.ROOT)
                (!favoritesOnly || item.id.toString() in favorites) &&
                    (selectedFolder == "Semua folder" || folderOf(item).equals(selectedFolder, true)) &&
                    (selectedSubject == "Semua mapel" || item.mapel.equals(selectedSubject, true)) &&
                    (q.isBlank() || item.ocrText.lowercase(Locale.ROOT).contains(q) || item.answer.lowercase(Locale.ROOT).contains(q) || item.mapel.lowercase(Locale.ROOT).contains(q))
            }
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val document = PdfDocument()
                    try {
                    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
                    val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL) }
                    val lines = mutableListOf<String>()
                    lines += "Scan PR Ultra - Riwayat"
                    lines += "Diekspor: ${SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id", "ID")).format(Date())}"
                    lines += "Jumlah soal: ${visible.size}"
                    lines += ""
                    visible.forEachIndexed { i, item ->
                        lines += "${i + 1}. [${item.mapel}] ${item.ocrText.ifBlank { "Soal kosong" }}"
                        lines += "Jawaban: ${item.answer}"
                        lines += "Model: ${item.modelUsed} | Folder: ${folderOf(item)}"
                        val steps = runCatching { val arr = org.json.JSONArray(item.stepsJson); (0 until arr.length()).map { arr.optString(it) } }.getOrDefault(emptyList<String>())
                        steps.forEach { lines += "- $it" }
                        lines += ""
                    }
                    if (visible.isEmpty()) lines += "Tidak ada riwayat yang sesuai dengan filter."
                    val wrapped = mutableListOf<String>()
                    lines.forEach { line ->
                        if (line.isBlank()) { wrapped += ""; return@forEach }
                        var rest = line
                        while (rest.length > 92) {
                            var cut = rest.lastIndexOf(' ', 92)
                            if (cut < 40) cut = 92
                            wrapped += rest.substring(0, cut).trimEnd()
                            rest = rest.substring(cut).trimStart()
                        }
                        wrapped += rest
                    }
                    var pageNumber = 1
                    var page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
                    var y = 42f
                    wrapped.forEachIndexed { lineIndex, line ->
                        val paint = if (lineIndex == 0) titlePaint else bodyPaint
                        val step = if (lineIndex == 0) 24f else 14f
                        if (y > 800f) {
                            document.finishPage(page)
                            pageNumber++
                            page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
                            y = 42f
                        }
                        page.canvas.drawText(line.take(100), 38f, y, paint)
                        y += step
                    }
                    document.finishPage(page)
                    contentResolver.openOutputStream(uri)?.use { document.writeTo(it) } ?: error("Lokasi PDF tidak dapat dibuka")
                    } finally {
                        document.close()
                    }
                }
            }
            Toast.makeText(this@HistoryActivity, if (result.isSuccess) "PDF riwayat berhasil diekspor." else "Gagal mengekspor PDF. Coba lokasi lain.", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatHistoryText(item: ScanHistory): String {
        val date = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id", "ID")).format(Date(item.createdAt))
        val steps = runCatching {
            val array = org.json.JSONArray(item.stepsJson)
            (0 until array.length()).joinToString("\n") { index -> "${index + 1}. ${array.optString(index)}" }
        }.getOrDefault("")
        return "Mata pelajaran: ${item.mapel}\nTanggal: $date\nSoal:\n${item.ocrText}\nJawaban:\n${item.answer}\nModel: ${item.modelUsed}\nLangkah:\n$steps"
    }

    private class HistoryAdapter(
        private val onClick: (ScanHistory) -> Unit,
        private val onLongClick: (ScanHistory) -> Unit
    ) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {
        private var items: List<ScanHistory> = emptyList()
        private var favoriteIds: Set<String> = emptySet()
        fun submit(list: List<ScanHistory>, favorites: Set<String>) { items = list; favoriteIds = favorites; notifyDataSetChanged() }
        class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val question: TextView = view.findViewById(R.id.history_question)
            val answer: TextView = view.findViewById(R.id.history_answer)
            val date: TextView = view.findViewById(R.id.history_date)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = HistoryViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false))
        override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
            val item = items[position]
            holder.question.text = if (item.id.toString() in favoriteIds) "★ ${item.ocrText.ifBlank { "Soal kosong" }}" else item.ocrText.ifBlank { "Soal kosong" }
            holder.answer.text = "${item.mapel} · ${item.answer}"
            holder.date.text = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID")).format(Date(item.createdAt)) + " · tahan untuk opsi"
            holder.itemView.setOnClickListener { onClick(item) }
            holder.itemView.setOnLongClickListener { onLongClick(item); true }
        }
        override fun getItemCount() = items.size
    }
}
