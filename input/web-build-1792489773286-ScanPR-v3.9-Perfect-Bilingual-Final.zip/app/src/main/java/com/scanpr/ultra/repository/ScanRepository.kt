// File: app/src/main/java/com/scanpr/ultra/repository/ScanRepository.kt
package com.scanpr.ultra.repository

import android.content.Context
import com.scanpr.ultra.data.AppDatabase
import com.scanpr.ultra.data.ScanHistory
import kotlinx.coroutines.flow.Flow

class ScanRepository(context: Context) {
    private val dao = AppDatabase.get(context).scanDao()
    fun observeAll(): Flow<List<ScanHistory>> = dao.observeAll()
    fun search(query: String): Flow<List<ScanHistory>> = if (query.isBlank()) dao.observeAll() else dao.search(query)
    suspend fun save(item: ScanHistory): Long = dao.insert(item)
    suspend fun getById(id: Long): ScanHistory? = dao.getById(id)
    suspend fun delete(id: Long) = dao.deleteById(id)
}
