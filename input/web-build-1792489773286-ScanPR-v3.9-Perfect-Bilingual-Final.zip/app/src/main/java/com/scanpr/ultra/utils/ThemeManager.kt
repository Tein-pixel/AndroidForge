// File: app/src/main/java/com/scanpr/ultra/utils/ThemeManager.kt
package com.scanpr.ultra.utils

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

enum class ThemeMode { LIGHT, DARK, SYSTEM }
private val Context.scanPrDataStore by preferencesDataStore(name = "scanpr_settings")

object ThemeManager {
    private val THEME_KEY = stringPreferencesKey("theme_mode")
    fun getMode(context: Context): Flow<ThemeMode> = context.scanPrDataStore.data.map { prefs ->
        runCatching { ThemeMode.valueOf(prefs[THEME_KEY] ?: ThemeMode.SYSTEM.name) }.getOrDefault(ThemeMode.SYSTEM)
    }
    suspend fun saveMode(context: Context, mode: ThemeMode) {
        context.scanPrDataStore.edit { it[THEME_KEY] = mode.name }
    }
    fun applyTheme(mode: ThemeMode) {
        AppCompatDelegate.setDefaultNightMode(when (mode) {
            ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
            ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        })
    }
    fun applySavedTheme(context: Context) {
        val saved: ThemeMode = try { runBlocking { getMode(context).first() } } catch (_: Exception) { ThemeMode.SYSTEM }
        applyTheme(saved)
    }
}
