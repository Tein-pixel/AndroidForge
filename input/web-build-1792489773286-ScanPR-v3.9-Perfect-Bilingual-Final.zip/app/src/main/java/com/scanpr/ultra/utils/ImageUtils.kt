// File: app/src/main/java/com/scanpr/ultra/utils/ImageUtils.kt
package com.scanpr.ultra.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import android.net.Uri
import android.util.Base64
import android.widget.ImageView
import com.bumptech.glide.Glide
import java.io.ByteArrayOutputStream

object ImageUtils {
    data class EncodedImage(val mimeType: String, val base64: String)

    fun show(context: Context, uri: Uri?, target: ImageView) {
        if (uri == null) { target.setImageDrawable(null); return }
        runCatching { Glide.with(context).load(uri).centerCrop().into(target) }
    }

    /**
     * Compresses a cropped image in memory before sending it to a vision-capable API.
     * The image is never written to a new permanent file. Returns null if it cannot be read
     * or remains too large; the caller may then fall back to OCR text only.
     */
    fun encodeForAi(context: Context, uri: Uri): EncodedImage? {
        var bitmap: Bitmap? = null
        return try {
            val resolver = context.contentResolver
            val orientation = runCatching {
                resolver.openInputStream(uri)?.use { stream ->
                    ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sampleSize = 1
            val longestSide = maxOf(bounds.outWidth, bounds.outHeight)
            while (longestSide / sampleSize > 3200) sampleSize *= 2
            val options = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null

            // BitmapFactory ignores EXIF orientation. Normalize it before sending the image to a vision model.
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
                ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(-90f); matrix.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
            }
            if (!matrix.isIdentity()) {
                val source = bitmap!!
                val oriented = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
                if (oriented !== source) { source.recycle(); bitmap = oriented }
            }

            var output = ByteArrayOutputStream()
            bitmap!!.compress(Bitmap.CompressFormat.JPEG, 90, output)
            var bytes = output.toByteArray()
            if (bytes.size > 4 * 1024 * 1024) {
                val old = bitmap!!
                val scale = minOf(1f, 2200f / maxOf(old.width, old.height).coerceAtLeast(1))
                val resized = Bitmap.createScaledBitmap(old,
                    (old.width * scale).toInt().coerceAtLeast(1),
                    (old.height * scale).toInt().coerceAtLeast(1), true)
                if (resized !== old) old.recycle()
                bitmap = resized
                output = ByteArrayOutputStream()
                bitmap!!.compress(Bitmap.CompressFormat.JPEG, 86, output)
                bytes = output.toByteArray()
            }
            if (bytes.isEmpty() || bytes.size > 4 * 1024 * 1024) return null
            EncodedImage("image/jpeg", Base64.encodeToString(bytes, Base64.NO_WRAP))
        } catch (_: Exception) {
            null
        } finally {
            bitmap?.let { if (!it.isRecycled) it.recycle() }
        }
    }
}
