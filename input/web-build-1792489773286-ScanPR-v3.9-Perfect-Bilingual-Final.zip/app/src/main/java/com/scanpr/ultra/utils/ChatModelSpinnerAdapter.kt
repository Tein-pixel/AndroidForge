package com.scanpr.ultra.utils

import android.content.Context
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

/** Accessible high-contrast spinner catalog grouped by provider. Headers are not selectable. */
class ChatModelSpinnerAdapter(
    context: Context,
    choices: List<ChatModelChoice>
) : BaseAdapter() {
    private val appContext = context
    private data class Row(val header: String? = null, val choice: ChatModelChoice? = null, val placeholder: String? = null)
    private val rows: List<Row> = buildList {
        listOf(
            AiPreferences.GEMINI to "Gemini",
            AiPreferences.GROQ to "Groq",
            AiPreferences.OPENROUTER to "OpenRouter"
        ).forEach { (provider, title) ->
            val entries = choices.filter { it.provider == provider }
            add(Row(header = title))
            if (entries.isNotEmpty()) entries.forEach { add(Row(choice = it)) }
            else add(Row(placeholder = "Tambahkan API key di Pengaturan AI"))
        }
    }

    override fun getCount(): Int = rows.size
    override fun getItem(position: Int): Any = rows[position]
    override fun getItemId(position: Int): Long = position.toLong()
    override fun areAllItemsEnabled(): Boolean = false
    override fun isEnabled(position: Int): Boolean = rows.getOrNull(position)?.choice != null

    fun modelAt(position: Int): ChatModelChoice? = rows.getOrNull(position)?.choice
    fun positionForValue(value: String?): Int = rows.indexOfFirst { it.choice?.value == value }.takeIf { it >= 0 } ?: -1
    fun firstVisionPosition(): Int = rows.indexOfFirst { it.choice?.supportsVision == true }.takeIf { it >= 0 } ?: -1
    fun choices(): List<ChatModelChoice> = rows.mapNotNull { it.choice }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val text = (convertView as? TextView) ?: TextView(appContext)
        val model = modelAt(position) ?: choices().firstOrNull()
        text.text = model?.let(::compactLabel) ?: "Pilih model AI"
        text.setTextColor(Color.rgb(28, 28, 30))
        text.textSize = 12f
        text.maxLines = 1
        text.gravity = Gravity.CENTER_VERTICAL
        text.setPadding(dp(8), 0, dp(28), 0)
        text.ellipsize = android.text.TextUtils.TruncateAt.END
        text.background = null
        return text
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = rows[position]
        val text = (convertView as? TextView) ?: TextView(appContext)
        text.gravity = Gravity.CENTER_VERTICAL
        text.maxLines = if (row.header != null) 1 else 2
        text.ellipsize = android.text.TextUtils.TruncateAt.END
        when {
            row.header != null -> {
                text.text = row.header.uppercase()
                text.setTextColor(Color.rgb(90, 90, 96))
                text.textSize = 11f
                text.setTypeface(null, Typeface.BOLD)
                text.setPadding(dp(12), dp(8), dp(12), dp(5))
                text.background = GradientDrawable().apply { setColor(Color.rgb(232, 232, 236)) }
                text.minHeight = dp(32)
            }
            row.placeholder != null -> {
                text.text = row.placeholder
                text.setTextColor(Color.rgb(120, 120, 125))
                text.textSize = 12f
                text.setTypeface(null, Typeface.ITALIC)
                text.setPadding(dp(20), dp(8), dp(12), dp(8))
                text.background = GradientDrawable().apply { setColor(Color.rgb(245, 245, 247)) }
                text.minHeight = dp(40)
            }
            else -> {
                text.text = row.choice?.let { "${it.modelId} · ${if (it.supportsVision) "Foto" else "Teks"}" }.orEmpty()
                text.setTextColor(Color.rgb(28, 28, 30))
                text.textSize = 13f
                text.setTypeface(null, Typeface.NORMAL)
                text.setPadding(dp(20), dp(8), dp(12), dp(8))
                text.background = GradientDrawable().apply { setColor(Color.rgb(250, 250, 252)) }
                text.minHeight = dp(44)
            }
        }
        return text
    }

    private fun compactLabel(choice: ChatModelChoice): String {
        val providerLabel = when (choice.provider) {
            AiPreferences.GEMINI -> "Gemini"
            AiPreferences.GROQ -> "Groq"
            else -> "OpenRouter"
        }
        val status = if (choice.supportsVision) "Foto" else "Teks"
        return "$providerLabel · ${choice.modelId} · $status"
    }

    private fun dp(value: Int): Int = (value * appContext.resources.displayMetrics.density).toInt()
}
