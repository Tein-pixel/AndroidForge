package com.scanpr.ultra

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.abs

/** Small dependency-free Cartesian plotter for y = mx + b. */
class GraphPlotView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0) : View(context, attrs, defStyleAttr) {
    private var m: Double? = null
    private var b: Double? = null
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f }
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3.5f; strokeCap = Paint.Cap.ROUND }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 25f }

    fun setFunction(slope: Double?, intercept: Double?) { m = slope; b = intercept; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        val left = 44f; val top = 28f; val right = w - 24f; val bottom = h - 38f
        if (right <= left || bottom <= top) return
        val plotW = right - left; val plotH = bottom - top
        val unit = minOf(plotW, plotH) / 20f
        val cx = left + plotW / 2f; val cy = top + plotH / 2f
        gridPaint.color = 0x33808080
        axisPaint.color = 0xFF707782.toInt()
        linePaint.color = 0xFF2563EB.toInt()
        textPaint.color = 0xFF6B7280.toInt()
        for (i in -10..10) {
            val x = cx + i * unit; val y = cy - i * unit
            canvas.drawLine(x, top, x, bottom, gridPaint)
            canvas.drawLine(left, y, right, y, gridPaint)
            if (i != 0 && i % 2 == 0) {
                canvas.drawText(i.toString(), x - 8f, cy + 25f, textPaint)
                canvas.drawText(i.toString(), cx + 7f, y + 8f, textPaint)
            }
        }
        canvas.drawLine(left, cy, right, cy, axisPaint)
        canvas.drawLine(cx, top, cx, bottom, axisPaint)
        canvas.drawText("x", right - 16f, cy - 10f, textPaint)
        canvas.drawText("y", cx + 10f, top + 18f, textPaint)
        val slope = m; val intercept = b
        if (slope != null && intercept != null) {
            var previousX: Float? = null; var previousY: Float? = null
            for (i in 0..400) {
                val xv = -10.0 + i / 20.0
                val yv = slope * xv + intercept
                val px = cx + xv.toFloat() * unit
                val py = cy - yv.toFloat() * unit
                val oldX = previousX
                val oldY = previousY
                if (py.isFinite() && oldX != null && oldY != null) canvas.drawLine(oldX, oldY, px, py, linePaint)
                previousX = px; previousY = if (py.isFinite() && abs(py) < 10_000f) py else null
                if (previousY == null) previousX = null
            }
        } else {
            textPaint.textSize = 22f
            val message = "Fungsi linear belum dikenali"
            canvas.drawText(message, maxOf(left, (w - textPaint.measureText(message)) / 2f), h / 2f, textPaint)
        }
    }
}
