package com.scanpr.ultra.utils

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** One normalized conversation turn, shared across all providers. Images stay in memory only. */
data class ChatTurn(
    val role: String, // "user" or "assistant"
    val text: String,
    val image: ImageUtils.EncodedImage? = null
)

data class ChatModelChoice(
    val value: String, // PROVIDER|model-id
    val provider: String,
    val modelId: String,
    val label: String,
    val supportsVision: Boolean
)

object ChatModelPrefs {
    private const val PREFS = "scanpr_chat_model"
    private const val LAST_MODEL = "last_model"
    fun get(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_MODEL, null)
    fun set(context: Context, model: String) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(LAST_MODEL, model).apply()
}

/** API conversation adapter: every request serializes the same normalized history for the selected model. */
class MultiModelChatApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(50, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun send(
        context: Context,
        choice: ChatModelChoice,
        history: List<ChatTurn>,
        userText: String,
        image: ImageUtils.EncodedImage?
    ): AiResult = withTimeoutOrNull(120_000L) {
        if (image != null && !choice.supportsVision) throw IllegalStateException("Model ini tidak mendukung foto. Pilih model berlabel Foto.")

        val apiKey = when (choice.provider) {
            AiPreferences.GEMINI -> AiKeyStore.geminiKey(context)
            AiPreferences.GROQ -> AiKeyStore.groqKey(context)
            AiPreferences.OPENROUTER -> AiKeyStore.openRouterKey(context)
            else -> ""
        }
        if (apiKey.isBlank()) throw IllegalStateException("API key provider model ini belum disimpan. Buka Pengaturan untuk menambahkannya.")
        val systemPrompt = """
Anda tutor sekolah yang teliti untuk SMP/SMA/SMK. Jawab dalam Bahasa Indonesia, gunakan percakapan sebelumnya sebagai konteks dan jangan mengulang jawaban kecuali diminta. Untuk soal dari gambar, teliti gambar langsung; OCR mungkin salah. Jangan menebak angka atau simbol yang buram. Untuk hitungan tunjukkan rumus, substitusi, langkah, dan hasil akhir dengan notasi terbaca (contoh (a+b)/(c+d), √x, x²), jangan keluarkan LaTeX mentah. Periksa ulang jawaban. Kembalikan JSON valid dengan skema {"jawaban_akhir":"...","langkah":["..."],"mapel":"...","metode_alternatif":["..."],"catatan":"..."}. Tanpa markdown fence.
        """.trimIndent()
        val safeHistory = history.takeLast(16)
        val raw = when (choice.provider) {
            AiPreferences.GEMINI -> askGemini(apiKey, choice.modelId, systemPrompt, safeHistory, userText, image)
            AiPreferences.GROQ -> askOpenAiCompatible("https://api.groq.com/openai/v1", apiKey, choice.modelId, systemPrompt, safeHistory, userText, image)
            AiPreferences.OPENROUTER -> askOpenAiCompatible("https://openrouter.ai/api/v1", apiKey, choice.modelId, systemPrompt, safeHistory, userText, image, true)
            else -> null
        } ?: throw IllegalStateException("Model ${choice.label} gagal menjawab. Periksa kuota API/key, koneksi, atau pilih model lain.")
        JsonParser.parse(raw, choice.label) ?: AiResult(
            jawabanAkhir = raw.take(12000),
            langkah = listOf("Model mengirim teks biasa; periksa kembali hasilnya dengan soal."),
            mapel = "Umum", modelUsed = choice.label, metodeAlternatif = emptyList(),
            catatan = "Respons tidak mengikuti format terstruktur. Periksa kembali angka, satuan, dan langkahnya."
        )
    } ?: throw IllegalStateException("Permintaan AI melewati batas waktu. Coba lagi atau pilih model lain.")

    private fun parts(text: String, image: ImageUtils.EncodedImage?): JSONArray {
        val result = JSONArray().put(JSONObject().put("text", text))
        if (image != null) result.put(JSONObject().put("inlineData", JSONObject().put("mimeType", image.mimeType).put("data", image.base64)))
        return result
    }

    private suspend fun askGemini(
        key: String,
        model: String,
        system: String,
        history: List<ChatTurn>,
        userText: String,
        image: ImageUtils.EncodedImage?
    ): String? = withContext(Dispatchers.IO) {
        runCatching {
            val contents = JSONArray()
            history.forEach { turn ->
                // Gemini names assistant turns "model"; all user turns keep their original image where present.
                contents.put(JSONObject().put("role", if (turn.role == "assistant") "model" else "user")
                    .put("parts", parts(turn.text, turn.image)))
            }
            contents.put(JSONObject().put("role", "user").put("parts", parts(userText, image)))
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json").put("maxOutputTokens", 4096))
            val encodedModel = URLEncoder.encode(model, Charsets.UTF_8.name()).replace("+", "%20")
            val request = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$encodedModel:generateContent")
                .header("x-goog-api-key", key).post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
            client.newCall(request).execute().use { response ->
                val responseText = response.body?.string().orEmpty()
                if (!response.isSuccessful) return@use null
                val data = JSONObject(responseText).optJSONArray("candidates") ?: JSONArray()
                val responseParts = data.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
                (0 until responseParts.length()).mapNotNull { responseParts.optJSONObject(it)?.optString("text")?.takeIf(String::isNotBlank) }.joinToString("\n").ifBlank { null }
            }
        }.getOrNull()
    }

    private suspend fun askOpenAiCompatible(
        baseUrl: String,
        key: String,
        model: String,
        system: String,
        history: List<ChatTurn>,
        userText: String,
        image: ImageUtils.EncodedImage?,
        isOpenRouter: Boolean = false
    ): String? = withContext(Dispatchers.IO) {
        runCatching {
            val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            fun content(text: String, photo: ImageUtils.EncodedImage?): Any {
                if (photo == null) return text
                return JSONArray()
                    .put(JSONObject().put("type", "text").put("text", text))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:${photo.mimeType};base64,${photo.base64}")))
            }
            history.forEach { turn -> messages.put(JSONObject().put("role", if (turn.role == "assistant") "assistant" else "user").put("content", content(turn.text, turn.image))) }
            messages.put(JSONObject().put("role", "user").put("content", content(userText, image)))
            val body = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.2).put("max_tokens", 4096)
            val builder = Request.Builder().url("${baseUrl.trimEnd('/')}/chat/completions").header("Authorization", "Bearer $key")
                .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            if (isOpenRouter) builder.header("X-Title", "Scan PR Ultra")
            client.newCall(builder.build()).execute().use { response ->
                val responseText = response.body?.string().orEmpty()
                if (!response.isSuccessful) return@use null
                val content = JSONObject(responseText).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.opt("content")
                when (content) {
                    is String -> content.takeIf(String::isNotBlank)
                    is JSONArray -> (0 until content.length()).mapNotNull { content.optJSONObject(it)?.optString("text")?.takeIf(String::isNotBlank) }.joinToString("\n").ifBlank { null }
                    else -> null
                }
            }
        }.getOrNull()
    }
}

object ChatModelCatalog {
    suspend fun discover(context: Context): List<ChatModelChoice> = withContext(Dispatchers.IO) {
        if (!NetworkUtils.isOnline(context)) return@withContext emptyList()
        val geminiKey = AiKeyStore.geminiKey(context)
        val groqKey = AiKeyStore.groqKey(context)
        val openRouterKey = AiKeyStore.openRouterKey(context)
        val results = coroutineScope {
            val geminiJob = async<List<String>> {
                if (geminiKey.isBlank()) emptyList() else runCatching { GeminiApi().listModels(geminiKey) }.getOrDefault(emptyList())
            }
            val groqJob = async<Set<String>> {
                if (groqKey.isBlank()) emptySet() else runCatching {
                    OpenAiCompatibleApi("https://api.groq.com/openai/v1").listModels(groqKey).toSet()
                }.getOrDefault(emptySet())
            }
            val openRouterJob = async<List<OpenRouterApi.FreeModelInfo>> {
                if (openRouterKey.isBlank()) emptyList() else runCatching {
                    OpenRouterApi().listFreeModelDetails(openRouterKey)
                }.getOrDefault(emptyList())
            }
            Triple(geminiJob.await(), groqJob.await(), openRouterJob.await())
        }
        val choices = mutableListOf<ChatModelChoice>()
        results.first.forEach { id ->
            choices += ChatModelChoice("${AiPreferences.GEMINI}|$id", AiPreferences.GEMINI, id, "Gemini · ${displayModel(id)} · Foto", true)
        }
        // These are the live Free-plan chat candidates documented by Groq; availability still depends on key/tier.
        val groqFreeCandidates = listOf("openai/gpt-oss-120b", "openai/gpt-oss-20b", "openai/gpt-oss-safeguard-20b", "qwen/qwen3.8-27b")
        groqFreeCandidates.filter { it in results.second }.forEach { id ->
            val vision = id == "qwen/qwen3.8-27b"
            choices += ChatModelChoice("${AiPreferences.GROQ}|$id", AiPreferences.GROQ, id,
                "Groq · ${displayModel(id)}" + if (vision) " · Foto" else " · Teks", vision)
        }
        if (openRouterKey.isNotBlank()) {
            // The special free router dynamically selects a free model compatible with the request's modalities.
            choices += ChatModelChoice("${AiPreferences.OPENROUTER}|openrouter/free", AiPreferences.OPENROUTER, "openrouter/free", "OpenRouter · Auto Free · Foto", true)
            results.third.forEach { info ->
                choices += ChatModelChoice("${AiPreferences.OPENROUTER}|${info.id}", AiPreferences.OPENROUTER, info.id,
                    "OpenRouter · ${displayModel(info.id)}" + if (info.supportsVision) " · Foto" else " · Teks", info.supportsVision)
            }
        }
        choices.distinctBy { it.value }.sortedWith(compareBy<ChatModelChoice>(
            { when (it.provider) { AiPreferences.GEMINI -> 0; AiPreferences.GROQ -> 1; else -> 2 } },
            { if (it.provider == AiPreferences.GEMINI && it.modelId == "gemini-3.8-flash") 0 else 1 },
            { it.modelId }
        ))
    }

    private fun displayModel(id: String): String = id.substringAfterLast('/').replace(":free", " (free)")
}
