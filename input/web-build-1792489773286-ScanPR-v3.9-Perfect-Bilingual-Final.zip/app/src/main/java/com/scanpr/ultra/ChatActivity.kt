package com.scanpr.ultra

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.scanpr.ultra.databinding.ActivityChatBinding
import com.scanpr.ultra.utils.AiPreferences
import com.scanpr.ultra.utils.ChatModelChoice
import com.scanpr.ultra.utils.ChatModelCatalog
import com.scanpr.ultra.utils.ChatModelPrefs
import com.scanpr.ultra.utils.ChatModelSpinnerAdapter
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.viewmodel.ResultViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ChatActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_DRAFT_TEXT = "chat_draft_text"
        const val EXTRA_DRAFT_IMAGE_URI = "chat_draft_image_uri"
    }

    private lateinit var binding: ActivityChatBinding
    private val vm: ResultViewModel by viewModels()
    private var chatModels: List<ChatModelChoice> = emptyList()
    private var modelAdapter: ChatModelSpinnerAdapter? = null
    private var currentChatModel: ChatModelChoice? = null
    private var pendingImageUri: Uri? = null
    private var cameraOutputUri: Uri? = null
    private var lastTransientError: String? = null
    private var refreshAfterSettings = false
    private var lastSentDraftText: String = ""
    private var lastSentDraftImageUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) setPendingImage(uri)
    }
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val uri = cameraOutputUri
        if (saved && uri != null) setPendingImage(uri)
        else if (!saved) Toast.makeText(this, "Foto tidak diambil.", Toast.LENGTH_SHORT).show()
    }
    private val speechInput = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) binding.chatInputEditText.setText(spoken)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.chatToolbar.setNavigationOnClickListener { finish() }
        binding.chatSendButton.setOnClickListener { sendMessage() }
        binding.chatAttachButton.setOnClickListener { chooseImageSource() }
        binding.chatVoiceButton.setOnClickListener { startVoiceInput() }
        binding.chatSettingsButton.setOnClickListener {
            refreshAfterSettings = true
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.chatInputEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
        }

        intent.getStringExtra(EXTRA_DRAFT_TEXT)?.takeIf { it.isNotBlank() }?.let { binding.chatInputEditText.setText(it) }
        intent.getStringExtra(EXTRA_DRAFT_IMAGE_URI)?.takeIf { it.isNotBlank() }?.let {
            runCatching { Uri.parse(it) }.getOrNull()?.let(::setPendingImage)
        }
        renderConversation()

        binding.chatModelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = modelAdapter?.modelAt(position) ?: return
                currentChatModel = selected
                ChatModelPrefs.set(this@ChatActivity, selected.value)
                if ((vm.hasImageInHistory() || pendingImageUri != null) && !selected.supportsVision) {
                    selectVisionModel(showToast = true)
                } else updateModelIndicator()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    vm.result.collect { result ->
                        if (result != null && result.modelUsed.contains("gagal", ignoreCase = true)) {
                            lastTransientError = result.catatan.ifBlank { result.jawabanAkhir }
                            // Failed messages are not inserted into shared history; keep the draft available to retry.
                            if (lastSentDraftText.isNotBlank()) binding.chatInputEditText.setText(lastSentDraftText)
                            if (lastSentDraftImageUri != null) setPendingImage(lastSentDraftImageUri!!)
                        } else if (result != null) {
                            lastTransientError = null
                            lastSentDraftText = ""
                            lastSentDraftImageUri = null
                        }
                        renderConversation()
                    }
                }
                launch {
                    vm.loading.collect { loading ->
                        binding.chatProgress.visibility = if (loading) View.VISIBLE else View.GONE
                        binding.chatSendButton.isEnabled = !loading
                        binding.chatAttachButton.isEnabled = !loading
                        binding.chatModelSpinner.isEnabled = !loading && chatModels.isNotEmpty()
                        if (loading) binding.chatModelIndicator.text = "● ${currentChatModel?.label ?: "AI"} · sedang menjawab…"
                        else updateModelIndicator()
                    }
                }
            }
        }
        loadModels()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && refreshAfterSettings) {
            refreshAfterSettings = false
            loadModels()
        }
    }

    private fun loadModels() {
        binding.chatModelIndicator.text = "● Memuat model Gemini, Groq, dan OpenRouter…"
        binding.chatModelSpinner.isEnabled = false
        lifecycleScope.launch {
            chatModels = withContext(Dispatchers.IO) {
                runCatching { ChatModelCatalog.discover(applicationContext) }.getOrDefault(emptyList())
            }
            if (chatModels.isEmpty()) {
                binding.chatModelIndicator.text = "● Model belum tersedia · perlu internet dan API key"
                binding.chatModelSpinner.isEnabled = false
                binding.chatSettingsButton.visibility = View.VISIBLE
                return@launch
            }
            val adapter = ChatModelSpinnerAdapter(this@ChatActivity, chatModels)
            modelAdapter = adapter
            binding.chatModelSpinner.adapter = adapter
            val saved = ChatModelPrefs.get(this@ChatActivity)
            var position = adapter.positionForValue(saved)
            if (position < 0) position = adapter.positionForValue("${AiPreferences.GEMINI}|gemini-3.8-flash")
            if (position < 0) position = adapter.firstVisionPosition()
            if (position < 0) position = chatModels.firstOrNull()?.let { adapter.positionForValue(it.value) } ?: -1
            binding.chatSettingsButton.visibility = View.GONE
            if (position >= 0) {
                binding.chatModelSpinner.setSelection(position, false)
                currentChatModel = adapter.modelAt(position)
                if ((vm.hasImageInHistory() || pendingImageUri != null) && currentChatModel?.supportsVision != true) {
                    selectVisionModel(showToast = false)
                } else updateModelIndicator()
            }
            binding.chatModelSpinner.isEnabled = true
        }
    }

    private fun selectVisionModel(showToast: Boolean): ChatModelChoice? {
        val preferred = chatModels.indexOfFirst { it.provider == AiPreferences.GEMINI && it.supportsVision }
            .takeIf { it >= 0 } ?: chatModels.indexOfFirst { it.provider == AiPreferences.GROQ && it.supportsVision }
                .takeIf { it >= 0 } ?: chatModels.indexOfFirst { it.provider == AiPreferences.OPENROUTER && it.supportsVision }
                    .takeIf { it >= 0 } ?: -1
        if (preferred < 0) return null
        val selected = chatModels[preferred]
        currentChatModel = selected
        modelAdapter?.positionForValue(selected.value)?.takeIf { it >= 0 }?.let { binding.chatModelSpinner.setSelection(it, false) }
        ChatModelPrefs.set(this, selected.value)
        updateModelIndicator()
        if (showToast) Toast.makeText(this, "Foto ada dalam percakapan; dipilih model yang mendukung foto.", Toast.LENGTH_SHORT).show()
        return selected
    }

    private fun updateModelIndicator() {
        val model = currentChatModel
        val cleanLabel = model?.label.orEmpty().removeSuffix(" · Foto").removeSuffix(" · Teks")
        binding.chatModelIndicator.text = when {
            pendingImageUri != null -> "● Foto terlampir · ${if (cleanLabel.isBlank()) "Pilih model vision" else cleanLabel}"
            model == null -> "● Model AI belum dipilih"
            model.supportsVision -> "● $cleanLabel · Support foto ✓"
            else -> "● $cleanLabel · Teks saja"
        }
    }

    private fun setPendingImage(uri: Uri) {
        pendingImageUri = uri
        binding.chatAttachmentStatus.text = "Foto siap dikirim · ${uri.lastPathSegment ?: "gambar"}"
        binding.chatAttachmentStatus.visibility = View.VISIBLE
        if (currentChatModel?.supportsVision != true) selectVisionModel(showToast = false)
        updateModelIndicator()
    }

    private fun chooseImageSource() {
        AlertDialog.Builder(this).setTitle("Lampirkan foto")
            .setItems(arrayOf("Galeri", "Kamera")) { _, which ->
                if (which == 0) pickImage.launch("image/*") else launchChatCamera()
            }.show()
    }

    private fun launchChatCamera() {
        runCatching {
            val folder = File(cacheDir, "chat-images").apply { mkdirs() }
            val file = File.createTempFile("scanpr-chat-", ".jpg", folder)
            cameraOutputUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            takePicture.launch(cameraOutputUri)
        }.onFailure { Toast.makeText(this, "Kamera tidak dapat dibuka. Gunakan galeri atau pemindai.", Toast.LENGTH_LONG).show() }
    }

    private fun sendMessage() {
        val text = binding.chatInputEditText.text?.toString()?.trim().orEmpty()
        val image = pendingImageUri
        if (text.isBlank() && image == null) {
            Toast.makeText(this, "Tulis pesan atau lampirkan foto terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val model = currentChatModel
        if (model == null) {
            Toast.makeText(this, "Pilih API key/model di Pengaturan AI terlebih dahulu.", Toast.LENGTH_LONG).show()
            return
        }
        if ((image != null || vm.hasImageInHistory()) && !model.supportsVision) {
            if (selectVisionModel(showToast = true) == null) {
                Toast.makeText(this, "Tidak ada model vision aktif. Tambahkan API key Gemini atau OpenRouter.", Toast.LENGTH_LONG).show()
                return
            }
        }
        lastTransientError = null
        lastSentDraftText = text
        lastSentDraftImageUri = image
        vm.send(applicationContext, currentChatModel ?: model, text, image, chatModels)
        binding.chatInputEditText.setText("")
        pendingImageUri = null
        binding.chatAttachmentStatus.visibility = View.GONE
        updateModelIndicator()
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan pertanyaan lanjutan")
        runCatching { speechInput.launch(intent) }
            .onFailure { Toast.makeText(this, "Input suara tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show() }
    }

    private fun renderConversation() {
        val container = binding.chatMessages
        container.removeAllViews()
        val turns = vm.conversationSnapshot()
        if (turns.isEmpty() && lastTransientError.isNullOrBlank()) {
            val empty = TextView(this).apply {
                text = "Mulai percakapan\n\nTulis pertanyaan atau lampirkan foto. Pilih model di bagian atas."
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(resolveThemeColor(com.scanpr.ultra.R.attr.colorTextSecondary, Color.GRAY))
                setPadding(dp(24), dp(28), dp(24), dp(28))
            }
            container.addView(empty, android.widget.LinearLayout.LayoutParams(-1, -2))
        }
        turns.forEach { turn ->
            val isUser = turn.role == "user"
            val bubble = TextView(this).apply {
                text = (if (isUser) "Kamu" else "AI") + "\n" + turn.text + if (turn.image != null) "\n\n[Foto terlampir]" else ""
                textSize = 15f
                setTextColor(resolveThemeColor(if (isUser) com.google.android.material.R.attr.colorOnPrimary else com.google.android.material.R.attr.colorOnSurface, Color.BLACK))
                setPadding(dp(14), dp(10), dp(14), dp(10))
                maxWidth = (resources.displayMetrics.widthPixels * 0.84f).toInt()
                background = GradientDrawable().apply {
                    setColor(resolveThemeColor(if (isUser) com.google.android.material.R.attr.colorPrimary else com.google.android.material.R.attr.colorSurface, Color.LTGRAY))
                    cornerRadius = dp(16).toFloat()
                }
                setTypeface(null, if (isUser) Typeface.NORMAL else Typeface.NORMAL)
            }
            val params = android.widget.LinearLayout.LayoutParams(-2, -2).apply {
                gravity = if (isUser) Gravity.END else Gravity.START
                bottomMargin = dp(10)
            }
            container.addView(bubble, params)
        }
        if (!lastTransientError.isNullOrBlank()) {
            val error = TextView(this).apply {
                text = "AI belum berhasil menjawab\n${lastTransientError}"
                textSize = 13f
                setTextColor(resolveThemeColor(com.google.android.material.R.attr.colorOnSurface, Color.BLACK))
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(resolveThemeColor(com.google.android.material.R.attr.colorSurface, Color.LTGRAY))
                    cornerRadius = dp(14).toFloat()
                }
            }
            container.addView(error, android.widget.LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        binding.chatScroll.post { binding.chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun resolveThemeColor(attr: Int, fallback: Int): Int {
        val typed = android.util.TypedValue()
        return if (theme.resolveAttribute(attr, typed, true)) {
            if (typed.resourceId != 0) runCatching { getColor(typed.resourceId) }.getOrDefault(fallback) else typed.data
        } else fallback
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
