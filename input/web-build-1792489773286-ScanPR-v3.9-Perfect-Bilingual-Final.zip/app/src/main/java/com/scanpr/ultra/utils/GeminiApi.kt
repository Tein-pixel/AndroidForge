package com.scanpr.ultra.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini REST client. Only model IDs documented as having a free tier are considered. */
class GeminiApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()

    suspend fun listModels(apiKey: String): List<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext emptyList()
        runCatching {
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000")
                .header("x-goog-api-key", apiKey)
                .get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use emptyList()
                val data = JSONObject(response.body?.string().orEmpty()).optJSONArray("models") ?: JSONArray()
                val supported = (0 until data.length()).mapNotNull { i ->
                    val obj = data.optJSONObject(i) ?: return@mapNotNull null
                    val methods = obj.optJSONArray("supportedGenerationMethods") ?: JSONArray()
                    val canGenerate = (0 until methods.length()).any { methods.optString(it) == "generateContent" }
                    obj.optString("name", "").removePrefix("models/").takeIf { canGenerate && it.isNotBlank() }
                }.toSet()
                // ListModels exposes availability, not billing flags. Keep a reviewed allow-list of current
                // models whose published Standard tier has free input/output; then require live API support.
                // 2.5 Flash/Pro do not have a standard free tier in the current pricing table; 2.0 and 1.5 are retired.
                // This cannot detect whether the user's Google Cloud project has billing enabled, so quotas/billing
                // still depend on that project and Google's current terms.
                val freeTierPriority = listOf(
                    "gemini-3.8-flash",
                    "gemini-3.6-flash",
                    "gemini-3.5-flash-lite",
                    "gemini-3.1-flash-lite",
                    "gemini-2.5-flash-lite"
                )
                freeTierPriority.filter { it in supported }
            }
        }.getOrDefault(emptyList())
    }

    suspend fun askGemini(prompt: String, apiKey: String, model: String, image: ImageUtils.EncodedImage? = null): String? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || model.isBlank()) return@withContext null
        runCatching {
            val parts = JSONArray().put(JSONObject().put("text", prompt))
            if (image != null) {
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", image.mimeType).put("data", image.base64)))
            }
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put("generationConfig", JSONObject().put("temperature", 0.15).put("responseMimeType", "application/json").put("maxOutputTokens", 4096))
                .toString()
            val urlModel = java.net.URLEncoder.encode(model, Charsets.UTF_8.name()).replace("+", "%20")
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$urlModel:generateContent")
                .header("x-goog-api-key", apiKey)
                .post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val candidates = JSONObject(response.body?.string().orEmpty()).optJSONArray("candidates") ?: JSONArray()
                val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
                (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text")?.takeIf(String::isNotBlank) }.joinToString("\n").ifBlank { null }
            }
        }.getOrNull()
    }
}
