package com.scanpr.ultra.utils

/** In-process conversation shared by scan results and the dedicated chat screen. */
object ConversationSession {
    val turns: MutableList<ChatTurn> = mutableListOf()
}
