// File: app/src/main/java/com/scanpr/ultra/viewmodel/HistoryViewModel.kt
package com.scanpr.ultra.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.scanpr.ultra.data.ScanHistory
import com.scanpr.ultra.repository.ScanRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class HistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ScanRepository(application)
    fun items(query: String): Flow<List<ScanHistory>> = repository.search(query)
    fun save(item: ScanHistory, onDone: (Long) -> Unit = {}) = viewModelScope.launch { onDone(repository.save(item)) }
}
