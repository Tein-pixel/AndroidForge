package com.scanpr.ultra.utils

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Provider credentials stay on this device, encrypted. Never ship personal API keys in an APK. */
object AiKeyStore {
    private const val PREFS_NAME = "scanpr_ai_credentials"
    private const val GEMINI_KEY = "gemini_api_key"
    private const val OPENROUTER_KEY = "openrouter_api_key"
    private const val GROQ_KEY = "groq_api_key"
    private const val CEREBRAS_KEY = "cerebras_api_key"

    private fun prefs(context: Context) = runCatching {
        val app = context.applicationContext
        val masterKey = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            app, PREFS_NAME, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrThrow()

    private fun key(context: Context, name: String, fallback: String = ""): String =
        runCatching { prefs(context).getString(name, null) ?: fallback }.getOrDefault(fallback).trim()

    fun geminiKey(context: Context) = key(context, GEMINI_KEY)
    fun openRouterKey(context: Context) = key(context, OPENROUTER_KEY)
    fun groqKey(context: Context) = key(context, GROQ_KEY)
    fun cerebrasKey(context: Context) = key(context, CEREBRAS_KEY)
    fun hasAnyKey(context: Context): Boolean = listOf(geminiKey(context), openRouterKey(context), groqKey(context), cerebrasKey(context)).any { it.isNotBlank() }

    fun save(context: Context, gemini: String, openRouter: String, groq: String, cerebras: String) {
        val p = prefs(context)
        val ok = p.edit()
            .putString(GEMINI_KEY, gemini.trim())
            .putString(OPENROUTER_KEY, openRouter.trim())
            .putString(GROQ_KEY, groq.trim())
            .putString(CEREBRAS_KEY, cerebras.trim())
            .commit()
        if (!ok) error("Kunci AI tidak berhasil disimpan.")
    }

    @Deprecated("Use the four-provider overload")
    fun save(context: Context, gemini: String, openRouter: String) =
        save(context, gemini, openRouter, groqKey(context), cerebrasKey(context))
}
