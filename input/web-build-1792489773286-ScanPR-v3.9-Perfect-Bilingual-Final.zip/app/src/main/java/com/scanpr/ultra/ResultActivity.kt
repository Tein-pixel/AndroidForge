package com.scanpr.ultra

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.app.AlertDialog
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.scanpr.ultra.data.ScanHistory
import com.scanpr.ultra.databinding.ActivityResultBinding
import com.scanpr.ultra.repository.ScanRepository
import com.scanpr.ultra.utils.AiResult
import com.scanpr.ultra.utils.ChatModelChoice
import com.scanpr.ultra.utils.ChatModelCatalog
import com.scanpr.ultra.utils.ChatModelPrefs
import com.scanpr.ultra.utils.ChatModelSpinnerAdapter
import com.scanpr.ultra.utils.ImageUtils
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.viewmodel.ResultViewModel
import androidx.activity.viewModels
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.util.Locale
import java.io.File

class ResultActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_OCR = "ocr_text"
        const val EXTRA_IMAGE_URI = "image_uri"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_STEPS = "steps_json"
        const val EXTRA_MAPEL = "mapel"
        const val EXTRA_MODEL = "model_used"
        const val EXTRA_ID = "history_id"
    }

    private lateinit var binding: ActivityResultBinding
    private val vm: ResultViewModel by viewModels()
    private lateinit var repository: ScanRepository
    private var imageUri = ""
    private var pendingChatImageUri: Uri? = null
    private var chatModels: List<ChatModelChoice> = emptyList()
    private var currentChatModel: ChatModelChoice? = null
    private var modelSpinnerAdapter: ChatModelSpinnerAdapter? = null
    private var ocrExpanded = false
    private var lastResult: AiResult? = null
    private var alreadySaved = false
    private var textToSpeech: TextToSpeech? = null

    private val createPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportPdf(uri)
    }
    private val speechInput = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) { binding.followupEditText.setText(spoken); submitFollowup() }
        }
    }
    private var cameraOutputUri: Uri? = null
    private val pickChatImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onChatImageReady(uri)
    }
    private val takeChatPicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val uri = cameraOutputUri
        if (saved && uri != null) onChatImageReady(uri)
        else Toast.makeText(this, "Foto tidak diambil.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ScanRepository(this)
        imageUri = intent.getStringExtra(EXTRA_IMAGE_URI).orEmpty()
        val parsedUri = runCatching { Uri.parse(imageUri).takeIf { imageUri.isNotBlank() } }.getOrNull()
        if (parsedUri == null) binding.resultImage.visibility = View.GONE else ImageUtils.show(this, parsedUri, binding.resultImage)
        binding.resultToolbar.setNavigationOnClickListener { finish() }
        binding.ocrEditText.setText(intent.getStringExtra(EXTRA_OCR).orEmpty())
        setOcrExpanded(false)
        binding.toggleOcrButton.setOnClickListener { setOcrExpanded(!ocrExpanded) }
        binding.ocrHeader.setOnClickListener { setOcrExpanded(!ocrExpanded) }
        binding.editOcrButton.setOnClickListener { setOcrExpanded(true, requestFocus = true) }
        binding.openChatButton.setOnClickListener {
            val chatIntent = Intent(this, ChatActivity::class.java)
            if (lastResult == null || lastResult?.modelUsed?.contains("gagal", ignoreCase = true) == true) {
                chatIntent.putExtra(ChatActivity.EXTRA_DRAFT_TEXT, binding.ocrEditText.text.toString())
                if (imageUri.isNotBlank()) chatIntent.putExtra(ChatActivity.EXTRA_DRAFT_IMAGE_URI, imageUri)
            }
            startActivity(chatIntent)
        }
        binding.chatComposerContainer.visibility = View.GONE
        binding.chatHistoryText.visibility = View.GONE
        binding.stepsRecyclerView.visibility = View.GONE
        binding.methodsText.visibility = View.GONE
        binding.resultNotesText.visibility = View.GONE
        binding.stepsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.solveButton.setOnClickListener {
            val correctedText = binding.ocrEditText.text.toString()
            // Keep the original cropped image attached: the vision model should inspect the actual pixels.
            sendWithCurrentModel(correctedText, parsedUri)
        }
        binding.copyButton.setOnClickListener { copyResult() }
        binding.shareButton.setOnClickListener { shareResult() }
        binding.saveButton.setOnClickListener { saveResult() }
        binding.exportPdfButton.setOnClickListener { createPdf.launch("ScanPR-Hasil.pdf") }
        binding.graphButton.setOnClickListener { startActivity(Intent(this, GraphActivity::class.java).putExtra(GraphActivity.EXTRA_EQUATION, binding.ocrEditText.text.toString())) }
        binding.speakAnswerButton.setOnClickListener { speakAnswer() }
        binding.searchSourcesButton.setOnClickListener { searchSources() }
        binding.followupSendButton.setOnClickListener { submitFollowup() }
        binding.followupImageButton.setOnClickListener { chooseChatImageSource() }
        binding.spinnerModel.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = modelSpinnerAdapter?.modelAt(position) ?: return
                currentChatModel = selected
                ChatModelPrefs.set(this@ResultActivity, selected.value)
                if ((vm.hasImageInHistory() || pendingChatImageUri != null) && !selected.supportsVision) {
                    selectVisionModel(showToast = true)
                } else updateModelIndicator()
            }
        }
        binding.followupEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitFollowup(); true } else false
        }
        binding.followupVoiceButton.setOnClickListener { startVoiceFollowup() }
        binding.toolShortButton.setOnClickListener { applyStudyTool("Tulis ulang jawaban sebelumnya secara ringkas dan langsung ke inti. Pertahankan angka, satuan, rumus penting, serta hasil akhir; jangan menghilangkan informasi yang mengubah makna.") }
        binding.toolDetailedButton.setOnClickListener { applyStudyTool("Perluas jawaban sebelumnya menjadi penjelasan lebih rinci dan runtut. Verifikasi ulang angka, satuan, rumus, dan fakta; jangan menambah detail yang tidak didukung soal.") }
        binding.toolHintButton.setOnClickListener { applyStudyTool("Berikan petunjuk bertahap tanpa langsung menampilkan jawaban akhir. Berhenti setelah petunjuk yang cukup untuk saya coba.") }
        binding.toolSimpleButton.setOnClickListener { applyStudyTool("Jelaskan jawaban dan konsepnya dengan bahasa yang lebih sederhana untuk pelajar, sertakan satu contoh singkat bila membantu.") }
        binding.toolExampleButton.setOnClickListener { applyStudyTool("Buat satu contoh soal baru yang sejenis tetapi memakai angka/konteks berbeda, lalu jelaskan jawaban langkah demi langkah.") }
        binding.toolSummaryButton.setOnClickListener { applyStudyTool("Buat rangkuman singkat materi yang dibutuhkan untuk memahami soal ini, dalam poin-poin dan definisi penting.") }
        binding.toolVerifyButton.setOnClickListener {
            applyStudyTool("Audit jawaban sebelumnya secara kritis. Cocokkan kembali teks soal, setiap angka/satuan, rumus, perhitungan dan fakta yang disebut. Jika soal matematika, hitung ulang secara independen. Sebutkan bagian yang benar, bagian yang mungkin salah, dan koreksi bila dapat dibuktikan. Jangan menyatakan benar bila tidak bisa diverifikasi.")
        }
        binding.toolQuizButton.setOnClickListener { openStudyActivity("quiz") }
        binding.toolFlashcardsButton.setOnClickListener { openStudyActivity("cards") }
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) textToSpeech?.language = Locale("id", "ID")
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.result.collect { result -> if (result != null) renderResult(result) } }
                launch {
                    vm.loading.collect { loading ->
                        binding.aiProgress.visibility = if (loading) View.VISIBLE else View.GONE
                        binding.solveButton.isEnabled = !loading
                        binding.followupSendButton.isEnabled = !loading
                        binding.modelChip.text = if (loading) "AI: mencoba provider…" else (lastResult?.modelUsed?.let { "AI: $it" } ?: "AI: menunggu")
                    }
                }
            }
        }
        val savedAnswer = intent.getStringExtra(EXTRA_ANSWER).orEmpty()
        if (savedAnswer.isNotBlank()) {
            val steps = runCatching {
                val array = JSONArray(intent.getStringExtra(EXTRA_STEPS).orEmpty())
                (0 until array.length()).map { array.optString(it) }
            }.getOrDefault(emptyList())
            vm.setResult(AiResult(savedAnswer, steps, intent.getStringExtra(EXTRA_MAPEL).orEmpty().ifBlank { "Umum" }, intent.getStringExtra(EXTRA_MODEL).orEmpty().ifBlank { "Riwayat" }, emptyList()))
            lifecycleScope.launch {
                val savedPhoto = parsedUri?.let { photoUri -> withContext(Dispatchers.IO) { ImageUtils.encodeForAi(applicationContext, photoUri) } }
                vm.seedConversation(binding.ocrEditText.text.toString(), savedAnswer, savedPhoto)
                val priorChat = vm.previousConversationDisplay()
                binding.chatHistoryText.text = priorChat
                binding.chatHistoryText.visibility = if (priorChat.isBlank()) View.GONE else View.VISIBLE
            }
            alreadySaved = true
            binding.saveButton.isEnabled = false
        } else {
            binding.answerText.text = "Siap untuk menjawab. Pilih model AI, lalu kirim soal."
            binding.resultNotesText.text = "Model dipilih dari katalog aktif sesuai API key yang tersimpan. Kuota gratis tetap mengikuti akun provider."
        }
        // v3.9: scanning/cropping only prepares the result screen. AI starts only after an explicit tap.
        loadChatModels(autoSendInitial = false, imageForInitial = parsedUri)
    }

    private fun renderResult(result: AiResult) {
        lastResult = result
        binding.subjectChip.text = result.mapel
        binding.modelChip.text = "AI: ${result.modelUsed}"
        binding.answerText.text = result.jawabanAkhir
        val priorChat = vm.previousConversationDisplay()
        binding.chatHistoryText.text = priorChat
        binding.chatHistoryText.visibility = if (priorChat.isBlank()) View.GONE else View.VISIBLE
        val fallbackLabel = result.modelUsed.removeSuffix(" (fallback otomatis)")
        val usedModel = chatModels.firstOrNull { it.label == fallbackLabel }
        val fallbackPosition = usedModel?.let { modelSpinnerAdapter?.positionForValue(it.value) } ?: -1
        if (usedModel != null && fallbackPosition >= 0) {
            currentChatModel = usedModel
            binding.spinnerModel.setSelection(fallbackPosition, false)
            ChatModelPrefs.set(this, currentChatModel!!.value)
            updateModelIndicator()
        }
        binding.stepsRecyclerView.adapter = StepsAdapter(result.langkah)
        binding.methodsText.text = if (result.metodeAlternatif.isEmpty()) "" else "Metode alternatif: " + result.metodeAlternatif.joinToString(" • ")
        binding.resultNotesText.text = "Catatan akurasi: ${result.catatan}\n\nAI dapat keliru. Cocokkan angka, satuan, dan instruksi soal dengan sumber pelajaran."
        binding.resultNotesText.visibility = if (result.modelUsed.contains("gagal", ignoreCase = true)) View.VISIBLE else View.GONE
    }

    private fun setOcrExpanded(expanded: Boolean, requestFocus: Boolean = false) {
        ocrExpanded = expanded
        binding.ocrEditText.visibility = if (expanded) View.VISIBLE else View.GONE
        binding.toggleOcrButton.setImageResource(if (expanded) R.drawable.ic_chevron_up else R.drawable.ic_chevron_down)
        binding.toggleOcrButton.contentDescription = if (expanded) "Sembunyikan teks terdeteksi" else "Tampilkan teks terdeteksi"
        if (expanded && requestFocus) {
            binding.ocrEditText.requestFocus()
            binding.ocrEditText.setSelection(binding.ocrEditText.text.length)
        }
    }

    private fun openStudyActivity(mode: String) {
        val contextForStudy = buildString {
            appendLine("Soal atau materi sumber:")
            appendLine(binding.ocrEditText.text?.toString()?.trim().orEmpty())
            val answer = lastResult?.jawabanAkhir.orEmpty()
            if (answer.isNotBlank()) {
                appendLine("Jawaban/pembahasan yang sudah tersedia:")
                appendLine(answer)
                lastResult?.langkah?.takeIf { it.isNotEmpty() }?.let { appendLine("Langkah:"); it.forEach { step -> appendLine("- $step") } }
            }
        }.trim()
        startActivity(Intent(this, StudyActivity::class.java)
            .putExtra(StudyActivity.EXTRA_MODE, mode)
            .putExtra(StudyActivity.EXTRA_CONTEXT, contextForStudy))
    }

    private fun applyStudyTool(instruction: String) {
        startActivity(Intent(this, ChatActivity::class.java)
            .putExtra(ChatActivity.EXTRA_DRAFT_TEXT, instruction))
    }

    private fun chooseChatImageSource() {
        AlertDialog.Builder(this)
            .setTitle("Lampirkan foto")
            .setItems(arrayOf("Galeri", "Kamera")) { _, which ->
                if (which == 0) pickChatImage.launch("image/*") else launchChatCamera()
            }
            .show()
    }

    private fun launchChatCamera() {
        runCatching {
            val folder = File(cacheDir, "chat-images").apply { mkdirs() }
            val imageFile = File.createTempFile("scanpr-chat-", ".jpg", folder)
            cameraOutputUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", imageFile)
            takeChatPicture.launch(cameraOutputUri)
        }.onFailure {
            Toast.makeText(this, "Kamera tidak dapat dibuka. Coba gunakan galeri atau kamera pemindai.", Toast.LENGTH_LONG).show()
        }
    }

    private fun onChatImageReady(uri: Uri) {
        pendingChatImageUri = uri
        if (currentChatModel?.supportsVision != true) selectVisionModel(showToast = false)
        updateModelIndicator()
        Toast.makeText(this, "Foto siap dikirim bersama pertanyaan.", Toast.LENGTH_SHORT).show()
    }

    private fun submitFollowup() {
        val followup = binding.followupEditText.text?.toString()?.trim().orEmpty()
        if (followup.isBlank() && pendingChatImageUri == null) {
            Toast.makeText(this, "Ketik pertanyaan atau lampirkan foto terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        alreadySaved = false
        binding.saveButton.isEnabled = true
        val imageToSend = pendingChatImageUri
        if (sendWithCurrentModel(followup, imageToSend)) {
            pendingChatImageUri = null
            binding.followupEditText.setText("")
            updateModelIndicator()
        }
    }

    private fun sendWithCurrentModel(text: String, image: Uri?): Boolean {
        var model = currentChatModel
        val conversationNeedsVision = vm.hasImageInHistory() || image != null
        if (model == null) {
            Toast.makeText(this, "Memuat model atau belum ada API key yang tersedia. Buka Pengaturan AI.", Toast.LENGTH_LONG).show()
            return false
        }
        if (conversationNeedsVision && !model.supportsVision) {
            model = selectVisionModel(showToast = true)
            if (model == null) {
                Toast.makeText(this, "Percakapan ini berisi foto. Tambahkan API key model vision di Pengaturan.", Toast.LENGTH_LONG).show()
                return false
            }
        }
        vm.send(applicationContext, model, text, image, chatModels)
        return true
    }

    private fun loadChatModels(autoSendInitial: Boolean, imageForInitial: Uri?) {
        binding.tvModelIndicator.text = "● Memuat katalog model AI…"
        lifecycleScope.launch {
            val discovered = withContext(Dispatchers.IO) { runCatching { ChatModelCatalog.discover(applicationContext) }.getOrDefault(emptyList()) }
            chatModels = discovered
            modelSpinnerAdapter = ChatModelSpinnerAdapter(this@ResultActivity, discovered)
            binding.spinnerModel.adapter = modelSpinnerAdapter
            if (discovered.isEmpty()) {
                currentChatModel = null
                binding.spinnerModel.isEnabled = false
                binding.tvModelIndicator.text = "● API key/model belum tersedia · buka Pengaturan AI"
                binding.resultNotesText.text = "Simpan API key Gemini, Groq, atau OpenRouter di Pengaturan AI. Daftar model mengikuti katalog provider, akses akun, dan kuota gratis."
                binding.resultNotesText.visibility = View.VISIBLE
                return@launch
            }
            binding.spinnerModel.isEnabled = true
            val saved = ChatModelPrefs.get(this@ResultActivity)
            var selection = modelSpinnerAdapter?.positionForValue(saved) ?: -1
            if (selection < 0) selection = modelSpinnerAdapter?.positionForValue("${com.scanpr.ultra.utils.AiPreferences.GEMINI}|gemini-3.8-flash") ?: -1
            if (selection < 0) selection = modelSpinnerAdapter?.firstVisionPosition() ?: -1
            if (selection < 0) selection = modelSpinnerAdapter?.positionForValue(discovered.first().value) ?: -1
            if (selection < 0) return@launch
            binding.spinnerModel.setSelection(selection, false)
            currentChatModel = modelSpinnerAdapter?.modelAt(selection)
            ChatModelPrefs.set(this@ResultActivity, currentChatModel!!.value)
            updateModelIndicator()
            if (autoSendInitial) {
                // If the scan includes a photo, pick a vision model before the first request.
                if (imageForInitial != null && currentChatModel?.supportsVision != true) selectVisionModel(showToast = false)
                sendWithCurrentModel(binding.ocrEditText.text.toString(), imageForInitial)
            }
        }
    }

    private fun selectVisionModel(showToast: Boolean): ChatModelChoice? {
        val current = currentChatModel
        if (current?.supportsVision == true) return current
        val preferred = chatModels.indexOfFirst { it.provider == com.scanpr.ultra.utils.AiPreferences.GEMINI && it.supportsVision }
            .takeIf { it >= 0 } ?: chatModels.indexOfFirst { it.provider == com.scanpr.ultra.utils.AiPreferences.GROQ && it.supportsVision }
                .takeIf { it >= 0 } ?: chatModels.indexOfFirst { it.provider == com.scanpr.ultra.utils.AiPreferences.OPENROUTER && it.supportsVision }
                    .takeIf { it >= 0 } ?: -1
        if (preferred < 0) return null
        currentChatModel = chatModels[preferred]
        modelSpinnerAdapter?.positionForValue(currentChatModel!!.value)?.takeIf { it >= 0 }?.let { binding.spinnerModel.setSelection(it, false) }
        ChatModelPrefs.set(this, currentChatModel!!.value)
        updateModelIndicator()
        if (showToast) Toast.makeText(this, "Percakapan berisi foto; otomatis beralih ke model vision.", Toast.LENGTH_SHORT).show()
        return currentChatModel
    }

    private fun updateModelIndicator() {
        val model = currentChatModel
        if (pendingChatImageUri != null) {
            binding.tvModelIndicator.text = "● Foto terlampir · ${model?.label ?: "Pilih model vision"}"
        } else if (model == null) {
            binding.tvModelIndicator.text = "● Tidak ada model AI tersedia"
        } else {
            binding.tvModelIndicator.text = if (model.supportsVision) "● ${model.label} · Support foto ✓" else "● ${model.label} · Teks saja"
        }
    }

    private fun startVoiceFollowup() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan pertanyaan lanjutan")
        runCatching { speechInput.launch(intent) }.onFailure { Toast.makeText(this, "Input suara tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show() }
    }

    private fun resultText(): String {
        val result = lastResult
        return "SCAN PR ULTRA\n\nSoal:\n${binding.ocrEditText.text}\n\nMata pelajaran: ${result?.mapel.orEmpty()}\nModel: ${result?.modelUsed.orEmpty()}\n\nJawaban:\n${result?.jawabanAkhir.orEmpty()}\n\nLangkah/penjelasan:\n${result?.langkah?.joinToString("\n").orEmpty()}\n\nMetode alternatif:\n${result?.metodeAlternatif?.joinToString("\n").orEmpty()}\n\nCatatan:\n${result?.catatan.orEmpty()}\n\nCatatan: Periksa kembali hasil dengan sumber pelajaran. AI dapat keliru."
    }

    private fun searchSources() {
        val query = binding.ocrEditText.text?.toString()?.trim().orEmpty()
        if (query.isBlank()) {
            Toast.makeText(this, "Masukkan soal atau kata kunci terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val url = "https://www.google.com/search?q=" + java.net.URLEncoder.encode(query.take(1000), Charsets.UTF_8.name())
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { Toast.makeText(this, "Browser tidak tersedia untuk mencari sumber.", Toast.LENGTH_LONG).show() }
    }

    private fun copyResult() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Scan PR Ultra", resultText()))
        Toast.makeText(this, "Hasil disalin.", Toast.LENGTH_SHORT).show()
    }

    private fun shareResult() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, resultText()), "Bagikan hasil"))
    }

    private fun speakAnswer() {
        val text = lastResult?.let { "Jawaban. ${it.jawabanAkhir}. Penjelasan. ${it.langkah.joinToString(". ")}" }.orEmpty()
        if (text.isBlank()) { Toast.makeText(this, "Belum ada jawaban untuk dibacakan.", Toast.LENGTH_SHORT).show(); return }
        val tts = textToSpeech
        if (tts == null) Toast.makeText(this, "Fitur bacakan belum siap.", Toast.LENGTH_SHORT).show()
        else tts.speak(text.take(4000), TextToSpeech.QUEUE_FLUSH, null, "scanpr_answer")
    }

    private fun exportPdf(uri: Uri) {
        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    val document = PdfDocument()
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = android.graphics.Color.BLACK }
                    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 17f; typeface = android.graphics.Typeface.DEFAULT_BOLD; color = android.graphics.Color.BLACK }
                    val lines = wrapLines(resultText(), 84)
                    val pageWidth = 595; val pageHeight = 842; val margin = 40f; val lineHeight = 16f
                    var pageNumber = 1
                    var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                    var canvas = page.canvas
                    var y = margin
                    canvas.drawText("Scan PR Ultra", margin, y, titlePaint)
                    y += 30f
                    for (line in lines) {
                        if (y > pageHeight - margin) {
                            document.finishPage(page)
                            pageNumber++
                            page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                            canvas = page.canvas; y = margin
                        }
                        canvas.drawText(line.take(95), margin, y, paint)
                        y += lineHeight
                    }
                    document.finishPage(page)
                    contentResolver.openOutputStream(uri)?.use { document.writeTo(it) } ?: error("Tidak dapat membuka lokasi penyimpanan")
                    document.close()
                }
            }
            Toast.makeText(this@ResultActivity, if (saved.isSuccess) "PDF berhasil disimpan." else "Gagal membuat PDF. Coba lokasi lain.", Toast.LENGTH_LONG).show()
        }
    }

    private fun wrapLines(text: String, width: Int): List<String> = buildList {
        text.lines().forEach { line ->
            if (line.isBlank()) { add(""); return@forEach }
            var rest = line
            while (rest.length > width) {
                var cut = rest.lastIndexOf(' ', width)
                if (cut < width / 2) cut = width
                add(rest.substring(0, cut).trimEnd())
                rest = rest.substring(cut).trimStart()
            }
            add(rest)
        }
    }

    private fun saveResult() {
        if (alreadySaved) {
            Toast.makeText(this, "Hasil ini sudah tersimpan di riwayat.", Toast.LENGTH_SHORT).show()
            return
        }
        val result = lastResult ?: run { Toast.makeText(this, "Tunggu sampai hasil tersedia.", Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            runCatching {
                repository.save(ScanHistory(ocrText = binding.ocrEditText.text.toString(), answer = result.jawabanAkhir,
                    stepsJson = JSONArray(result.langkah).toString(), mapel = result.mapel, modelUsed = result.modelUsed, imageUri = imageUri))
            }.onSuccess {
                alreadySaved = true; binding.saveButton.isEnabled = false
                Toast.makeText(this@ResultActivity, "Hasil disimpan ke riwayat.", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(this@ResultActivity, "Gagal menyimpan riwayat.", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }

    private class StepsAdapter(private val items: List<String>) : RecyclerView.Adapter<StepsAdapter.StepViewHolder>() {
        class StepViewHolder(val text: TextView, val number: TextView, val line: View) : RecyclerView.ViewHolder(text.parent as View)
        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): StepViewHolder {
            val view = android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_step, parent, false)
            return StepViewHolder(view.findViewById(R.id.step_text), view.findViewById(R.id.step_number), view.findViewById(R.id.step_line))
        }
        override fun onBindViewHolder(holder: StepViewHolder, position: Int) {
            holder.number.text = (position + 1).toString(); holder.text.text = items[position]
            holder.line.visibility = if (position == items.lastIndex) View.INVISIBLE else View.VISIBLE
        }
        override fun getItemCount() = items.size
    }
}
