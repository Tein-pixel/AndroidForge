package com.scanpr.ultra

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.scanpr.ultra.databinding.ActivityGraphBinding
import com.scanpr.ultra.utils.ThemeManager
import java.util.Locale

class GraphActivity : AppCompatActivity() {
    companion object { const val EXTRA_EQUATION = "graph_equation" }
    private lateinit var binding: ActivityGraphBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityGraphBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.graphToolbar.setNavigationOnClickListener { finish() }
        val raw = intent.getStringExtra(EXTRA_EQUATION).orEmpty()
        val equation = Regex("(?i)\\by\\s*=\\s*([^\\n,;]+)").find(raw)?.groupValues?.getOrNull(1)?.trim()
        binding.graphEquationText.text = if (equation == null) "Persamaan: belum dikenali" else "y = $equation"
        val result = equation?.let { parseLinear(it) }
        if (result == null) {
            binding.graphStatusText.text = "Fungsi tidak dikenali sebagai fungsi linear. Contoh format yang didukung: y = 2x + 3, y = -x + 1, y = 0.5x."
            binding.graphPlotView.setFunction(null, null)
        } else {
            binding.graphStatusText.text = "Grafik linear: y = ${fmt(result.first)}x + ${fmt(result.second)}"
            binding.graphPlotView.setFunction(result.first, result.second)
        }
    }

    private fun parseLinear(expression: String): Pair<Double, Double>? = runCatching {
        val s = expression.lowercase(Locale.US).replace(" ", "").replace("-", "+-").trimStart('+')
        if (s.isBlank() || s.any { !(it.isDigit() || it in "+-.x") }) return@runCatching null
        var m = 0.0
        var b = 0.0
        val terms = s.split('+').filter { it.isNotBlank() }
        if (terms.isEmpty()) return@runCatching null
        for (term in terms) {
            if ('x' in term) {
                if (term.count { it == 'x' } != 1 || !term.endsWith('x')) return@runCatching null
                val coefficient = term.dropLast(1)
                m += when (coefficient) { "", "+" -> 1.0; "-" -> -1.0; else -> coefficient.toDouble() }
            } else b += term.toDouble()
        }
        m to b
    }.getOrNull()

    private fun fmt(v: Double): String = if (v == v.toLong().toDouble()) v.toLong().toString() else String.format(Locale.US, "%.3f", v).trimEnd('0').trimEnd('.')
}
