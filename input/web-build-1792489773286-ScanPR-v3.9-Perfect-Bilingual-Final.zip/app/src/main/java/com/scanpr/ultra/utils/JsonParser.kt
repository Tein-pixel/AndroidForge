package com.scanpr.ultra.utils

import org.json.JSONArray
import org.json.JSONObject

object JsonParser {
    fun parse(raw: String, model: String): AiResult? {
        val cleaned = raw.trim()
            .replace(Regex("^```(?:json)?\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s*```$"), "").trim()
        if (cleaned.isBlank()) return null
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start >= 0 && end > start) {
            val parsed = runCatching { JSONObject(cleaned.substring(start, end + 1)) }.getOrNull()
            if (parsed != null) {
                val stepsArray = parsed.optJSONArray("langkah") ?: parsed.optJSONArray("steps") ?: JSONArray()
                val steps = (0 until stepsArray.length()).mapNotNull { stepsArray.optString(it).takeIf(String::isNotBlank)?.let(::normalizeMath) }
                val methodsArray = parsed.optJSONArray("metode_alternatif") ?: JSONArray()
                val methods = (0 until methodsArray.length()).mapNotNull { methodsArray.optString(it).takeIf(String::isNotBlank)?.let(::normalizeMath) }
                val answer = normalizeMath(parsed.optString("jawaban_akhir", parsed.optString("answer", parsed.optString("final_answer", ""))).trim())
                if (answer.isNotBlank() && answer != "null") {
                    val subject = parsed.optString("mapel", parsed.optString("subject", "Umum")).ifBlank { "Umum" }
                    val notes = normalizeMath(parsed.optString("catatan", parsed.optString("notes", "Periksa kembali jawaban dan kecocokannya dengan soal. AI dapat keliru.")).ifBlank { "Periksa kembali jawaban dan kecocokannya dengan soal. AI dapat keliru." })
                    return AiResult(answer, steps.ifEmpty { listOf("Cocokkan kembali jawaban dengan teks soal yang tertera.") }, subject, model, methods, notes)
                }
                // A JSON object appeared but had an unknown schema; retry another provider rather than guessing.
                return null
            }
            if (cleaned.startsWith("{") || cleaned.startsWith("[")) return null
        }
        // Some OpenAI-compatible models ignore JSON instructions. Preserve their plain response instead
        // of treating a useful answer as total provider failure.
        return AiResult(
            jawabanAkhir = normalizeMath(cleaned.take(12000)),
            langkah = listOf("Model mengirim jawaban berbentuk teks; cocokkan langsung setiap langkah dengan soal."),
            mapel = "Umum",
            modelUsed = model,
            metodeAlternatif = emptyList(),
            catatan = "Respons model tidak mengikuti format terstruktur. Periksa kembali fakta, angka, satuan, dan langkahnya secara manual."
        )
    }

    /** Convert common math notation to readable Unicode/ASCII so TextViews do not show raw LaTeX. */
    private fun normalizeMath(input: String): String {
        var value = input
            .replace("\\[", "").replace("\\]", "")
            .replace("\\(", "").replace("\\)", "")
            .replace("$$", "")
            .replace(Regex("""\\(?:left|right)\b"""), "")
            .replace(Regex("""\\(?:quad|qquad|,|;|!)"""), " ")
        repeat(5) {
            value = value
                .replace(Regex("""\\(?:dfrac|tfrac|frac)\{([^{}]+)\}\{([^{}]+)\}""")) { "(${it.groupValues[1]})/(${it.groupValues[2]})" }
                .replace(Regex("""\\sqrt\{([^{}]+)\}""")) { "√(${it.groupValues[1]})" }
                .replace(Regex("""\\(?:mathrm|mathit|mathbf|text)\{([^{}]*)\}""")) { it.groupValues[1] }
        }
        value = value
            .replace(Regex("""\\(?:times|cdot)\b"""), " × ")
            .replace(Regex("""\\div\b"""), " ÷ ")
            .replace(Regex("""\\pi\b"""), "π")
            .replace(Regex("""\\leq\b"""), "≤")
            .replace(Regex("""\\geq\b"""), "≥")
            .replace(Regex("""\\neq\b"""), "≠")
            .replace(Regex("""\\pm\b"""), "±")
            .replace(Regex("""\\approx\b"""), "≈")
            .replace(Regex("""\\infty\b"""), "∞")
            .replace(Regex("""\\%"""), "%")
            .replace("\\\\", "\n")
        val superChars = "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻"
        val superNormal = "0123456789+-"
        val subChars = "₀₁₂₃₄₅₆₇₈₉₊₋"
        val subNormal = "0123456789+-"
        value = value
            .replace(Regex("""\^\{([0-9+\-]+)\}""")) { m -> m.groupValues[1].map { c -> superChars.getOrNull(superNormal.indexOf(c)) ?: c }.joinToString("") }
            .replace(Regex("""\^([0-9])""")) { m -> superChars[superNormal.indexOf(m.groupValues[1][0])].toString() }
            .replace(Regex("""_\{([0-9+\-]+)\}""")) { m -> m.groupValues[1].map { c -> subChars.getOrNull(subNormal.indexOf(c)) ?: c }.joinToString("") }
            .replace(Regex("""_([0-9])""")) { m -> subChars[subNormal.indexOf(m.groupValues[1][0])].toString() }
        return value.trim()
    }

}
