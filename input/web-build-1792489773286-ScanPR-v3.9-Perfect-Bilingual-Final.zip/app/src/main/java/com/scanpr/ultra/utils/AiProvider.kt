package com.scanpr.ultra.utils

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

 data class AiResult(
    val jawabanAkhir: String,
    val langkah: List<String>,
    val mapel: String,
    val modelUsed: String,
    val metodeAlternatif: List<String>,
    val catatan: String = "Periksa kembali hasil dengan materi/buku pelajaran. AI dapat keliru."
)

/** Online-only solver. For photo questions, a vision-capable model must receive the actual image. */
class AiProvider(private val context: Context) {
    suspend fun solveAuto(ocrText: String, imageUri: Uri? = null): AiResult {
        val text = ocrText.trim()
        if (text.isBlank() && imageUri == null) throw IllegalArgumentException("Ketik soal atau pilih gambar terlebih dahulu.")
        if (!NetworkUtils.isOnline(context)) throw IllegalStateException("Tidak ada koneksi internet. Jawaban soal memerlukan AI online.")
        val providers = AiPreferences.providerOrder(context)
        fun hasKey(provider: String): Boolean = when (provider) {
            AiPreferences.GEMINI -> AiKeyStore.geminiKey(context).isNotBlank()
            AiPreferences.OPENROUTER -> AiKeyStore.openRouterKey(context).isNotBlank()
            AiPreferences.GROQ -> AiKeyStore.groqKey(context).isNotBlank()
            AiPreferences.CEREBRAS -> AiKeyStore.cerebrasKey(context).isNotBlank()
            else -> false
        }
        if (providers.none(::hasKey)) {
            val message = if (AiPreferences.getPriority(context) == AiPreferences.AUTO) {
                "Mode Auto gratis memerlukan API key Gemini atau OpenRouter. Simpan salah satunya di Pengaturan."
            } else {
                "API key untuk provider terpilih belum disimpan. Buka Pengaturan atau pilih provider lain."
            }
            throw IllegalStateException(message)
        }

        val encodedImage = imageUri?.let { uri ->
            withContext(kotlinx.coroutines.Dispatchers.IO) { ImageUtils.encodeForAi(context, uri) }
                ?: throw IllegalStateException("Gambar tidak bisa dibaca untuk AI. Crop ulang, pilih gambar lain, atau ketik soal.")
        }
        val safeText = text.take(10000).ifBlank { "OCR tidak menemukan teks yang bisa dipercaya; baca seluruh soal langsung dari gambar terlampir." }
        val textPrompt = buildPrompt(safeText, false)
        val visualPrompt = buildPrompt(safeText, encodedImage != null)
        val response = withTimeoutOrNull(150000L) {
            var winnerProvider: String? = null
            var winner: AiResult? = null
            for (provider in providers) {
                val answer = tryProvider(provider, visualPrompt, textPrompt, encodedImage)
                if (answer != null) { winnerProvider = provider; winner = answer; break }
            }
            val first = winner ?: return@withTimeoutOrNull null
            // Photo questions get a separate second-model audit where another configured vision provider exists.
            if (encodedImage != null && winnerProvider != null) {
                val second = verifyWithSecondModel(safeText, encodedImage, first, winnerProvider!!)
                if (second != null) second.copy(
                    catatan = (second.catatan + " Pemeriksaan silang dilakukan dengan model lain. Cocokkan tetap dengan soal asli.").take(1800)
                ) else first.copy(
                    catatan = (first.catatan + " Pemeriksaan silang tidak tersedia; hanya satu model berhasil menjawab gambar ini.").take(1800)
                )
            } else first
        }
        return response ?: throw IllegalStateException("Semua model AI gagal, tidak mendukung gambar, atau kuotanya habis. Coba ganti model/provider di Pengaturan atau gunakan foto yang lebih jelas.")
    }

    private fun buildPrompt(text: String, imageAttached: Boolean) = """
Anda tutor sekolah yang sangat teliti untuk SMP/SMA/SMK. Jawab dalam Bahasa Indonesia.
Aturan anti-tebakan:
- Baca soal apa adanya, jangan mengarang atau memperbaiki angka, simbol, satuan, nama, opsi, atau tanggal tanpa bukti.
- __IMAGE_SOURCE_RULE__
- Jika soal berupa gambar, baca bentuk pecahan bertumpuk, garis pembagian, akar (√), pangkat, indeks, tanda negatif, simbol < dan >, serta koma/titik. Jangan mengubah pecahan menjadi teks samar. Tulis notasi yang bisa dibaca langsung: (a+b)/(c+d), √(x), x², ½; jangan keluarkan LaTeX mentah seperti \frac{a}{b}. Untuk pecahan bertumpuk, tentukan pembilang dan penyebut dari gambar sebelum menulis ulang. Jika soal hanya teks, pertahankan simbol yang diketik.
- Untuk pilihan ganda, sebut opsi serta alasan. Untuk hitungan, tunjukkan rumus, substitusi, hasil dan cek ulang. Untuk esai, jawab sesuai perintah.
- Jika gambar buram, terpotong, angka/simbol ambigu, opsi tidak terlihat, atau data soal tak lengkap, jangan memilih jawaban spekulatif. Jelaskan bagian yang tidak terbaca dan minta foto/crop yang lebih jelas.
- Gambar adalah sumber utama. OCR yang diberikan mungkin salah; koreksi OCR dengan melihat piksel gambar dan abaikan OCR jika tidak cocok.
- Periksa ulang hasil hitungan/fakta dan konsistensi langkah sebelum menjawab. Jangan pernah menjamin akurasi 100%.
Keluarkan JSON valid saja dengan skema:
{"jawaban_akhir":"...","langkah":["..."],"mapel":"...","metode_alternatif":["..."],"catatan":"ketidakjelasan/asumsi/verifikasi"}
Semua nilai harus string atau array string. Tanpa markdown fence.

OCR (RUJUKAN SEKUNDER, MUNGKIN SALAH):
$text
""".trimIndent().replace("__IMAGE_SOURCE_RULE__", if (imageAttached) "SOAL BERUPA GAMBAR TERLAMPIR: teliti gambar itu langsung. Jika tulisan tangan tidak terbaca, jangan menebak." else "Tidak ada gambar; gunakan teks yang diketik pengguna.")

    private suspend fun tryProvider(provider: String, prompt: String, textPrompt: String, image: ImageUtils.EncodedImage?): AiResult? = when (provider) {
        AiPreferences.GEMINI -> tryGemini(prompt, textPrompt, image)
        AiPreferences.OPENROUTER -> tryOpenRouter(prompt, textPrompt, image)
        AiPreferences.GROQ -> tryGroq(prompt, textPrompt, image)
        AiPreferences.CEREBRAS -> if (image == null) tryCerebras(textPrompt) else null // Current flow intentionally refuses text-only fallback for a photo.
        else -> null
    }

    private suspend fun tryGemini(prompt: String, textPrompt: String, image: ImageUtils.EncodedImage?): AiResult? {
        val key = AiKeyStore.geminiKey(context)
        if (key.isBlank()) return null
        val api = GeminiApi()
        val active = api.listModels(key)
        val selected = AiPreferences.getSelectedModel(context, AiPreferences.GEMINI)
        val models = (listOf(selected.takeUnless { it == AiPreferences.MODEL_AUTO }).filterNotNull() + active).distinct().filter { it in active }
        for (model in models.take(3)) {
            // If a photo was supplied, only accept a response that actually included the image.
            val raw = if (image != null) api.askGemini(prompt, key, model, image) else api.askGemini(textPrompt, key, model, null)
            if (!raw.isNullOrBlank()) JsonParser.parse(raw, "Gemini · $model")?.let { return it }
        }
        return null
    }

    private suspend fun tryOpenRouter(prompt: String, textPrompt: String, image: ImageUtils.EncodedImage?): AiResult? {
        val key = AiKeyStore.openRouterKey(context)
        if (key.isBlank()) return null
        val api = OpenRouterApi()
        val selected = AiPreferences.getSelectedModel(context, AiPreferences.OPENROUTER)
        if (image != null) {
            val candidates = buildList {
                if (selected == "openrouter/free" || selected == AiPreferences.MODEL_AUTO) add("openrouter/free")
                else if (selected.endsWith(":free")) add(selected)
                addAll(api.listFreeVisionModels(key))
                add("openrouter/free")
            }.distinct()
            for (model in candidates.take(8)) {
                val raw = api.askOpenRouter(prompt, key, model, image) ?: continue
                JsonParser.parse(raw, "OpenRouter Vision · $model")?.let { return it }
            }
            return null
        }
        val candidates = buildList {
            if (selected == AiPreferences.MODEL_AUTO || selected == "openrouter/free") add("openrouter/free")
            else if (selected.endsWith(":free")) add(selected)
            addAll(api.listFreeModels(key))
            add("openrouter/free")
        }.distinct()
        for (model in candidates.take(8)) {
            val raw = api.askOpenRouter(textPrompt, key, model) ?: continue
            JsonParser.parse(raw, "OpenRouter · $model")?.let { return it }
        }
        return null
    }

    private suspend fun tryGroq(prompt: String, textPrompt: String, image: ImageUtils.EncodedImage?): AiResult? {
        val key = AiKeyStore.groqKey(context)
        if (key.isBlank()) return null
        val api = OpenAiCompatibleApi("https://api.groq.com/openai/v1")
        val active = api.listModels(key).toSet()
        val selected = AiPreferences.getSelectedModel(context, AiPreferences.GROQ)
        val candidates = if (image != null) {
            // Groq documents this model as vision-capable; do not assume every /models entry accepts images.
            val visionModel = "qwen/qwen3.8-27b"
            if ((selected == AiPreferences.MODEL_AUTO || selected == visionModel) && visionModel in active) listOf(visionModel) else emptyList()
        } else {
            (listOfNotNull(selected.takeUnless { it == AiPreferences.MODEL_AUTO }?.takeIf { it in active }) +
                listOf("openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b").filter { it in active }).distinct()
        }
        for (model in candidates.take(3)) {
            val raw = api.ask(if (image != null) prompt else textPrompt, key, model, image) ?: continue
            JsonParser.parse(raw, "Groq · $model")?.let { return it }
        }
        return null
    }

    private suspend fun tryCerebras(textPrompt: String): AiResult? {
        val key = AiKeyStore.cerebrasKey(context)
        if (key.isBlank()) return null
        val api = OpenAiCompatibleApi("https://api.cerebras.ai/v1")
        val active = api.listModels(key).toSet()
        val selected = AiPreferences.getSelectedModel(context, AiPreferences.CEREBRAS)
        val candidates = (listOf(selected.takeUnless { it == AiPreferences.MODEL_AUTO }) +
            listOf("llama3.1-8b", "gpt-oss-120b", "llama-3.3-70b")).filterNotNull().filter { it in active }.distinct()
        for (model in candidates.take(3)) {
            val raw = api.ask(textPrompt, key, model) ?: continue
            JsonParser.parse(raw, "Cerebras · $model")?.let { return it }
        }
        return null
    }

    private suspend fun verifyWithSecondModel(
        text: String,
        image: ImageUtils.EncodedImage,
        first: AiResult,
        firstProvider: String
    ): AiResult? {
        val auditProviders = when (firstProvider) {
            AiPreferences.GEMINI -> listOf(AiPreferences.OPENROUTER)
            AiPreferences.OPENROUTER -> listOf(AiPreferences.GEMINI)
            AiPreferences.GROQ, AiPreferences.CEREBRAS -> listOf(AiPreferences.GEMINI, AiPreferences.OPENROUTER)
            else -> listOf(AiPreferences.GEMINI, AiPreferences.OPENROUTER).filter { it != firstProvider }
        }
        val auditPrompt = """
Anda reviewer independen untuk jawaban soal sekolah. Periksa gambar asli dengan teliti, terutama angka, tanda minus, pangkat, akar, pecahan, garis pecahan, dan opsi jawaban. OCR bisa salah. Audit jawaban kandidat di bawah. Jika benar, pertahankan; jika salah, perbaiki; jika gambar tidak cukup jelas, jangan menebak dan katakan bagian yang perlu difoto ulang. Hitung ulang secara mandiri dan cari inkonsistensi.
Kandidat model pertama:
Jawaban: ${first.jawabanAkhir}
Langkah: ${first.langkah.joinToString(" | ")}
Catatan: ${first.catatan}
OCR rujukan sekunder (dapat salah): $text
Keluarkan JSON valid dengan skema {"jawaban_akhir":"...","langkah":["..."],"mapel":"...","metode_alternatif":["..."],"catatan":"hasil audit"}. Gambar terlampir adalah sumber utama.
""".trimIndent()
        for (provider in auditProviders) {
            val reviewed = tryProvider(provider, auditPrompt, auditPrompt, image)
            if (reviewed != null) return reviewed
        }
        return null
    }
}
