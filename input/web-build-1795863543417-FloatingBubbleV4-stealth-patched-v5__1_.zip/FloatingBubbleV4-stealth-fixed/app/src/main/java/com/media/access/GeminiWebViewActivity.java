// GeminiWebViewActivity.java : java, Android 29+, com.media.access
// v3: image attachment (Gemini Vision).
// v4-coloros: direct wlp.width/height, pre-content sizing, 4-point apply, correct JS compare.
package com.media.access;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;

public class GeminiWebViewActivity extends Activity {

    public static final String EXTRA_QUERY      = "query";
    public static final String EXTRA_IMAGE_PATH = "image_path";

    private static final String GEMINI_URL = "https://gemini.google.com/app";
    private static final String UA =
            "Mozilla/5.0 (Linux; Android 11; Pixel 5) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36";

    private static final int REQ_FILE = 3001;

    // 72% wide x 70% tall
    private static final float PANEL_W_RATIO = 0.72f;
    private static final float PANEL_H_RATIO = 0.70f;

    private WebView      webView;
    private LinearLayout root;
    private String   query     = "";
    private String   imagePath = null;
    private boolean  injected  = false;

    private ValueCallback<Uri[]> filePathCallback;
    private Uri                  pendingImageUri;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        // ── ColorOS pre-content sizing ────────────────────────────────────────
        applyPanelSize();

        query     = getIntent().getStringExtra(EXTRA_QUERY);
        imagePath = getIntent().getStringExtra(EXTRA_IMAGE_PATH);
        if (query == null) query = "";

        if (imagePath != null && !imagePath.isEmpty()) {
            pendingImageUri = uriFromPath(imagePath);
        }

        // ── root — black glass panel ──────────────────────────────────────────
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable panelBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF181818, 0xFF080808});
        panelBg.setCornerRadius(px(18));
        root.setBackground(panelBg);
        root.setClipToOutline(true);
        root.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        // ── top bar ───────────────────────────────────────────────────────────
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);

        GradientDrawable topBarBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF242424, 0xFF161616});
        topBarBg.setCornerRadii(new float[]{
                px(18), px(18), px(18), px(18), 0, 0, 0, 0});
        topBar.setBackground(topBarBg);
        topBar.setPadding(px(12), px(12), px(14), px(12));

        ImageButton closeBtn = new ImageButton(this);
        closeBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeBtn.setBackgroundColor(Color.TRANSPARENT);
        closeBtn.setColorFilter(Color.WHITE);
        closeBtn.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp =
                new LinearLayout.LayoutParams(px(36), px(36));
        closeLp.setMargins(0, 0, px(8), 0);
        topBar.addView(closeBtn, closeLp);

        TextView titleTv = new TextView(this);
        titleTv.setText(imagePath != null ? "Gemini Vision" : "Gemini AI");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(16f);
        topBar.addView(titleTv, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // ── image preview chip ────────────────────────────────────────────────
        if (pendingImageUri != null) {
            LinearLayout imgChip = new LinearLayout(this);
            imgChip.setOrientation(LinearLayout.HORIZONTAL);
            imgChip.setGravity(Gravity.CENTER_VERTICAL);
            imgChip.setBackgroundColor(0xFF111111);
            imgChip.setPadding(px(10), px(8), px(8), px(8));

            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Bitmap bmp = loadThumbnail(imagePath);
            if (bmp != null) thumb.setImageBitmap(bmp);
            else            thumb.setImageResource(android.R.drawable.ic_menu_camera);
            LinearLayout.LayoutParams thumbLp =
                    new LinearLayout.LayoutParams(px(52), px(52));
            thumbLp.setMargins(0, 0, px(10), 0);
            imgChip.addView(thumb, thumbLp);

            TextView lbl = new TextView(this);
            lbl.setText("Gambar siap — klik ikon \uD83D\uDCCE di Gemini\natau gunakan tombol Kirim \u2192");
            lbl.setTextColor(0xFFCCCCCC);
            lbl.setTextSize(11.5f);
            imgChip.addView(lbl, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button sendImgBtn = new Button(this);
            sendImgBtn.setText("Kirim \u2192");
            GradientDrawable sib = new GradientDrawable();
            sib.setColor(0xFF242424);
            sib.setCornerRadius(px(8));
            sendImgBtn.setBackground(sib);
            sendImgBtn.setTextColor(Color.WHITE);
            sendImgBtn.setTextSize(11.5f);
            sendImgBtn.setAllCaps(false);
            sendImgBtn.setPadding(px(12), px(6), px(12), px(6));
            sendImgBtn.setOnClickListener(v -> triggerImageAttach());
            imgChip.addView(sendImgBtn);

            root.addView(imgChip, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        // ── text query chip ───────────────────────────────────────────────────
        if (!query.isEmpty()) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setBackgroundColor(0xFF0E0E0E);
            chip.setPadding(px(12), px(8), px(8), px(8));

            TextView queryTv = new TextView(this);
            String display = query.length() > 110
                    ? query.substring(0, 110) + "\u2026" : query;
            queryTv.setText(display);
            queryTv.setTextColor(0xFFCCCCCC);
            queryTv.setTextSize(12f);
            queryTv.setMaxLines(2);
            chip.addView(queryTv, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button copyBtn = new Button(this);
            copyBtn.setText("Salin");
            copyBtn.setBackground(null);
            copyBtn.setTextColor(0xFFAAAAAA);
            copyBtn.setTextSize(11.5f);
            copyBtn.setAllCaps(false);
            copyBtn.setOnClickListener(v -> copyToClipboard());
            chip.addView(copyBtn);

            Button sendBtn = new Button(this);
            sendBtn.setText("Kirim \u2192");
            GradientDrawable sb = new GradientDrawable();
            sb.setColor(0xFF242424);
            sb.setCornerRadius(px(8));
            sendBtn.setBackground(sb);
            sendBtn.setTextColor(Color.WHITE);
            sendBtn.setTextSize(11.5f);
            sendBtn.setAllCaps(false);
            sendBtn.setPadding(px(14), px(6), px(14), px(6));
            sendBtn.setOnClickListener(v -> injectText());
            chip.addView(sendBtn);

            root.addView(chip, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        // ── webview ───────────────────────────────────────────────────────────
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0D0D0D);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setSupportZoom(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setUserAgentString(UA);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);

        // Masks WebView automation fingerprint so Gemini and any embedded portal
        // treats this as a regular Chrome browser, not an automated WebView.
        final String STEALTH_JS =
            "(function(){"
            + "try{"
            + "  Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
            + "  Object.defineProperty(navigator,'plugins',{get:()=>[1,2,3,4,5]});"
            + "  Object.defineProperty(navigator,'languages',{get:()=>['id-ID','id','en-US','en']});"
            + "  window.chrome={runtime:{}};"
            + "  delete window.callPhantom;"
            + "  delete window._phantom;"
            + "}catch(e){}"
            + "})()";

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                view.evaluateJavascript(STEALTH_JS, null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!query.isEmpty() && !injected) {
                    view.postDelayed(GeminiWebViewActivity.this::injectText, 2200);
                }
                if (pendingImageUri != null && !injected) {
                    view.postDelayed(GeminiWebViewActivity.this::triggerImageAttach, 2500);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv,
                    ValueCallback<Uri[]> fileCb,
                    FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = fileCb;

                if (pendingImageUri != null) {
                    Uri img = pendingImageUri;
                    pendingImageUri = null;
                    filePathCallback.onReceiveValue(new Uri[]{img});
                    filePathCallback = null;
                    injected = true;
                    return true;
                }

                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("image/*");
                startActivityForResult(
                        Intent.createChooser(intent, "Pilih Gambar"), REQ_FILE);
                return true;
            }
        });

        webView.loadUrl(GEMINI_URL);

        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        // post-layout pass
        root.post(this::applyPanelSize);
    }

    // ── four sizing points ────────────────────────────────────────────────────

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        applyPanelSize();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyPanelSize();
    }

    /**
     * Direct wlp.width/height assignment — bypasses ColorOS setLayout() intercept.
     * Also calls setLayout() for stock Android / other OEMs that honour it.
     */
    private void applyPanelSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = (int)(dm.widthPixels  * PANEL_W_RATIO);
        int h = (int)(dm.heightPixels * PANEL_H_RATIO);

        Window win = getWindow();
        win.setLayout(w, h);

        WindowManager.LayoutParams wlp = win.getAttributes();
        wlp.width   = w;
        wlp.height  = h;
        wlp.gravity = Gravity.CENTER;
        wlp.x = 0;
        wlp.y = 0;
        wlp.flags    |= WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        wlp.dimAmount = 0.55f;
        win.setAttributes(wlp);
    }

    // ── lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    // ── image attachment ──────────────────────────────────────────────────────

    private void triggerImageAttach() {
        if (webView == null || pendingImageUri == null) return;
        String js =
            "(function(){"
            + "var s=['input[type=file]','button[aria-label*=\"image\"]',"
            + "'button[aria-label*=\"Upload\"]','button[aria-label*=\"Attach\"]',"
            + "'.upload-button','[data-tooltip*=\"image\"]'];"
            + "for(var i=0;i<s.length;i++){var e=document.querySelector(s[i]);"
            + "if(e){e.click();return 'clicked';}}"
            + "return 'not_found';})()";
        webView.evaluateJavascript(js, r -> {});
    }

    // ── text injection ────────────────────────────────────────────────────────

    private void injectText() {
        if (webView == null || query.isEmpty()) return;
        injected = true;
        String safe = query
                .replace("\\", "\\\\")
                .replace("'",  "\\'")
                .replace("\n", "\\n")
                .replace("\r", "");
        String js =
            "(function(){"
            + "var s=['[aria-label=\"Enter a prompt here\"]','p[data-placeholder]',"
            + "'.ql-editor','[contenteditable=true]','textarea'];"
            + "for(var i=0;i<s.length;i++){var e=document.querySelector(s[i]);"
            + "if(e){e.focus();"
            + "if(e.tagName==='TEXTAREA'){e.value='" + safe + "';}"
            + "else{e.textContent='" + safe + "';}"
            + "e.dispatchEvent(new Event('input',{bubbles:true}));"
            + "e.dispatchEvent(new Event('change',{bubbles:true}));"
            + "return 'ok';}}"
            + "return 'miss';})()";
        webView.evaluateJavascript(js, result -> runOnUiThread(() -> {
            if (!("\"ok\"".equals(result))) {
                copyToClipboard();
                Toast.makeText(this,
                        "Auto-inject gagal \u2014 teks sudah disalin, tempel manual",
                        Toast.LENGTH_LONG).show();
            }
        }));
    }

    private void copyToClipboard() {
        ClipboardManager cm =
                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null)
            cm.setPrimaryClip(ClipData.newPlainText("gemini_query", query));
    }

    // ── utils ─────────────────────────────────────────────────────────────────

    private Uri uriFromPath(String path) {
        if (path == null) return null;
        try {
            File f = new File(path);
            if (!f.exists()) return null;
            try {
                return FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", f);
            } catch (Exception ex) {
                return Uri.fromFile(f);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private Bitmap loadThumbnail(String path) {
        if (path == null) return null;
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 4;
            return BitmapFactory.decodeFile(path, opts);
        } catch (Exception e) {
            return null;
        }
    }

    private int px(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
