// BubbleService.java : java, Android 29+, com.media.access
// v4: LocalBroadcastManager (intra-process, hidden from other apps),
//     ML Kit OCR path for text-dest camera/gallery captures,
//     notification renamed to generic "Display Service".
package com.media.access;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.graphics.Outline;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class BubbleService extends Service {

    public static final String ACTION_SETTINGS_CHANGED = "da.SETTINGS_CHANGED";

    private static final String CHANNEL_ID = "dsp_ch";
    private static final int    NOTIF_ID   = 42;

    private WindowManager windowManager;
    private BubbleView    bubbleView;
    private View          panelView;
    private WindowManager.LayoutParams bubbleParams;
    private boolean       panelShown = false;

    private View          cropOverlayView;

    private ScanSettingDialog scanSettingDialog;

    private int screenWidth, screenHeight;

    private BroadcastReceiver textExtractedRx;
    private BroadcastReceiver settingsRx;

    // ── lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIF_ID, buildNotification());
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth  = dm.widthPixels;
        screenHeight = dm.heightPixels;
        scanSettingDialog = new ScanSettingDialog(this, windowManager);
        registerReceivers();
        addBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        scanSettingDialog.dismiss();
        safeRemove(bubbleView);
        if (panelShown) safeRemove(panelView);
        safeRemove(cropOverlayView);
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
        try { lbm.unregisterReceiver(textExtractedRx); } catch (Exception ignored) {}
        try { lbm.unregisterReceiver(settingsRx);       } catch (Exception ignored) {}
    }

    // ── receivers ─────────────────────────────────────────────────────────────

    private void registerReceivers() {
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);

        textExtractedRx = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                String text = intent.getStringExtra(DisplayAccessService.EXTRA_TEXT);
                if (text == null || text.trim().isEmpty()) {
                    // On API 29: neither accessibility tree nor pixel OCR available.
                    // Suggest camera OCR as fallback.
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                        Toast.makeText(BubbleService.this,
                                "Konten ini berupa gambar — tidak ada teks UI.\n" +
                                "Pakai tombol Kamera untuk foto layar → OCR otomatis.",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(BubbleService.this,
                                "Tidak ada teks terdeteksi di area itu.",
                                Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
                routeText(text.trim());
            }
        };
        lbm.registerReceiver(textExtractedRx,
                new IntentFilter(DisplayAccessService.ACTION_TEXT_EXTRACTED));

        settingsRx = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) { applySettings(); }
        };
        lbm.registerReceiver(settingsRx, new IntentFilter(ACTION_SETTINGS_CHANGED));
    }

    // ── bubble ────────────────────────────────────────────────────────────────

    private void addBubble() {
        int sz = dp(SharedPrefHelper.getBubbleSizeDp(this));
        bubbleView = new BubbleView(this);

        bubbleParams = new WindowManager.LayoutParams(
                sz, sz,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                // FLAG_SECURE: bubble will not appear in screenshots or screen recordings
                // taken by exam apps that use MediaProjection for screen monitoring.
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = screenWidth - sz - dp(8);
        bubbleParams.y = dp(200);

        attachTouch(bubbleView, bubbleParams);
        windowManager.addView(bubbleView, bubbleParams);
        applySettings();
    }

    private void applySettings() {
        if (bubbleView == null) return;
        bubbleView.setShape(SharedPrefHelper.getBubbleShape(this));
        int color = SharedPrefHelper.getBubbleColor(this);
        int alpha = SharedPrefHelper.getBubbleAlpha(this);
        bubbleView.setFillColor(color);
        bubbleView.setAlpha(alpha / 255f);
        int sz = dp(SharedPrefHelper.getBubbleSizeDp(this));
        if (bubbleParams.width != sz) {
            bubbleParams.width  = sz;
            bubbleParams.height = sz;
            try { windowManager.updateViewLayout(bubbleView, bubbleParams); } catch (Exception ignored) {}
        }
    }

    // ── touch / drag / snap ───────────────────────────────────────────────────

    private void attachTouch(View view, WindowManager.LayoutParams params) {
        int[] initPos    = new int[2];
        float[] initTouch = new float[2];
        long[] t0        = new long[1];

        view.setOnTouchListener((v, ev) -> {
            switch (ev.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initPos[0]   = params.x;
                    initPos[1]   = params.y;
                    initTouch[0] = ev.getRawX();
                    initTouch[1] = ev.getRawY();
                    t0[0]        = System.currentTimeMillis();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    params.x = initPos[0] + (int)(ev.getRawX() - initTouch[0]);
                    params.y = initPos[1] + (int)(ev.getRawY() - initTouch[1]);
                    windowManager.updateViewLayout(view, params);
                    return true;

                case MotionEvent.ACTION_UP:
                    float dx = Math.abs(ev.getRawX() - initTouch[0]);
                    float dy = Math.abs(ev.getRawY() - initTouch[1]);
                    if (System.currentTimeMillis() - t0[0] < 220 && dx < 12 && dy < 12) {
                        togglePanel();
                    } else {
                        snapToEdge(params, view);
                    }
                    return true;
            }
            return false;
        });
    }

    private void snapToEdge(WindowManager.LayoutParams p, View v) {
        int center = p.x + v.getWidth() / 2;
        int target = (center < screenWidth / 2) ? dp(8) : screenWidth - v.getWidth() - dp(8);
        animX(p, v, target);
    }

    private void animX(WindowManager.LayoutParams p, View v, int targetX) {
        final int  start = p.x;
        final int  dist  = targetX - start;
        final long t0    = System.currentTimeMillis();
        final long dur   = 180L;
        v.post(new Runnable() {
            @Override public void run() {
                float t = Math.min(1f, (System.currentTimeMillis() - t0) / (float) dur);
                t = 1f - (1f - t) * (1f - t);
                p.x = start + (int)(dist * t);
                try { windowManager.updateViewLayout(v, p); } catch (Exception ignored) {}
                if (t < 1f) v.postDelayed(this, 8);
            }
        });
    }

    // ── pill menu ─────────────────────────────────────────────────────────────

    private void togglePanel() {
        if (panelShown) {
            safeRemove(panelView);
            panelShown = false;
        } else {
            panelView = buildPillMenu();
            int menuSizePx = dp(SharedPrefHelper.getMenuSizeDp(this));
            int itemCount  = 7;
            int panelW     = menuSizePx + dp(20);
            int panelH     = itemCount * (menuSizePx + dp(12)) + dp(24);

            WindowManager.LayoutParams pp = new WindowManager.LayoutParams(
                    panelW, panelH,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_SECURE,
                    PixelFormat.TRANSLUCENT);
            pp.gravity = Gravity.TOP | Gravity.START;
            boolean onRight = bubbleParams.x > screenWidth / 2;
            pp.x = onRight ? bubbleParams.x - panelW - dp(4) : bubbleParams.x + bubbleParams.width + dp(4);
            pp.y = bubbleParams.y;
            windowManager.addView(panelView, pp);
            panelShown = true;
        }
    }

    private View buildPillMenu() {
        int menuSizePx = dp(SharedPrefHelper.getMenuSizeDp(this));

        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.VERTICAL);
        pill.setGravity(Gravity.CENTER_HORIZONTAL);
        pill.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        pill.setBackground(getDrawable(R.drawable.panel_glass));
        pill.setClipToOutline(true);
        pill.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(28));
            }
        });
        pill.setPadding(0, dp(10), 0, dp(10));

        pill.addView(pillItem(R.drawable.ic_search,       menuSizePx, v -> { closePanel(); launchWeb(WebActivity.MODE_SEARCH, ""); }));
        pill.addView(pillItem(R.drawable.ic_sparkle,      menuSizePx, v -> { closePanel(); onSparkle(); }));
        pill.addView(pillItem(R.drawable.ic_globe,        menuSizePx, v -> { closePanel(); launchGemini("", null); }));
        pill.addView(pillItem(R.drawable.ic_translate,    menuSizePx, v -> { closePanel(); launchWeb(WebActivity.MODE_TRANSLATE, ""); }));
        pill.addView(pillItem(R.drawable.ic_gallery,      menuSizePx, v -> { closePanel(); launchCamera(CameraProxyActivity.MODE_GALLERY); }));
        pill.addView(pillItem(R.drawable.ic_camera,       menuSizePx, v -> { closePanel(); launchCamera(CameraProxyActivity.MODE_CAMERA); }));
        pill.addView(pillItem(R.drawable.ic_scan_setting, menuSizePx, v -> { closePanel(); toggleScanSetting(); }));

        return pill;
    }

    private View pillItem(int iconRes, int sizePx, View.OnClickListener listener) {
        ImageButton btn = new ImageButton(this);
        btn.setImageDrawable(getDrawable(iconRes));
        btn.setScaleType(ImageButton.ScaleType.CENTER_INSIDE);
        btn.setBackground(getDrawable(R.drawable.pill_button_bg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sizePx, sizePx);
        lp.setMargins(0, dp(5), 0, dp(5));
        btn.setLayoutParams(lp);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void closePanel() {
        if (panelShown) { safeRemove(panelView); panelShown = false; }
    }

    // ── scan setting ──────────────────────────────────────────────────────────

    private void toggleScanSetting() {
        if (scanSettingDialog.isVisible()) {
            scanSettingDialog.dismiss();
        } else {
            int dialogX = Math.max(dp(16), bubbleParams.x - dp(310));
            int dialogY = Math.max(dp(60), bubbleParams.y);
            scanSettingDialog.show(dialogX, dialogY);
        }
    }

    // ── sparkle / crop flow ───────────────────────────────────────────────────

    private void onSparkle() {
        if (!DisplayAccessService.isEnabled(this)) {
            Toast.makeText(this,
                    "Aktifkan aksesibilitas:\nPengaturan → Aksesibilitas → Display Access",
                    Toast.LENGTH_LONG).show();
            Intent acc = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            acc.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(acc);
            return;
        }
        showCropOverlay();
    }

    private void showCropOverlay() {
        if (cropOverlayView != null) return;
        float lineThick = SharedPrefHelper.getLineThicknessDp(this);
        int   lineColor = SharedPrefHelper.getLineColor(this);

        CropOverlayView ov = new CropOverlayView(this, lineThick, lineColor);
        ov.setListener(new CropOverlayView.OnCropListener() {
            @Override public void onConfirm(Rect cropRect) {
                // Remove overlay first so the app behind reclaims the active window.
                // 300ms delay lets the system register the focus shift before we query it.
                removeCropOverlay();
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                    Intent intent = new Intent(DisplayAccessService.ACTION_CROP_CONFIRM);
                    intent.putExtra(DisplayAccessService.EXTRA_RECT_LEFT,   cropRect.left);
                    intent.putExtra(DisplayAccessService.EXTRA_RECT_TOP,    cropRect.top);
                    intent.putExtra(DisplayAccessService.EXTRA_RECT_RIGHT,  cropRect.right);
                    intent.putExtra(DisplayAccessService.EXTRA_RECT_BOTTOM, cropRect.bottom);
                    LocalBroadcastManager.getInstance(BubbleService.this).sendBroadcast(intent);
                }, 300);
            }
            @Override public void onCancel() { removeCropOverlay(); }
        });

        WindowManager.LayoutParams op = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        op.gravity = Gravity.TOP | Gravity.START;
        cropOverlayView = ov;
        windowManager.addView(cropOverlayView, op);
    }

    private void removeCropOverlay() {
        if (cropOverlayView != null) { safeRemove(cropOverlayView); cropOverlayView = null; }
    }

    // ── routing ───────────────────────────────────────────────────────────────

    private void routeText(String text) {
        int dest = SharedPrefHelper.getTextDest(this);
        switch (dest) {
            case SharedPrefHelper.DEST_AI:
                launchGemini(text, null);
                break;
            case SharedPrefHelper.DEST_TRANSLATE:
                launchWeb(WebActivity.MODE_TRANSLATE, text);
                break;
            case SharedPrefHelper.DEST_SEARCH:
            default:
                launchWeb(WebActivity.MODE_SEARCH, text);
                break;
        }
    }

    // ── launches ──────────────────────────────────────────────────────────────

    private void launchGemini(String text, String imagePath) {
        Intent intent = new Intent(this, GeminiWebViewActivity.class);
        intent.putExtra(GeminiWebViewActivity.EXTRA_QUERY, text);
        if (imagePath != null && !imagePath.isEmpty())
            intent.putExtra(GeminiWebViewActivity.EXTRA_IMAGE_PATH, imagePath);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    private void launchWeb(int mode, String query) {
        Intent intent = new Intent(this, WebActivity.class);
        intent.putExtra(WebActivity.EXTRA_MODE, mode);
        intent.putExtra(WebActivity.EXTRA_QUERY, query);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    private void launchCamera(int mode) {
        Intent intent = new Intent(this, CameraProxyActivity.class);
        intent.putExtra(CameraProxyActivity.EXTRA_MODE, mode);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    // ── notification ──────────────────────────────────────────────────────────

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notif_channel_name),
                    NotificationManager.IMPORTANCE_MIN);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        // Generic system-looking notification — minimises exam app suspicion.
        // No text body, lowest-priority channel, system stat icon.
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("System UI Service")
                .setContentText("")
                .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .build();
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private void safeRemove(View v) {
        if (v == null) return;
        try { windowManager.removeView(v); } catch (Exception ignored) {}
    }

    private int dp(int v)   { return (int)(v * getResources().getDisplayMetrics().density); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
}
