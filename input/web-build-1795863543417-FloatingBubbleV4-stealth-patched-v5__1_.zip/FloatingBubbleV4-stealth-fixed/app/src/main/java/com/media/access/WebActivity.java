// WebActivity.java : java, Android 29+, com.media.access
// Generic WebView activity — Google Search, AI Mode, Translate.
// v4-coloros: direct wlp.width/height assignment (setLayout ignored on ColorOS 7/Android10).
//             Four-point sizing: pre-content, post-layout, onAttachedToWindow, onWindowFocusChanged.
package com.media.access;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class WebActivity extends Activity {

    public static final String EXTRA_MODE  = "web_mode";
    public static final String EXTRA_QUERY = "web_query";

    public static final int MODE_SEARCH    = 0;
    public static final int MODE_TRANSLATE = 1;
    public static final int MODE_AI        = 2;

    private static final String UA =
            "Mozilla/5.0 (Linux; Android 11; Pixel 5) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36";

    // 74% wide x 68% tall
    private static final float PANEL_W_RATIO = 0.74f;
    private static final float PANEL_H_RATIO = 0.68f;

    private WebView      webView;
    private LinearLayout root;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        // ── ColorOS pre-content sizing ────────────────────────────────────────
        // Must happen BEFORE setContentView. On ColorOS 7, the window size is
        // committed during the first layout pass triggered by setContentView,
        // so attributes set before that call are the ones that stick.
        applyPanelSize();

        int    mode  = getIntent().getIntExtra(EXTRA_MODE,  MODE_SEARCH);
        String query = getIntent().getStringExtra(EXTRA_QUERY);
        if (query == null) query = "";

        // ── root — black glass panel ──────────────────────────────────────────
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable panelBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF181818, 0xFF080808});
        panelBg.setCornerRadius(px(18));
        root.setBackground(panelBg);
        root.setClipToOutline(true);
        root.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        // ── top bar ───────────────────────────────────────────────────────────
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);

        GradientDrawable topBarBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF242424, 0xFF161616});
        topBarBg.setCornerRadii(new float[]{
                px(18), px(18), px(18), px(18), 0, 0, 0, 0});
        topBar.setBackground(topBarBg);
        topBar.setPadding(px(12), px(12), px(14), px(12));

        ImageButton closeBtn = new ImageButton(this);
        closeBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeBtn.setBackgroundColor(Color.TRANSPARENT);
        closeBtn.setColorFilter(Color.WHITE);
        closeBtn.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp =
                new LinearLayout.LayoutParams(px(36), px(36));
        closeLp.setMargins(0, 0, px(8), 0);
        topBar.addView(closeBtn, closeLp);

        TextView titleTv = new TextView(this);
        titleTv.setText(modeTitle(mode));
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(16f);
        topBar.addView(titleTv, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // ── webview ───────────────────────────────────────────────────────────
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0D0D0D);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setUserAgentString(UA);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // JS injected at page-start so it runs BEFORE the exam portal's own scripts.
        // Masks WebView fingerprint: navigator.webdriver (automation flag), plugins
        // array (empty in WebView, non-empty in real Chrome), and languages.
        // Portal exam online yang cek navigator.webdriver akan dapat undefined — sama
        // seperti browser biasa, bukan WebView/automation.
        final String STEALTH_JS =
            "(function(){"
            + "try{"
            + "  Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
            + "  Object.defineProperty(navigator,'plugins',{get:()=>[1,2,3,4,5]});"
            + "  Object.defineProperty(navigator,'languages',{get:()=>['id-ID','id','en-US','en']});"
            + "  window.chrome={runtime:{}};"
            + "  delete window.callPhantom;"
            + "  delete window._phantom;"
            + "}catch(e){}"
            + "})()";

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                view.evaluateJavascript(STEALTH_JS, null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String loadUrl) {
                if (loadUrl.startsWith("http://") || loadUrl.startsWith("https://")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(loadUrl)));
                } catch (Exception ignored) {}
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(buildUrl(mode, query));

        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        // post-layout pass — catches devices that apply size after first measure
        root.post(this::applyPanelSize);
    }

    // ── four sizing points ────────────────────────────────────────────────────

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        // ColorOS fires this after the window is registered with WindowManager.
        // Most reliable hook on ColorOS 7 (Android 10).
        applyPanelSize();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyPanelSize();
    }

    /**
     * Sets panel dimensions by writing directly to WindowManager.LayoutParams.
     *
     * ColorOS 7 / Android 10 specific: getWindow().setLayout() is intercepted
     * and silently discarded by the ColorOS window manager fork. The only
     * reliable way to enforce a size is to write wlp.width / wlp.height directly
     * and call setAttributes(), which bypasses the ColorOS override path.
     */
    private void applyPanelSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = (int)(dm.widthPixels  * PANEL_W_RATIO);
        int h = (int)(dm.heightPixels * PANEL_H_RATIO);

        Window win = getWindow();
        // Also call setLayout for non-ColorOS devices that honour it
        win.setLayout(w, h);

        WindowManager.LayoutParams wlp = win.getAttributes();
        // Direct assignment — works on ColorOS where setLayout is a no-op
        wlp.width   = w;
        wlp.height  = h;
        wlp.gravity = Gravity.CENTER;
        wlp.x = 0;
        wlp.y = 0;
        // Ensure dim-behind is applied regardless of theme resolution
        wlp.flags |= WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        wlp.dimAmount = 0.55f;
        win.setAttributes(wlp);
    }

    // ── lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private static String buildUrl(int mode, String query) {
        String enc = Uri.encode(query);
        switch (mode) {
            case MODE_TRANSLATE:
                return query.isEmpty()
                        ? "https://translate.google.com"
                        : "https://translate.google.com/?text=" + enc;
            case MODE_AI:
                return query.isEmpty()
                        ? "https://www.google.com/search?udm=50"
                        : "https://www.google.com/search?q=" + enc + "&udm=50";
            default:
                return query.isEmpty()
                        ? "https://www.google.com"
                        : "https://www.google.com/search?q=" + enc;
        }
    }

    private static String modeTitle(int mode) {
        switch (mode) {
            case MODE_TRANSLATE: return "Google Translate";
            case MODE_AI:        return "Google AI";
            default:             return "Google Search";
        }
    }

    private int px(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
