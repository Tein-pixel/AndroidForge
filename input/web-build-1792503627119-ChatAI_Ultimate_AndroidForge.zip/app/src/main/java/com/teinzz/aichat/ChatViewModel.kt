package com.teinzz.aichat

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teinzz.aichat.data.*
import com.teinzz.aichat.network.AiRepository
import com.teinzz.aichat.network.ProviderException
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).conversations()
    val themeManager = ThemeManager(app)
    private val repository = AiRepository(themeManager)
    val conversations = dao.observeConversations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val messages = mutableStateListOf<MessageEntity>()
    var currentConversationId = mutableStateOf<Long?>(null); private set
    var currentModel = mutableStateOf(ModelCatalog.byId(themeManager.getLastModel())); private set
    var isGenerating = mutableStateOf(false); private set
    var errorMessage = mutableStateOf<String?>(null); private set
    var showPaidModels = mutableStateOf(false); private set
    private var activeSendJob: Job? = null

    init { viewModelScope.launch { runCatching { dao.latest() }.getOrNull()?.let { selectConversation(it.id) } } }
    fun newChat() { activeSendJob?.cancel(); activeSendJob = null; isGenerating.value = false; currentConversationId.value = null; messages.clear(); errorMessage.value = null }
    fun setPaidVisible(value: Boolean) { showPaidModels.value = value }
    fun selectModel(model: AiModel) {
        currentModel.value = model; themeManager.setLastModel(model.id)
        viewModelScope.launch { currentConversationId.value?.let { dao.updateModel(it, model.id) } }
    }
    fun selectConversation(id: Long) {
        activeSendJob?.cancel(); isGenerating.value = false
        viewModelScope.launch {
            val conv = dao.conversation(id)
            currentConversationId.value = id
            if (conv != null) currentModel.value = ModelCatalog.byId(conv.modelId)
            messages.clear(); messages.addAll(dao.messages(id)); errorMessage.value = null
        }
    }
    fun renameConversation(id: Long, title: String) { viewModelScope.launch { dao.rename(id, title.trim().ifBlank { "New chat" }.take(80)) } }
    fun deleteConversation(id: Long) { viewModelScope.launch { dao.deleteMessages(id); dao.deleteConversation(id); if (currentConversationId.value == id) newChat() } }

    fun send(text: String, imagePath: String? = null, attachmentName: String? = null) {
        if (isGenerating.value || (text.isBlank() && imagePath == null)) return
        errorMessage.value = null
        activeSendJob = viewModelScope.launch {
            var assistantId = 0L
            try {
                val previous = messages.toList()
                var conversationId = currentConversationId.value
                if (conversationId == null) {
                    val title = text.trim().ifBlank { if (imagePath != null) "Image analysis" else attachmentName ?: "New chat" }.take(40)
                    conversationId = dao.insertConversation(ConversationEntity(title = title, modelId = currentModel.value.id))
                    currentConversationId.value = conversationId
                }
                val userMessage = MessageEntity(conversationId = conversationId!!, role = "user", content = text, imagePath = imagePath, fileName = attachmentName)
                val userId = dao.insertMessage(userMessage)
                messages.add(userMessage.copy(id = userId))
                dao.touch(conversationId)
                val assistant = MessageEntity(conversationId = conversationId, role = "assistant", content = "")
                assistantId = dao.insertMessage(assistant)
                messages.add(assistant.copy(id = assistantId))
                isGenerating.value = true
                val buffer = StringBuilder()
                var lastPersist = 0L
                repository.stream(currentModel.value, previous, text, imagePath).collect { chunk ->
                    buffer.append(chunk)
                    val index = messages.indexOfLast { it.id == assistantId }
                    if (index >= 0) messages[index] = messages[index].copy(content = buffer.toString())
                    val now = System.currentTimeMillis()
                    if (now - lastPersist > 250) { dao.updateMessage(assistantId, buffer.toString()); lastPersist = now }
                }
                if (buffer.isEmpty()) buffer.append("Model menyelesaikan permintaan tanpa teks. Coba lagi atau pilih model lain.")
                dao.updateMessage(assistantId, buffer.toString())
                val finalIndex = messages.indexOfLast { it.id == assistantId }
                if (finalIndex >= 0) messages[finalIndex] = messages[finalIndex].copy(content = buffer.toString())
                dao.touch(conversationId)
            } catch (t: Throwable) {
                if (t is CancellationException) {
                    if (assistantId != 0L) messages.lastOrNull { it.id == assistantId }?.let { msg -> runCatching { dao.updateMessage(assistantId, msg.content) } }
                    throw t
                }
                val friendly = when (t) {
                    is ProviderException -> t.message ?: "Permintaan gagal."
                    else -> "Tidak dapat terhubung. Periksa internet, API key, model, lalu coba lagi. (${t.javaClass.simpleName})"
                }
                errorMessage.value = friendly
                val last = messages.lastOrNull()
                if (last?.role == "assistant" && last.content.isBlank()) {
                    val idx = messages.lastIndex; messages[idx] = last.copy(content = friendly)
                    runCatching { dao.updateMessage(last.id, friendly) }
                }
            } finally { if (activeSendJob == coroutineContext[kotlinx.coroutines.Job]) { isGenerating.value = false; activeSendJob = null } }
        }
    }

    fun stopGenerating() { activeSendJob?.cancel(); isGenerating.value = false }
    suspend fun testConnection(model: AiModel): String = repository.test(model)
}
