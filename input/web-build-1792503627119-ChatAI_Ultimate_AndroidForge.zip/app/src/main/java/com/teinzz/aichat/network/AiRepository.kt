package com.teinzz.aichat.network

import android.util.Base64
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.Gson
import com.teinzz.aichat.ThemeManager
import com.teinzz.aichat.data.AiModel
import com.teinzz.aichat.data.MessageEntity
import com.teinzz.aichat.data.Provider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class ProviderException(val httpCode: Int, message: String): Exception(message)

class AiRepository(private val keys: ThemeManager) {
    private val api = AiApi.create()
    private val gson = Gson()

    fun stream(model: AiModel, conversation: List<MessageEntity>, userText: String, imagePath: String?): Flow<String> = flow {
        val key = keys.getApiKey(model.provider)
        if (key.isBlank()) throw ProviderException(0, "API key ${model.provider.apiKeyLabel} belum diatur. Buka Settings untuk memasukkannya.")
        if (imagePath != null && !model.vision) throw ProviderException(0, "Model ini tidak dikonfigurasi untuk menerima gambar. Pilih model vision seperti Gemini atau Nemotron Super VL.")
        val payload = if (model.provider == Provider.GEMINI) geminiPayload(conversation, userText, imagePath) else openAiPayload(model, conversation, userText, imagePath)
        val url = if (model.provider == Provider.GEMINI) GeminiService.streamUrl(model.id) else when (model.provider) {
            Provider.GROQ -> GroqService.STREAM_URL
            Provider.OPENROUTER -> OpenRouterService.STREAM_URL
            else -> error("Unsupported provider")
        }
        val response = api.stream(
            url,
            if (model.provider == Provider.GEMINI) null else "Bearer $key",
            if (model.provider == Provider.GEMINI) key else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.REFERER else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.APP_TITLE else null,
            gson.toJson(payload).toRequestBody("application/json; charset=utf-8".toMediaType())
        )
        val body = response.body()
        if (!response.isSuccessful || body == null) {
            val details = runCatching { response.errorBody()?.string()?.take(800) }.getOrNull().orEmpty()
            val friendly = when (response.code()) {
                401, 403 -> "API key salah atau akses model tidak tersedia. Periksa key dan izin provider."
                429 -> "Batas penggunaan tercapai (429). Tunggu atau pilih model/provider lain."
                else -> "Provider mengembalikan HTTP ${response.code()}. ${details.take(350)}"
            }
            throw ProviderException(response.code(), friendly)
        }
        body.charStream().buffered().use { reader ->
            while (true) {
                val line = reader.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.removePrefix("data:").trim()
                if (data.isBlank() || data == "[DONE]") continue
                val chunk = runCatching {
                    val root = JsonParser.parseString(data).asJsonObject
                    if (model.provider == Provider.GEMINI) {
                        root.getAsJsonArray("candidates")?.firstOrNull()?.asJsonObject?.getAsJsonObject("content")
                            ?.getAsJsonArray("parts")?.firstOrNull()?.asJsonObject?.get("text")?.asString.orEmpty()
                    } else {
                        root.getAsJsonArray("choices")?.firstOrNull()?.asJsonObject?.getAsJsonObject("delta")
                            ?.get("content")?.takeUnless { it.isJsonNull }?.asString.orEmpty()
                    }
                }.getOrDefault("")
                if (chunk.isNotEmpty()) emit(chunk)
            }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun test(model: AiModel): String {
        val key = keys.getApiKey(model.provider)
        if (key.isBlank()) throw ProviderException(0, "API key belum diatur.")
        val url = when (model.provider) {
            Provider.GEMINI -> GeminiService.KEY_CHECK_URL
            Provider.GROQ -> GroqService.KEY_CHECK_URL
            Provider.OPENROUTER -> OpenRouterService.KEY_CHECK_URL
        }
        val response = api.probe(
            url,
            if (model.provider == Provider.GEMINI) null else "Bearer $key",
            if (model.provider == Provider.GEMINI) key else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.REFERER else null,
            if (model.provider == Provider.OPENROUTER) OpenRouterService.APP_TITLE else null
        )
        if (!response.isSuccessful) {
            val message = when (response.code()) {
                401, 403 -> "API key salah atau akses ditolak (HTTP ${response.code()})."
                429 -> "Rate limit provider tercapai (HTTP 429)."
                else -> "Provider mengembalikan HTTP ${response.code()}."
            }
            response.errorBody()?.close()
            throw ProviderException(response.code(), message)
        }
        response.body()?.close()
        return "Koneksi berhasil (HTTP ${response.code()}). Tes ini tidak menghasilkan teks AI atau memakai token output. Status gratis/berbayar tetap mengikuti dashboard provider."
    }

    private fun geminiPayload(history: List<MessageEntity>, text: String, imagePath: String?): JsonObject {
        val contents = JsonArray()
        history.filter { it.role == "user" || it.role == "assistant" }.takeLast(18).forEach { msg ->
            val content = JsonObject(); content.addProperty("role", if (msg.role == "assistant") "model" else "user")
            val parts = JsonArray(); val p = JsonObject(); p.addProperty("text", msg.content); parts.add(p); content.add("parts", parts); contents.add(content)
        }
        val content = JsonObject(); content.addProperty("role", "user"); val parts = JsonArray()
        val textPart = JsonObject(); textPart.addProperty("text", text.ifBlank { "Tolong analisis gambar ini." }); parts.add(textPart)
        imagePath?.let { path -> imagePart(path)?.let { parts.add(it) } }
        content.add("parts", parts); contents.add(content)
        val config = JsonObject(); config.addProperty("temperature", 0.7); config.addProperty("maxOutputTokens", 8192)
        return JsonObject().apply { add("contents", contents); add("generationConfig", config) }
    }

    private fun openAiPayload(model: AiModel, history: List<MessageEntity>, text: String, imagePath: String?): JsonObject {
        val messages = JsonArray()
        val system = JsonObject(); system.addProperty("role", "system"); system.addProperty("content", "Kamu adalah asisten yang membantu, akurat, dan ringkas. Jawab dengan bahasa yang digunakan pengguna. Jangan mengaku sebagai ChatGPT, Gemini, atau Claude."); messages.add(system)
        history.filter { it.role == "user" || it.role == "assistant" }.takeLast(18).forEach { msg ->
            val item = JsonObject(); item.addProperty("role", msg.role); item.addProperty("content", msg.content); messages.add(item)
        }
        val user = JsonObject(); user.addProperty("role", "user")
        if (imagePath != null) {
            val blocks = JsonArray(); val t = JsonObject(); t.addProperty("type", "text"); t.addProperty("text", text.ifBlank { "Please analyze this image." }); blocks.add(t)
            imageDataUrl(imagePath)?.let { image -> val im = JsonObject(); im.addProperty("type", "image_url"); val imUrl = JsonObject(); imUrl.addProperty("url", image); im.add("image_url", imUrl); blocks.add(im) }
            user.add("content", blocks)
        } else user.addProperty("content", text)
        messages.add(user)
        return JsonObject().apply { addProperty("model", model.id); addProperty("stream", true); addProperty("temperature", 0.7); addProperty("max_tokens", 8192); add("messages", messages) }
    }

    private fun imagePart(path: String): JsonObject? = runCatching {
        val f = File(path); if (!f.exists() || f.length() > 12L * 1024 * 1024) return null
        val data = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        JsonObject().apply { add("inline_data", JsonObject().apply { addProperty("mime_type", "image/jpeg"); addProperty("data", data) }) }
    }.getOrNull()
    private fun imageDataUrl(path: String): String? = runCatching {
        val f = File(path); if (!f.exists() || f.length() > 12L * 1024 * 1024) return null
        "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
    }.getOrNull()
}
