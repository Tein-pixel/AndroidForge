package com.teinzz.aichat.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Provider(val title: String, val apiKeyLabel: String) {
    GEMINI("Gemini · Google", "GEMINI_API_KEY"), GROQ("Groq", "GROQ_API_KEY"), OPENROUTER("OpenRouter", "OPENROUTER_API_KEY")
}

data class AiModel(
    val id: String,
    val name: String,
    val provider: Provider,
    val badge: String,
    val freeTier: Boolean,
    val vision: Boolean = false,
    val description: String = ""
)

object ModelCatalog {
    val all = listOf(
        AiModel("gemini-3.8-flash", "Gemini 3.8 Flash", Provider.GEMINI, "FREE TIER", true, true, "Model Flash terbaru; akses dan batas gratis bergantung akun."),
        AiModel("gemini-3.5-flash-lite", "Gemini 3.5 Flash-Lite", Provider.GEMINI, "FREE TIER", true, true, "Model ringan dengan free tier sesuai aturan akun; cek ketersediaan di AI Studio."),
        AiModel("gemini-4-argon", "Gemini 4 Argon", Provider.GEMINI, "PAID", false, true, "Model reasoning flagship; tidak tersedia di tier gratis."),
        AiModel("openai/gpt-oss-120b", "GPT-OSS 120B", Provider.GROQ, "USAGE-BASED", false, false, "Model Groq aktif pengganti model Llama lama."),
        AiModel("openai/gpt-oss-20b", "GPT-OSS 20B", Provider.GROQ, "USAGE-BASED", false, false, "Model Groq cepat untuk penggunaan umum."),
        AiModel("qwen/qwen3.8-27b", "Qwen 3.8 27B", Provider.GROQ, "USAGE-BASED", false, true, "Tersedia pada tier developer sesuai daftar Groq terbaru."),
        AiModel("openrouter/free", "OpenRouter Free Router", Provider.OPENROUTER, "FREE ROUTER", true, true, "Memilih model gratis yang tersedia secara otomatis."),
        AiModel("nvidia/nemotron-3.5-super-vl:free", "Nemotron 3.5 Super VL", Provider.OPENROUTER, "FREE · VISION", true, true, "Model multimodal gratis; kapasitas dan uptime dapat berubah."),
        AiModel("minimax/minimax-m3.1-flash:free", "MiniMax M3.1 Flash", Provider.OPENROUTER, "FREE", true, true, "Model gratis pada katalog OpenRouter saat riset."),
        AiModel("nvidia/nemotron-3-ultra:free", "Nemotron 3 Ultra", Provider.OPENROUTER, "FREE", true, false, "Model teks gratis; limit provider berlaku."),
        AiModel("deepseek/deepseek-v4.1-flash", "DeepSeek V4.1 Flash", Provider.OPENROUTER, "PAID / CHECK ROUTE", false, true, "ID model terbaru yang terlihat di katalog OpenRouter."),
        AiModel("anthropic/claude-sonnet-4.5", "Claude Sonnet 4.5", Provider.OPENROUTER, "PAID", false, true, "Model Anthropic via OpenRouter; biaya berlaku."),
        AiModel("openai/gpt-5-mini", "GPT-5 mini", Provider.OPENROUTER, "PAID", false, true, "Model OpenAI via OpenRouter; biaya berlaku.")
    )
    fun default() = all.first()
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: default()
}

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val modelId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,
    val content: String,
    val imagePath: String? = null,
    val fileName: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
