package com.teinzz.aichat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: ChatViewModel = viewModel()
            val storedTheme by vm.themeManager.theme.collectAsState(initial = vm.themeManager.getInitialTheme())
            val dark = when (storedTheme) { ThemeMode.DARK -> true; ThemeMode.LIGHT -> false; ThemeMode.SYSTEM -> isSystemInDarkTheme() }
            val view = LocalView.current
            SideEffect {
                window.statusBarColor = if (dark) android.graphics.Color.rgb(33, 33, 33) else android.graphics.Color.WHITE
                window.navigationBarColor = if (dark) android.graphics.Color.rgb(33, 33, 33) else android.graphics.Color.WHITE
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !dark
            }
            val lightColors = lightColorScheme(
                primary = Color(0xFF171717), onPrimary = Color.White, background = Color.White, onBackground = Color(0xFF111111),
                surface = Color.White, onSurface = Color(0xFF111111), surfaceVariant = Color(0xFFF4F4F4), onSurfaceVariant = Color(0xFF5F6368),
                outlineVariant = Color(0xFFE5E5E5), secondaryContainer = Color(0xFFEFEFEF), surfaceContainerLow = Color(0xFFF9F9F9)
            )
            val darkColors = darkColorScheme(
                primary = Color(0xFFECECEC), onPrimary = Color(0xFF171717), background = Color(0xFF212121), onBackground = Color(0xFFECECEC),
                surface = Color(0xFF212121), onSurface = Color(0xFFECECEC), surfaceVariant = Color(0xFF2F2F2F), onSurfaceVariant = Color(0xFFB7B7B7),
                outlineVariant = Color(0xFF2F2F2F), secondaryContainer = Color(0xFF383838), surfaceContainerLow = Color(0xFF171717)
            )
            MaterialTheme(colorScheme = if (dark) darkColors else lightColors, typography = Typography(bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 27.sp))) {
                var screen by remember { mutableStateOf("chat") }
                BackHandler(enabled = screen != "chat") { screen = "chat" }
                when (screen) {
                    "settings" -> SettingsScreen(vm, onBack = { screen = "chat" })
                    "camera" -> CameraScreen(onBack = { screen = "chat" }, onUsePhoto = { path -> vm.send("", ImageCompressor.cameraFile(this@MainActivity, path), "Camera.jpg"); screen = "chat" })
                    else -> ChatScreen(vm, onSettings = { screen = "settings" }, onCamera = { screen = "camera" })
                }
            }
        }
    }
}
