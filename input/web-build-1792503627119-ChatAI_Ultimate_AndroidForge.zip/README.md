# ChatAI Ultimate — AndroidForge project

**Project type:** Android native · Kotlin · Jetpack Compose · Material 3  
**Minimum Android:** API 24 / Android 7.0  
**Target SDK:** 34  
**Package:** `com.teinzz.aichat`

This is a source project ZIP intended for an AndroidForge Gradle build. It is not an APK, and no API keys are included.

## Main features in this build

- Chat-style layout with light/dark/system theme, model picker, welcome suggestions, streamed AI responses, basic Markdown and copyable code blocks.
- Room conversation history with grouped drawer, search, rename/delete, new chat and selected model stored per conversation.
- Settings for Gemini, Groq, and OpenRouter API keys using AndroidX EncryptedSharedPreferences; theme preference uses DataStore.
- Provider-key connection checks use provider model/auth endpoints (no text generation request), so the test itself does not consume output tokens.
- SSE response parsing for Gemini `streamGenerateContent` and OpenAI-compatible Groq/OpenRouter `chat/completions` endpoints.
- Gallery image attach and JPEG compression; PDF, TXT, CSV and DOCX text extraction; CameraX preview, touch-to-focus, pinch zoom, camera switch, flash mode and retake/use-photo flow.
- Free-model filter and labels. The app does **not** claim that every account has a free quota; provider limits, billing and per-model eligibility can change.

## Build in AndroidForge

1. Upload this ZIP, then choose the Android/Gradle project option if the builder asks. The archive already places `settings.gradle`, `build.gradle`, and `app/` at its root.
2. If AndroidForge asks for a project folder instead of a ZIP, extract the archive and select the directory containing `settings.gradle`.
3. Let AndroidForge resolve Maven dependencies and run the Gradle build. Compile SDK 35 and JDK 17 are required; target SDK is 34.
4. Install the generated APK, open **Settings**, enter your own provider API key, press **Save key**, then **Test connection**.

No Gradle wrapper JAR or Android SDK is bundled. This runtime did not have Gradle or Android SDK installed, so the project could not be compiled here. A successful AndroidForge build is not claimed until its build result is checked. If the builder reports a dependency, SDK, or Kotlin compile error, use the exact error log to patch the project rather than changing arbitrary versions.

## Current model catalogue notes (checked 20 October 2026)

The model list intentionally removes the example model IDs in the original brief when official provider documentation lists them as retired or replaced:

- **Gemini:** `gemini-3.8-flash` is the default. `gemini-4-argon` is labelled paid-only; Gemini 3.5 Flash-Lite is offered as another lower-cost option subject to current account availability.
- **Groq:** the older `llama-3.1-8b-instant` and `llama-3.3-70b-versatile` IDs are not offered as the default developer-tier options here because Groq's deprecation notice states their developer-tier shutdown date was 16 August 2026. The catalogue uses the newer GPT-OSS and Qwen replacement IDs.
- **OpenRouter:** offers a free-router choice and individual free endpoints; their rate limits and availability can change. Paid models are hidden unless **Show paid / usage-based models** is enabled.

A provider cannot always be classified as “free key” versus “paid key” just by inspecting the string. The app labels its curated model catalogue and checks whether credentials are accepted; billing tier, remaining quota, and model entitlement are controlled by the provider dashboard.

## Research sources

- Gemini model list and model lifecycle: https://ai.google.dev/gemini-api/docs/models and https://ai.google.dev/gemini-api/docs/deprecations/
- Gemini pricing / free-tier qualification: https://ai.google.dev/gemini-api/docs/pricing
- Gemini SSE streaming endpoint: https://ai.google.dev/api/generate-content
- Groq supported models and replacement notices: https://console.groq.com/docs/models and https://console.groq.com/docs/deprecations
- OpenRouter free-model catalogue and model details: https://openrouter.ai/collections/free-models and https://openrouter.ai/nvidia/nemotron-3.5-super-vl
- Compose drawer pattern: https://developer.android.com/develop/ui/compose/components/drawer
- CameraX focus, zoom and torch: https://developer.android.com/media/camera/camerax/configuration and https://developer.android.com/reference/androidx/camera/view/CameraController

## Important implementation limits

- “ChatAI Ultimate” is an independent client. It is not an official ChatGPT, Gemini, or Claude app, and it cannot inherit subscriptions from those apps. Each direct API has its own key, policy, limits and pricing.
- API keys are stored encrypted on-device, but API keys on a client device cannot be protected like secrets held on a private backend. Do not share the APK preloaded with personal keys.
- Free/paid labels are catalogue metadata, not a guarantee of quota, price, or access for an account. Recheck provider dashboards before heavy use.
- Image inputs are passed only when the selected catalogue entry is marked as vision-capable. Some free router endpoints can change their supported modalities.
- Offline requests show a recoverable connection error; automatic background/offline request queueing is not implemented in this initial source build.
- Markdown supports common formatting and fenced code blocks; it is a lightweight renderer, not a full CommonMark implementation.
