package com.tein.booster;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/** Dashboard: skor perangkat, Boost 1-tap, 1-Tap Cache Cleaner, statistik live, dan semua alat. */
public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private GaugeView gauge;
    private TextView scoreChip;
    private TextView boostBtn;
    private TextView resultTv;
    private TextView lastTv;
    private Stat ram;
    private Stat st;
    private Stat bat;
    private LinearLayout banner;
    private TextView bannerTv;
    private boolean boosting;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            refreshStats(false);
            h.postDelayed(this, 2500L);
        }
    };

    private static final class Stat {
        LinearLayout view;
        TextView value;
        TextView sub;
        BarView bar;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = Ui.col(this);
        int p = Ui.dp(this, 16);
        col.setPadding(p, Ui.dp(this, 14), p, Ui.dp(this, 28));
        sv.addView(col, new ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP));
        setContentView(sv);

        // ---- header
        LinearLayout head = Ui.row(this);
        head.addView(Ui.badge(this, "\u26A1", Ui.CYAN, 42));
        LinearLayout titles = Ui.col(this);
        titles.addView(Ui.tvb(this, "Tein Booster", 22, Ui.TEXT));
        titles.addView(Ui.tv(this, "Kondisi perangkat hari ini", 13, Ui.SUB));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        tp.setMargins(Ui.dp(this, 12), 0, 0, 0);
        head.addView(titles, tp);
        TextView gear = Ui.tvb(this, "\u2699\uFE0F", 22, Ui.TEXT);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(Ui.ripple(this, Ui.rect(this, 0x00000000, 22), 22));
        gear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        head.addView(gear, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        col.addView(head);

        // ---- hero
        LinearLayout hero = Ui.card(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(this, 232), Ui.dp(this, 232));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(gauge, gp);
        scoreChip = Ui.chip(this, "-", Ui.CYAN);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        cp.gravity = Gravity.CENTER_HORIZONTAL;
        cp.topMargin = Ui.dp(this, 4);
        hero.addView(scoreChip, cp);
        boostBtn = Ui.button(this, "Boost sekarang", v -> doBoost());
        hero.addView(boostBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));
        resultTv = Ui.tv(this, "", 13, Ui.MINT);
        resultTv.setGravity(Gravity.CENTER);
        hero.addView(resultTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        lastTv = Ui.tv(this, "", 12, Ui.SUB);
        lastTv.setGravity(Gravity.CENTER);
        hero.addView(lastTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        col.addView(hero, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));

        // ---- 1-Tap Cache Cleaner
        LinearLayout cache = Ui.col(this);
        cache.setBackground(Ui.grad(this, 0xFF5B3DF5, 0xFF2F7BFF, 20));
        cache.setPadding(p, p, p, p);
        cache.addView(Ui.tvb(this, "1-Tap Cache Cleaner", 19, 0xFFFFFFFF));
        cache.addView(Ui.tv(this, "Hapus cache semua aplikasi otomatis lewat Aksesibilitas. Cukup tekan sekali.", 13, 0xDDFFFFFF),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        TextView go = Ui.button2(this, "Bersihkan sekarang", 0xFFFFFFFF, 0xFFE4ECFF, v -> {
            Intent i = new Intent(this, CacheCleanerActivity.class);
            i.putExtra("autostart", true);
            startActivity(i);
        });
        cache.addView(go, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        col.addView(cache, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));

        // ---- statistik
        LinearLayout stats = Ui.row(this);
        stats.setGravity(Gravity.TOP);
        ram = makeStat("RAM");
        st = makeStat("Penyimpanan");
        bat = makeStat("Baterai");
        stats.addView(ram.view, statLp(0, 0, 4, 0));
        stats.addView(st.view, statLp(4, 0, 4, 0));
        stats.addView(bat.view, statLp(4, 0, 0, 0));
        col.addView(stats, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));

        // ---- banner izin
        banner = Ui.card(this);
        banner.setBackground(Ui.outline(this, Ui.alpha(Ui.EMBER, 0x18), Ui.alpha(Ui.EMBER, 0x70), 18));
        bannerTv = Ui.tvb(this, "", 14, Ui.EMBER);
        banner.addView(bannerTv);
        banner.addView(Ui.ghost(this, "Atur izin", v -> startActivity(new Intent(this, PermissionsActivity.class))),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(banner, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));

        // ---- alat
        col.addView(Ui.sectionTitle(this, "Semua booster"));
        LinearLayout tools = Ui.col(this);
        addRow(tools,
                tile("\uD83D\uDE80", "RAM Booster", "Tutup proses latar", Ui.CYAN, RamBoosterActivity.class),
                tile("\uD83D\uDDD1\uFE0F", "Junk Cleaner", "File sampah & sisa", Ui.VIOLET, JunkCleanerActivity.class));
        addRow(tools,
                tile("\uD83D\uDCBE", "Penyimpanan", "File besar & duplikat", Ui.BLUE, StorageActivity.class),
                tile("\uD83D\uDD0B", "Hemat Baterai", "Profil hemat daya", Ui.MINT, BatteryActivity.class));
        addRow(tools,
                tile("\u2744\uFE0F", "Pendingin", "Pantau & turunkan suhu", 0xFF4FC3F7, CoolerActivity.class),
                tile("\uD83C\uDFAE", "Game Booster", "Fokus penuh saat main", Ui.PINK, GameBoosterActivity.class));
        addRow(tools,
                tile("\uD83D\uDCE6", "Manajer Aplikasi", "Cadangkan & hapus", Ui.EMBER, AppManagerActivity.class),
                tile("\uD83C\uDF10", "Network Booster", "DNS, ping, kecepatan", Ui.BLUE, NetworkActivity.class));
        addRow(tools,
                tile("\uD83C\uDFAE", "Pusat Gaming", "GFX, HUD, monitor, tes sentuh", Ui.MINT, GameCenterActivity.class),
                tile("\uD83D\uDCCA", "Monitor Performa", "RAM, suhu, jaringan live", Ui.CYAN, PerformanceMonitorActivity.class));
        addRow(tools,
                tile("\uD83D\uDCBE", "Game Saya", "Perpustakaan & favorit game", Ui.MINT, GameLibraryActivity.class),
                tile("\uD83C\uDFAE", "Panel Game", "Volume, layar, dan kontrol cepat", Ui.BLUE, GamePanelActivity.class));
        addRow(tools,
                tile("\uD83D\uDCF9", "Perekam Layar", "Rekam gameplay ke MP4", Ui.PINK, ScreenRecorderActivity.class),
                tile("\uD83D\uDD0A", "Visualisasi Suara", "Meter mikrofon manual", Ui.VIOLET, SoundVisualizerActivity.class));
        addRow(tools,
                tile("\u26A1", "Turbo UI", "Percepat animasi sistem", Ui.EMBER, TurboActivity.class),
                tile("\uD83D\uDCF1", "Info Perangkat", "Spesifikasi lengkap", 0xFF9AA7D0, DeviceInfoActivity.class));
        addRow(tools,
                tile("\uD83D\uDEE1\uFE0F", "Pusat Izin", "Aktifkan semua izin", Ui.MINT, PermissionsActivity.class),
                tile("\u2699\uFE0F", "Pengaturan", "Auto boost & daftar putih", Ui.VIOLET, SettingsActivity.class));
        col.addView(tools);

        String version = "1.0.0";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        TextView foot = Ui.tv(this, "Tein Booster v" + version + " \u2022 data berasal dari perangkatmu", 11, Ui.SUB);
        foot.setGravity(Gravity.CENTER);
        col.addView(foot, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 22, 0, 0));

        Ui.reveal(head, hero, cache, stats, banner, tools);

        if (!Prefs.getBool(this, Prefs.ONBOARDED, false)) {
            Prefs.putBool(this, Prefs.ONBOARDED, true);
            startActivity(new Intent(this, PermissionsActivity.class));
        }
    }

    private LinearLayout.LayoutParams statLp(float l, float t, float r, float b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        lp.setMargins(Ui.dp(this, l), Ui.dp(this, t), Ui.dp(this, r), Ui.dp(this, b));
        return lp;
    }

    private Stat makeStat(String label) {
        Stat s = new Stat();
        s.view = Ui.col(this);
        s.view.setBackground(Ui.outline(this, Ui.PANEL, Ui.LINE, 16));
        int q = Ui.dp(this, 12);
        s.view.setPadding(q, q, q, q);
        s.view.addView(Ui.tv(this, label, 12, Ui.SUB));
        s.value = Ui.num(this, "-", 24, Ui.TEXT);
        s.view.addView(s.value, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 2, 0, 0));
        s.bar = new BarView(this);
        s.view.addView(s.bar, Ui.lp(this, Ui.MATCH, Ui.dp(this, 5), 0, 6, 0, 0));
        s.sub = Ui.tv(this, "", 11, Ui.SUB);
        s.sub.setSingleLine(true);
        s.view.addView(s.sub, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        return s;
    }

    private View tile(String emoji, String title, String sub, int color, final Class<?> target) {
        LinearLayout t = Ui.col(this);
        t.setBackground(Ui.ripple(this, Ui.outline(this, Ui.PANEL, Ui.LINE, 18), 18));
        int q = Ui.dp(this, 14);
        t.setPadding(q, q, q, q);
        t.addView(Ui.badge(this, emoji, color, 44));
        t.addView(Ui.tvb(this, title, 15, Ui.TEXT), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 12, 0, 0));
        t.addView(Ui.tv(this, sub, 12, Ui.SUB), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 2, 0, 0));
        t.setClickable(true);
        t.setOnClickListener(v -> startActivity(new Intent(this, target)));
        Ui.pressable(t);
        return t;
    }

    private void addRow(LinearLayout parent, View a, View b) {
        LinearLayout r = Ui.row(this);
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, Ui.MATCH, 1f);
        la.setMargins(0, 0, Ui.dp(this, 6), 0);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, Ui.MATCH, 1f);
        lb.setMargins(Ui.dp(this, 6), 0, 0, 0);
        r.addView(a, la);
        r.addView(b, lb);
        parent.addView(r, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStats(true);
        h.postDelayed(loop, 2500L);
        int miss = Perm.requiredMissing(this);
        banner.setVisibility(miss > 0 ? View.VISIBLE : View.GONE);
        bannerTv.setText("Izin belum lengkap (" + miss + " dari " + Perm.REQUIRED_TOTAL + "). Beberapa booster belum bisa jalan penuh.");
        long last = Prefs.getLong(this, Prefs.LAST_BOOST, 0L);
        lastTv.setText(last > 0 ? "Boost terakhir: " + Fmt.ago(last) : "");
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(loop);
    }

    private int usageColor(float f) {
        if (f < 0.6f) return Ui.MINT;
        if (f < 0.8f) return Ui.EMBER;
        return Ui.CORAL;
    }

    private void refreshStats(boolean animate) {
        long rt = Sys.ramTotal(this);
        long ra = Sys.ramAvail(this);
        float rf = rt > 0 ? 1f - (float) ra / (float) rt : 0f;
        ram.value.setText(Fmt.pct(rf));
        ram.sub.setText(Fmt.bytes(rt - ra) + " / " + Fmt.bytes(rt));
        ram.bar.setSmooth(rf, usageColor(rf));

        float sf = Sys.storageUsed();
        long stt = Sys.storageTotal();
        st.value.setText(Fmt.pct(sf));
        st.sub.setText(Fmt.bytes(stt - Sys.storageFree()) + " / " + Fmt.bytes(stt));
        st.bar.setSmooth(sf, usageColor(sf));

        Sys.Batt b = Sys.battery(this);
        bat.value.setText(b.level + "%");
        bat.sub.setText(String.format(Locale.US, "%.1f\u00B0C", b.tempC) + (b.charging ? " \u2022 mengisi" : ""));
        bat.bar.setSmooth(b.level / 100f, b.level >= 50 ? Ui.MINT : (b.level >= 20 ? Ui.EMBER : Ui.CORAL));

        if (!boosting) {
            int score = Sys.score(this);
            gauge.setProgress(score / 100f, animate);
            gauge.setCenter(String.valueOf(score), "skor perangkat");
            scoreChip.setText(Sys.scoreLabel(score));
        }
    }

    private void doBoost() {
        if (boosting) return;
        boosting = true;
        boostBtn.setText("Memboost...");
        resultTv.setText("");
        gauge.setSpinning(true);
        gauge.setCenter("...", "memproses");
        final android.content.Context app = getApplicationContext();
        Bg.run(() -> {
            final Optimizer.Result r = Optimizer.fullBoost(app);
            Bg.ui(() -> {
                boosting = false;
                if (isFinishing() || isDestroyed()) return;
                gauge.setSpinning(false);
                boostBtn.setText("Boost sekarang");
                String msg = r.killed + " aplikasi dioptimalkan \u2022 ";
                msg += r.ramFreed > 0 ? "RAM bebas +" + Fmt.bytes(r.ramFreed) : "RAM sudah optimal";
                resultTv.setText("\u2713 " + msg);
                lastTv.setText("Boost terakhir: baru saja");
                refreshStats(true);
            });
        });
    }
}
