package com.tein.booster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Overlay HUD yang dapat dipindah; tidak membaca isi game atau merekam layar. */
public class GameHudService extends Service {
    public static final String ACTION_START = "com.tein.booster.hud.START";
    public static final String ACTION_STOP = "com.tein.booster.hud.STOP";
    private static final String CHANNEL = "tein_game_hud";
    private static final int NOTIFICATION_ID = 7301;
    public static volatile boolean running = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View panel;
    private TextView stats;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!running || stats == null) return;
            Sys.Batt b = Sys.battery(GameHudService.this);
            stats.setText(String.format(Locale.US, "RAM %.0f%%  •  BAT %d%%  •  %.1f°C", Sys.ramUsed(GameHudService.this) * 100f, b.level, b.tempC));
            handler.postDelayed(this, 1500L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopHud(); return START_NOT_STICKY; }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        try {
            startForeground(NOTIFICATION_ID, buildNotification());
            createOverlay();
            running = true;
            handler.removeCallbacks(ticker);
            handler.post(ticker);
        } catch (Exception e) {
            stopHud();
        }
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Game HUD", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Status layanan HUD gaming yang sedang aktif");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Tein Booster • Game HUD")
                .setContentText("Widget RAM, baterai, dan suhu sedang aktif")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build();
    }

    private void createOverlay() {
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; }
        LinearLayout outer = Ui.col(this);
        outer.setBackground(Ui.outline(this, 0xEE101828, Ui.MINT, 14));
        outer.setPadding(Ui.dp(this, 10), Ui.dp(this, 7), Ui.dp(this, 10), Ui.dp(this, 8));
        LinearLayout head = Ui.row(this);
        TextView title = Ui.tvb(this, "TEIN HUD  •  GESER", 10, Ui.MINT);
        head.addView(title, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView close = Ui.tvb(this, "×", 18, Ui.TEXT);
        close.setGravity(Gravity.CENTER);
        close.setPadding(Ui.dp(this, 9), 0, Ui.dp(this, 4), 0);
        close.setOnClickListener(v -> stopHud());
        head.addView(close);
        outer.addView(head);
        stats = Ui.tvb(this, "Membaca kondisi…", 11, Ui.TEXT);
        outer.addView(stats, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 4, 0, 0));
        head.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = e.getRawX(); downY = e.getRawY(); startX = params.x; startY = params.y; return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = startX + (int) (e.getRawX() - downX);
                params.y = startY + (int) (e.getRawY() - downY);
                try { wm.updateViewLayout(panel, params); } catch (Exception ignored) {}
                return true;
            }
            return e.getAction() == MotionEvent.ACTION_UP;
        });
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(Ui.WRAP, Ui.WRAP, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = Ui.dp(this, 12); params.y = Ui.dp(this, 120);
        panel = outer;
        wm.addView(panel, params);
    }

    private void stopHud() {
        running = false;
        handler.removeCallbacks(ticker);
        if (wm != null && panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
        panel = null; stats = null;
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacks(ticker);
        if (wm != null && panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
        panel = null; stats = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
