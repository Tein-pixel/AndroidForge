package com.teinzz.teintools;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.res.ColorStateList;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "tein_tools_settings";
    private static final int REQ_CAMERA = 712;
    private static final int REQ_OPEN_FILE = 4101;
    private static final int REQ_CREATE_FILE = 4102;
    private static final int REQ_OPEN_IMAGE = 4103;
    private static final int SPLASH_DURATION_MS = 1050;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private String currentPage = "home";
    private String themeMode = "dark";
    private String accentMode = "violet";
    private boolean torchOn = false;
    private boolean pendingTorchOn = false;

    private LinearLayout screenColumn;
    private LinearLayout pageBody;
    private LinearLayout networkResultCard;
    private TextView networkResultText;
    private ProgressBar networkProgress;
    private TextView cacheStatusText;
    private ProgressBar cacheProgress;
    private String cleanerFeedback = "Ready. TeinTools can clean its own temporary cache.";
    private boolean cleaningCache = false;
    private TextView timerDisplay;
    private TextView stopwatchDisplay;
    private EditText qrInputField;
    private ImageView qrPreview;
    private EditText fileContentField;
    private Bitmap lastQrBitmap;
    private List<ApplicationInfo> installedAppsCache = new ArrayList<>();

    private String calcExpression = "";
    private long stopwatchStartedAt = 0L;
    private long stopwatchAccumulated = 0L;
    private boolean stopwatchRunning = false;
    private boolean timerRunning = false;
    private long timerEndsAt = 0L;
    private long timerOriginalDuration = 0L;

    private final Runnable splashComplete = new Runnable() {
        @Override public void run() { if (!isFinishing()) renderPage("home"); }
    };

    private final Runnable stopwatchTick = new Runnable() {
        @Override public void run() {
            if (stopwatchRunning && "stopwatch".equals(currentPage) && stopwatchDisplay != null) {
                long elapsed = stopwatchAccumulated + (SystemClock.elapsedRealtime() - stopwatchStartedAt);
                stopwatchDisplay.setText(formatStopwatch(elapsed));
            }
            if (stopwatchRunning) handler.postDelayed(this, 100L);
        }
    };

    private final Runnable timerTick = new Runnable() {
        @Override public void run() {
            if (!timerRunning) return;
            long remaining = Math.max(0L, timerEndsAt - SystemClock.elapsedRealtime());
            if (timerDisplay != null) timerDisplay.setText(formatTimer(remaining));
            if (remaining <= 0L) {
                timerRunning = false;
                if (timerDisplay != null) timerDisplay.setText("00:00");
                Toast.makeText(MainActivity.this, "Timer selesai", Toast.LENGTH_LONG).show();
                return;
            }
            handler.postDelayed(this, 250L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        themeMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString("theme", "dark");
        accentMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString("accent", "violet");
        showSplashScreen();
        handler.postDelayed(splashComplete, SPLASH_DURATION_MS);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(splashComplete);
        handler.removeCallbacks(stopwatchTick);
        handler.removeCallbacks(timerTick);
        if (torchOn) setTorch(false);
        super.onDestroy();
    }

    private void showSplashScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(liquidBackground());
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(28), dp(24), dp(28), dp(24));

        ImageView artwork = new ImageView(this);
        artwork.setImageResource(R.drawable.hero_liquid);
        artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);
        artwork.setAdjustViewBounds(true);
        artwork.setAlpha(0.0f);
        artwork.setScaleX(0.92f);
        artwork.setScaleY(0.92f);
        content.addView(artwork, new LinearLayout.LayoutParams(dp(220), dp(220)));

        TextView title = label("TeinTools", 30, textColor(), true);
        title.setGravity(Gravity.CENTER);
        title.setAlpha(0f);
        content.addView(title, marginParams(-1, -2, 0, dp(8), 0, 0));
        TextView subtitle = label("LIQUID GLASS  ·  ULTIMATE TOOLBOX", 10, muted(), true);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setAlpha(0f);
        content.addView(subtitle, marginParams(-1, -2, 0, dp(5), 0, dp(22)));

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
        progress.setProgressTintList(ColorStateList.valueOf(accent()));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.argb(70, 180, 190, 230)));
        content.addView(progress, new LinearLayout.LayoutParams(dp(150), dp(4)));
        root.addView(content, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        setContentView(root);

        artwork.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(620L).start();
        title.animate().alpha(1f).setStartDelay(170L).setDuration(440L).start();
        subtitle.animate().alpha(1f).setStartDelay(270L).setDuration(420L).start();
    }

    private boolean isLight() {
        if ("light".equals(themeMode)) return true;
        if ("dark".equals(themeMode)) return false;
        int mask = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return mask != android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }
    private int accent() {
        switch (accentMode) {
            case "blue": return Color.rgb(83, 142, 255);
            case "cyan": return Color.rgb(69, 213, 212);
            case "green": return Color.rgb(98, 217, 160);
            default: return Color.rgb(143, 132, 255);
        }
    }
    private int bg() { return isLight() ? Color.rgb(232, 238, 249) : Color.rgb(8, 11, 24); }
    private int surface() { return isLight() ? Color.argb(222, 255, 255, 255) : Color.argb(206, 26, 32, 54); }
    private int surfaceRaised() { return isLight() ? Color.argb(230, 249, 251, 255) : Color.argb(218, 36, 43, 69); }
    private int textColor() { return isLight() ? Color.rgb(26, 31, 46) : Color.rgb(243, 245, 255); }
    private int muted() { return isLight() ? Color.rgb(103, 112, 132) : Color.rgb(165, 175, 202); }
    private int borderColor() { return isLight() ? Color.argb(170, 210, 220, 240) : Color.argb(105, 205, 218, 255); }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    /** Layered gradients provide an Android 10-compatible liquid-glass illusion without API-31-only blur. */
    private Drawable liquidBackground() {
        int baseTop = isLight() ? Color.rgb(241, 246, 255) : Color.rgb(8, 11, 24);
        int baseBottom = isLight() ? Color.rgb(224, 231, 246) : Color.rgb(16, 19, 39);
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{baseTop, baseBottom});
        GradientDrawable violetGlow = new GradientDrawable();
        violetGlow.setShape(GradientDrawable.RECTANGLE);
        violetGlow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        violetGlow.setGradientCenter(0.94f, 0.08f);
        violetGlow.setGradientRadius(dp(430));
        violetGlow.setColors(new int[]{Color.argb(isLight() ? 65 : 78, Color.red(accent()), Color.green(accent()), Color.blue(accent())), Color.TRANSPARENT});
        GradientDrawable cyanGlow = new GradientDrawable();
        cyanGlow.setShape(GradientDrawable.RECTANGLE);
        cyanGlow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        cyanGlow.setGradientCenter(0.04f, 0.78f);
        cyanGlow.setGradientRadius(dp(380));
        cyanGlow.setColors(new int[]{Color.argb(isLight() ? 36 : 48, 67, 202, 228), Color.TRANSPARENT});
        return new LayerDrawable(new Drawable[]{base, violetGlow, cyanGlow});
    }

    private void renderPage(String page) {
        currentPage = page;
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        window.setStatusBarColor(bg());
        window.setNavigationBarColor(bg());
        int flags = isLight() ? (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : 0;
        window.getDecorView().setSystemUiVisibility(flags);

        FrameLayout root = new FrameLayout(this);
        root.setBackground(liquidBackground());
        screenColumn = new LinearLayout(this);
        screenColumn.setOrientation(LinearLayout.VERTICAL);
        root.addView(screenColumn, new FrameLayout.LayoutParams(-1, -1));

        screenColumn.addView(makeTopBar(page), new LinearLayout.LayoutParams(-1, dp(76)));
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(false);
        scrollView.setClipToPadding(false);
        scrollView.setVerticalScrollBarEnabled(false);
        pageBody = new LinearLayout(this);
        pageBody.setOrientation(LinearLayout.VERTICAL);
        pageBody.setPadding(dp(18), dp(8), dp(18), dp(22));
        scrollView.addView(pageBody, new ScrollView.LayoutParams(-1, -2));
        screenColumn.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1));

        switch (page) {
            case "home": buildHome(pageBody); break;
            case "tools": buildTools(pageBody); break;
            case "settings": buildSettings(pageBody); break;
            case "device": buildDevicePage(pageBody); break;
            case "network": buildNetworkPage(pageBody); break;
            case "flash": buildFlashPage(pageBody); break;
            case "calculator": buildCalculatorPage(pageBody); break;
            case "notes": buildNotesPage(pageBody); break;
            case "qr": buildQrPage(pageBody); break;
            case "stopwatch": buildStopwatchPage(pageBody); break;
            case "timer": buildTimerPage(pageBody); break;
            case "converter": buildConverterPage(pageBody); break;
            case "files": buildFilesPage(pageBody); break;
            case "apps": buildAppsPage(pageBody); break;
            case "system": buildSystemPage(pageBody); break;
            case "cleaner": buildCleanerPage(pageBody); break;
            case "sensors": buildSensorPage(pageBody); break;
            case "permissions": buildPermissionsPage(pageBody); break;
            default: buildHome(pageBody); break;
        }
        if (isPrimaryPage(page)) screenColumn.addView(makeBottomNav(page), new LinearLayout.LayoutParams(-1, dp(70)));
        setContentView(root);
        screenColumn.setAlpha(0f);
        screenColumn.setTranslationY(dp(5));
        screenColumn.animate().alpha(1f).translationY(0f).setDuration(260L).start();
        for (int i = 0; i < pageBody.getChildCount(); i++) {
            View child = pageBody.getChildAt(i);
            child.setAlpha(0f);
            child.setTranslationY(dp(10));
            child.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(i * 30L, 180L)).setDuration(300L).start();
        }
        if ("stopwatch".equals(page) && stopwatchRunning) { handler.removeCallbacks(stopwatchTick); handler.post(stopwatchTick); }
        if ("timer".equals(page) && timerRunning) {
            updateTimerLabel();
            handler.removeCallbacks(timerTick);
            handler.post(timerTick);
        }
    }

    private boolean isPrimaryPage(String page) {
        return "home".equals(page) || "tools".equals(page) || "settings".equals(page);
    }

    private View makeTopBar(String page) {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(19), dp(8), dp(19), dp(6));
        if (isPrimaryPage(page)) {
            LinearLayout mark = new LinearLayout(this);
            mark.setGravity(Gravity.CENTER);
            mark.setBackground(backgroundGradient(accent(), blend(accent(), Color.BLACK, 0.35f), 1));
            TextView t = label("T", 22, Color.WHITE, true);
            t.setGravity(Gravity.CENTER);
            mark.addView(t, new LinearLayout.LayoutParams(dp(45), dp(45)));
            bar.addView(mark);
            LinearLayout brand = new LinearLayout(this);
            brand.setOrientation(LinearLayout.VERTICAL);
            brand.setPadding(dp(11), 0, 0, 0);
            brand.addView(label("TeinTools", 19, textColor(), true));
            brand.addView(label("ULTIMATE TOOLBOX", 9, muted(), true));
            bar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
            TextView topAction = pill("⌁", surfaceRaised(), accent(), 42);
            topAction.setOnClickListener(v -> renderPage("system"));
            bar.addView(topAction);
        } else {
            TextView back = pill("‹", surfaceRaised(), textColor(), 43);
            back.setTextSize(30);
            back.setOnClickListener(v -> renderPage("home"));
            bar.addView(back);
            LinearLayout titleBox = new LinearLayout(this);
            titleBox.setOrientation(LinearLayout.VERTICAL);
            titleBox.setPadding(dp(11), 0, 0, 0);
            titleBox.addView(label(pageTitle(page), 18, textColor(), true));
            titleBox.addView(label(pageSubtitle(page), 10, muted(), false));
            bar.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
            TextView topAction = pill("⋯", surfaceRaised(), accent(), 42);
            topAction.setOnClickListener(v -> renderPage("settings"));
            bar.addView(topAction);
        }
        return bar;
    }

    private String pageTitle(String page) {
        switch (page) {
            case "device": return "Device Monitor";
            case "network": return "Network Lab";
            case "flash": return "Flashlight";
            case "calculator": return "Calculator";
            case "notes": return "Quick Notes";
            case "qr": return "QR Studio";
            case "stopwatch": return "Stopwatch";
            case "timer": return "Countdown Timer";
            case "converter": return "Unit Converter";
            case "files": return "File Hub";
            case "apps": return "Installed Apps";
            case "system": return "System Shortcuts";
            case "cleaner": return "Cache Cleaner";
            case "sensors": return "Sensor Lab";
            case "permissions": return "Permission Inspector";
            default: return "TeinTools";
        }
    }
    private String pageSubtitle(String page) {
        switch (page) {
            case "device": return "Live device information";
            case "network": return "Connectivity diagnostics";
            case "flash": return "Hardware torch control";
            case "calculator": return "Fast, local arithmetic";
            case "notes": return "Saved only on this device";
            case "qr": return "Scan, create, and save QR";
            case "stopwatch": return "Precise elapsed time";
            case "timer": return "Simple countdown";
            case "converter": return "Common unit conversions";
            case "files": return "Android document picker";
            case "apps": return "Open app settings quickly";
            case "system": return "Native Android settings";
            case "cleaner": return "One-tap temporary cache cleanup";
            case "sensors": return "Hardware sensors reported by Android";
            case "permissions": return "Check this app’s permissions";
            default: return "Appearance and preferences";
        }
    }

    private View makeBottomNav(String selected) {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(10), dp(7), dp(10), dp(9));
        nav.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        String[][] items = {{"◈", "Home", "home"}, {"▦", "Tools", "tools"}, {"⚙", "Settings", "settings"}};
        for (String[] item : items) {
            boolean active = selected.equals(item[2]);
            LinearLayout cell = new LinearLayout(this);
            cell.setGravity(Gravity.CENTER);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setPadding(dp(12), dp(4), dp(12), dp(2));
            TextView icon = label(item[0], 20, active ? accent() : muted(), true);
            icon.setGravity(Gravity.CENTER);
            TextView text = label(item[1], 10, active ? textColor() : muted(), active);
            text.setGravity(Gravity.CENTER);
            cell.addView(icon);
            cell.addView(text);
            cell.setOnClickListener(v -> renderPage(item[2]));
            nav.addView(cell, new LinearLayout.LayoutParams(0, -1, 1));
        }
        nav.setElevation(dp(12));
        return nav;
    }

    private void buildHome(LinearLayout body) {
        FrameLayout visualHeader = new FrameLayout(this);
        visualHeader.setBackground(backgroundGradient(blend(accent(), Color.rgb(20, 36, 79), 0.30f), Color.rgb(20, 27, 53), 2));
        visualHeader.setClipToOutline(true);
        ImageView heroArt = new ImageView(this);
        heroArt.setImageResource(R.drawable.hero_liquid);
        heroArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroArt.setContentDescription("Abstract liquid-glass artwork");
        heroArt.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        heroArt.setAlpha(isLight() ? 0.56f : 0.76f);
        heroArt.setTranslationX(dp(12));
        heroArt.animate().translationX(0f).setDuration(640L).start();
        FrameLayout.LayoutParams artLp = new FrameLayout.LayoutParams(dp(142), dp(142), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        artLp.setMargins(0, 0, dp(8), 0);
        visualHeader.addView(heroArt, artLp);

        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.VERTICAL);
        status.setPadding(dp(20), dp(20), dp(20), dp(18));
        TextView eyebrow = label("YOUR DEVICE, AT A GLANCE", 10, Color.WHITE, true);
        status.addView(eyebrow);
        TextView device = label(deviceName(), 22, Color.WHITE, true, dp(8));
        device.setMaxWidth(dp(220));
        status.addView(device, marginParams(-1, -2, 0, dp(8), dp(86), 0));
        TextView subtitle = label("A calmer workspace for your everyday tools.", 11, Color.argb(232, 244, 247, 255), false);
        subtitle.setMaxWidth(dp(235));
        status.addView(subtitle, marginParams(-1, -2, 0, dp(5), dp(74), 0));

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView api = label("ANDROID 10  ·  API 29", 10, Color.WHITE, true);
        api.setBackground(solid(roundRect(Color.argb(48, 255, 255, 255), dp(30), Color.argb(90, 255, 255, 255))));
        api.setPadding(dp(10), dp(7), dp(10), dp(7));
        statusRow.addView(api, new LinearLayout.LayoutParams(0, -2, 1));
        TextView refresh = pill("↻ Refresh", Color.argb(42, 255, 255, 255), Color.WHITE, 40);
        refresh.setOnClickListener(v -> renderPage("home"));
        statusRow.addView(refresh);
        status.addView(statusRow, marginParams(-1, -2, 0, dp(17), 0, 0));
        visualHeader.addView(status, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        body.addView(visualHeader, marginParams(-1, -2, 0, 0, 0, dp(17)));

        addSectionTitle(body, "Device snapshot", "Current values from Android");
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statTile("CPU CORES", String.valueOf(Runtime.getRuntime().availableProcessors()), "reported", "◈"), new LinearLayout.LayoutParams(0, dp(94), 1));
        stats.addView(statTile("RAM FREE", formatBytes(availableRam()), "available", "▤"), new LinearLayout.LayoutParams(0, dp(94), 1));
        stats.addView(statTile("STORAGE", formatBytes(freeStorage()), "free", "▣"), new LinearLayout.LayoutParams(0, dp(94), 1));
        body.addView(stats, marginParams(-1, -2, 0, 0, 0, dp(22)));

        addSectionTitle(body, "Quick access", "Your everyday tools");
        addToolGrid(body, new Tool[]{
                new Tool("◈", "Device Monitor", "RAM, storage, battery", "device"),
                new Tool("⌁", "Network Lab", "Ping, DNS, speed", "network"),
                new Tool("ϟ", "Flashlight", "Torch control", "flash"),
                new Tool("＋", "Calculator", "Everyday math", "calculator"),
                new Tool("◷", "Stopwatch", "Track elapsed time", "stopwatch"),
                new Tool("◴", "Countdown", "Simple timer", "timer"),
                new Tool("▧", "QR Studio", "Scan and create QR", "qr"),
                new Tool("▤", "Quick Notes", "Save ideas locally", "notes"),
                new Tool("✧", "Cache Cleaner", "One-tap app cache", "cleaner"),
                new Tool("◉", "Sensor Lab", "Hardware sensors", "sensors")
        });

        LinearLayout hint = card("Built for real Android permissions", "No root required. TeinTools reports what the system exposes and uses native settings for protected controls.", false);
        body.addView(hint, marginParams(-1, -2, 0, dp(22), 0, 0));
    }

    private void buildTools(LinearLayout body) {
        addSectionTitle(body, "All tools", "Local utilities, diagnostics, and shortcuts");
        addToolGrid(body, new Tool[]{
                new Tool("◈", "Device Monitor", "CPU, RAM, battery", "device"),
                new Tool("⌁", "Network Lab", "Connection tests", "network"),
                new Tool("ϟ", "Flashlight", "Camera torch", "flash"),
                new Tool("＋", "Calculator", "Arithmetic", "calculator"),
                new Tool("◷", "Stopwatch", "Elapsed time", "stopwatch"),
                new Tool("◴", "Countdown", "Timer", "timer"),
                new Tool("▧", "QR Studio", "Scan/generate QR", "qr"),
                new Tool("▤", "Quick Notes", "Private local notes", "notes"),
                new Tool("↔", "Unit Converter", "Length, temp, data", "converter"),
                new Tool("▣", "File Hub", "Open/save files", "files"),
                new Tool("▥", "Installed Apps", "App info shortcuts", "apps"),
                new Tool("✧", "Cache Cleaner", "Clean TeinTools cache", "cleaner"),
                new Tool("◉", "Sensor Lab", "Hardware sensor list", "sensors"),
                new Tool("♧", "Permission Inspector", "App permission status", "permissions"),
                new Tool("⚙", "System Shortcuts", "Wi-Fi, display, power", "system")
        });
        LinearLayout note = card("Platform note", "Android 10 blocks privileged actions by design. Cache Cleaner safely clears TeinTools temporary files; it cannot silently erase other apps’ private caches. Use Android Settings for system-wide storage management.", false);
        body.addView(note, marginParams(-1, -2, 0, dp(20), 0, 0));
    }

    private void buildSettings(LinearLayout body) {
        addSectionTitle(body, "Appearance", "Personalize your toolbox");
        LinearLayout themeCard = card(null, null, false);
        themeCard.addView(label("Theme mode", 15, textColor(), true));
        addText(themeCard, "Choose a look that feels comfortable on your screen.", 11, muted(), false, dp(8));
        LinearLayout themeRow = new LinearLayout(this);
        themeRow.setOrientation(LinearLayout.HORIZONTAL);
        addChoice(themeRow, "System", "system".equals(themeMode), () -> { themeMode = "system"; saveAppearance(); renderPage("settings"); });
        addChoice(themeRow, "Dark", "dark".equals(themeMode), () -> { themeMode = "dark"; saveAppearance(); renderPage("settings"); });
        addChoice(themeRow, "Light", "light".equals(themeMode), () -> { themeMode = "light"; saveAppearance(); renderPage("settings"); });
        themeCard.addView(themeRow, marginParams(-1, -2, 0, dp(12), 0, 0));
        body.addView(themeCard, marginParams(-1, -2, 0, 0, 0, dp(14)));

        LinearLayout accentCard = card(null, null, false);
        accentCard.addView(label("Accent color", 15, textColor(), true));
        addText(accentCard, "The accent is used for active states and highlights.", 11, muted(), false, dp(7));
        LinearLayout colorRow = new LinearLayout(this);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        addColorChoice(colorRow, "Violet", "violet", Color.rgb(143,132,255));
        addColorChoice(colorRow, "Blue", "blue", Color.rgb(83,142,255));
        addColorChoice(colorRow, "Cyan", "cyan", Color.rgb(69,213,212));
        addColorChoice(colorRow, "Green", "green", Color.rgb(98,217,160));
        accentCard.addView(colorRow, marginParams(-1, -2, 0, dp(12), 0, 0));
        body.addView(accentCard, marginParams(-1, -2, 0, 0, 0, dp(14)));

        LinearLayout privacy = card("Privacy and permissions", "Notes are saved in app-private storage. Files use Android's document picker. Network tests contact public HTTPS endpoints only when you press a test button. QR scanning uses the camera only after you start scanning.", false);
        body.addView(privacy, marginParams(-1, -2, 0, 0, 0, dp(14)));
        LinearLayout about = card("About TeinTools", "Version 1.1.0\nPackage: com.teinzz.teintools\nDesigned for Android 10 (API 29), no root required. Liquid-glass styling uses compatibility gradients.", false);
        body.addView(about, marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void addChoice(LinearLayout row, String label, boolean selected, Runnable action) {
        TextView t = pill(label, selected ? blend(accent(), surface(), isLight() ? 0.78f : 0.68f) : surfaceRaised(), selected ? accent() : muted(), 40);
        t.setTextSize(11);
        t.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
        lp.setMargins(0, 0, dp(6), 0);
        row.addView(t, lp);
    }

    private void addColorChoice(LinearLayout row, String name, String value, int color) {
        LinearLayout cell = new LinearLayout(this);
        cell.setGravity(Gravity.CENTER);
        cell.setOrientation(LinearLayout.VERTICAL);
        View dot = new View(this);
        GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color);
        if (accentMode.equals(value)) d.setStroke(dp(3), textColor());
        dot.setBackground(d);
        cell.addView(dot, new LinearLayout.LayoutParams(dp(27), dp(27)));
        TextView txt = label(name, 9, accentMode.equals(value) ? textColor() : muted(), accentMode.equals(value));
        txt.setGravity(Gravity.CENTER);
        cell.addView(txt, marginParams(-1, -2, 0, dp(5), 0, 0));
        cell.setOnClickListener(v -> { accentMode = value; saveAppearance(); renderPage("settings"); });
        row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void saveAppearance() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("theme", themeMode).putString("accent", accentMode).apply();
    }

    private void buildDevicePage(LinearLayout body) {
        LinearLayout hero = card(null, null, true);
        hero.addView(label(deviceName(), 21, Color.WHITE, true));
        addText(hero, Build.MANUFACTURER + " · " + Build.MODEL, 12, Color.argb(220,255,255,255), false, dp(5));
        TextView refresh = pill("↻  Refresh readings", Color.argb(38,255,255,255), Color.WHITE, 42);
        refresh.setOnClickListener(v -> renderPage("device"));
        hero.addView(refresh, marginParams(-1, -2, 0, dp(14), 0, 0));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addSectionTitle(body, "Memory and storage", "Available capacity reported by Android");
        LinearLayout memory = card(null, null, false);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        addKeyValue(memory, "Available RAM", formatBytes(mi.availMem));
        addKeyValue(memory, "Total RAM", formatBytes(mi.totalMem));
        addKeyValue(memory, "Low-memory state", mi.lowMemory ? "System reports low memory" : "Normal");
        StatFs s = new StatFs(Environment.getDataDirectory().getAbsolutePath());
        addKeyValue(memory, "Internal storage free", formatBytes(s.getAvailableBytes()));
        addKeyValue(memory, "Internal storage total", formatBytes(s.getTotalBytes()));
        body.addView(memory, marginParams(-1, -2, 0, 0, 0, dp(15)));

        addSectionTitle(body, "Battery and temperature", "Values supplied by the device");
        LinearLayout battery = card(null, null, false);
        Intent intent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (intent != null) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int percent = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
            addKeyValue(battery, "Battery level", percent >= 0 ? percent + "%" : "Unavailable");
            int temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            addKeyValue(battery, "Battery temperature", temp >= 0 ? String.format(Locale.US, "%.1f °C", temp / 10f) : "Unavailable");
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            addKeyValue(battery, "Charging", status == BatteryManager.BATTERY_STATUS_CHARGING ? "Charging" : status == BatteryManager.BATTERY_STATUS_FULL ? "Full" : "Not charging");
            int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            addKeyValue(battery, "Battery health", batteryHealth(health));
        } else addKeyValue(battery, "Battery status", "Unavailable");
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                PowerManager pm = getSystemService(PowerManager.class);
                addKeyValue(battery, "Thermal status", pm == null ? "Unavailable" : thermalStatus(pm.getCurrentThermalStatus()));
            } catch (Exception ex) { addKeyValue(battery, "Thermal status", "Not exposed by this device"); }
        }
        body.addView(battery, marginParams(-1, -2, 0, 0, 0, dp(15)));

        addSectionTitle(body, "System profile", "Static device and OS details");
        LinearLayout details = card(null, null, false);
        addKeyValue(details, "Android version", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        addKeyValue(details, "Build fingerprint", shorten(Build.FINGERPRINT, 62));
        addKeyValue(details, "CPU ABI", join(Build.SUPPORTED_ABIS, ", "));
        addKeyValue(details, "Available CPU cores", String.valueOf(Runtime.getRuntime().availableProcessors()));
        addKeyValue(details, "App target SDK", "29 (Android 10 compatibility target)");
        body.addView(details, marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void buildNetworkPage(LinearLayout body) {
        addSectionTitle(body, "Connection overview", "Current network as seen by Android");
        LinearLayout info = card(null, null, false);
        addKeyValue(info, "Connectivity", networkSummary());
        addKeyValue(info, "Wi-Fi details", wifiSummary());
        addKeyValue(info, "Downstream estimate", networkBandwidth());
        body.addView(info, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addSectionTitle(body, "Run diagnostics", "Each test runs only when selected");
        LinearLayout results = card(null, null, false);
        networkProgress = new ProgressBar(this);
        networkProgress.setIndeterminate(true);
        networkProgress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
        networkProgress.setVisibility(View.GONE);
        results.addView(networkProgress, marginParams(dp(24), dp(24), 0, 0, 0, dp(8)));
        networkResultText = label("Ready. Choose a test below.", 12, muted(), false);
        results.addView(networkResultText);
        body.addView(results, marginParams(-1, -2, 0, 0, 0, dp(13)));

        addActionButton(body, "Test HTTPS connectivity", "Checks a public connectivity endpoint", () -> runNetworkTest("HTTPS", this::testHttps));
        addActionButton(body, "Resolve DNS", "Resolves example.com through the configured resolver", () -> runNetworkTest("DNS", this::testDns));
        addActionButton(body, "TCP latency", "Measures a TCP connection to 1.1.1.1:443", () -> runNetworkTest("TCP", this::testTcp));
        addActionButton(body, "Estimate download speed", "Downloads a small test payload; data usage applies", () -> runNetworkTest("Speed", this::testDownloadSpeed));
        addActionButton(body, "Open Wi-Fi settings", "Use Android's native network controls", () -> launchSettings(Settings.ACTION_WIFI_SETTINGS));
        addText(body, "Note: ICMP ping and Wi-Fi scans can be blocked or throttled on Android. These tests use HTTPS, DNS, and TCP instead of reporting unreliable fake ping values.", 10, muted(), false, dp(16));
    }

    private void runNetworkTest(String label, NetworkTest test) {
        if (networkResultText != null) networkResultText.setText(label + " · checking connection…");
        if (networkProgress != null) networkProgress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            String result;
            try { result = test.run(); }
            catch (Exception ex) { result = "Failed: " + safeMessage(ex); }
            final String finalResult = result;
            runOnUiThread(() -> {
                if (networkProgress != null) networkProgress.setVisibility(View.GONE);
                if (networkResultText != null) networkResultText.setText(label + "\n" + finalResult);
            });
        }, "tein-network-test").start();
    }

    private String testHttps() throws Exception {
        long start = SystemClock.elapsedRealtime();
        HttpURLConnection c = (HttpURLConnection)new URL("https://connectivitycheck.gstatic.com/generate_204").openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(7000); c.setInstanceFollowRedirects(false); c.setRequestMethod("GET");
        int code = c.getResponseCode();
        long elapsed = SystemClock.elapsedRealtime() - start;
        c.disconnect();
        return "HTTP " + code + " in " + elapsed + " ms" + (code == 204 ? " · Internet reachable" : " · Endpoint replied");
    }

    private String testDns() throws Exception {
        long start = SystemClock.elapsedRealtime();
        InetAddress[] addresses = InetAddress.getAllByName("example.com");
        long elapsed = SystemClock.elapsedRealtime() - start;
        String ip = addresses.length > 0 ? addresses[0].getHostAddress() : "No address returned";
        return "example.com → " + ip + "\nResolved in " + elapsed + " ms";
    }

    private String testTcp() throws Exception {
        long start = SystemClock.elapsedRealtime();
        Socket socket = new Socket();
        socket.connect(new InetSocketAddress("1.1.1.1", 443), 6000);
        long elapsed = SystemClock.elapsedRealtime() - start;
        socket.close();
        return "TCP connect succeeded in " + elapsed + " ms";
    }

    private String testDownloadSpeed() throws Exception {
        URLConnection c = new URL("https://speed.cloudflare.com/__down?bytes=2000000").openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(10000);
        long start = SystemClock.elapsedRealtime();
        long bytes = 0L;
        byte[] buffer = new byte[32768];
        try (InputStream in = c.getInputStream()) {
            int n;
            while ((n = in.read(buffer)) != -1) bytes += n;
        }
        long elapsed = Math.max(1L, SystemClock.elapsedRealtime() - start);
        double mbps = (bytes * 8.0) / (elapsed / 1000.0) / 1_000_000.0;
        return String.format(Locale.US, "Received %s in %.2f s\nEstimated throughput: %.2f Mbps", formatBytes(bytes), elapsed / 1000.0, mbps);
    }

    private interface NetworkTest { String run() throws Exception; }

    private void buildFlashPage(LinearLayout body) {
        LinearLayout hero = card(null, null, true);
        TextView icon = label(torchOn ? "ϟ" : "✧", 54, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        hero.addView(icon, new LinearLayout.LayoutParams(-1, dp(100)));
        TextView state = label(torchOn ? "Flashlight is ON" : "Flashlight is OFF", 19, Color.WHITE, true);
        state.setGravity(Gravity.CENTER);
        hero.addView(state, marginParams(-1, -2, 0, dp(3), 0, 0));
        TextView toggle = pill(torchOn ? "Turn off" : "Turn on", Color.argb(45, 255,255,255), Color.WHITE, 46);
        toggle.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                pendingTorchOn = true;
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            } else {
                setTorch(!torchOn);
                renderPage("flash");
            }
        });
        hero.addView(toggle, marginParams(-1, -2, 0, dp(18), dp(6), dp(4)));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(15)));
        LinearLayout note = card("Compatibility", "The torch is controlled through Android's Camera2 API. Some devices cannot turn on the torch when another app is using the camera, and some devices do not have a flash.", false);
        body.addView(note, marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void setTorch(boolean enabled) {
        try {
            CameraManager manager = (CameraManager)getSystemService(CAMERA_SERVICE);
            String selected = null;
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Boolean hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(hasFlash)) {
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { selected = id; break; }
                    if (selected == null) selected = id;
                }
            }
            if (selected == null) { toast("This device does not report a camera flash."); return; }
            manager.setTorchMode(selected, enabled);
            torchOn = enabled;
        } catch (Exception ex) {
            toast("Cannot control torch: " + safeMessage(ex));
            torchOn = false;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && pendingTorchOn) {
                setTorch(true);
                pendingTorchOn = false;
                renderPage("flash");
            } else if (grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                pendingTorchOn = false;
                toast("Camera permission is needed for torch control.");
            }
        }
    }

    private void buildCalculatorPage(LinearLayout body) {
        LinearLayout panel = card(null, null, false);
        EditText display = new EditText(this);
        display.setSingleLine(false);
        display.setMinLines(2);
        display.setMaxLines(3);
        display.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        display.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        display.setTextColor(textColor());
        display.setHintTextColor(muted());
        display.setHint("0");
        display.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        display.setPadding(dp(10), dp(15), dp(10), dp(15));
        display.setBackground(solid(roundRect(surfaceRaised(), dp(18), borderColor())));
        display.setText(calcExpression);
        panel.addView(display, marginParams(-1, dp(100), 0, 0, 0, dp(14)));
        String[][] keys = {{"C", "⌫", "%", "÷"}, {"7", "8", "9", "×"}, {"4", "5", "6", "−"}, {"1", "2", "3", "+"}, {"(", "0", ".", ")"}, {"±", "="}};
        for (String[] rowKeys : keys) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (String key : rowKeys) {
                TextView button = pill(key, isOperator(key) ? blend(accent(), surface(), isLight() ? 0.82f : 0.66f) : surfaceRaised(), isOperator(key) ? accent() : textColor(), 52);
                button.setTextSize(19);
                button.setOnClickListener(v -> {
                    String newExpression = display.getText().toString();
                    switch (key) {
                        case "C": newExpression = ""; break;
                        case "⌫": if (!newExpression.isEmpty()) newExpression = newExpression.substring(0, newExpression.length() - 1); break;
                        case "=":
                            try { double value = new ExpressionParser(newExpression).parse(); newExpression = formatNumber(value); }
                            catch (Exception e) { newExpression = "Error"; }
                            break;
                        case "±":
                            if (!newExpression.isEmpty() && !"Error".equals(newExpression)) newExpression = "(" + newExpression + ")*-1";
                            break;
                        default:
                            if ("Error".equals(newExpression)) newExpression = "";
                            newExpression += key.equals("×") ? "*" : key.equals("÷") ? "/" : key.equals("−") ? "-" : key;
                    }
                    calcExpression = newExpression;
                    display.setText(newExpression);
                    display.setSelection(display.getText().length());
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                row.addView(button, lp);
            }
            panel.addView(row);
        }
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(16)));
        addText(body, "Supports +, −, ×, ÷, parentheses, and %. Calculations run locally.", 10, muted(), false, dp(14));
    }

    private boolean isOperator(String s) { return "+".equals(s) || "−".equals(s) || "×".equals(s) || "÷".equals(s) || "=".equals(s) || "%".equals(s); }

    private static class ExpressionParser {
        private final String s; private int pos = -1; private int ch;
        ExpressionParser(String input) { s = input.replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", ""); }
        void nextChar() { ch = (++pos < s.length()) ? s.charAt(pos) : -1; }
        boolean eat(int c) { while (ch == ' ') nextChar(); if (ch == c) { nextChar(); return true; } return false; }
        double parse() { nextChar(); double x = parseExpression(); if (pos < s.length()) throw new RuntimeException("Unexpected character"); if (Double.isNaN(x) || Double.isInfinite(x)) throw new RuntimeException("Invalid result"); return x; }
        double parseExpression() { double x = parseTerm(); for (;;) { if (eat('+')) x += parseTerm(); else if (eat('-')) x -= parseTerm(); else return x; } }
        double parseTerm() { double x = parseFactor(); for (;;) { if (eat('*')) x *= parseFactor(); else if (eat('/')) { double d = parseFactor(); if (d == 0) throw new RuntimeException("Divide by zero"); x /= d; } else if (eat('%')) { double d = parseFactor(); if (d == 0) throw new RuntimeException("Divide by zero"); x %= d; } else return x; } }
        double parseFactor() {
            if (eat('+')) return parseFactor();
            if (eat('-')) return -parseFactor();
            double x; int start = this.pos;
            if (eat('(')) { x = parseExpression(); if (!eat(')')) throw new RuntimeException("Missing )"); }
            else if ((ch >= '0' && ch <= '9') || ch == '.') { while ((ch >= '0' && ch <= '9') || ch == '.') nextChar(); x = Double.parseDouble(s.substring(start, this.pos)); }
            else throw new RuntimeException("Number expected");
            return x;
        }
    }

    private void buildNotesPage(LinearLayout body) {
        LinearLayout panel = card(null, null, false);
        addText(panel, "Notes are stored locally on this device.", 12, muted(), false, dp(6));
        EditText editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setTextSize(15);
        editor.setTextColor(textColor());
        editor.setHintTextColor(muted());
        editor.setHint("Write a reminder or idea…");
        editor.setMinLines(10);
        editor.setMaxLines(20);
        editor.setPadding(dp(13), dp(13), dp(13), dp(13));
        editor.setBackground(solid(roundRect(surfaceRaised(), dp(16), borderColor())));
        editor.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString("notes", ""));
        panel.addView(editor, marginParams(-1, -2, 0, dp(12), 0, 0));
        TextView status = label("Saved automatically", 10, muted(), false);
        panel.addView(status, marginParams(-1, -2, 0, dp(8), 0, 0));
        editor.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("notes", s.toString()).apply();
                status.setText("Saved locally · " + s.length() + " characters");
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addActionButton(body, "Share note", "Open Android share sheet", () -> shareText("TeinTools note", editor.getText().toString()));
    }

    private void buildQrPage(LinearLayout body) {
        LinearLayout scanCard = card(null, null, false);
        scanCard.addView(label("Scan a QR code", 16, textColor(), true));
        addText(scanCard, "The camera opens only after you press Scan.", 11, muted(), false, dp(5));
        TextView scan = pill("Scan QR code", accent(), Color.WHITE, 46);
        scan.setOnClickListener(v -> new IntentIntegrator(MainActivity.this).setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES).setPrompt("Align the code inside the frame").setBeepEnabled(false).setOrientationLocked(false).initiateScan());
        scanCard.addView(scan, marginParams(-1, -2, 0, dp(14), 0, 0));
        body.addView(scanCard, marginParams(-1, -2, 0, 0, 0, dp(14)));

        LinearLayout gen = card(null, null, false);
        gen.addView(label("Create a QR code", 16, textColor(), true));
        qrInputField = editField("Text or URL to encode", false);
        gen.addView(qrInputField, marginParams(-1, dp(54), 0, dp(10), 0, 0));
        TextView generate = pill("Generate QR", blend(accent(), surface(), isLight() ? 0.78f : 0.65f), accent(), 44);
        generate.setOnClickListener(v -> generateQr());
        gen.addView(generate, marginParams(-1, -2, 0, dp(10), 0, 0));
        qrPreview = new ImageView(this);
        qrPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrPreview.setPadding(dp(12), dp(12), dp(12), dp(12));
        qrPreview.setBackground(solid(roundRect(Color.WHITE, dp(18), borderColor())));
        gen.addView(qrPreview, marginParams(-1, dp(260), dp(12), dp(4), dp(12), dp(4)));
        TextView save = pill("Save QR to Pictures/TeinTools", surfaceRaised(), textColor(), 44);
        save.setOnClickListener(v -> saveQrBitmap());
        gen.addView(save, marginParams(-1, -2, 0, dp(9), 0, 0));
        body.addView(gen, marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void generateQr() {
        if (qrInputField == null || qrInputField.getText().toString().trim().isEmpty()) { toast("Enter some text or a URL first."); return; }
        try {
            String text = qrInputField.getText().toString().trim();
            BitMatrix matrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 600, 600);
            int width = matrix.getWidth(), height = matrix.getHeight();
            int[] pixels = new int[width * height];
            for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) pixels[y * width + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
            lastQrBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            lastQrBitmap.setPixels(pixels, 0, width, 0, 0, width, height);
            qrPreview.setImageBitmap(lastQrBitmap);
        } catch (WriterException e) { toast("QR could not be generated."); }
    }

    private void saveQrBitmap() {
        if (lastQrBitmap == null) { toast("Generate a QR code first."); return; }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "TeinTools-QR-" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TeinTools");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            ContentResolver resolver = getContentResolver();
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("Could not create image entry");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("Could not open image output");
                lastQrBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            ContentValues done = new ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING, 0); resolver.update(uri, done, null, null);
            toast("QR saved to Pictures/TeinTools");
        } catch (Exception e) { toast("Could not save QR: " + safeMessage(e)); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanResult != null) {
            if (scanResult.getContents() != null) {
                String contents = scanResult.getContents();
                renderPage("qr");
                if (qrInputField != null) qrInputField.setText(contents);
                toast("QR scanned: " + shorten(contents, 100));
            } else toast("Scan cancelled.");
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_CREATE_FILE) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("No file stream");
                String content = fileContentField == null ? "Created with TeinTools\n" : fileContentField.getText().toString();
                out.write(content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                toast("File saved successfully.");
            } catch (Exception e) { toast("Could not write file: " + safeMessage(e)); }
        } else if (requestCode == REQ_OPEN_FILE || requestCode == REQ_OPEN_IMAGE) {
            toast("Selected: " + queryDisplayName(uri));
        }
    }

    private void buildStopwatchPage(LinearLayout body) {
        LinearLayout panel = card(null, null, true);
        stopwatchDisplay = label(formatStopwatch(stopwatchAccumulated + (stopwatchRunning ? SystemClock.elapsedRealtime() - stopwatchStartedAt : 0L)), 42, Color.WHITE, true);
        stopwatchDisplay.setGravity(Gravity.CENTER);
        stopwatchDisplay.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        panel.addView(stopwatchDisplay, new LinearLayout.LayoutParams(-1, dp(132)));
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView start = pill(stopwatchRunning ? "Pause" : "Start", Color.argb(48,255,255,255), Color.WHITE, 48);
        start.setOnClickListener(v -> {
            if (stopwatchRunning) {
                stopwatchAccumulated += SystemClock.elapsedRealtime() - stopwatchStartedAt;
                stopwatchRunning = false;
            } else {
                stopwatchStartedAt = SystemClock.elapsedRealtime();
                stopwatchRunning = true;
            }
            handler.removeCallbacks(stopwatchTick);
            renderPage("stopwatch");
        });
        TextView reset = pill("Reset", Color.argb(28,255,255,255), Color.WHITE, 48);
        reset.setOnClickListener(v -> { stopwatchRunning = false; stopwatchAccumulated = 0L; stopwatchStartedAt = 0L; handler.removeCallbacks(stopwatchTick); renderPage("stopwatch"); });
        actions.addView(start, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(reset, new LinearLayout.LayoutParams(0, dp(48), 1));
        panel.addView(actions, marginParams(-1, -2, 0, dp(5), 0, 0));
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addText(body, "Uses Android's monotonic elapsed-realtime clock. The stopwatch continues while the app process remains active.", 10, muted(), false, dp(12));
    }

    private void buildTimerPage(LinearLayout body) {
        LinearLayout panel = card(null, null, true);
        timerDisplay = label(formatTimer(timerRunning ? timerEndsAt - SystemClock.elapsedRealtime() : timerOriginalDuration), 42, Color.WHITE, true);
        timerDisplay.setGravity(Gravity.CENTER);
        timerDisplay.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        panel.addView(timerDisplay, new LinearLayout.LayoutParams(-1, dp(122)));
        EditText mins = editField("Minutes", true);
        mins.setText("5");
        panel.addView(mins, marginParams(-1, dp(52), 0, dp(8), 0, 0));
        EditText secs = editField("Seconds", true);
        secs.setText("0");
        panel.addView(secs, marginParams(-1, dp(52), 0, dp(8), 0, 0));
        TextView start = pill(timerRunning ? "Restart timer" : "Start timer", Color.argb(48,255,255,255), Color.WHITE, 47);
        start.setOnClickListener(v -> {
            try {
                long m = Long.parseLong(mins.getText().toString().trim().isEmpty() ? "0" : mins.getText().toString().trim());
                long s = Long.parseLong(secs.getText().toString().trim().isEmpty() ? "0" : secs.getText().toString().trim());
                long duration = Math.max(0L, m * 60_000L + s * 1000L);
                if (duration <= 0L || duration > 24L * 60L * 60L * 1000L) { toast("Set a duration between 1 second and 24 hours."); return; }
                timerOriginalDuration = duration;
                timerEndsAt = SystemClock.elapsedRealtime() + duration;
                timerRunning = true;
                handler.removeCallbacks(timerTick); handler.post(timerTick);
                renderPage("timer");
            } catch (NumberFormatException ex) { toast("Enter a valid number of minutes and seconds."); }
        });
        panel.addView(start, marginParams(-1, -2, 0, dp(14), 0, 0));
        TextView cancel = pill("Cancel / reset", Color.argb(25,255,255,255), Color.WHITE, 43);
        cancel.setOnClickListener(v -> { timerRunning = false; timerEndsAt = 0L; timerOriginalDuration = 0L; handler.removeCallbacks(timerTick); renderPage("timer"); });
        panel.addView(cancel, marginParams(-1, -2, 0, dp(8), 0, 0));
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addText(body, "The timer is active while the app process is alive. Closing or force-stopping the app can end the countdown; it is not an alarm-clock service.", 10, muted(), false, dp(12));
    }

    private void updateTimerLabel() {
        if (timerDisplay != null) timerDisplay.setText(formatTimer(timerRunning ? timerEndsAt - SystemClock.elapsedRealtime() : timerOriginalDuration));
    }

    private void buildConverterPage(LinearLayout body) {
        LinearLayout panel = card(null, null, false);
        panel.addView(label("Convert a value", 16, textColor(), true));
        EditText amount = editField("Enter value", true);
        amount.setText("1");
        panel.addView(amount, marginParams(-1, dp(54), 0, dp(11), 0, 0));
        String[] conversions = {"m → km", "km → m", "cm → m", "m → cm", "°C → °F", "°F → °C", "MB → GB", "GB → MB", "km/h → mph", "mph → km/h"};
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, conversions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        panel.addView(spinner, marginParams(-1, dp(52), 0, dp(9), 0, 0));
        TextView output = label("Result appears here", 18, accent(), true);
        output.setPadding(dp(5), dp(17), dp(5), dp(17));
        panel.addView(output);
        TextView convert = pill("Convert", blend(accent(), surface(), isLight() ? 0.78f : 0.66f), accent(), 46);
        convert.setOnClickListener(v -> {
            try {
                double x = Double.parseDouble(amount.getText().toString().trim());
                double y;
                String unit = (String)spinner.getSelectedItem();
                switch (unit) {
                    case "m → km": y = x / 1000; break;
                    case "km → m": y = x * 1000; break;
                    case "cm → m": y = x / 100; break;
                    case "m → cm": y = x * 100; break;
                    case "°C → °F": y = x * 9 / 5 + 32; break;
                    case "°F → °C": y = (x - 32) * 5 / 9; break;
                    case "MB → GB": y = x / 1000; break;
                    case "GB → MB": y = x * 1000; break;
                    case "km/h → mph": y = x * 0.621371; break;
                    default: y = x / 0.621371; break;
                }
                output.setText(formatNumber(y) + "   " + unit.substring(unit.indexOf('→') + 1).trim());
            } catch (Exception e) { output.setText("Enter a valid number."); }
        });
        panel.addView(convert, marginParams(-1, -2, 0, dp(6), 0, 0));
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addText(body, "Data size conversions use decimal units (1 GB = 1000 MB).", 10, muted(), false, dp(12));
    }

    private void buildFilesPage(LinearLayout body) {
        LinearLayout info = card("Storage Access Framework", "Files are chosen with Android's system document picker. TeinTools does not request full-storage access.", false);
        body.addView(info, marginParams(-1, -2, 0, 0, 0, dp(14)));
        addActionButton(body, "Open a file", "Select a document from a provider on this device", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i, REQ_OPEN_FILE);
        });
        addActionButton(body, "Pick an image", "Choose an image using Android's picker", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i, REQ_OPEN_IMAGE);
        });
        LinearLayout content = card(null, null, false);
        content.addView(label("Create a text file", 15, textColor(), true));
        fileContentField = editField("Text to save…", false);
        fileContentField.setMinLines(5);
        fileContentField.setGravity(Gravity.TOP | Gravity.START);
        content.addView(fileContentField, marginParams(-1, dp(150), 0, dp(10), 0, 0));
        TextView save = pill("Save with Android picker", accent(), Color.WHITE, 45);
        save.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TITLE, "TeinTools-note.txt"); startActivityForResult(i, REQ_CREATE_FILE);
        });
        content.addView(save, marginParams(-1, -2, 0, dp(9), 0, 0));
        body.addView(content, marginParams(-1, -2, 0, 0, 0, dp(18)));
    }

    private void buildAppsPage(LinearLayout body) {
        addText(body, "Open Android's App Info screen to manage permissions, battery use, or storage for a selected app. TeinTools does not force-stop other apps.", 11, muted(), false, dp(10));
        EditText search = editField("Search installed apps", false);
        body.addView(search, marginParams(-1, dp(52), 0, dp(5), 0, dp(10)));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list, new LinearLayout.LayoutParams(-1, -2));
        try {
            installedAppsCache = getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA);
            Collections.sort(installedAppsCache, Comparator.comparing(a -> String.valueOf(getPackageManager().getApplicationLabel(a)).toLowerCase(Locale.ROOT)));
        } catch (Exception e) { installedAppsCache = new ArrayList<>(); }
        Runnable update = () -> {
            list.removeAllViews();
            String query = search.getText().toString().toLowerCase(Locale.ROOT).trim();
            int count = 0;
            for (ApplicationInfo app : installedAppsCache) {
                boolean system = (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                String name = String.valueOf(getPackageManager().getApplicationLabel(app));
                if (system && !query.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(query)) continue;
                if (system && query.isEmpty()) continue;
                if (!name.toLowerCase(Locale.ROOT).contains(query) && !app.packageName.toLowerCase(Locale.ROOT).contains(query)) continue;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(13), dp(12), dp(13), dp(12));
                row.setBackground(solid(roundRect(surface(), dp(15), borderColor())));
                LinearLayout labels = new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL);
                labels.addView(label(name, 13, textColor(), true));
                labels.addView(label(app.packageName, 9, muted(), false));
                row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
                row.addView(label("›", 24, accent(), true));
                row.setOnClickListener(v -> {
                    try { Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.packageName)); startActivity(i); }
                    catch (Exception e) { toast("Cannot open app settings."); }
                });
                LinearLayout.LayoutParams rp = marginParams(-1, -2, 0, dp(3), 0, dp(3));
                list.addView(row, rp);
                count++;
                if (count >= 80) break;
            }
            if (count == 0) addText(list, "No matching apps found.", 12, muted(), false, dp(12));
        };
        update.run();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { update.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void buildCleanerPage(LinearLayout body) {
        LinearLayout hero = card(null, null, true);
        LinearLayout titleLine = new LinearLayout(this);
        titleLine.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(label("One-tap Cache Cleaner", 18, Color.WHITE, true));
        copy.addView(label("Clean temporary files owned by TeinTools.", 11, Color.argb(230, 242, 245, 255), false), marginParams(-1, -2, 0, dp(5), 0, 0));
        titleLine.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        TextView icon = pill("✧", Color.argb(48, 255, 255, 255), Color.WHITE, 54);
        icon.setTextSize(25);
        titleLine.addView(icon, marginParams(54, 54, dp(8), 0, 0, 0));
        hero.addView(titleLine);
        hero.addView(label(formatBytes(cacheSize()), 25, Color.WHITE, true), marginParams(-1, -2, 0, dp(18), 0, 0));
        hero.addView(label("Current TeinTools cache", 10, Color.argb(215, 241, 245, 255), false), marginParams(-1, -2, 0, dp(3), 0, 0));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));

        LinearLayout details = card(null, null, false);
        addKeyValue(details, "Internal cache", formatBytes(directorySize(getCacheDir())));
        File external = getExternalCacheDir();
        addKeyValue(details, "External cache", external == null ? "Not available" : formatBytes(directorySize(external)));
        addKeyValue(details, "Cleanup scope", "TeinTools only");
        body.addView(details, marginParams(-1, -2, 0, 0, 0, dp(14)));

        LinearLayout status = card(null, null, false);
        cacheStatusText = label(cleanerFeedback, 12, muted(), false);
        status.addView(cacheStatusText);
        cacheProgress = new ProgressBar(this);
        cacheProgress.setIndeterminate(true);
        cacheProgress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
        cacheProgress.setVisibility(cleaningCache ? View.VISIBLE : View.GONE);
        status.addView(cacheProgress, marginParams(dp(26), dp(26), 0, dp(8), 0, 0));
        body.addView(status, marginParams(-1, -2, 0, 0, 0, dp(12)));

        addActionButton(body, cleaningCache ? "Cleaning cache…" : "Clean TeinTools cache now", "One tap · deletes only temporary cache files owned by this app", () -> cleanOwnCache());
        addActionButton(body, "Open Android storage settings", "Review storage and clear other apps’ caches manually", this::openStorageSettings);
        LinearLayout note = card("Important Android limitation", "Android 10 keeps other apps’ private cache directories isolated. A normal non-root app cannot erase every app’s cache in one tap. This cleaner never touches your photos, downloads, notes, or app settings.", false);
        body.addView(note, marginParams(-1, -2, 0, dp(10), 0, dp(20)));
    }

    private void cleanOwnCache() {
        if (cleaningCache) { toast("Cache cleanup is already running."); return; }
        cleaningCache = true;
        cleanerFeedback = "Cleaning temporary files safely…";
        if (cacheStatusText != null) cacheStatusText.setText(cleanerFeedback);
        if (cacheProgress != null) cacheProgress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            long before = cacheSize();
            long attempted = clearDirectoryContents(getCacheDir());
            File ext = getExternalCacheDir();
            if (ext != null) attempted += clearDirectoryContents(ext);
            final long removedEstimate = Math.min(before, attempted);
            runOnUiThread(() -> {
                cleaningCache = false;
                cleanerFeedback = "Cleanup complete · " + formatBytes(removedEstimate) + " temporary data removed.";
                if ("cleaner".equals(currentPage)) renderPage("cleaner");
                toast("TeinTools cache cleaned: " + formatBytes(removedEstimate));
            });
        }, "tein-cache-cleaner").start();
    }

    private long cacheSize() {
        long total = directorySize(getCacheDir());
        File ext = getExternalCacheDir();
        if (ext != null) total += directorySize(ext);
        return total;
    }

    private long directorySize(File file) {
        if (file == null || !file.exists()) return 0L;
        if (file.isFile()) return file.length();
        long total = 0L;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) total += directorySize(child);
        return total;
    }

    private long clearDirectoryContents(File directory) {
        if (directory == null || !directory.exists() || !directory.isDirectory()) return 0L;
        long removed = 0L;
        File[] children = directory.listFiles();
        if (children == null) return 0L;
        for (File child : children) {
            long size = directorySize(child);
            if (deleteRecursively(child)) removed += size;
        }
        return removed;
    }

    private boolean deleteRecursively(File file) {
        if (file == null || !file.exists()) return true;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        return file.delete() || !file.exists();
    }

    private void openStorageSettings() {
        try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); }
        catch (Exception first) {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)); }
            catch (Exception second) { launchSettings(Settings.ACTION_SETTINGS); }
        }
    }

    private void buildSensorPage(LinearLayout body) {
        SensorManager manager = (SensorManager)getSystemService(SENSOR_SERVICE);
        List<Sensor> sensors = manager == null ? Collections.emptyList() : manager.getSensorList(Sensor.TYPE_ALL);
        LinearLayout hero = card(null, null, true);
        hero.addView(label(String.valueOf(sensors.size()), 34, Color.WHITE, true));
        hero.addView(label("hardware sensor types reported", 11, Color.argb(220, 245, 247, 255), false), marginParams(-1, -2, 0, dp(2), 0, 0));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));
        addSectionTitle(body, "Available sensors", "The list is read from Android; sensors may be virtual or vendor-specific");
        if (sensors.isEmpty()) {
            body.addView(card("No sensor data", "Android did not report any sensors to this app.", false), marginParams(-1, -2, 0, 0, 0, dp(18)));
        } else {
            for (Sensor sensor : sensors) {
                LinearLayout item = card(null, null, false);
                item.addView(label(sensor.getName(), 13, textColor(), true));
                addText(item, sensor.getVendor() + " · " + sensor.getStringType(), 10, muted(), false, dp(4));
                addKeyValue(item, "Power", String.format(Locale.US, "%.2f mA", sensor.getPower()));
                addKeyValue(item, "Wake-up sensor", sensor.isWakeUpSensor() ? "Yes" : "No");
                body.addView(item, marginParams(-1, -2, 0, 0, 0, dp(8)));
            }
        }
        LinearLayout note = card("Privacy", "TeinTools lists sensor metadata only. It does not continuously read motion or location sensor values in the background.", false);
        body.addView(note, marginParams(-1, -2, 0, dp(8), 0, dp(20)));
    }

    private void buildPermissionsPage(LinearLayout body) {
        addSectionTitle(body, "Permission status", "Live status reported for this app on this device");
        LinearLayout card = card(null, null, false);
        addKeyValue(card, "Camera", checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED ? "Granted" : "Not granted");
        addKeyValue(card, "Internet", "Normal permission · granted by Android");
        addKeyValue(card, "Network state", "Normal permission · granted by Android");
        addKeyValue(card, "Wi-Fi state", "Normal permission · granted by Android");
        body.addView(card, marginParams(-1, -2, 0, 0, 0, dp(14)));
        addActionButton(body, "Open TeinTools app settings", "Review permissions, notifications, and storage controls", () -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            catch (Exception e) { toast("Could not open app settings."); }
        });
        LinearLayout note = card("Permission principle", "Camera access is requested only when scanning a QR code or turning on the torch. Denying it does not disable unrelated tools.", false);
        body.addView(note, marginParams(-1, -2, 0, dp(12), 0, dp(20)));
    }

    private void buildSystemPage(LinearLayout body) {
        addSectionTitle(body, "Native Android controls", "Opens system pages; no hidden changes");
        addActionButton(body, "Wi-Fi settings", "Choose a network or change Wi-Fi options", () -> launchSettings(Settings.ACTION_WIFI_SETTINGS));
        addActionButton(body, "Display settings", "Brightness, display size, and sleep", () -> launchSettings(Settings.ACTION_DISPLAY_SETTINGS));
        addActionButton(body, "Battery settings", "Battery usage and power controls", () -> launchSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        addActionButton(body, "Installed app settings", "Manage apps and their permissions manually", () -> launchSettings(Settings.ACTION_APPLICATION_SETTINGS));
        addActionButton(body, "Device information", "Open the system device information page", () -> launchSettings(Settings.ACTION_DEVICE_INFO_SETTINGS));
        addActionButton(body, "General settings", "Open Android Settings", () -> launchSettings(Settings.ACTION_SETTINGS));
        addActionButton(body, "Share device diagnostics", "Share a text summary of Android, battery, network, and storage", this::shareDiagnostics);
        LinearLayout warning = card("No fake boost button", "Android prevents ordinary apps from controlling privileged system services. Use these official settings to make changes safely, rather than trusting an app to claim it has increased CPU performance.", false);
        body.addView(warning, marginParams(-1, -2, 0, dp(8), 0, dp(18)));
    }

    private void shareDiagnostics() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent battery = registerReceiver(null, filter);
        int level = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery == null ? 100 : battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int percent = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
        String report = "TeinTools device report\n" +
                "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "Battery: " + (percent < 0 ? "unavailable" : percent + "%") + "\n" +
                "Network: " + networkSummary() + "\n" +
                "Wi-Fi: " + wifiSummary() + "\n" +
                "Available RAM: " + formatBytes(availableRam()) + "\n" +
                "Free storage: " + formatBytes(freeStorage()) + "\n" +
                "Generated locally by TeinTools.";
        shareText("Share device diagnostics", report);
    }

    private void launchSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { toast("This settings page is not available on this device."); }
    }

    private String networkSummary() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            Network net = cm.getActiveNetwork();
            if (net == null) return "No active network";
            NetworkCapabilities caps = cm.getNetworkCapabilities(net);
            if (caps == null) return "Network state unavailable";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "Wi-Fi · internet validated" : "Wi-Fi · not validated";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "Mobile data · internet validated" : "Mobile data · not validated";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN transport";
            return "Connected · transport type unavailable";
        } catch (Exception e) { return "Unavailable"; }
    }

    private String wifiSummary() {
        try {
            WifiManager wm = (WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) return "Wi-Fi is off or unavailable";
            WifiInfo info = wm.getConnectionInfo();
            if (info == null || info.getNetworkId() == -1) return "Not connected to Wi-Fi";
            int freq = info.getFrequency();
            String band = freq >= 4900 && freq < 5900 ? "5 GHz" : freq >= 2400 && freq < 2500 ? "2.4 GHz" : "band unavailable";
            return band + " · " + freq + " MHz · " + info.getLinkSpeed() + " Mbps link rate · RSSI " + info.getRssi() + " dBm";
        } catch (Exception e) { return "Details not exposed by this device"; }
    }

    private String networkBandwidth() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork(); NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            if (c == null) return "Unavailable";
            int kbps = c.getLinkDownstreamBandwidthKbps();
            return kbps >= 1000 ? String.format(Locale.US, "Reported link %d Mbps", kbps / 1000) : "Reported link " + kbps + " kbps";
        } catch (Exception e) { return "Unavailable"; }
    }

    private String batteryHealth(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Good";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Overheating";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Dead";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Over voltage";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Cold";
            default: return "Unknown / unavailable";
        }
    }

    private String thermalStatus(int status) {
        switch (status) {
            case PowerManager.THERMAL_STATUS_NONE: return "No reported thermal throttling";
            case PowerManager.THERMAL_STATUS_LIGHT: return "Light";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Moderate";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Severe";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Critical";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Emergency";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Shutdown threshold reported";
            default: return "Unknown";
        }
    }

    private long availableRam() {
        try { ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(info); return info.availMem; }
        catch (Exception e) { return 0L; }
    }
    private long freeStorage() { try { return new StatFs(Environment.getDataDirectory().getAbsolutePath()).getAvailableBytes(); } catch (Exception e) { return 0L; } }
    private String deviceName() { String model = Build.MODEL == null ? "Android device" : Build.MODEL; return model.trim().isEmpty() ? "Android device" : model; }
    private String formatBytes(long bytes) {
        if (bytes < 0) return "Unavailable";
        if (bytes < 1024) return bytes + " B";
        double val = bytes; String[] units = {"B", "KB", "MB", "GB", "TB"}; int unit = 0;
        while (val >= 1024 && unit < units.length - 1) { val /= 1024.0; unit++; }
        return String.format(Locale.US, "%.1f %s", val, units[unit]);
    }
    private String formatNumber(double value) {
        if (Math.abs(value) < 0.000000001) value = 0;
        if (Math.abs(value - Math.rint(value)) < 0.000000001 && Math.abs(value) < 1e12) return String.format(Locale.US, "%.0f", value);
        return new DecimalFormat("0.########").format(value);
    }
    private String formatStopwatch(long millis) {
        long tenths = millis / 100L; long hours = tenths / 36000L; long minutes = (tenths / 600L) % 60L; long seconds = (tenths / 10L) % 60L; long fraction = tenths % 10L;
        return String.format(Locale.US, "%02d:%02d:%02d.%d", hours, minutes, seconds, fraction);
    }
    private String formatTimer(long millis) {
        long sec = Math.max(0L, millis) / 1000L;
        return String.format(Locale.US, "%02d:%02d", sec / 60L, sec % 60L);
    }
    private String join(String[] array, String separator) { if (array == null || array.length == 0) return "Unavailable"; StringBuilder s = new StringBuilder(); for (String x : array) { if (s.length() > 0) s.append(separator); s.append(x); } return s.toString(); }
    private String shorten(String s, int max) { if (s == null) return "Unavailable"; return s.length() <= max ? s : s.substring(0, max - 1) + "…"; }
    private String safeMessage(Exception e) { String s = e.getMessage(); return s == null || s.trim().isEmpty() ? e.getClass().getSimpleName() : shorten(s, 110); }

    private String queryDisplayName(Uri uri) {
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) { int i = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (i >= 0) return cursor.getString(i); }
        } catch (Exception ignored) { } finally { if (cursor != null) cursor.close(); }
        return uri.getLastPathSegment() == null ? "selected file" : uri.getLastPathSegment();
    }

    private void shareText(String title, String text) {
        Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text); startActivity(Intent.createChooser(i, title));
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }

    private void addToolGrid(LinearLayout body, Tool[] tools) {
        for (int i = 0; i < tools.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(makeToolTile(tools[i]), new LinearLayout.LayoutParams(0, dp(126), 1));
            if (i + 1 < tools.length) row.addView(makeToolTile(tools[i + 1]), new LinearLayout.LayoutParams(0, dp(126), 1));
            else row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(126), 1));
            body.addView(row, marginParams(-1, -2, 0, 0, 0, dp(10)));
        }
    }

    private View makeToolTile(Tool tool) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(14), dp(14), dp(12), dp(11));
        tile.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        tile.setElevation(dp(3));
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-1, -1);
        outer.setMargins(0, 0, dp(7), 0);
        TextView icon = pill(tool.icon, blend(accent(), surface(), isLight() ? 0.77f : 0.60f), accent(), 36);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(38)));
        tile.addView(label(tool.name, 13, textColor(), true), marginParams(-1, -2, 0, dp(10), 0, 0));
        TextView desc = label(tool.description, 10, muted(), false);
        tile.addView(desc);
        tile.setOnClickListener(v -> {
            v.animate().cancel();
            v.animate().scaleX(0.985f).scaleY(0.985f).setDuration(75L).withEndAction(() -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(95L).start();
                renderPage(tool.target);
            }).start();
        });
        tile.setLayoutParams(outer);
        return tile;
    }

    private static class Tool {
        final String icon, name, description, target;
        Tool(String icon, String name, String description, String target) { this.icon = icon; this.name = name; this.description = description; this.target = target; }
    }

    private void addSectionTitle(LinearLayout parent, String title, String subtitle) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.addView(label(title, 17, textColor(), true));
        if (subtitle != null) box.addView(label(subtitle, 10, muted(), false), marginParams(-1, -2, 0, dp(3), 0, 0));
        parent.addView(box, marginParams(-1, -2, 0, dp(3), 0, dp(12)));
    }

    private View statTile(String title, String value, String footer, String symbol) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(10), dp(11), dp(8), dp(8));
        card.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        card.addView(label(symbol + "  " + title, 8, muted(), true));
        card.addView(label(value, 15, textColor(), true), marginParams(-1, -2, 0, dp(10), 0, 0));
        card.addView(label(footer, 9, muted(), false));
        card.setElevation(dp(2));
        return card;
    }

    private LinearLayout card(String title, String subtitle, boolean hero) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(15), dp(16), dp(15));
        if (hero) c.setBackground(backgroundGradient(blend(accent(), Color.rgb(39,50,88), 0.42f), Color.rgb(24, 31, 58), 2));
        else c.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        c.setElevation(dp(3));
        if (title != null) c.addView(label(title, 15, textColor(), true));
        if (subtitle != null) addText(c, subtitle, 11, muted(), false, dp(7));
        return c;
    }

    private void addActionButton(LinearLayout parent, String title, String subtitle, Runnable action) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(13), dp(15), dp(12));
        box.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        box.addView(label(title, 13, textColor(), true));
        if (subtitle != null) box.addView(label(subtitle, 10, muted(), false), marginParams(-1, -2, 0, dp(4), 0, 0));
        box.setOnClickListener(v -> {
            v.animate().cancel();
            v.animate().scaleX(0.99f).scaleY(0.99f).setDuration(70L).withEndAction(() -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(100L).start();
                action.run();
            }).start();
        });
        box.setElevation(dp(2));
        parent.addView(box, marginParams(-1, -2, 0, dp(4), 0, dp(5)));
    }

    private void addKeyValue(LinearLayout parent, String key, String value) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(8), 0, dp(8));
        TextView left = label(key, 11, muted(), false);
        TextView right = label(value, 11, textColor(), true); right.setGravity(Gravity.END);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        parent.addView(row);
        View line = new View(this); line.setBackgroundColor(borderColor());
        parent.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setIncludeFontPadding(true); t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private TextView label(String text, float size, int color, boolean bold, int topMargin) {
        TextView t = label(text, size, color, bold); t.setLayoutParams(marginParams(-1, -2, 0, topMargin, 0, 0)); return t;
    }
    private void addText(LinearLayout parent, String text, float size, int color, boolean bold, int topMargin) {
        parent.addView(label(text, size, color, bold), marginParams(-1, -2, 0, topMargin, 0, 0));
    }
    private TextView pill(String text, int background, int color, int height) {
        TextView t = label(text, 12, color, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(12), 0, dp(12), 0);
        t.setBackground(solid(roundRect(background, dp(16), borderColor())));
        t.setMinHeight(dp(height)); return t;
    }
    private EditText editField(String hint, boolean numeric) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true); edit.setTextSize(14); edit.setTextColor(textColor()); edit.setHintTextColor(muted()); edit.setHint(hint);
        edit.setPadding(dp(13), 0, dp(13), 0); edit.setBackground(solid(roundRect(surfaceRaised(), dp(15), borderColor())));
        if (numeric) edit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        return edit;
    }

    private LinearLayout.LayoutParams marginParams(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
        lp.setMargins(left, top, right, bottom); return lp;
    }

    private GradientDrawable roundRect(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(dp(1), stroke); return d;
    }
    private GradientDrawable solid(GradientDrawable d) { return d; }
    private GradientDrawable backgroundGradient(int first, int second, int style) {
        int specular = blend(first, Color.WHITE, style == 2 ? 0.15f : 0.075f);
        int lower = blend(second, accent(), style == 2 ? 0.10f : 0.045f);
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{specular, first, lower});
        d.setCornerRadius(dp(style == 2 ? 28 : 20));
        d.setStroke(dp(1), style == 2 ? Color.argb(150, 222, 232, 255) : borderColor());
        d.setDither(true);
        return d;
    }
    private int blend(int a, int b, float ratioB) {
        ratioB = Math.max(0f, Math.min(1f, ratioB));
        float ratioA = 1f - ratioB;
        return Color.rgb(Math.round(Color.red(a)*ratioA + Color.red(b)*ratioB), Math.round(Color.green(a)*ratioA + Color.green(b)*ratioB), Math.round(Color.blue(a)*ratioA + Color.blue(b)*ratioB));
    }
}
