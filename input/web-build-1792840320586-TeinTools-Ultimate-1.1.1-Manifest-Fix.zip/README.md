# TeinTools Ultimate 1.1.0 — Android 10-first

TeinTools is a lightweight, non-root Android toolbox built in Java with native Android Views. The app targets Android 10 (API 29) and uses a liquid-glass visual language: translucent gradient surfaces, thin specular borders, an original abstract glass artwork used on the splash and home hero only, and short motion transitions.

## Included tools

- **Device Monitor:** hardware/OS details, available RAM/storage, battery details and thermal information where the device exposes it.
- **Network Lab:** HTTPS reachability, DNS resolution, TCP connection latency, a small download-throughput estimate and Wi-Fi details available through Android.
- **One-tap Cache Cleaner:** measures and clears TeinTools' own internal and external cache directories. A separate action opens Android storage settings for user-controlled cleanup elsewhere.
- **Sensor Lab:** lists sensor metadata returned by Android; it does not continuously collect sensor measurements in the background.
- **Permission Inspector:** shows camera-permission status and links to the app's native settings.
- **QR Studio:** scan, generate and save QR codes.
- **Flashlight, Calculator, Stopwatch, Countdown Timer, Unit Converter, Quick Notes, File Hub, Installed Apps, System Shortcuts** and a **Share Device Diagnostics** action.
- Persistent theme and accent preferences, splash loading motion, page-entry transitions, action press feedback, and progress indicators for asynchronous work.

## Important Android 10 limitation: cache cleanup

A regular, non-root app cannot silently delete other apps' private cache directories. Android's scoped-storage model isolates app-specific directories; the system-wide consent action for clearing app caches was introduced in Android 11 (API 30), not Android 10. So the cleaner truthfully cleans TeinTools' own cache in one tap and provides a shortcut to Android storage settings for the rest. It does not delete user photos, downloads, notes, or preferences.

## Liquid glass on Android 10

This app uses a compatibility implementation: layered gradients, translucent card fills, highlight strokes and a small number of artwork placements. Native system/window blur APIs are Android 12+ APIs, so the UI does not depend on them. This avoids an API mismatch on Android 10 and keeps rendering relatively light.

## Build

- JDK: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (pinned in `.github/workflows/build.yml`)
- compileSdk: 34
- minSdk: 29 (Android 10)
- targetSdk: 29

The GitHub Actions workflow builds a debug APK, verifies it exists, and uploads it as an artifact retained for 14 days. This source ZIP has not been device-tested. Verify the Actions build and install/test the APK on a physical Android 10 device before treating it as release-ready.

## Package

`com.teinzz.teintools`
