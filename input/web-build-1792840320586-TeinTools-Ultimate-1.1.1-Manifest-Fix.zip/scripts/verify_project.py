#!/usr/bin/env python3
"""Lightweight pre-build contract checks for TeinTools. No third-party packages required."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
checks = []

def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append(name)
    if not condition:
        errors.append(f"FAIL: {name}" + (f" — {detail}" if detail else ""))
    else:
        print(f"PASS: {name}")

main = ROOT / "app/src/main/java/com/teinzz/teintools/MainActivity.java"
gradle = ROOT / "app/build.gradle"
manifest = ROOT / "app/src/main/AndroidManifest.xml"
workflow = ROOT / ".github/workflows/build.yml"
art = ROOT / "app/src/main/res/drawable-nodpi/hero_liquid.webp"

check("required project files exist", all(p.is_file() for p in [main, gradle, manifest, workflow, art]))

if gradle.exists():
    g = gradle.read_text(encoding="utf-8")
    check("Android 10 minimum SDK", bool(re.search(r"minSdk\s+29\b", g)))
    check("Android 10 compatibility target", bool(re.search(r"targetSdk\s+29\b", g)))
    check("compile SDK 34", bool(re.search(r"compileSdk\s+34\b", g)))
    check("AGP 8.7.3", "com.android.application' version '8.7.3'" in (ROOT / "build.gradle").read_text(encoding="utf-8"))
    check("version 1.1.0 / code 2", "versionName '1.1.0'" in g and "versionCode 2" in g)

if manifest.exists():
    try:
        tree = ET.parse(manifest)
        root = tree.getroot()
        ns = "{http://schemas.android.com/apk/res/android}"
        app = root.find("application")
        launcher = None
        if app is not None:
            for activity in app.findall("activity"):
                actions = [x.get(ns + "name") for filt in activity.findall("intent-filter") for x in filt.findall("action")]
                categories = [x.get(ns + "name") for filt in activity.findall("intent-filter") for x in filt.findall("category")]
                if "android.intent.action.MAIN" in actions and "android.intent.category.LAUNCHER" in categories:
                    launcher = activity
                    break
        check("manifest XML parses", True)
        check("launcher activity is exported", launcher is not None and launcher.get(ns + "exported") == "true")
        check("hardware acceleration enabled", app is not None and app.get(ns + "hardwareAccelerated") == "true")
    except ET.ParseError as e:
        check("manifest XML parses", False, str(e))

if main.exists():
    java = main.read_text(encoding="utf-8")
    required = [
        "showSplashScreen()", "liquidBackground()", "buildCleanerPage", "clearDirectoryContents",
        "buildSensorPage", "buildPermissionsPage", "shareDiagnostics", "buildNetworkPage",
        "buildQrPage", "buildFlashPage", "buildNotesPage", "buildTimerPage",
    ]
    check("feature entry points included", all(token in java for token in required), ", ".join(t for t in required if t not in java))
    check("cache cleanup is scoped to this app", "getCacheDir()" in java and "getExternalCacheDir()" in java and "only temporary cache files" in java)
    check("no hidden global-cache API", "ACTION_CLEAR_APP_CACHE" not in java)
    check("balanced Java braces", java.count("{") == java.count("}"), f"{java.count('{')} opening / {java.count('}')} closing")

if workflow.exists():
    w = workflow.read_text(encoding="utf-8")
    check("CI pins Gradle 8.9", "gradle-version: '8.9'" in w)
    check("CI uploads the APK", "actions/upload-artifact@v4" in w and "app/build/outputs/apk/debug/app-debug.apk" in w)
    check("CI runs source contract checks", "python3 scripts/verify_project.py" in w)

if art.exists():
    check("hero artwork is bundled", art.stat().st_size > 5000 and art.stat().st_size < 500_000, f"size {art.stat().st_size} bytes")

if errors:
    print("\n".join(errors), file=sys.stderr)
    print(f"\n{len(errors)} failure(s), {len(checks)} checks.", file=sys.stderr)
    sys.exit(1)
print(f"\nAll {len(checks)} project contract checks passed.")
