package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ManhwaScraper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val proxyBase = "https://api.allorigins.win/raw?url="

    private val domains = listOf(
        "https://kiryuu.to/manga/?m_orderby=latest"            to "Kiryuu",
        "https://komikcast.mom/daftar-komik/?order=update"     to "Komikcast",
        "https://asuracomic.net/series?order=update"           to "Asura"
    )

    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> =
        withContext(Dispatchers.IO) {
            val allManhwa = mutableListOf<Manhwa>()

            for ((baseUrl, sourceName) in domains) {
                var targetUrl = baseUrl
                if (query.isNotEmpty()) {
                    targetUrl = "${baseUrl.substringBefore("/manga")}/?s=${query.replace(" ", "+")}"
                } else if (genre.isNotEmpty() && genre != "Semua") {
                    targetUrl = "${baseUrl.substringBefore("/manga")}/genre/" +
                        "${genre.lowercase().replace(" ", "-")}/?m_orderby=latest"
                }

                try {
                    val finalUrl = proxyBase + URLEncoder.encode(targetUrl, "UTF-8")
                    val request = Request.Builder()
                        .url(finalUrl)
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                        .build()

                    client.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val html = response.body?.string() ?: ""
                            val doc = Jsoup.parse(html, targetUrl)

                            val elements = doc.select(
                                ".listupd .bs, .bsx, .page-item-detail, .manga__item, .grid > div"
                            )

                            for (el in elements) {
                                val title = el.select(
                                    ".tt h3 a, .tt h4 a, .post-title h3 a, " +
                                        ".manga__item-title a, .text-white"
                                ).text().trim()
                                val link = el.select(
                                    ".tt h3 a, .tt h4 a, .post-title h3 a, " +
                                        ".manga__item-title a, .text-white"
                                ).attr("href")
                                var imgUrl = el.select("img").attr("data-src")
                                if (imgUrl.isNullOrEmpty()) imgUrl = el.select("img").attr("src")
                                val latestChapter = el
                                    .select(".epxs, .chapter-item .btn-link, .chapter-item a")
                                    .first()?.text()?.trim() ?: "Chapter Baru"

                                if (title.isNotEmpty() && link.isNotEmpty() && imgUrl.isNotEmpty()) {
                                    allManhwa.add(Manhwa(title, link, imgUrl, latestChapter, sourceName))
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            if (allManhwa.isEmpty()) {
                allManhwa.add(
                    Manhwa(
                        "Gagal Memuat / Server Down",
                        "https://google.com",
                        "https://via.placeholder.com/300x400?text=Error",
                        "Cek koneksi atau Proxy",
                        "System"
                    )
                )
            }

            allManhwa.distinctBy { it.link }
        }
}
