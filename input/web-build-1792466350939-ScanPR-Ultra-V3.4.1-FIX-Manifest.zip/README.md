# Scan PR Ultra 3.4.0 — Camera & Crop Fix

## Changes in this build
- Requests Android camera permission on the first launch, then starts CameraX when granted. If permission is denied, shows an explanation and a shortcut to app settings; gallery and text entry remain usable.
- Forces the camera preview to fill the available display using CameraX `FILL_CENTER` and compatibility rendering.
- Adds tap-to-focus/auto-exposure metering with a visible focus ring.
- Adds a flashlight/torch toggle and turns it off when the activity leaves the foreground.
- Registers `com.canhub.cropper.CropImageActivity` explicitly with a readable toolbar theme.
- Adds an explicit `✓ Pakai foto` confirmation title in the crop editor; both camera photos and gallery selections pass through crop before OCR.
- Increases provider request timeouts so hosted free models have enough time to respond. Gemini candidates include model IDs currently documented with a free tier.
- Bumps app version to 3.4.0 / versionCode 5.

## AI provider behavior
- Auto mode uses Gemini free-tier models and OpenRouter `openrouter/free` or explicit `:free` variants only.
- Groq and Cerebras can be selected manually; exact free quota depends on the user's provider plan and model.
- Grok/xAI API and OpenAI GPT API are not included in free-only auto mode because their API usage is billed separately from the consumer Grok/ChatGPT apps. GPT-OSS/Qwen/Llama/Gemma may be reachable through free model hosting when currently available.
- No API key is embedded in the APK. Credentials are entered by the user and stored encrypted on device. Do not use keys on accounts with active billing unless you understand the charges.
- Offline fallback is a limited local solver; it does not pretend to solve every subject without internet.

## Build
Project uses Gradle 8.4, Android Gradle Plugin 8.3.2, Kotlin 1.9.20, Java 17, compileSdk 34, minSdk 24. The ZIP includes `gradlew`/wrapper properties; if `gradle-wrapper.jar` is absent, AndroidForge may regenerate the wrapper.

## Verification note
The source was statically checked for XML well-formedness, duplicate Kotlin declarations, unresolved view-binding ID names, and ZIP integrity. A full Android Gradle build and on-device test were not possible in the current editing environment. Run a new AndroidForge build, then test camera permission, preview, flash, focus, crop confirmation and OCR on the target device.
