package com.scanpr.ultra.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class OpenRouterApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(28, TimeUnit.SECONDS)
        .callTimeout(32, TimeUnit.SECONDS)
        .build()

    /** Read the live catalog and return only explicitly free model variants. */
    suspend fun listFreeModels(apiKey: String): List<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext emptyList()
        runCatching {
            val request = Request.Builder().url("https://openrouter.ai/api/v1/models")
                .header("Authorization", "Bearer $apiKey")
                .header("X-Title", "Scan PR Ultra")
                .get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use emptyList()
                val data = JSONObject(response.body?.string().orEmpty()).optJSONArray("data") ?: JSONArray()
                val ids = (0 until data.length()).mapNotNull { i ->
                    val obj = data.optJSONObject(i) ?: return@mapNotNull null
                    val id = obj.optString("id", "")
                    val pricing = obj.optJSONObject("pricing")
                    val isFreeVariant = id.endsWith(":free") && (pricing == null || (isZero(pricing.optString("prompt")) && isZero(pricing.optString("completion"))))
                    if (isFreeVariant && id.isNotBlank()) id else null
                }.distinct()
                ids.sortedWith(compareBy<String> { priority(it) }.thenBy { it }).take(8)
            }
        }.getOrDefault(emptyList())
    }

    private fun isZero(value: String): Boolean = value.toDoubleOrNull()?.let { it == 0.0 } == true

    private fun priority(id: String): Int = when {
        listOf("deepseek", "qwen", "nemotron", "gpt-oss", "trinity").any { it in id.lowercase() } -> 0
        listOf("llama", "mistral", "gemma").any { it in id.lowercase() } -> 1
        else -> 2
    }

    suspend fun askOpenRouter(prompt: String, apiKey: String, model: String, image: ImageUtils.EncodedImage? = null): String? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || !(model.endsWith(":free") || model == "openrouter/free")) return@withContext null
        runCatching {
            val content: Any = if (image == null) prompt else JSONArray()
                .put(JSONObject().put("type", "text").put("text", prompt))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:${image.mimeType};base64,${image.base64}")))
            val body = JSONObject().put("model", model)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
                .put("temperature", 0.15).put("max_tokens", 3500).toString()
            val request = Request.Builder().url("https://openrouter.ai/api/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey").header("X-Title", "Scan PR Ultra")
                .post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                JSONObject(response.body?.string().orEmpty()).optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("message")?.optString("content")?.takeIf(String::isNotBlank)
            }
        }.getOrNull()
    }
}
