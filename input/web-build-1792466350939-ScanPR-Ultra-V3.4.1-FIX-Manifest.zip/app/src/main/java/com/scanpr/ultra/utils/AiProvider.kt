package com.scanpr.ultra.utils

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext

data class AiResult(
    val jawabanAkhir: String,
    val langkah: List<String>,
    val mapel: String,
    val modelUsed: String,
    val metodeAlternatif: List<String>,
    val catatan: String = "Periksa kembali hasil dengan materi/buku pelajaran. AI dapat keliru."
)

/** Multi-provider failover. Model IDs are discovered live so retired model names are not hard-coded. */
class AiProvider(private val context: Context) {
    suspend fun solveAuto(ocrText: String, imageUri: Uri? = null): AiResult {
        val text = ocrText.trim()
        if (text.isBlank() && imageUri == null) return SolverEngine.solveOffline(text)
        if (!NetworkUtils.isOnline(context)) return SolverEngine.solveOffline(text)

        val encodedImage = imageUri?.takeIf { AiKeyStore.hasAnyKey(context) }?.let { uri ->
            withContext(kotlinx.coroutines.Dispatchers.IO) { ImageUtils.encodeForAi(context, uri) }
        }
        if (text.isBlank() && encodedImage == null) {
            return SolverEngine.solveOffline(text).copy(
                modelUsed = "Offline · gambar/teks tidak terbaca",
                catatan = "Teks OCR kosong dan gambar tidak berhasil disiapkan untuk AI. Coba crop ulang, pilih foto yang lebih jelas, atau ketik soal secara manual."
            )
        }
        val safeText = text.take(10000).ifBlank { "Teks OCR tidak tersedia; baca soal secara langsung dari gambar yang terlampir." }
        val textPrompt = buildPrompt(safeText, false)
        val prompt = buildPrompt(safeText, encodedImage != null)
        // Bound total latency; every provider has its own shorter network timeouts as well.
        val onlineResult = withTimeoutOrNull(90000L) {
            for (provider in AiPreferences.providerOrder(context)) {
                val result = when (provider) {
                    AiPreferences.GEMINI -> tryGemini(prompt, textPrompt, encodedImage)
                    AiPreferences.OPENROUTER -> tryOpenRouter(prompt, textPrompt, encodedImage)
                    AiPreferences.GROQ -> tryGroq(textPrompt)
                    AiPreferences.CEREBRAS -> tryCerebras(textPrompt)
                    else -> null
                }
                if (result != null) return@withTimeoutOrNull result
            }
            null
        }
        if (onlineResult != null) return onlineResult
        val local = SolverEngine.solveOffline(text)
        return if (AiKeyStore.hasAnyKey(context)) {
            local.copy(modelUsed = "Offline fallback · provider gagal/kuota habis", catatan = "AI online tidak berhasil dijangkau. Jawaban offline hanya mendukung tipe soal tertentu; jangan anggap soal yang tidak didukung sudah terjawab.")
        } else {
            local.copy(modelUsed = "Offline · API belum disiapkan", catatan = "Belum ada kunci AI online yang disimpan. Mode offline hanya mendukung beberapa operasi dan persamaan sederhana.")
        }
    }

    private fun buildPrompt(text: String, imageAttached: Boolean) = """
Anda adalah tutor sekolah yang teliti untuk semua mata pelajaran SMP/SMA/SMK. Jawab dalam Bahasa Indonesia kecuali pengguna meminta bahasa lain.
TUGAS:
1. Identifikasi mata pelajaran dan jenis tugas secara otomatis (matematika, fisika, kimia, biologi, Bahasa Indonesia/Inggris, sejarah, geografi, ekonomi, PPKn, informatika, seni, agama, atau lainnya).
2. Baca soal secara literal. Jangan mengganti angka, satuan, nama, periode, atau pilihan jawaban. Jika ada beberapa soal di satu gambar/teks, jawab satu per satu dengan nomor yang sama seperti sumber.
3. Untuk pilihan ganda, sebutkan opsi yang dipilih dan alasan; jelaskan opsi lain secara singkat jika informasinya cukup.
4. Untuk hitungan, tampilkan rumus, substitusi angka, satuan, dan cek hasil/operasi bila memungkinkan. Jangan membuat langkah hitung fiktif.
5. Untuk esai, jawab sesuai perintah soal dengan struktur yang sesuai. Bedakan fakta dari interpretasi. Jangan buat kutipan, URL, atau sumber palsu. Jika fakta bisa berubah dari waktu ke waktu dan tidak ada sumber web yang benar-benar diakses pada permintaan ini, jangan mengaku telah memverifikasinya secara live.
6. Jika soal terpotong, ambigu, teks OCR rusak, atau data penting hilang, jangan menebak diam-diam. Nyatakan bagian yang tidak jelas dan minta koreksi/nyatakan asumsi pada catatan.
7. Jelaskan langkah yang dapat dipelajari, bukan sekadar klaim bahwa jawaban benar. Jika perhitungan penting, hitung ulang sebelum menjawab. Jangan pernah menjamin akurasi 100%.
8. Jika pengguna sedang meminta rangkuman, kuis, flashcard, petunjuk, contoh, atau penyederhanaan, lakukan instruksi itu dengan tetap memakai konteks soal.
9. Jika isi pengguna bukan soal melainkan percakapan lanjutan, jawab sesuai permintaan dan konteks yang tersedia.

Keluarkan JSON valid SAJA dengan skema:
{"jawaban_akhir":"jawaban utama yang jelas","langkah":["langkah/penjelasan satu","langkah/penjelasan dua"],"mapel":"nama mapel","metode_alternatif":["metode alternatif jika benar-benar ada"],"catatan":"asumsi, bagian yang meragukan, atau catatan verifikasi"}
Pastikan seluruh nilai adalah string/array string, tidak ada markdown fence, dan jangan mengarang data yang tidak tersedia.
${if (imageAttached) "GAMBAR SOAL TERLAMPIR: periksa isi gambar secara langsung. Gunakan gambar untuk memeriksa ulang teks OCR; bila OCR berbeda dari gambar, sebutkan ketidakpastian dalam catatan dan jangan menebak karakter yang tidak terbaca." else "Tidak ada gambar terlampir; gunakan teks soal yang diberikan."}

KONTEN PENGGUNA:
$text
""".trimIndent()

    private suspend fun tryGemini(prompt: String, textPrompt: String, image: ImageUtils.EncodedImage?): AiResult? {
        val key = AiKeyStore.geminiKey(context)
        if (key.isBlank()) return null
        val api = GeminiApi()
        val models = api.listModels(key).take(2)
        for (model in models) {
            val visualRaw = if (image != null) api.askGemini(prompt, key, model, image) else null
            if (!visualRaw.isNullOrBlank()) JsonParser.parse(visualRaw, "Gemini Vision · $model")?.let { return it }
            val raw = api.askGemini(textPrompt, key, model, null) ?: continue
            JsonParser.parse(raw, "Gemini · $model")?.let { return it }
        }
        return null
    }

    private suspend fun tryGroq(prompt: String): AiResult? {
        val key = AiKeyStore.groqKey(context)
        if (key.isBlank()) return null
        val api = OpenAiCompatibleApi("https://api.groq.com/openai/v1")
        // The current Groq free-plan table includes these IDs. Do not blindly call every
        // returned model: availability in /models does not by itself prove a free quota.
        val active = api.listModels(key).toSet()
        val documentedFreeCandidates = listOf("openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b")
        val models = documentedFreeCandidates.filter { it in active }.take(1)
        for (model in models) {
            val raw = api.ask(prompt, key, model) ?: continue
            JsonParser.parse(raw, "Groq · $model")?.let { return it }
        }
        return null
    }

    private suspend fun tryCerebras(prompt: String): AiResult? {
        val key = AiKeyStore.cerebrasKey(context)
        if (key.isBlank()) return null
        val api = OpenAiCompatibleApi("https://api.cerebras.ai/v1")
        // A Cerebras API key may belong to a quota-limited free account or a billed plan.
        // Only try conservative candidates; the settings screen warns that account terms vary.
        val active = api.listModels(key).toSet()
        val candidates = listOf("llama3.1-8b", "gpt-oss-120b", "llama-3.3-70b")
        val models = candidates.filter { it in active }.take(1)
        for (model in models) {
            val raw = api.ask(prompt, key, model) ?: continue
            JsonParser.parse(raw, "Cerebras · $model")?.let { return it }
        }
        return null
    }

    private suspend fun tryOpenRouter(prompt: String, textPrompt: String, image: ImageUtils.EncodedImage?): AiResult? {
        val key = AiKeyStore.openRouterKey(context)
        if (key.isBlank()) return null
        val api = OpenRouterApi()
        // The free router is first; it may choose a vision-capable model when image input is attached.
        val routerVisual = if (image != null) api.askOpenRouter(prompt, key, "openrouter/free", image) else null
        if (!routerVisual.isNullOrBlank()) JsonParser.parse(routerVisual, "OpenRouter Vision · free router")?.let { return it }
        val routerText = api.askOpenRouter(textPrompt, key, "openrouter/free")
        if (!routerText.isNullOrBlank()) JsonParser.parse(routerText, "OpenRouter · free router")?.let { return it }
        val models = api.listFreeModels(key).take(2)
        for (model in models) {
            val raw = api.askOpenRouter(textPrompt, key, model) ?: continue
            JsonParser.parse(raw, "OpenRouter · $model")?.let { return it }
        }
        return null
    }

}
