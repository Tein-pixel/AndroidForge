package app.yomikaze.sources

import app.yomikaze.core.ContentSummary
import app.yomikaze.core.MediaCategory
import app.yomikaze.core.MediaType
import app.yomikaze.core.PublicationStatus
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLEncoder
import java.time.Instant

internal fun encodeQuery(value: String): String = URLEncoder.encode(value, "UTF-8")

internal fun JsonElement?.asObjectOrNull(): JsonObject? = this as? JsonObject

internal fun JsonElement?.asTextOrNull(): String? {
    val primitive = this as? JsonPrimitive ?: return null
    return primitive.contentOrNull?.trim()?.takeIf { it.isNotEmpty() && it != "null" }
}

internal fun JsonObject.text(vararg names: String): String? {
    names.forEach { name ->
        val value = this[name].asTextOrNull()
        if (!value.isNullOrBlank()) return value
    }
    return null
}

internal fun JsonObject.intValue(vararg names: String): Int? {
    names.forEach { name ->
        val value = this[name] as? JsonPrimitive
        value?.intOrNull?.let { return it }
    }
    return null
}

internal fun JsonObject.booleanValue(vararg names: String): Boolean? {
    names.forEach { name ->
        val value = this[name] as? JsonPrimitive
        value?.booleanOrNull?.let { return it }
    }
    return null
}

internal fun JsonElement?.stringList(): List<String> = when (this) {
    is JsonArray -> mapNotNull { value ->
        value.asTextOrNull() ?: value.asObjectOrNull()?.text("name", "title", "label", "genre")
    }.distinct()
    is JsonObject -> values.mapNotNull { value ->
        value.asTextOrNull() ?: value.asObjectOrNull()?.text("name", "title", "label", "genre")
    }.distinct()
    else -> this.asTextOrNull()?.split(',', '|')?.map(String::trim)?.filter(String::isNotBlank).orEmpty()
}

internal fun JsonElement?.findArray(vararg preferredKeys: String, depth: Int = 0): JsonArray? {
    if (this is JsonArray) return this
    if (depth > 5) return null
    val obj = this as? JsonObject ?: return null
    preferredKeys.forEach { key ->
        val value = obj[key]
        if (value is JsonArray) return value
        value?.findArray(*preferredKeys, depth = depth + 1)?.let { return it }
    }
    obj.values.forEach { value ->
        value.findArray(*preferredKeys, depth = depth + 1)?.let { return it }
    }
    return null
}

internal fun JsonElement?.findObject(vararg preferredKeys: String, depth: Int = 0): JsonObject? {
    if (depth > 7) return null
    val obj = this as? JsonObject ?: return when (this) {
        is JsonArray -> firstNotNullOfOrNull { it.findObject(*preferredKeys, depth = depth + 1) }
        else -> null
    }

    val identityKeys = setOf("title", "name", "slug", "id", "manga_id", "mangaId", "seriesId", "comicId")
    if (obj.keys.any { it in identityKeys }) return obj

    preferredKeys.forEach { key ->
        val child = obj[key]
        if (child != null) {
            child.findObject(*preferredKeys, depth = depth + 1)?.let { return it }
        }
    }
    obj.values.forEach { child ->
        child.findObject(*preferredKeys, depth = depth + 1)?.let { return it }
    }
    if (obj.keys.any { it in setOf("pages", "images", "chapters", "chapterList", "author", "artist") }) return obj
    return if (depth == 0) obj else null
}

internal fun JsonElement?.asContentArray(): List<JsonObject> {
    val array = findArray(
        "data", "results", "items", "comics", "manga", "mangas", "series", "popular",
        "latest", "search", "list", "content", "chapters", "chapterList", "episodes",
    ) ?: return emptyList()
    return array.mapNotNull { it as? JsonObject }
}

internal fun JsonObject.toStatus(): PublicationStatus = when (
    text("status", "state", "publicationStatus")?.lowercase()
) {
    "ongoing", "publishing", "on going", "berjalan", "aktif", "serializing" -> PublicationStatus.ONGOING
    "completed", "complete", "finished", "end", "tamat" -> PublicationStatus.COMPLETED
    "hiatus", "paused", "break" -> PublicationStatus.HIATUS
    "cancelled", "canceled", "dropped" -> PublicationStatus.CANCELLED
    else -> PublicationStatus.UNKNOWN
}

internal fun mediaTypeFrom(value: String?, default: MediaType = MediaType.MANGA): MediaType = when {
    value.isNullOrBlank() -> default
    value.contains("novel", true) -> MediaType.NOVEL
    value.contains("manhwa", true) || value.contains("webtoon", true) || value.equals("kr", true) || value.equals("ko", true) -> MediaType.MANHWA
    value.contains("manhua", true) || value.equals("zh", true) -> MediaType.MANHUA
    value.contains("comic", true) || value.equals("en", true) -> MediaType.COMIC
    else -> MediaType.MANGA
}

internal fun readingModeFrom(type: MediaType, tags: List<String>, explicit: String? = null): app.yomikaze.core.ReadingMode = when {
    explicit.equals("text", true) || type == MediaType.NOVEL -> app.yomikaze.core.ReadingMode.TEXT
    explicit.equals("webtoon", true) || tags.any {
        it.contains("webtoon", true) || it.contains("manhwa", true) || it.contains("scroll", true)
    } || type == MediaType.MANHWA -> app.yomikaze.core.ReadingMode.WEBTOON
    else -> app.yomikaze.core.ReadingMode.PAGED
}

internal fun parseEpoch(value: String?): Long {
    if (value.isNullOrBlank()) return 0L
    value.toLongOrNull()?.let { return if (it < 10_000_000_000L) it * 1000L else it }
    return runCatching { Instant.parse(value).toEpochMilli() }.getOrDefault(0L)
}

internal fun parseJsonObject(raw: String): JsonObject = runCatching {
    Json.parseToJsonElement(raw).jsonObject
}.getOrElse { throw IllegalStateException("Respons sumber bukan JSON yang valid: ${it.message}") }

internal fun List<ContentSummary>.filterCategory(category: MediaCategory?): List<ContentSummary> = when (category) {
    null, MediaCategory.ALL -> this
    MediaCategory.MANGA_JP -> filter { it.category == MediaCategory.MANGA_JP || it.originalLanguage.equals("ja", true) }
    MediaCategory.MANHWA_KR, MediaCategory.WEBTOON -> filter { it.mediaType == MediaType.MANHWA || it.category == MediaCategory.MANHWA_KR }
    MediaCategory.MANHUA_CN -> filter { it.mediaType == MediaType.MANHUA || it.category == MediaCategory.MANHUA_CN }
    MediaCategory.COMIC, MediaCategory.OEL -> filter { it.mediaType == MediaType.COMIC || it.category == MediaCategory.COMIC || it.category == MediaCategory.OEL }
    MediaCategory.NOVEL, MediaCategory.LIGHT_NOVEL -> filter { it.mediaType == MediaType.NOVEL }
}
