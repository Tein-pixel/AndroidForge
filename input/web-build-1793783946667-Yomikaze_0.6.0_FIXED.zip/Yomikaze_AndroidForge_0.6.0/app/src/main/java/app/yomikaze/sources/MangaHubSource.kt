package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MangaHubSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "mangahub"
    override val name = "MangaHub"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA, MediaType.COMIC)

    private val apiUrl = "https://api.mghubcdn.com/graphql"
    private val imageBase = "https://img.mghubcdn.com/file/imghub"
    private val thumbBase = "https://thumb.mghubcdn.com"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val gql = """{search(x:m01,q:${gqlString(query)},page:${page.coerceAtLeast(1)}){id title slug status image author artist genres description}}"""
        return listFrom(http.postGraphQL(apiUrl, gql), "search").take(limit.coerceAtLeast(1))
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val gql = """{popular(x:m01,page:${page.coerceAtLeast(1)}){id title slug status image author artist genres description}}"""
        return listFrom(http.postGraphQL(apiUrl, gql), "popular").take(limit.coerceAtLeast(1))
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val gql = """{latest(x:m01,page:${page.coerceAtLeast(1)}){id title slug status image author artist genres description}}"""
        return listFrom(http.postGraphQL(apiUrl, gql), "latest").take(limit.coerceAtLeast(1))
    }

    override suspend fun details(contentId: String): ContentDetails {
        val slug = contentId.trim('/')
        val gql = """{manga(x:m01,slug:${gqlString(slug)}){id title slug status image author artist genres description chapters{slug title number date}}}"""
        val root = parseRoot(http.postGraphQL(apiUrl, gql))
        val manga = root["data"]?.jsonObject?.get("manga")?.jsonObject
            ?: error(root.graphQlError("MangaHub tidak mengembalikan detail judul."))
        val summary = mapSummary(manga)
        val chapters = manga["chapters"]?.jsonArray.orEmpty().mapNotNull { element ->
            val obj = element.jsonObject
            val chapterSlug = obj.string("slug") ?: return@mapNotNull null
            val number = obj.string("number") ?: "?"
            Chapter(
                id = "$slug|$number|$chapterSlug",
                contentId = slug,
                sourceId = id,
                number = number,
                title = obj.string("title"),
                publishedAt = parseIso(obj.string("date")),
            )
        }.sortedWith(compareBy({ it.number.toDoubleOrNull() ?: Double.MAX_VALUE }, { it.number }))
        return ContentDetails(
            summary = summary,
            authors = listOfNotNull(manga.string("author")),
            artists = listOfNotNull(manga.string("artist")),
            chapters = chapters,
        )
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> =
        details(contentId).chapters

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val parts = chapterId.split('|', limit = 3)
        val slug = parts.getOrNull(0)?.takeIf { it.isNotBlank() } ?: error("ID bab MangaHub tidak valid.")
        val number = parts.getOrNull(1)?.takeIf { it.isNotBlank() && it != "?" } ?: "1"
        val gql = """{chapter(x:m01,slug:${gqlString(slug)},number:$number){pages}}"""
        val root = parseRoot(http.postGraphQL(apiUrl, gql))
        val pagesElement = root["data"]?.jsonObject?.get("chapter")?.jsonObject?.get("pages")
            ?: error(root.graphQlError("MangaHub tidak mengembalikan halaman bab."))

        // MangaHub can return pages as an indexed object or as an array.
        val entries: List<Pair<String, JsonElement>> = when (pagesElement) {
            is JsonObject -> pagesElement.entries.sortedWith(
                compareBy<Map.Entry<String, JsonElement>>(
                    { it.key.toIntOrNull() ?: Int.MAX_VALUE },
                    { it.key },
                ),
            ).map { it.key to it.value }
            is JsonArray -> pagesElement.mapIndexed { index, value -> index.toString() to value }
            else -> emptyList()
        }
        val pages = entries.mapNotNull { (_, value) -> imagePath(value) }
            .mapIndexed { index, path -> Page(index, resolveImageUrl(path)) }
        if (pages.isEmpty()) error("Bab ini tidak memiliki halaman gambar yang dapat dibaca.")
        return ChapterContent.Images(pages)
    }

    private fun listFrom(json: String, key: String): List<ContentSummary> {
        val root = parseRoot(json)
        val values = root["data"]?.jsonObject?.get(key) as? JsonArray ?: return emptyList()
        return values.mapNotNull { element -> runCatching { mapSummary(element.jsonObject) }.getOrNull() }
    }

    private fun mapSummary(obj: JsonObject): ContentSummary {
        val slug = obj.string("slug") ?: obj.string("id") ?: error("MangaHub: slug judul tidak tersedia.")
        val genresValue = obj["genres"]
        val genres = when (genresValue) {
            is JsonArray -> genresValue.mapNotNull { it.jsonPrimitive.contentOrNull?.trim() }.filter(String::isNotBlank)
            is JsonPrimitive -> genresValue.content.split(',').map(String::trim).filter(String::isNotBlank)
            else -> emptyList()
        }
        val status = when (obj.string("status")?.lowercase()) {
            "completed", "complete", "finished" -> PublicationStatus.COMPLETED
            "hiatus" -> PublicationStatus.HIATUS
            "cancelled", "canceled" -> PublicationStatus.CANCELLED
            "ongoing", "publishing" -> PublicationStatus.ONGOING
            else -> PublicationStatus.UNKNOWN
        }
        val image = obj.string("image")
        return ContentSummary(
            id = slug,
            sourceId = id,
            title = obj.string("title")?.stripMarkdown()?.takeIf(String::isNotBlank) ?: slug,
            description = obj.string("description").orEmpty().stripMarkdown(),
            coverUrl = image?.let(::resolveThumbUrl),
            mediaType = MediaType.MANGA,
            status = status,
            tags = genres,
            originalLanguage = "en",
            readingMode = if (genres.any { it.contains("webtoon", true) || it.contains("manhwa", true) }) ReadingMode.WEBTOON else ReadingMode.PAGED,
        )
    }

    private fun imagePath(value: JsonElement): String? = when (value) {
        is JsonPrimitive -> value.contentOrNull?.takeIf(String::isNotBlank)
        is JsonObject -> sequenceOf("url", "src", "path", "file", "filename", "image")
            .mapNotNull { key -> value[key]?.jsonPrimitive?.contentOrNull }
            .firstOrNull(String::isNotBlank)
        else -> null
    }

    private fun resolveImageUrl(path: String): String {
        val cleaned = path.trim()
        if (cleaned.startsWith("https://") || cleaned.startsWith("http://")) return cleaned
        return "$imageBase/${cleaned.trimStart('/')}"
    }

    private fun resolveThumbUrl(path: String): String {
        val cleaned = path.trim()
        if (cleaned.startsWith("https://") || cleaned.startsWith("http://")) return cleaned
        return "$thumbBase/${cleaned.trimStart('/')}"
    }

    private fun parseRoot(json: String): JsonObject =
        runCatching { Json.parseToJsonElement(json).jsonObject }
            .getOrElse { error("Respons MangaHub bukan JSON yang valid.") }

    private fun JsonObject.graphQlError(fallback: String): String =
        this["errors"]?.jsonArray?.firstOrNull()?.jsonObject?.get("message")?.jsonPrimitive?.contentOrNull
            ?: fallback

    private fun JsonObject.string(key: String): String? =
        this[key]?.let { element ->
            when (element) {
                is JsonPrimitive -> element.contentOrNull
                else -> null
            }
        }?.takeIf(String::isNotBlank)

    private fun gqlString(value: String): String = JsonPrimitive(value).toString()

    private fun parseIso(value: String?): Long =
        value?.let { runCatching { java.time.Instant.parse(it).toEpochMilli() }.getOrDefault(0L) } ?: 0L
}
