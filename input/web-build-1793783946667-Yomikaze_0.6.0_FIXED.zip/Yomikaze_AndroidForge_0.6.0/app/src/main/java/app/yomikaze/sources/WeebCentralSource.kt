package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WeebCentralSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "weebcentral"
    override val name = "WeebCentral"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA)

    private val base = "https://weebcentral.com"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/search?q=${URLEncoder.encode(query, "UTF-8")}&page=$page")
        return doc.select("a[href*=/series/]")
            .mapNotNull { runCatching { anchorToSummary(it) }.getOrNull() }
            .distinctBy { it.id }
            .take(limit)
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/")
        return doc.select("a[href*=/series/]")
            .mapNotNull { runCatching { anchorToSummary(it) }.getOrNull() }
            .distinctBy { it.id }
            .take(limit)
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/latest")
        return doc.select("a[href*=/series/]")
            .mapNotNull { runCatching { anchorToSummary(it) }.getOrNull() }
            .distinctBy { it.id }
            .take(limit)
    }

    override suspend fun details(contentId: String): ContentDetails {
        val slug = contentId.trim('/')
        val doc = parse("$base/series/$slug")
        val title = doc.selectFirst("h1")?.text()?.trim().orEmpty()
        val cover = doc.selectFirst("img[alt]")?.absUrl("src")
        val description = doc.selectFirst("p")?.text()?.trim().orEmpty()
        val chapters = doc.select("a[href*=/chapter/]").mapNotNull { a ->
            val href = a.absUrl("href")
            Chapter(
                id = href,
                contentId = slug,
                sourceId = id,
                number = extractNum(a.text()) ?: "?",
                title = a.text().trim(),
                url = href,
            )
        }.distinctBy { it.id }.sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }
        return ContentDetails(
            ContentSummary(
                id = slug,
                sourceId = id,
                title = title.ifBlank { slug },
                coverUrl = cover,
                description = description,
                mediaType = MediaType.MANGA,
            ),
            chapters = chapters,
        )
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> =
        details(contentId).chapters

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val doc = parse(chapterId)
        val pages = doc.select("img[src*=/manga/], img[data-src]").mapNotNull { img ->
            val src = img.absUrl("src").ifBlank { img.absUrl("data-src") }
            src.takeIf { it.startsWith("http") }
        }.distinct()
        return ChapterContent.Images(pages.mapIndexed { i, url -> Page(i, url) })
    }

    private suspend fun parse(url: String): Document = withContext(Dispatchers.IO) {
        val html = http.get(
            url,
            mapOf(
                "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Referer" to "https://weebcentral.com/",
            ),
        )
        Jsoup.parse(html, url)
    }

    private fun anchorToSummary(a: Element): ContentSummary? {
        val href = a.absUrl("href").ifBlank { "$base${a.attr("href")}" }
        if (!href.contains("/series/")) return null
        val id = href.substringAfter("/series/").substringBefore("/").substringBefore("?")
        if (id.isBlank()) return null
        val container = a.closest("article") ?: a.parent() ?: return null
        val cover = container.selectFirst("img")?.absUrl("src")
        val title = container.selectFirst("h1, h2, h3, .title, strong")?.text()?.trim()
            ?: a.text().trim()
        if (title.isBlank()) return null
        return ContentSummary(
            id = id,
            sourceId = this.id,
            title = title,
            coverUrl = cover,
            mediaType = MediaType.MANGA,
        )
    }

    private fun extractNum(text: String): String? =
        Regex("Chapter\\s+(\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)
}
