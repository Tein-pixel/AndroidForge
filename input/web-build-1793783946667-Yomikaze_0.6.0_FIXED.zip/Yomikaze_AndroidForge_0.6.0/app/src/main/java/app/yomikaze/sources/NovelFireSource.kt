package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NovelFireSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "novelfire"
    override val name = "NovelFire"
    override val mediaTypes = setOf(MediaType.NOVEL)

    private val base = "https://novelfire.net"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/search?keyword=${URLEncoder.encode(query, "UTF-8")}")
        return doc.select("div.novel-item, div.book-item, li.novel-item")
            .take(limit)
            .mapNotNull { runCatching { itemToSummary(it) }.getOrNull() }
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/ranking?page=$page")
        return doc.select("a[href*=/book/]")
            .mapNotNull { runCatching { anchorToSummary(it) }.getOrNull() }
            .distinctBy { it.id }
            .take(limit)
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> = popular(null, page, limit)

    override suspend fun details(contentId: String): ContentDetails {
        val slug = contentId.trim('/')
        val doc = parse("$base/book/$slug")
        val title = doc.selectFirst("h1.novel-title, .novel-title, h1")?.text()?.trim().orEmpty()
        val cover = doc.selectFirst(".novel-cover img, .book-cover img, img[alt]")?.absUrl("src")
            ?.takeIf { it.startsWith("http") }
        val description = doc.selectFirst(".summary, .description, div.summary")?.text()?.trim().orEmpty()
        val author = doc.select("a[href*=/author/]").map { it.text().trim() }.filter { it.isNotBlank() }
        val genres = doc.select("a[href*=/genre/]").map { it.text().trim() }.filter { it.isNotBlank() }
        val summary = ContentSummary(
            id = slug,
            sourceId = id,
            title = title.ifBlank { slug.replace('-', ' ') },
            description = description,
            coverUrl = cover,
            mediaType = MediaType.NOVEL,
            category = if (genres.any { it.contains("Light Novel", true) }) MediaCategory.LIGHT_NOVEL else MediaCategory.NOVEL,
            tags = genres,
            originalLanguage = "en",
            readingMode = ReadingMode.TEXT,
        )
        return ContentDetails(summary, authors = author, chapters = chapters(slug, null))
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> {
        val slug = contentId.trim('/')
        val all = mutableListOf<Chapter>()
        var page = 1
        while (true) {
            val doc = parse("$base/book/$slug/chapters?page=$page")
            val anchors = doc.select("ul.chapter-list li a, .chapter-list a, a[href*=/chapter-]")
            if (anchors.isEmpty()) break
            anchors.forEach { anchor ->
                val href = anchor.absUrl("href").ifBlank { "$base${anchor.attr("href")}" }
                val number = Regex("/chapter-(\\d+(?:\\.\\d+)?)").find(href)?.groupValues?.get(1) ?: return@forEach
                all += Chapter(
                    id = href,
                    contentId = slug,
                    sourceId = id,
                    number = number,
                    title = anchor.text().trim().takeIf { it.isNotBlank() },
                    url = href,
                )
            }
            if (doc.selectFirst("a[rel=next], .pagination a:contains(Next)") == null) break
            page += 1
        }
        return all.distinctBy { it.id }.sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }
    }

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val doc = parse(chapterId)
        val title = doc.selectFirst("h1, .chapter-title")?.text()?.trim().orEmpty()
        val content = doc.selectFirst("#content, #chapter-content, .chapter-content, div.text-left")
            ?: error("NovelFire chapter content missing")
        val paragraphs = content.select("p").map { it.text().trim() }.filter { it.isNotBlank() }
            .ifEmpty { content.text().split("\n").map { it.trim() }.filter { it.isNotBlank() } }
        return ChapterContent.Text(title, paragraphs)
    }

    private suspend fun parse(url: String): Document = withContext(Dispatchers.IO) {
        Jsoup.parse(http.get(url, mapOf("Referer" to "$base/")), url)
    }

    private fun itemToSummary(element: Element): ContentSummary {
        val anchor = element.selectFirst("h3 a, .novel-title a, a[href*=/book/]")
            ?: error("NovelFire item missing anchor")
        val href = anchor.absUrl("href").ifBlank { "$base${anchor.attr("href")}" }
        val slug = href.substringAfter("/book/").substringBefore("/").substringBefore("?")
        val cover = element.selectFirst("img")?.let { img ->
            img.absUrl("src").ifBlank { img.absUrl("data-src") }.ifBlank { img.attr("data-src") }
        }?.takeIf { it.startsWith("http") }
        return ContentSummary(
            id = slug,
            sourceId = id,
            title = anchor.text().trim().ifBlank { slug.replace('-', ' ') },
            coverUrl = cover,
            mediaType = MediaType.NOVEL,
            readingMode = ReadingMode.TEXT,
            originalLanguage = "en",
        )
    }

    private fun anchorToSummary(a: Element): ContentSummary? {
        val href = a.absUrl("href").ifBlank { "$base${a.attr("href")}" }
        if (!href.contains("/book/")) return null
        val slug = href.substringAfter("/book/").substringBefore("/").substringBefore("?")
        if (slug.isBlank()) return null
        val container = a.closest("div, li") ?: a.parent() ?: return null
        val cover = container.selectFirst("img")?.absUrl("src")?.takeIf { it.startsWith("http") }
        return ContentSummary(
            id = slug,
            sourceId = id,
            title = a.text().trim().ifBlank { slug.replace('-', ' ') },
            coverUrl = cover,
            mediaType = MediaType.NOVEL,
            readingMode = ReadingMode.TEXT,
            originalLanguage = "en",
        )
    }
}
