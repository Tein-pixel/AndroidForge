package app.yomikaze.core

interface ContentSource {
    val id: String
    val name: String
    val mediaTypes: Set<MediaType>
    /** Marks a source that is only shown when the user enables the dedicated source mode. */
    val isRestricted: Boolean get() = false

    suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary>
    suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary>
    suspend fun latest(page: Int, limit: Int): List<ContentSummary>
    suspend fun details(contentId: String): ContentDetails
    suspend fun chapters(contentId: String, language: String? = null): List<Chapter>
    suspend fun loadChapter(chapterId: String): ChapterContent
}
