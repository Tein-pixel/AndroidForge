package app.yomikaze.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import app.yomikaze.core.Chapter
import app.yomikaze.ui.DetailViewModel
import app.yomikaze.ui.components.EmptyState
import app.yomikaze.ui.components.LoadingState
import app.yomikaze.work.ChapterDownloadWorker
import coil3.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    onBack: () -> Unit,
    onRead: (String, String, String, Boolean) -> Unit,
    viewModel: DetailViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val details = state.details
    val context = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(details?.summary?.title ?: "Detail komik", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Kembali") } },
        )
        when {
            state.loading -> LoadingState()
            state.error != null && details == null -> EmptyState(state.error ?: "Detail tidak dapat dimuat.")
            details != null -> {
                val summary = details.summary
                val resumeChapter = details.chapters.firstOrNull { it.id == state.progress?.chapterId }
                    ?: details.chapters.lastOrNull()
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            AsyncImage(
                                model = summary.coverUrl,
                                contentDescription = summary.title,
                                modifier = Modifier.width(126.dp).aspectRatio(2f / 3f)
                                    .clip(RoundedCornerShape(16.dp)),
                                contentScale = ContentScale.Crop,
                            )
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text(summary.title, style = MaterialTheme.typography.titleLarge,
                                    maxLines = 4, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${summary.mediaType.name.lowercase().replaceFirstChar { it.uppercase() }}  ·  ${statusLabel(summary.status.name)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (summary.year != null) {
                                    Text("Tahun ${summary.year}", style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (details.authors.isNotEmpty()) {
                                    Text("Penulis: ${details.authors.joinToString()}",
                                        style = MaterialTheme.typography.bodySmall, maxLines = 2,
                                        overflow = TextOverflow.Ellipsis)
                                }
                                if (details.artists.isNotEmpty()) {
                                    Text("Ilustrator: ${details.artists.joinToString()}",
                                        style = MaterialTheme.typography.bodySmall, maxLines = 2,
                                        overflow = TextOverflow.Ellipsis)
                                }
                                Text("${details.chapters.size} bab tersedia",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Button(
                                onClick = {
                                    resumeChapter?.let { chapter ->
                                        if (!chapter.externalUrl.isNullOrBlank()) openExternal(context, chapter.externalUrl)
                                        else onRead(chapter.sourceId, chapter.contentId, chapter.id, viewModel.isNovel())
                                    }
                                },
                                enabled = resumeChapter != null,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                            ) { Text(if (state.progress != null) "Lanjut baca" else "Mulai baca") }
                            OutlinedButton(
                                onClick = viewModel::toggleLibrary,
                                shape = RoundedCornerShape(12.dp),
                            ) {
                                Icon(
                                    if (state.inLibrary) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = null,
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(if (state.inLibrary) "Tersimpan" else "Simpan")
                            }
                        }
                    }

                    if (summary.tags.isNotEmpty()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Genre", modifier = Modifier.padding(horizontal = 16.dp),
                                    style = MaterialTheme.typography.titleMedium)
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                                ) {
                                    summary.tags.take(4).forEach { tag ->
                                        Surface(color = MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(8.dp)) {
                                            Text(tag, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                                                style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (summary.description.isNotBlank()) {
                        item {
                            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Sinopsis", style = MaterialTheme.typography.titleMedium)
                                Text(summary.description, style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text("Daftar bab", style = MaterialTheme.typography.titleLarge)
                            Text("Terbaru di atas", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    items(details.chapters.asReversed(), key = { it.id }) { chapter ->
                        ChapterRow(
                            chapter = chapter,
                            onOpen = {
                                if (!chapter.externalUrl.isNullOrBlank()) openExternal(context, chapter.externalUrl)
                                else onRead(chapter.sourceId, chapter.contentId, chapter.id, viewModel.isNovel())
                            },
                            onDownload = {
                                enqueueDownload(context, chapter.sourceId, chapter.contentId, chapter.id)
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChapterRow(chapter: Chapter, onOpen: () -> Unit, onDownload: () -> Unit) {
    ListItem(
        headlineContent = {
            Text(
                "Bab ${chapter.number}${chapter.title?.takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""}",
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        },
        supportingContent = {
            val info = buildList {
                add(chapter.language.uppercase())
                if (chapter.pageCount > 0) add("${chapter.pageCount} halaman")
                chapter.scanlationGroups.firstOrNull()?.let(::add)
                if (!chapter.externalUrl.isNullOrBlank()) add("Sumber eksternal")
            }
            Text(info.joinToString("  ·  "), maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        trailingContent = {
            Row {
                if (!chapter.externalUrl.isNullOrBlank()) {
                    Icon(Icons.Default.OpenInNew, contentDescription = "Buka sumber eksternal",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onDownload, enabled = chapter.externalUrl.isNullOrBlank()) {
                    Icon(Icons.Default.Download, contentDescription = "Unduh bab")
                }
            }
        },
        modifier = Modifier.clickable(onClick = onOpen).padding(horizontal = 8.dp),
        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.background),
    )
}

private fun statusLabel(value: String): String = when (value) {
    "ONGOING" -> "Berjalan"
    "COMPLETED" -> "Tamat"
    "HIATUS" -> "Hiatus"
    "CANCELLED" -> "Dibatalkan"
    else -> "Tidak diketahui"
}

private fun openExternal(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun enqueueDownload(context: Context, sourceId: String, contentId: String, chapterId: String) {
    val request = OneTimeWorkRequestBuilder<ChapterDownloadWorker>()
        .setInputData(
            Data.Builder()
                .putString(ChapterDownloadWorker.KEY_SOURCE, sourceId)
                .putString(ChapterDownloadWorker.KEY_CONTENT, contentId)
                .putString(ChapterDownloadWorker.KEY_CHAPTER, chapterId)
                .build(),
        )
        .build()
    WorkManager.getInstance(context).enqueue(request)
}
