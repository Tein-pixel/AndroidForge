package app.yomikaze.data

import app.yomikaze.core.*
import app.yomikaze.sources.SourceRegistry
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CatalogRepository @Inject constructor(
    private val registry: SourceRegistry,
    private val settings: SettingsRepository
) {
    private suspend fun isRestricted() = settings.isRestrictedModeEnabled.first()

    suspend fun search(query: String, sourceId: String?, page: Int = 1, limit: Int = 24): List<ContentSummary> = coroutineScope {
        val restricted = isRestricted()
        val sources = sourceId?.let { listOf(registry.get(it)) } ?: registry.getActiveSources(restricted)
        val results = sources.map { source ->
            async { runCatching { source.search(query, page, limit) }.getOrDefault(emptyList()) }
        }.flatMap { it.await() }
        prioritizeIndonesian(results)
    }

    suspend fun popular(category: MediaCategory, page: Int = 1, limit: Int = 24): List<ContentSummary> {
        val restricted = isRestricted()
        if (category == MediaCategory.ALL) return browseAll(restricted, page, 10)
        return coroutineScope {
            val results = registry.forCategory(category, restricted).map { source ->
                async { runCatching { source.popular(category, page, limit) }.getOrDefault(emptyList()) }
            }.flatMap { it.await() }
            prioritizeIndonesian(results)
        }
    }

    suspend fun latest(page: Int = 1, limit: Int = 18): List<ContentSummary> {
        val restricted = isRestricted()
        return coroutineScope {
            val results = registry.getActiveSources(restricted).map { source ->
                async { runCatching { source.latest(page, limit) }.getOrDefault(emptyList()) }
            }.flatMap { it.await() }
            prioritizeIndonesian(results).take(limit.coerceAtLeast(1))
        }
    }

    suspend fun browseAll(isRestricted: Boolean, page: Int = 1, perSource: Int = 10): List<ContentSummary> = coroutineScope {
        val results = registry.getActiveSources(isRestricted).map { source ->
            async { runCatching { source.popular(null, page, perSource) }.getOrDefault(emptyList()) }
        }.flatMap { it.await() }
        prioritizeIndonesian(results)
    }

    /** Indonesian-language catalogs appear first while preserving source-specific entries. */
    private fun prioritizeIndonesian(items: List<ContentSummary>): List<ContentSummary> =
        items.distinctBy { "${it.sourceId}:${it.id}" }
            .sortedBy { item ->
                val sourceIsIndonesian = item.sourceId in setOf("komiku", "sankaapi", "kiryuu")
                if (item.originalLanguage.equals("id", ignoreCase = true) || sourceIsIndonesian) 0 else 1
            }

    suspend fun details(sourceId: String, contentId: String): ContentDetails =
        registry.get(sourceId).details(contentId)

    suspend fun chapterContent(sourceId: String, chapterId: String): ChapterContent =
        registry.get(sourceId).loadChapter(chapterId)
}

@Singleton
class LibraryRepository @Inject constructor(
    private val libraryDao: LibraryDao,
    private val progressDao: ProgressDao,
) {
    fun observeLibrary(): Flow<List<LibraryEntity>> = libraryDao.observeAll()
    fun observeProgress(contentId: String): Flow<ProgressEntity?> = progressDao.observe(contentId)
    suspend fun find(contentId: String): LibraryEntity? = libraryDao.find(contentId)
    suspend fun add(summary: ContentSummary) {
        libraryDao.upsert(
            LibraryEntity(summary.id, summary.sourceId, summary.title, summary.coverUrl, summary.mediaType.name, summary.readingMode.name, System.currentTimeMillis(), null)
        )
    }
    suspend fun remove(contentId: String) = libraryDao.delete(contentId)
    suspend fun saveProgress(contentId: String, chapterId: String, page: Int, totalPages: Int) {
        val now = System.currentTimeMillis()
        progressDao.upsert(ProgressEntity(contentId, chapterId, page, totalPages, now))
        libraryDao.touch(contentId, now)
    }
}

@Singleton
class DownloadRepository @Inject constructor(
    private val downloadDao: DownloadDao,
) {
    fun observeAll(): Flow<List<DownloadEntity>> = downloadDao.observeAll()
    fun observeForContent(contentId: String): Flow<List<DownloadEntity>> = downloadDao.observeForContent(contentId)
    suspend fun find(chapterId: String): DownloadEntity? = downloadDao.find(chapterId)
    suspend fun update(entity: DownloadEntity) = downloadDao.upsert(entity)
    suspend fun remove(chapterId: String) = downloadDao.delete(chapterId)
}