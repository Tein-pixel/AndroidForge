package app.yomikaze.sources

import app.yomikaze.core.ContentSource
import app.yomikaze.core.MediaCategory
import app.yomikaze.core.MediaType
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SourceRegistry @Inject constructor(
    val mangaDex: MangaDexSource,
    val mangaHub: MangaHubSource,
    val weebCentral: WeebCentralSource,
    val kiryuu: KiryuuSource,
    val novelFire: NovelFireSource,
    val sankaApi: SankaApiSource,
    val anikuro: AnikuroSource,
    val komiku: KomikuSource,
    val manytoon: ManytoonSource
) {
    private val allSources = listOf(
        mangaDex, mangaHub, weebCentral, kiryuu, novelFire,
        sankaApi, anikuro, komiku, manytoon,
    )

    fun getActiveSources(isRestricted: Boolean): List<ContentSource> {
        return allSources.filter { it.isRestricted == isRestricted }
    }
    
    fun get(sourceId: String): ContentSource = allSources.first { it.id == sourceId }

    fun forCategory(category: MediaCategory, isRestricted: Boolean): List<ContentSource> {
        val sources = getActiveSources(isRestricted)
        return when (category) {
            MediaCategory.NOVEL, MediaCategory.LIGHT_NOVEL -> sources.filter { MediaType.NOVEL in it.mediaTypes }
            MediaCategory.ALL -> sources
            else -> sources.filter { MediaType.NOVEL !in it.mediaTypes }
        }
    }
}