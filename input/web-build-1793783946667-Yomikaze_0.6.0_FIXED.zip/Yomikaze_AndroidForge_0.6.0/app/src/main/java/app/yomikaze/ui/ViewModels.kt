package app.yomikaze.ui

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.yomikaze.core.*
import app.yomikaze.data.*
import app.yomikaze.sources.SourceRegistry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class BrowseState(
    val loading: Boolean = true,
    val category: MediaCategory = MediaCategory.ALL,
    val items: List<ContentSummary> = emptyList(),
    val latestItems: List<ContentSummary> = emptyList(),
    val error: String? = null,
)

@HiltViewModel
class BrowseViewModel @Inject constructor(
    private val catalog: CatalogRepository,
    private val settings: SettingsRepository
) : ViewModel() {
    private val _state = MutableStateFlow(BrowseState())
    val state: StateFlow<BrowseState> = _state.asStateFlow()
    val categories = MediaCategory.values().toList()

    val genres = listOf("Semua Genre", "Action", "Romance", "Fantasy", "Comedy", "Horror", "Mature")
    private val _selectedGenre = MutableStateFlow("Semua Genre")
    val selectedGenre = _selectedGenre.asStateFlow()
    private var loadJob: Job? = null

    init {
        viewModelScope.launch {
            settings.isRestrictedModeEnabled.distinctUntilChanged().collect {
                load(_state.value.category)
            }
        }
    }

    fun setGenre(genre: String) { _selectedGenre.value = genre }

    fun load(category: MediaCategory) {
        loadJob?.cancel()
        _state.update { it.copy(loading = true, category = category, error = null) }
        loadJob = viewModelScope.launch {
            val popularResult = runCatching { catalog.popular(category, 1, 24) }
            val latestResult = runCatching { catalog.latest(1, 18) }
            val popular = popularResult.getOrDefault(emptyList())
            val latest = latestResult.getOrDefault(emptyList())
            _state.update {
                it.copy(
                    loading = false,
                    items = popular,
                    latestItems = latest,
                    error = if (popular.isEmpty() && latest.isEmpty()) {
                        popularResult.exceptionOrNull()?.message ?: latestResult.exceptionOrNull()?.message
                    } else null,
                )
            }
        }
    }
}

data class SettingsState(val isRestricted: Boolean = false)

data class SearchState(
    val query: String = "",
    val loading: Boolean = false,
    val results: List<ContentSummary> = emptyList(),
    val error: String? = null,
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val catalog: CatalogRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(SearchState())
    val state: StateFlow<SearchState> = _state.asStateFlow()

    fun setQuery(value: String) { _state.update { it.copy(query = value) } }

    fun submit() {
        val current = _state.value
        if (current.query.trim().length < 2) return
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val result = runCatching { catalog.search(current.query.trim(), null) }
            _state.update {
                it.copy(
                    loading = false,
                    results = result.getOrDefault(emptyList()),
                    error = result.exceptionOrNull()?.message,
                )
            }
        }
    }
}

data class DetailState(
    val loading: Boolean = true,
    val details: ContentDetails? = null,
    val inLibrary: Boolean = false,
    val progress: ProgressEntity? = null,
    val error: String? = null,
)

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val catalog: CatalogRepository,
    private val library: LibraryRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val sourceId: String = savedStateHandle["sourceId"] ?: error("sourceId missing")
    private val contentId: String = savedStateHandle["contentId"] ?: error("contentId missing")
    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            library.observeProgress(contentId).collect { progress ->
                _state.update { it.copy(progress = progress) }
            }
        }
        viewModelScope.launch {
            _state.update { it.copy(inLibrary = library.find(contentId) != null) }
        }
        refresh()
    }

    fun refresh() {
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val result = runCatching { catalog.details(sourceId, contentId) }
            _state.update {
                it.copy(
                    loading = false,
                    details = result.getOrNull(),
                    error = result.exceptionOrNull()?.message,
                )
            }
        }
    }

    fun toggleLibrary() {
        val details = _state.value.details ?: return
        viewModelScope.launch {
            if (_state.value.inLibrary) {
                library.remove(contentId)
                _state.update { it.copy(inLibrary = false) }
            } else {
                library.add(details.summary)
                _state.update { it.copy(inLibrary = true) }
            }
        }
    }

    fun isNovel(): Boolean = _state.value.details?.summary?.mediaType == MediaType.NOVEL
}

data class ReaderState(
    val loading: Boolean = true,
    val content: ChapterContent? = null,
    val chapter: Chapter? = null,
    val chapters: List<Chapter> = emptyList(),
    val page: Int = 0,
    val readingMode: ReadingMode = ReadingMode.PAGED,
    val error: String? = null,
)

private data class LoadedReader(
    val chapters: List<Chapter>,
    val chapter: Chapter?,
    val content: ChapterContent,
    val readingMode: ReadingMode,
    val resumePage: Int,
)

@HiltViewModel
class ReaderViewModel @Inject constructor(
    private val catalog: CatalogRepository,
    private val library: LibraryRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val sourceId: String = savedStateHandle["sourceId"] ?: error("sourceId missing")
    private val contentId: String = savedStateHandle["contentId"] ?: error("contentId missing")
    private var currentChapterId: String = savedStateHandle["chapterId"] ?: error("chapterId missing")

    private val _state = MutableStateFlow(ReaderState())
    val state: StateFlow<ReaderState> = _state.asStateFlow()

    init { load(currentChapterId) }

    fun load(chapterId: String) {
        currentChapterId = chapterId
        _state.update { it.copy(loading = true, error = null, page = 0) }
        viewModelScope.launch {
            val result = runCatching {
                val details = catalog.details(sourceId, contentId)
                val chapter = details.chapters.firstOrNull { it.id == chapterId }
                if (chapter?.externalUrl?.isNotBlank() == true) {
                    error("Bab ini tersedia melalui halaman eksternal, bukan reader internal.")
                }
                val content = catalog.chapterContent(sourceId, chapterId)
                val saved = library.observeProgress(contentId).first()
                val resumePage = saved?.takeIf { it.chapterId == chapterId }?.page ?: 0
                LoadedReader(details.chapters, chapter, content, details.summary.readingMode, resumePage)
            }
            val loaded = result.getOrNull()
            _state.update {
                it.copy(
                    loading = false,
                    chapters = loaded?.chapters.orEmpty(),
                    chapter = loaded?.chapter,
                    content = loaded?.content,
                    readingMode = loaded?.readingMode ?: ReadingMode.PAGED,
                    page = loaded?.resumePage ?: 0,
                    error = result.exceptionOrNull()?.message,
                )
            }
            loaded?.let { value ->
                val total = when (val chapterContent = value.content) {
                    is ChapterContent.Images -> chapterContent.pages.size
                    is ChapterContent.Text -> 1
                }
                value.chapter?.let { library.saveProgress(contentId, it.id, value.resumePage, total) }
            }
        }
    }

    fun onPageChanged(page: Int, total: Int) {
        _state.update { it.copy(page = page) }
        viewModelScope.launch { library.saveProgress(contentId, currentChapterId, page, total) }
    }

    fun nextChapter(): Chapter? {
        val chapters = _state.value.chapters
        val index = chapters.indexOfFirst { it.id == currentChapterId }
        return chapters.getOrNull(index + 1)
    }

    fun previousChapter(): Chapter? {
        val chapters = _state.value.chapters
        val index = chapters.indexOfFirst { it.id == currentChapterId }
        return chapters.getOrNull(index - 1)
    }
}

@HiltViewModel
class LibraryViewModel @Inject constructor(
    repository: LibraryRepository,
) : ViewModel() {
    val library: StateFlow<List<LibraryEntity>> =
        repository.observeLibrary()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settings: SettingsRepository,
    registry: SourceRegistry
) : ViewModel() {
    val sources: List<ContentSource> = registry.getActiveSources(false) + registry.getActiveSources(true)

    val isRestrictedModeEnabled = settings.isRestrictedModeEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun toggleRestrictedMode(enabled: Boolean) {
        viewModelScope.launch { settings.setRestrictedMode(enabled) }
    }
}
