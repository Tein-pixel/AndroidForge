package app.yomikaze.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.ui.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val isRestricted by viewModel.isRestrictedModeEnabled.collectAsStateWithLifecycle()
    
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Pengaturan") })
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            
            item { Text("Sumber Aktif", style = MaterialTheme.typography.titleMedium) }
            items(viewModel.sources.filter { it.isRestricted == isRestricted }) { source ->
                ListItem(
                    headlineContent = { Text(source.name) },
                    supportingContent = { Text(source.mediaTypes.joinToString { it.name.lowercase() }) },
                )
            }

            item { Spacer(Modifier.height(16.dp)) }
            item { Text("Penyimpanan Unduhan", style = MaterialTheme.typography.titleMedium) }
            item { 
                Text(
                    "Bab tersimpan di files/downloads/...", 
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                ) 
            }
            
            item { Spacer(Modifier.height(32.dp)) }

            // --- TOGGLE DISEMBUNYIKAN DI PALING BAWAH ---
            item {
                Text(
                    "Mode Lanjutan", 
                    style = MaterialTheme.typography.labelSmall, 
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isRestricted) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Aktifkan Sumber Khusus", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "Hanya menampilkan katalog dari sumber alternatif.", 
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        Switch(
                            checked = isRestricted,
                            onCheckedChange = { viewModel.toggleRestrictedMode(it) }
                        )
                    }
                }
            }
        }
    }
}