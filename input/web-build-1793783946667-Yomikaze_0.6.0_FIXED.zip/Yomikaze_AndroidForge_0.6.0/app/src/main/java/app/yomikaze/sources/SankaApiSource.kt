package app.yomikaze.sources

import kotlinx.coroutines.CancellationException
import app.yomikaze.core.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.URI
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Adapter for the Sanka comic REST gateway.
 *
 * The supplied base URL is known, but its endpoint schema was not part of the project files.
 * Therefore each operation tries the documented-looking path first and a small set of
 * conventional aliases. Field mapping intentionally accepts common Indonesian/English keys.
 * Adjust ENDPOINT_CANDIDATES if the live API uses a different route.
 */
@Singleton
class SankaApiSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "sankaapi"
    override val name = "Sanka API"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA, MediaType.COMIC)

    private val base = "https://www.sankavollerei.web.id/comic"
    private val requestHeaders = mapOf(
        "Accept" to "application/json, text/plain, */*",
        "Referer" to "https://www.sankavollerei.web.id/",
    )

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val q = encodeQuery(query.trim())
        val p = page.coerceAtLeast(1)
        val raw = getFirstCatalog(
            listOf(
                "$base/search?q=$q&page=$p",
                "$base/search?query=$q&page=$p",
                "$base/search?keyword=$q&page=$p",
                "$base?search=$q&page=$p",
            ),
        )
        return parseList(raw).take(limit.coerceIn(1, 100))
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val p = page.coerceAtLeast(1)
        val raw = getFirstCatalog(
            listOf(
                "$base/popular?page=$p&limit=$limit",
                "$base/popular?pages=$p",
                "$base?sort=popular&page=$p",
            ),
        )
        return parseList(raw).filterCategory(category).take(limit.coerceIn(1, 100))
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val p = page.coerceAtLeast(1)
        val raw = getFirstCatalog(
            listOf(
                "$base/latest?page=$p&limit=$limit",
                "$base/updates?page=$p",
                "$base?sort=latest&page=$p",
            ),
        )
        return parseList(raw).take(limit.coerceIn(1, 100))
    }

    override suspend fun details(contentId: String): ContentDetails {
        val key = encodeQuery(contentId.trim('/'))
        val raw = getFirstJson(
            listOf(
                "$base/detail/$key",
                "$base/details/$key",
                "$base/manga/$key",
                "$base/$key",
            ),
        )
        val root = Json.parseToJsonElement(raw)
        val item = root.findObject("manga", "comic", "detail", "details", "result", "data")
            ?: error("Sanka API: objek detail tidak ditemukan pada respons.")
        val summary = mapSummary(item, contentId)
        val chapterArray = root.findArray("chapters", "chapterList", "chapter_list", "episodes", "data")
            ?: item.findArray("chapters", "chapterList", "chapter_list", "episodes")
        val chapters = chapterArray?.mapNotNull { element ->
            val chapter = element as? JsonObject ?: return@mapNotNull null
            val chapterId = chapter.text("id", "chapterId", "chapter_id", "slug", "url", "link")
                ?: return@mapNotNull null
            val number = chapter.text("number", "chapter", "chapterNumber", "chapter_number", "name", "title")
                ?.let(::chapterNumber) ?: "?"
            val url = chapter.text("url", "link", "href")?.let { absoluteUrl(base, it) }
            Chapter(
                id = url ?: chapterId,
                contentId = summary.id,
                sourceId = id,
                number = number,
                title = chapter.text("title", "name", "chapterTitle"),
                language = chapter.text("language", "lang") ?: "id",
                pageCount = chapter.intValue("pages", "pageCount", "page_count") ?: 0,
                publishedAt = parseEpoch(chapter.text("date", "createdAt", "created_at", "updatedAt")),
                url = url,
            )
        }.orEmpty().distinctBy { it.id }
            .sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }
        return ContentDetails(
            summary = summary,
            authors = item["authors"].stringList().ifEmpty { listOfNotNull(item.text("author", "writer")) },
            artists = item["artists"].stringList().ifEmpty { listOfNotNull(item.text("artist", "illustrator")) },
            chapters = chapters,
        )
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> =
        details(contentId).chapters.filter { language.isNullOrBlank() || it.language.equals(language, true) }

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val target = if (chapterId.startsWith("http://") || chapterId.startsWith("https://")) {
            chapterId
        } else {
            val key = encodeQuery(chapterId)
            getFirst(
                listOf(
                    "$base/chapter/$key",
                    "$base/read/$key",
                    "$base/chapters/$key",
                ),
            )
        }
        val body = if (target.startsWith("http://") || target.startsWith("https://")) {
            http.get(target, requestHeaders + ("Accept" to "text/html,application/json,*/*"))
        } else target
        return parseChapterBody(body, chapterId)
    }

    private suspend fun getFirstCatalog(urls: List<String>): String {
        var emptyJson: String? = null
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                val body = http.get(url, requestHeaders)
                val parsed = runCatching { parseList(body) }.getOrNull()
                if (!parsed.isNullOrEmpty()) return body
                if (parsed != null && emptyJson == null) emptyJson = body
                else if (parsed == null) lastError = IllegalStateException("Respons bukan katalog JSON: $url")
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        return emptyJson ?: throw IllegalStateException(
            "Sanka API tidak menemukan endpoint katalog yang cocok. ${lastError?.message.orEmpty()}",
            lastError,
        )
    }

    private suspend fun getFirstJson(urls: List<String>): String {
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                val body = http.get(url, requestHeaders)
                Json.parseToJsonElement(body)
                return body
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        throw IllegalStateException("Sanka API tidak mengembalikan JSON detail yang valid. ${lastError?.message.orEmpty()}", lastError)
    }

    private suspend fun getFirst(urls: List<String>): String {
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                return http.get(url, requestHeaders)
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        throw IllegalStateException(
            "Sanka API tidak dapat diakses melalui endpoint kandidat. ${lastError?.message.orEmpty()}",
            lastError,
        )
    }

    private fun parseList(raw: String): List<ContentSummary> {
        val root = runCatching { Json.parseToJsonElement(raw) }.getOrElse {
            error("Sanka API mengembalikan respons non-JSON untuk katalog.")
        }
        return root.asContentArray().mapNotNull { item ->
            runCatching { mapSummary(item) }.getOrNull()
        }.distinctBy { it.id }
    }

    private fun mapSummary(item: JsonObject, fallbackId: String? = null): ContentSummary {
        val title = item.text("title", "name", "judul", "manga_name", "comic_title", "series")
            ?.stripMarkdown()?.takeIf(String::isNotBlank) ?: fallbackId ?: error("Sanka API: judul kosong.")
        val rawId = item.text("id", "slug", "manga_id", "mangaId", "comic_id", "url", "link") ?: fallbackId
            ?: error("Sanka API: id/slug tidak tersedia.")
        val id = normalizeContentId(rawId)
        val cover = item.imageText("cover", "coverUrl", "cover_url", "image", "thumbnail", "thumb", "poster")
        val tags = item["genres"].stringList().ifEmpty { item["tags"].stringList() }
        val typeText = item.text("type", "kind", "demographic", "originalLanguage", "language")
        val type = mediaTypeFrom(typeText)
        val explicitMode = item.text("readingMode", "reading_mode", "readerMode")
        val language = item.text("originalLanguage", "original_language", "language", "lang") ?: "id"
        return ContentSummary(
            id = id,
            sourceId = this.id,
            title = title,
            altTitles = item["altTitles"].stringList().ifEmpty { item["alternativeTitles"].stringList() },
            description = item.text("description", "synopsis", "summary", "sinopsis").orEmpty().stripMarkdown(),
            coverUrl = cover?.let { absoluteUrl(base, it) },
            mediaType = type,
            category = when (type) {
                MediaType.MANHWA -> MediaCategory.MANHWA_KR
                MediaType.MANHUA -> MediaCategory.MANHUA_CN
                MediaType.COMIC -> MediaCategory.COMIC
                else -> null
            },
            status = item.toStatus(),
            year = item.intValue("year", "released", "releaseYear"),
            tags = tags,
            originalLanguage = language,
            readingMode = readingModeFrom(type, tags, explicitMode),
        )
    }

    private fun JsonObject.imageText(vararg keys: String): String? {
        keys.forEach { key ->
            val value = this[key]
            value.asTextOrNull()?.let { return it }
            val nested = value.asObjectOrNull()
            nested?.text("url", "src", "image", "original", "large")?.let { return it }
        }
        return null
    }

    private fun JsonElement?.chapterImages(): List<String> {
        val element = this ?: return emptyList()
        val candidates: List<JsonElement> = when (element) {
            is JsonArray -> element.toList()
            is JsonObject -> element.entries.sortedWith(
                compareBy<Map.Entry<String, JsonElement>>({ it.key.toIntOrNull() ?: Int.MAX_VALUE }, { it.key }),
            ).map { it.value }
            else -> listOf(element)
        }
        return candidates.mapNotNull { page ->
            page.asTextOrNull() ?: page.asObjectOrNull()?.text("url", "src", "image", "file", "path", "original")
        }.map { absoluteUrl(base, it) }.distinct()
    }

    private fun parseChapterBody(raw: String, chapterId: String): ChapterContent {
        val root = runCatching { Json.parseToJsonElement(raw) }.getOrNull()
        if (root != null) {
            val holder = root.findObject("chapter", "reader", "data", "result") ?: root.asObjectOrNull()
            val pagesElement = holder?.get("pages") ?: holder?.get("images") ?: holder?.get("data")
            val urls = pagesElement.chapterImages().ifEmpty { root.findArray("pages", "images")?.flatMap { it.chapterImages() }.orEmpty() }
            if (urls.isNotEmpty()) return ChapterContent.Images(urls.mapIndexed { index, url -> Page(index, url) })
        }
        val doc: Document = Jsoup.parse(raw, chapterId.takeIf { it.startsWith("http") } ?: base)
        val images = doc.select(
            ".reader img, .reader-area img, .reading-content img, .chapter-content img, #readerarea img, .page-break img, img[data-src], img[data-lazy-src]",
        ).mapNotNull { image ->
            sequenceOf("data-src", "data-lazy-src", "data-original", "src").map { image.attr(it) }
                .firstOrNull { it.startsWith("http") }
        }.distinct()
        if (images.isEmpty()) error("Sanka API: gambar bab tidak ditemukan. Periksa selector reader atau endpoint chapter.")
        return ChapterContent.Images(images.mapIndexed { index, url -> Page(index, url) })
    }

    private fun normalizeContentId(raw: String): String {
        if (raw.startsWith("http://") || raw.startsWith("https://")) {
            return runCatching { URI(raw).path.trim('/').substringAfterLast('/') }.getOrDefault(raw)
        }
        return raw.trim().trim('/')
    }

    private fun absoluteUrl(origin: String, value: String): String = when {
        value.startsWith("https://") || value.startsWith("http://") -> value
        value.startsWith("//") -> "https:$value"
        else -> runCatching { URI(origin).resolve(value).toString() }.getOrDefault(value)
    }

    private fun chapterNumber(raw: String): String =
        Regex("(?i)(?:chapter|chap|bab|ch)\\s*([0-9]+(?:\\.[0-9]+)?)").find(raw)?.groupValues?.get(1)
            ?: raw.filter { it.isDigit() || it == '.' }.ifBlank { raw }
}
