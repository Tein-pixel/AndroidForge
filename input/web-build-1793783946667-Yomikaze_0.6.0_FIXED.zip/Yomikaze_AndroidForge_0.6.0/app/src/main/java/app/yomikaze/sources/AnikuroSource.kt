package app.yomikaze.sources

import kotlinx.coroutines.CancellationException
import app.yomikaze.core.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

/** Adapter for the public Anikuro REST gateway (MangaBuddy-backed manga/manhwa catalog). */
@Singleton
class AnikuroSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "anikuro"
    override val name = "Anikuro"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA, MediaType.COMIC)

    private val base = "https://aor-rex-anikuro-api.hf.space"
    private val headers = mapOf(
        "Accept" to "application/json, text/plain, */*",
        "Referer" to "$base/",
    )

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val q = encodeQuery(query.trim())
        val p = page.coerceAtLeast(1)
        val raw = getFirstCatalog(
            listOf(
                "$base/manga?search=$q&page=$p&limit=$limit",
                "$base/manga?q=$q&page=$p&limit=$limit",
                "$base/manga?query=$q&page=$p",
            ),
        )
        return parseList(raw).take(limit.coerceIn(1, 100))
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val p = page.coerceAtLeast(1)
        val raw = getFirstCatalog(
            listOf(
                "$base/manga?sort=popular&page=$p&limit=$limit",
                "$base/manga/popular?page=$p&limit=$limit",
                "$base/manga?order=popular&page=$p",
            ),
        )
        return parseList(raw).filterCategory(category).take(limit.coerceIn(1, 100))
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val p = page.coerceAtLeast(1)
        val raw = getFirstCatalog(
            listOf(
                "$base/manga?sort=latest&page=$p&limit=$limit",
                "$base/manga/latest?page=$p&limit=$limit",
                "$base/manga?order=updated&page=$p",
            ),
        )
        return parseList(raw).take(limit.coerceIn(1, 100))
    }

    override suspend fun details(contentId: String): ContentDetails {
        val key = encodeQuery(contentId.trim('/'))
        val raw = getFirstJson(
            listOf(
                "$base/manga/$key",
                "$base/manga?id=$key",
                "$base/manga?slug=$key",
            ),
        )
        val root = Json.parseToJsonElement(raw)
        val item = root.findObject("manga", "comic", "series", "detail", "result", "data")
            ?: error("Anikuro: objek detail tidak tersedia pada respons /manga.")
        val summary = mapSummary(item, contentId)
        val chapterArray = root.findArray("chapters", "chapterList", "chapter_list", "episodes")
            ?: item.findArray("chapters", "chapterList", "chapter_list", "episodes")
        val chapters = chapterArray?.mapNotNull { element ->
            val chapter = element as? JsonObject ?: return@mapNotNull null
            val chapterId = chapter.text("id", "chapterId", "chapter_id", "slug", "url", "link")
                ?: return@mapNotNull null
            val chapterUrl = chapter.text("url", "link", "href")?.let { resolveUrl(it) }
            Chapter(
                id = chapterUrl ?: chapterId,
                contentId = summary.id,
                sourceId = id,
                number = chapter.text("number", "chapter", "chapterNumber", "name", "title")
                    ?.let(::chapterNumber) ?: "?",
                title = chapter.text("title", "name", "chapterTitle"),
                language = chapter.text("language", "lang", "translatedLanguage") ?: "en",
                pageCount = chapter.intValue("pages", "pageCount", "page_count") ?: 0,
                publishedAt = parseEpoch(chapter.text("date", "createdAt", "updatedAt", "publishAt")),
                url = chapterUrl,
                externalUrl = chapter.text("externalUrl", "external_url")?.let(::resolveUrl),
            )
        }.orEmpty().distinctBy { it.id }
            .sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }

        return ContentDetails(
            summary = summary,
            authors = item["authors"].stringList().ifEmpty { listOfNotNull(item.text("author", "writer")) },
            artists = item["artists"].stringList().ifEmpty { listOfNotNull(item.text("artist", "illustrator")) },
            chapters = chapters,
        )
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> =
        details(contentId).chapters.filter { language.isNullOrBlank() || it.language.equals(language, true) }

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val raw = if (chapterId.startsWith("http://") || chapterId.startsWith("https://")) {
            http.get(chapterId, headers + ("Accept" to "application/json,text/html,*/*"))
        } else {
            val key = encodeQuery(chapterId)
            getFirst(
                listOf(
                    "$base/chapter/$key",
                    "$base/manga/chapter/$key",
                    "$base/read/$key",
                ),
            )
        }

        val root = runCatching { Json.parseToJsonElement(raw) }.getOrNull()
        if (root != null) {
            val holder = root.findObject("chapter", "reader", "data", "result") ?: root as? JsonObject
            val pagesElement = holder?.get("pages") ?: holder?.get("images") ?: holder?.get("imageUrls")
            val pages = collectPageUrls(pagesElement)
            if (pages.isNotEmpty()) return ChapterContent.Images(pages.mapIndexed { index, url -> Page(index, resolveUrl(url)) })
        }

        val doc = Jsoup.parse(raw, base)
        val imageUrls = doc.select(
            ".reader img, .reader-area img, .reading-content img, .chapter-content img, #readerarea img, img[data-src], img[data-original]",
        ).mapNotNull { image ->
            sequenceOf("data-src", "data-original", "data-lazy-src", "src")
                .map { image.attr(it) }
                .firstOrNull { it.startsWith("http") }
        }.distinct()
        if (imageUrls.isEmpty()) error("Anikuro: halaman bab tidak ditemukan. Periksa skema pages pada respons API.")
        return ChapterContent.Images(imageUrls.mapIndexed { index, url -> Page(index, url) })
    }

    private suspend fun getFirstCatalog(urls: List<String>): String {
        var emptyJson: String? = null
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                val body = http.get(url, headers)
                val parsed = runCatching { parseList(body) }.getOrNull()
                if (!parsed.isNullOrEmpty()) return body
                if (parsed != null && emptyJson == null) emptyJson = body
                else if (parsed == null) lastError = IllegalStateException("Respons bukan katalog JSON: $url")
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        return emptyJson ?: throw IllegalStateException(
            "Anikuro tidak menemukan endpoint katalog JSON yang cocok. ${lastError?.message.orEmpty()}",
            lastError,
        )
    }

    private suspend fun getFirstJson(urls: List<String>): String {
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                val body = http.get(url, headers)
                Json.parseToJsonElement(body)
                return body
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        throw IllegalStateException("Anikuro tidak mengembalikan JSON detail yang valid. ${lastError?.message.orEmpty()}", lastError)
    }

    private suspend fun getFirst(urls: List<String>): String {
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                return http.get(url, headers)
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        throw IllegalStateException(
            "Anikuro API gagal pada endpoint /manga atau turunannya. ${lastError?.message.orEmpty()}",
            lastError,
        )
    }

    private fun parseList(raw: String): List<ContentSummary> {
        val root = runCatching { Json.parseToJsonElement(raw) }.getOrElse {
            error("Anikuro: endpoint katalog tidak mengembalikan JSON valid.")
        }
        return root.asContentArray().mapNotNull { item -> runCatching { mapSummary(item) }.getOrNull() }
            .distinctBy { it.id }
    }

    private fun mapSummary(item: JsonObject, fallbackId: String? = null): ContentSummary {
        val title = item.text("title", "name", "mangaName", "manga_name", "seriesName")
            ?.stripMarkdown()?.takeIf(String::isNotBlank) ?: fallbackId ?: error("Anikuro: judul kosong.")
        val rawId = item.text("id", "slug", "mangaId", "manga_id", "url", "link") ?: fallbackId
            ?: error("Anikuro: id judul tidak tersedia.")
        val normalizedId = normalizeId(rawId)
        val typeText = item.text("type", "mangaType", "manga_type", "category", "originalLanguage", "language")
        val type = mediaTypeFrom(typeText)
        val tags = item["genres"].stringList().ifEmpty { item["tags"].stringList() }
        val cover = item.imageText("image", "cover", "coverUrl", "cover_url", "thumbnail", "poster", "thumb")
        val lang = item.text("language", "lang", "originalLanguage", "original_language") ?: "en"
        return ContentSummary(
            id = normalizedId,
            sourceId = id,
            title = title,
            altTitles = item["altTitles"].stringList().ifEmpty { item["alternativeTitles"].stringList() },
            description = item.text("description", "synopsis", "summary", "plot").orEmpty().stripMarkdown(),
            coverUrl = cover?.let(::resolveUrl),
            mediaType = type,
            category = when (type) {
                MediaType.MANHWA -> MediaCategory.MANHWA_KR
                MediaType.MANHUA -> MediaCategory.MANHUA_CN
                MediaType.COMIC -> MediaCategory.COMIC
                else -> null
            },
            status = item.toStatus(),
            year = item.intValue("year", "releaseYear", "release_year"),
            tags = tags,
            originalLanguage = lang,
            readingMode = readingModeFrom(type, tags, item.text("readingMode", "reading_mode")),
        )
    }

    private fun JsonObject.imageText(vararg names: String): String? {
        names.forEach { key ->
            val value = this[key]
            value.asTextOrNull()?.let { return it }
            value.asObjectOrNull()?.text("url", "src", "image", "original")?.let { return it }
        }
        return null
    }

    private fun collectPageUrls(value: JsonElement?): List<String> {
        val candidates = when (value) {
            is JsonArray -> value.toList()
            is JsonObject -> value.entries.sortedWith(
                compareBy<Map.Entry<String, JsonElement>>({ it.key.toIntOrNull() ?: Int.MAX_VALUE }, { it.key }),
            ).map { it.value }
            null -> emptyList()
            else -> listOf(value)
        }
        return candidates.mapNotNull { page ->
            page.asTextOrNull() ?: page.asObjectOrNull()?.text("url", "src", "image", "file", "path")
        }.filter(String::isNotBlank).distinct()
    }

    private fun resolveUrl(value: String): String = when {
        value.startsWith("https://") || value.startsWith("http://") -> value
        value.startsWith("//") -> "https:$value"
        else -> "$base/${value.trimStart('/')}"
    }

    private fun normalizeId(value: String): String = if (value.startsWith("http://") || value.startsWith("https://")) {
        value.trimEnd('/').substringAfterLast('/')
    } else value.trim().trim('/')

    private fun chapterNumber(value: String): String =
        Regex("(?i)(?:chapter|chap|ch|bab)\\s*([0-9]+(?:\\.[0-9]+)?)").find(value)?.groupValues?.get(1)
            ?: value.filter { it.isDigit() || it == '.' }.ifBlank { value }
}
