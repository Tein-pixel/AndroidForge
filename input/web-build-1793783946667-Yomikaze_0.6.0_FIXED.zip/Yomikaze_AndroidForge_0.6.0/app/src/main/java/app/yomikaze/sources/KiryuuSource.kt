package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class KiryuuSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "kiryuu"
    override val name = "Kiryuu"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA)

    private val base = "https://kiryuu02.com"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/?s=${URLEncoder.encode(query, "UTF-8")}")
        return doc.select("div.bs, div.listupd > div")
            .mapNotNull { parseCard(it) }.take(limit)
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/manga/?page=$page&order=popular")
        return doc.select("div.bs, div.listupd > div")
            .mapNotNull { parseCard(it) }.take(limit)
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/manga/?page=$page&order=update")
        return doc.select("div.bs, div.listupd > div")
            .mapNotNull { parseCard(it) }.take(limit)
    }

    override suspend fun details(contentId: String): ContentDetails {
        val slug = contentId.substringAfter("/manga/").trimEnd('/')
        val doc = parse("$base/manga/$slug/")
        val title = doc.selectFirst("h1.entry-title")?.text()?.trim().orEmpty()
        val cover = doc.selectFirst("div.thumb img")?.absUrl("src")
        val description = doc.selectFirst("div.entry-content")?.text()?.trim().orEmpty()
        val chapters = doc.select("div.eplister li a").mapNotNull { a ->
            val href = a.absUrl("href")
            Chapter(
                id = href,
                contentId = slug,
                sourceId = id,
                number = Regex("Chapter\\s*([\\d.]+)").find(a.text())?.groupValues?.get(1) ?: "?",
                title = a.text().trim(),
                url = href,
            )
        }.reversed()
        return ContentDetails(
            ContentSummary(
                id = slug,
                sourceId = id,
                title = title.ifBlank { slug },
                coverUrl = cover,
                description = description,
                mediaType = MediaType.MANGA,
            ),
            chapters = chapters,
        )
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> =
        details(contentId).chapters

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val doc = parse(chapterId)
        val pages = doc.select("div#readerarea img").mapNotNull { it.absUrl("src").takeIf { u -> u.startsWith("http") } }
        return ChapterContent.Images(pages.mapIndexed { i, url -> Page(i, url) })
    }

    private suspend fun parse(url: String): Document = withContext(Dispatchers.IO) {
        val html = http.get(
            url,
            mapOf(
                "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Referer" to "https://kiryuu02.com/",
            ),
        )
        Jsoup.parse(html, url)
    }

    private fun parseCard(item: Element): ContentSummary? {
        val a = item.selectFirst("a[href*=/manga/]") ?: return null
        val href = a.absUrl("href")
        val slug = href.substringAfter("/manga/").trimEnd('/')
        if (slug.isBlank()) return null
        return ContentSummary(
            id = slug,
            sourceId = id,
            title = item.selectFirst("h4, .tt")?.text()?.trim() ?: a.text().trim(),
            coverUrl = item.selectFirst("img")?.absUrl("src"),
            mediaType = MediaType.MANGA,
        )
    }
}
