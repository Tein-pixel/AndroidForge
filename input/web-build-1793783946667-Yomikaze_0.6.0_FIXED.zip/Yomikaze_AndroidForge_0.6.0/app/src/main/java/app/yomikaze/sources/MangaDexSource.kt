package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MangaDexSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "mangadex"
    override val name = "MangaDex"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA, MediaType.COMIC)

    private val base = "https://api.mangadex.org"
    private val uploads = "https://uploads.mangadex.org"

    private val allowedRatings = "&contentRating[]=safe"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val offset = (page - 1).coerceAtLeast(0) * limit
        val url = "$base/manga?title=${encode(query)}" +
            "&limit=${limit.coerceIn(1, 100)}&offset=$offset" +
            "&includes[]=cover_art&order[relevance]=desc" +
            allowedRatings + "&availableTranslatedLanguage[]=id&hasAvailableChapters=true"
        val indonesian = parseMangaList(http.get(url))
        if (indonesian.isNotEmpty()) return indonesian
        val fallback = url.replace("&availableTranslatedLanguage[]=id", "")
        return parseMangaList(http.get(fallback))
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val offset = (page - 1).coerceAtLeast(0) * limit
        val url = buildString {
            append("$base/manga?limit=${limit.coerceIn(1, 100)}&offset=$offset")
            append("&includes[]=cover_art&order[followedCount]=desc")
            append(allowedRatings)
            append("&availableTranslatedLanguage[]=id")
            append("&hasAvailableChapters=true")
            when (category) {
                MediaCategory.MANGA_JP -> append("&originalLanguage[]=ja")
                MediaCategory.MANHWA_KR, MediaCategory.WEBTOON -> append("&originalLanguage[]=ko")
                MediaCategory.MANHUA_CN -> append("&originalLanguage[]=zh")
                MediaCategory.OEL, MediaCategory.COMIC -> append("&originalLanguage[]=en")
                else -> Unit
            }
        }
        val indonesian = parseMangaList(http.get(url))
        if (indonesian.isNotEmpty()) return indonesian
        return parseMangaList(http.get(url.replace("&availableTranslatedLanguage[]=id", "")))
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val offset = (page - 1).coerceAtLeast(0) * limit
        val url = "$base/manga?limit=${limit.coerceIn(1, 100)}&offset=$offset" +
            "&includes[]=cover_art&order[latestUploadedChapter]=desc" +
            allowedRatings + "&availableTranslatedLanguage[]=id&hasAvailableChapters=true"
        val indonesian = parseMangaList(http.get(url))
        if (indonesian.isNotEmpty()) return indonesian
        return parseMangaList(http.get(url.replace("&availableTranslatedLanguage[]=id", "")))
    }

    override suspend fun details(contentId: String): ContentDetails {
        val url = "$base/manga/$contentId?includes[]=cover_art&includes[]=author&includes[]=artist"
        val data = Json.parseToJsonElement(http.get(url)).jsonObject["data"]?.jsonObject
            ?: error("MangaDex returned no data for $contentId")
        val summary = toSummary(data)
        val relationships = data["relationships"]?.jsonArray.orEmpty()
        val authors = relationships
            .filter { it.jsonObject["type"]?.jsonPrimitive?.contentOrNull == "author" }
            .mapNotNull { it.jsonObject["attributes"]?.jsonObject?.get("name")?.jsonPrimitive?.contentOrNull }
        val artists = relationships
            .filter { it.jsonObject["type"]?.jsonPrimitive?.contentOrNull == "artist" }
            .mapNotNull { it.jsonObject["attributes"]?.jsonObject?.get("name")?.jsonPrimitive?.contentOrNull }
        val translated = chapters(contentId, "id").ifEmpty { chapters(contentId, "en") }
        return ContentDetails(summary, authors, artists, translated)
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> {
        val lang = language ?: "id"
        val all = mutableListOf<Chapter>()
        var offset = 0
        val limit = 500
        while (true) {
            val url = "$base/manga/$contentId/feed?translatedLanguage[]=$lang" +
                "&limit=$limit&offset=$offset" +
                "&order[volume]=asc&order[chapter]=asc&includes[]=scanlation_group"
            val root = Json.parseToJsonElement(http.get(url)).jsonObject
            val data = root["data"]?.jsonArray ?: break
            if (data.isEmpty()) break
            data.forEach { element ->
                val c = element.jsonObject
                val attrs = c["attributes"]?.jsonObject ?: return@forEach
                val raw = attrs["chapter"]?.jsonPrimitive?.contentOrNull
                val number = if (raw.isNullOrBlank()) "1" else raw
                all += Chapter(
                    id = c["id"]?.jsonPrimitive?.contentOrNull ?: return@forEach,
                    contentId = contentId,
                    sourceId = id,
                    number = number,
                    volume = attrs["volume"]?.jsonPrimitive?.contentOrNull,
                    title = attrs["title"]?.jsonPrimitive?.contentOrNull,
                    language = attrs["translatedLanguage"]?.jsonPrimitive?.contentOrNull ?: lang,
                    pageCount = attrs["pages"]?.jsonPrimitive?.intOrNull ?: 0,
                    publishedAt = parseIso(attrs["publishAt"]?.jsonPrimitive?.contentOrNull),
                    externalUrl = attrs["externalUrl"]?.jsonPrimitive?.contentOrNull,
                    scanlationGroups = c["relationships"]?.jsonArray.orEmpty()
                        .filter { it.jsonObject["type"]?.jsonPrimitive?.contentOrNull == "scanlation_group" }
                        .mapNotNull { it.jsonObject["attributes"]?.jsonObject?.get("name")?.jsonPrimitive?.contentOrNull },
                )
            }
            offset += limit
            val total = root["total"]?.jsonPrimitive?.intOrNull ?: all.size
            if (offset >= total) break
        }
        return all.sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }
    }

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val root = Json.parseToJsonElement(http.get("$base/at-home/server/$chapterId")).jsonObject
        val baseUrl = root["baseUrl"]?.jsonPrimitive?.contentOrNull
            ?: error("MangaDex at-home response missing baseUrl")
        val chapter = root["chapter"]?.jsonObject ?: error("MangaDex at-home response missing chapter")
        val hash = chapter["hash"]?.jsonPrimitive?.contentOrNull
            ?: error("MangaDex at-home response missing hash")

        val dataSaver = chapter["dataSaver"]?.jsonArray.orEmpty().mapNotNull { it.jsonPrimitive.contentOrNull }
        val data = chapter["data"]?.jsonArray.orEmpty().mapNotNull { it.jsonPrimitive.contentOrNull }
        val useSaver = dataSaver.isNotEmpty()
        val files = if (useSaver) dataSaver else data
        val quality = if (useSaver) "data-saver" else "data"

        if (files.isEmpty()) error("Bab ini belum memiliki halaman yang dapat dibaca.")
        val pages = files.mapIndexed { index, filename ->
            Page(index = index, url = "$baseUrl/$quality/$hash/$filename")
        }
        return ChapterContent.Images(pages)
    }

    private fun parseMangaList(json: String): List<ContentSummary> {
        val root = Json.parseToJsonElement(json).jsonObject
        return root["data"]?.jsonArray.orEmpty().mapNotNull { element ->
            runCatching { toSummary(element.jsonObject) }.getOrNull()
        }
    }

    private fun toSummary(data: JsonObject): ContentSummary {
        val mangaId = data["id"]?.jsonPrimitive?.contentOrNull ?: error("missing manga id")
        val attrs = data["attributes"]?.jsonObject ?: error("missing attributes")
        val titleMap = attrs["title"]?.jsonObject
        val altMaps = attrs["altTitles"]?.jsonArray.orEmpty()
        val title = localized(titleMap) ?: altMaps.firstNotNullOfOrNull { localized(it.jsonObject) } ?: "Untitled"
        val description = localized(attrs["description"]?.jsonObject).orEmpty().stripMarkdown()
        val originalLanguage = attrs["originalLanguage"]?.jsonPrimitive?.contentOrNull ?: "ja"
        val mediaType = when (originalLanguage) {
            "ko" -> MediaType.MANHWA
            "zh" -> MediaType.MANHUA
            "en" -> MediaType.COMIC
            else -> MediaType.MANGA
        }
        val category = when (originalLanguage) {
            "ja" -> MediaCategory.MANGA_JP
            "ko" -> MediaCategory.MANHWA_KR
            "zh" -> MediaCategory.MANHUA_CN
            "en" -> MediaCategory.OEL
            else -> null
        }
        val status = when (attrs["status"]?.jsonPrimitive?.contentOrNull) {
            "ongoing" -> PublicationStatus.ONGOING
            "completed" -> PublicationStatus.COMPLETED
            "hiatus" -> PublicationStatus.HIATUS
            "cancelled" -> PublicationStatus.CANCELLED
            else -> PublicationStatus.UNKNOWN
        }
        val tags = attrs["tags"]?.jsonArray.orEmpty().mapNotNull { tag ->
            localized(tag.jsonObject["attributes"]?.jsonObject?.get("name")?.jsonObject)
        }
        return ContentSummary(
            id = mangaId,
            sourceId = id,
            title = title,
            altTitles = altMaps.mapNotNull { localized(it.jsonObject) },
            description = description,
            coverUrl = coverUrl(mangaId, data["relationships"]?.jsonArray ?: JsonArray(emptyList())),
            mediaType = mediaType,
            category = category,
            status = status,
            year = attrs["year"]?.jsonPrimitive?.intOrNull,
            tags = tags,
            originalLanguage = originalLanguage,
            readingMode = if (mediaType == MediaType.MANHWA) ReadingMode.WEBTOON else ReadingMode.PAGED,
            contentRating = ContentRating.SAFE,
        )
    }

    private fun localized(map: JsonObject?): String? {
        if (map == null) return null
        listOf("id", "en", "ja-ro", "ko-ro", "zh-ro", "ja", "ko", "zh").forEach { key ->
            map[key]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }?.let { return it }
        }
        return map.values.firstOrNull { it is JsonPrimitive && it.isString }?.jsonPrimitive?.contentOrNull
    }

    private fun coverUrl(mangaId: String, relationships: JsonArray): String? {
        val cover = relationships.firstOrNull {
            it.jsonObject["type"]?.jsonPrimitive?.contentOrNull == "cover_art"
        }?.jsonObject ?: return null
        val fileName = cover["attributes"]?.jsonObject?.get("fileName")?.jsonPrimitive?.contentOrNull
            ?: return null
        return "$uploads/covers/$mangaId/$fileName.512.jpg"
    }

    private fun parseIso(value: String?): Long {
        if (value == null) return 0L
        return runCatching { java.time.Instant.parse(value).toEpochMilli() }.getOrDefault(0L)
    }

    private fun encode(value: String): String =
        java.net.URLEncoder.encode(value, "UTF-8")
}
