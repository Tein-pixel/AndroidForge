package app.yomikaze.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.serialization.json.JsonPrimitive
import java.util.concurrent.TimeUnit

class RateLimiter(private val permitsPerSecond: Double) {
    private val mutex = Mutex()
    private var nextFreeNanos = System.nanoTime()

    suspend fun acquire() {
        mutex.withLock {
            val interval = (1_000_000_000.0 / permitsPerSecond).toLong().coerceAtLeast(1L)
            val now = System.nanoTime()
            val wait = nextFreeNanos - now
            if (wait > 0L) delay(wait / 1_000_000L)
            nextFreeNanos = maxOf(nextFreeNanos, System.nanoTime()) + interval
        }
    }
}

class HttpClient(
    private val client: OkHttpClient,
    private val rateLimiter: RateLimiter,
) {
    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        rateLimiter.acquire()
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json")
            .apply { headers.forEach { (k, v) -> header(k, v) } }
            .build()
        return withContext(Dispatchers.IO) {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw HttpException(response.code, url, response.body?.string().orEmpty().take(300))
                }
                response.body?.string().orEmpty()
            }
        }
    }

    suspend fun postGraphQL(url: String, query: String, headers: Map<String, String> = emptyMap()): String {
        rateLimiter.acquire()
        val jsonBody = "{\"query\":${JsonPrimitive(query)}}"
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json")
            .header("Content-Type", "application/json; charset=utf-8")
            .apply { headers.forEach { (key, value) -> header(key, value) } }
            .post(jsonBody)
            .build()
        return withContext(Dispatchers.IO) {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw HttpException(response.code, url, body.take(300))
                }
                body
            }
        }
    }

    suspend fun getResponse(url: String, headers: Map<String, String> = emptyMap()): Response {
        rateLimiter.acquire()
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .apply { headers.forEach { (k, v) -> header(k, v) } }
            .build()
        return withContext(Dispatchers.IO) { client.newCall(request).execute() }
    }

    companion object {
        const val USER_AGENT = "Yomikaze/0.4.0 (Android)"
    }
}

class HttpException(
    val statusCode: Int,
    val url: String,
    val snippet: String,
) : RuntimeException("HTTP $statusCode for $url :: $snippet")

fun defaultOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(25, TimeUnit.SECONDS)
    .writeTimeout(25, TimeUnit.SECONDS)
    .retryOnConnectionFailure(true)
    .followRedirects(true)
    .build()
