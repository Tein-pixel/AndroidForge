package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ManytoonSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "manytoon"
    override val name = "Manytoon"
    override val mediaTypes = setOf(MediaType.MANHWA, MediaType.MANGA)
    override val isRestricted = true

    private val apiBase = "https://manytoon-scrapper.vercel.app"
    private val webBase = "https://manytoon.com"

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> = fetchList(page)
    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> = fetchList(page)

    private suspend fun fetchList(page: Int): List<ContentSummary> {
        val json = http.get("$apiBase/api/latest?page=$page")
        val root = Json.parseToJsonElement(json).jsonObject
        val results = root["results"]?.jsonArray ?: return emptyList()
        
        return results.mapNotNull { item ->
            val obj = item.jsonObject
            val url = obj["url"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
            val contentId = url.substringAfter("/comic/").trimEnd('/')
            ContentSummary(
                id = contentId,
                sourceId = id,
                title = obj["title"]?.jsonPrimitive?.contentOrNull ?: "Untitled",
                coverUrl = obj["cover_image"]?.jsonPrimitive?.contentOrNull,
                mediaType = MediaType.MANHWA,
                contentRating = ContentRating.RESTRICTED
            )
        }
    }

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        // API gak ada endpoint search, jadi tarik latest terus filter lokal
        return fetchList(page).filter { it.title.contains(query, ignoreCase = true) }
    }

    override suspend fun details(contentId: String): ContentDetails {
        val json = http.get("$apiBase/api/$contentId/details")
        val root = Json.parseToJsonElement(json).jsonObject
        val title = root["title"]?.jsonPrimitive?.contentOrNull ?: contentId
        val cover = root["cover_image"]?.jsonPrimitive?.contentOrNull
        val desc = root["description"]?.jsonPrimitive?.contentOrNull.orEmpty()

        // Scrape chapter pake Jsoup
        val html = http.get("$webBase/comic/$contentId/")
        val doc = Jsoup.parse(html)
        val chapters = doc.select("li.wp-manga-chapter a").mapNotNull { a ->
            val href = a.absUrl("href")
            val num = Regex("chapter-(\\d+(?:\\.\\d+)?)").find(href)?.groupValues?.get(1) ?: "?"
            Chapter(
                id = "$contentId|$num",
                contentId = contentId,
                sourceId = id,
                number = num,
                title = "Chapter $num",
                url = href
            )
        }.reversed()

        return ContentDetails(
            summary = ContentSummary(
                id = contentId,
                sourceId = id,
                title = title,
                coverUrl = cover,
                description = desc,
                mediaType = MediaType.MANHWA,
                contentRating = ContentRating.RESTRICTED
            ),
            chapters = chapters
        )
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> = details(contentId).chapters

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val parts = chapterId.split("|")
        val contentId = parts[0]
        val chapterNum = parts[1]
        
        val json = http.get("$apiBase/api/images/$contentId/chapter-$chapterNum")
        val root = Json.parseToJsonElement(json).jsonObject
        val images = root["imageUrls"]?.jsonArray ?: error("No images found")
        
        val pages = images.mapIndexed { index, img ->
            Page(index, img.jsonPrimitive.contentOrNull ?: "")
        }
        return ChapterContent.Images(pages)
    }
}