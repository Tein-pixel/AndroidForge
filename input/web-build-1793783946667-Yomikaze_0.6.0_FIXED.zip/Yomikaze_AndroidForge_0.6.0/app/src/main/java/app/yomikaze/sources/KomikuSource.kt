package app.yomikaze.sources

import kotlinx.coroutines.CancellationException
import app.yomikaze.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URI
import javax.inject.Inject
import javax.inject.Singleton

/** HTML adapter for Komiku. Uses tolerant selectors because the theme may change over time. */
@Singleton
class KomikuSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "komiku"
    override val name = "Komiku"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA, MediaType.COMIC)

    private val base = "https://komiku.id"
    private val headers = mapOf(
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language" to "id-ID,id;q=0.9,en;q=0.7",
        "Referer" to "$base/",
    )

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val q = encodeQuery(query.trim())
        val p = page.coerceAtLeast(1)
        val doc = parseCatalog(
            listOf(
                "$base/?s=$q&paged=$p",
                "$base/?post_type=manga&s=$q&paged=$p",
                "$base/search/$q/page/$p/",
            ),
        )
        return extractCards(doc).take(limit.coerceIn(1, 100))
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val p = page.coerceAtLeast(1)
        val doc = parseCatalog(
            listOf(
                "$base/daftar-komik/?orderby=popular&paged=$p",
                "$base/daftar-komik/?order=popular&page=$p",
                "$base/?orderby=popular&paged=$p",
                "$base/",
            ),
        )
        return extractCards(doc).filterCategory(category).take(limit.coerceIn(1, 100))
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val p = page.coerceAtLeast(1)
        val doc = parseCatalog(
            listOf(
                "$base/daftar-komik/?orderby=update&paged=$p",
                "$base/daftar-komik/?sort=latest&page=$p",
                "$base/?orderby=update&paged=$p",
                "$base/",
            ),
        )
        return extractCards(doc).take(limit.coerceIn(1, 100))
    }

    override suspend fun details(contentId: String): ContentDetails {
        val doc = parseDetail(detailCandidates(contentId), contentId)
        val pageUrl = doc.location().ifBlank { contentUrl(contentId) }
        val title = doc.selectFirst("h1.entry-title, h1.judul, .entry-title, .entry-title-single, h1")
            ?.text()?.trim().orEmpty()
        val cover = firstImage(
            doc.selectFirst(".ims img, .thumb img, .series-thumb img, img#seriesimg, .summary_image img, .thumb a img, .entry-content img"),
        )
        val description = doc.selectFirst(
            "#Sinopsis, .sinopsis, .desc, .entry-content, .entry-content-single, .series-synopsis, .summary__content, .description",
        )?.text()?.trim().orEmpty()
        val tags = doc.select(
            "a[href*='/genre/'], a[href*='/manga-genre/'], .genre-info a, .manga-genre a, .seriestugenre a",
        ).map { it.text().trim() }.filter(String::isNotBlank).distinct()
        val author = doc.select("a[href*='/author/'], a[href*='/artist/']")
            .map { it.text().trim() }.filter(String::isNotBlank).distinct()
        val statusText = labeledValue(doc, "status", "status komik", "status manga")
        val status = when (statusText?.lowercase()) {
            "ongoing", "on-going", "berjalan", "aktif" -> PublicationStatus.ONGOING
            "completed", "complete", "tamat", "finished" -> PublicationStatus.COMPLETED
            "hiatus" -> PublicationStatus.HIATUS
            "cancelled", "canceled", "drop" -> PublicationStatus.CANCELLED
            else -> PublicationStatus.UNKNOWN
        }
        val mediaText = doc.selectFirst(".type, .manga-type, .seriestugenre")?.text().orEmpty()
        val type = mediaTypeFrom(mediaText)
        val summary = ContentSummary(
            id = normalizeId(contentId, pageUrl),
            sourceId = id,
            title = title.ifBlank { normalizeId(contentId, pageUrl).replace('-', ' ').replaceFirstChar { it.uppercase() } },
            description = description.stripMarkdown(),
            coverUrl = cover,
            mediaType = type,
            category = when (type) {
                MediaType.MANHWA -> MediaCategory.MANHWA_KR
                MediaType.MANHUA -> MediaCategory.MANHUA_CN
                MediaType.COMIC -> MediaCategory.COMIC
                else -> null
            },
            status = status,
            tags = tags,
            originalLanguage = "id",
            readingMode = readingModeFrom(type, tags + mediaText),
        )
        val chapters = extractChapters(doc, summary.id)
        return ContentDetails(summary, authors = author, chapters = chapters)
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> =
        details(contentId).chapters

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val url = if (chapterId.startsWith("http://") || chapterId.startsWith("https://")) {
            chapterId
        } else {
            absoluteUrl(base, chapterId)
        }
        val doc = parse(url)
        val images = doc.select(
            "#readerarea img, .reader-area img, .reader img, .reading-content img, .chapter-content img, " +
                ".reader-content img, .main-reading-area img, #Baca_Komik img, .komik-reader img, .page-break img",
        ).mapNotNull(::imageUrl).filter { it.startsWith("http") }.distinct()
        if (images.isEmpty()) {
            error("Komiku: gambar reader tidak ditemukan. Struktur halaman mungkin berubah.")
        }
        return ChapterContent.Images(images.mapIndexed { index, image -> Page(index, image) })
    }

    private suspend fun parseCatalog(urls: List<String>): Document {
        var emptyDocument: Document? = null
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                val document = parse(url)
                if (extractCards(document).isNotEmpty()) return document
                if (emptyDocument == null) emptyDocument = document
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        return emptyDocument ?: throw IllegalStateException(
            "Komiku tidak menemukan halaman katalog yang cocok. ${lastError?.message.orEmpty()}",
            lastError,
        )
    }

    private suspend fun parseDetail(urls: List<String>, contentId: String): Document {
        var firstDocument: Document? = null
        var lastError: Throwable? = null
        urls.distinct().forEach { url ->
            try {
                val document = parse(url)
                if (firstDocument == null) firstDocument = document
                val hasTitle = document.selectFirst("h1.entry-title, h1.judul, .entry-title, h1")
                    ?.text()?.isNotBlank() == true
                if (hasTitle || extractChapters(document, contentId).isNotEmpty()) return document
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        return firstDocument ?: throw IllegalStateException(
            "Komiku tidak menemukan halaman detail judul. ${lastError?.message.orEmpty()}",
            lastError,
        )
    }

    private suspend fun parse(url: String): Document = withContext(Dispatchers.IO) {
        val html = http.get(url, headers)
        Jsoup.parse(html, url)
    }

    private fun extractCards(doc: Document): List<ContentSummary> {
        val anchors = doc.select(
            "a[href*='/manga/'], a[href*='/komik/'], a[href*='/comic/'], .ls4 a, .bge a, .listupd a, .daftar-komik a",
        )
        return anchors.mapNotNull { anchor ->
            runCatching { anchorToSummary(anchor) }.getOrNull()
        }.distinctBy { it.id }
    }

    private fun anchorToSummary(anchor: Element): ContentSummary? {
        val href = anchor.absUrl("href").ifBlank { absoluteUrl(base, anchor.attr("href")) }
        if (!href.startsWith("http") || href.contains("/chapter/") || href.contains("/bab/")) return null
        val container = anchor.closest(".ls4, .bge, .bs, .item, article, li, .daftar-komik") ?: anchor.parent()
        val title = sequenceOf(
            anchor.selectFirst(".judul, .title, h3, h4, .tt" )?.text(),
            container?.selectFirst(".judul, .title, h3, h4, .tt")?.text(),
            anchor.attr("title"),
            anchor.text(),
        ).firstOrNull { !it.isNullOrBlank() }?.trim() ?: return null
        val cover = firstImage(container?.selectFirst("img"))
        val idValue = normalizeId(href, href)
        if (idValue.isBlank()) return null
        val tags = container?.select(".type, .genre, .status")?.eachText().orEmpty()
        val type = mediaTypeFrom(tags.joinToString(" "))
        return ContentSummary(
            id = idValue,
            sourceId = id,
            title = title.stripMarkdown(),
            coverUrl = cover,
            mediaType = type,
            category = when (type) {
                MediaType.MANHWA -> MediaCategory.MANHWA_KR
                MediaType.MANHUA -> MediaCategory.MANHUA_CN
                MediaType.COMIC -> MediaCategory.COMIC
                else -> null
            },
            tags = tags,
            originalLanguage = "id",
            readingMode = readingModeFrom(type, tags),
        )
    }

    private fun extractChapters(doc: Document, contentId: String): List<Chapter> {
        val anchors = doc.select(
            "#chapterlist a, .chapter-list a, .eplister a, .cl li a, .list-chapter a, " +
                "a[href*='/chapter/'], a[href*='/bab/'], a[href*='/chapter-'], a[href*='/ch-']",
        )
        return anchors.mapNotNull { anchor ->
            val href = anchor.absUrl("href").ifBlank { absoluteUrl(base, anchor.attr("href")) }
            if (!href.startsWith("http")) return@mapNotNull null
            val label = anchor.text().trim().ifBlank { anchor.attr("title").trim() }
            val number = Regex("(?i)(?:chapter|chap|ch|bab|episode|ep)[\\s_-]*([0-9]+(?:\\.[0-9]+)?)")
                .find(label.ifBlank { href })?.groupValues?.get(1)
                ?: Regex("([0-9]+(?:\\.[0-9]+)?)").find(label)?.groupValues?.get(1)
                ?: return@mapNotNull null
            Chapter(
                id = href,
                contentId = contentId,
                sourceId = id,
                number = number,
                title = label.takeIf(String::isNotBlank),
                language = "id",
                url = href,
            )
        }.distinctBy { it.id }.sortedBy { it.number.toDoubleOrNull() ?: Double.MAX_VALUE }
    }

    private fun imageUrl(image: Element): String? = sequenceOf(
        "data-src", "data-lazy-src", "data-original", "data-cfsrc", "src",
    ).map { image.attr(it).trim() }.firstOrNull { it.startsWith("http") }
        ?: image.attr("srcset").substringBefore(',').substringBefore(' ').takeIf { it.startsWith("http") }

    private fun firstImage(image: Element?): String? = image?.let(::imageUrl)

    private fun labeledValue(doc: Document, vararg labels: String): String? {
        doc.select(".info-item, .infox, .spe, .imptdt, table tr, .series-info li").forEach { row ->
            val text = row.text()
            if (labels.any { text.contains(it, ignoreCase = true) }) {
                val value = row.selectFirst("span, td:last-child, .right")?.text()?.trim()
                    ?: text.substringAfter(':', "").trim()
                if (value.isNotBlank()) return value
            }
        }
        return null
    }

    private fun detailCandidates(contentId: String): List<String> {
        if (contentId.startsWith("http://") || contentId.startsWith("https://")) return listOf(contentId)
        val slug = contentId.trim('/')
        return listOf(
            "$base/manga/$slug/",
            "$base/komik/$slug/",
            "$base/comic/$slug/",
            "$base/$slug/",
        )
    }

    private fun contentUrl(contentId: String): String =
        if (contentId.startsWith("http://") || contentId.startsWith("https://")) contentId
        else "$base/manga/${contentId.trim('/')}/"

    private fun normalizeId(value: String, fallbackUrl: String): String {
        val candidate = if (value.startsWith("http://") || value.startsWith("https://")) value else fallbackUrl
        return runCatching { URI(candidate).path.trim('/').substringAfterLast('/') }.getOrDefault(value.trim('/'))
    }

    private fun absoluteUrl(origin: String, value: String): String = when {
        value.startsWith("http://") || value.startsWith("https://") -> value
        value.startsWith("//") -> "https:$value"
        else -> runCatching { URI(origin).resolve(value).toString() }.getOrDefault(value)
    }
}
