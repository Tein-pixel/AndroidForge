package app.yomikaze.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.core.ContentSummary
import app.yomikaze.ui.BrowseViewModel
import app.yomikaze.ui.components.ContentCard
import app.yomikaze.ui.components.EmptyState
import app.yomikaze.ui.components.LoadingState
import coil3.compose.SubcomposeAsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    onOpen: (String, String) -> Unit,
    onSearch: () -> Unit,
    viewModel: BrowseViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val selectedGenre by viewModel.selectedGenre.collectAsStateWithLifecycle()
    val filteredItems = remember(state.items, selectedGenre) {
        if (selectedGenre == "Semua Genre") state.items
        else state.items.filter { item -> item.tags.any { it.contains(selectedGenre, ignoreCase = true) } }
    }
    val featured = filteredItems.firstOrNull()
    val popularItems = filteredItems.drop(1).ifEmpty { filteredItems }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text("YOMIKAZE", style = MaterialTheme.typography.titleLarge, letterSpacing = 1.3.sp)
                    Text("Temukan cerita berikutnya", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            actions = {
                IconButton(onClick = { viewModel.load(state.category) }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Muat ulang")
                }
                IconButton(onClick = onSearch) {
                    Icon(Icons.Default.Search, contentDescription = "Cari")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(viewModel.categories) { category ->
                FilterChip(
                    selected = state.category == category,
                    onClick = { viewModel.load(category) },
                    label = { Text(category.label) },
                )
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(viewModel.genres) { genre ->
                FilterChip(
                    selected = selectedGenre == genre,
                    onClick = { viewModel.setGenre(genre) },
                    label = { Text(genre) },
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        when {
            state.loading && state.items.isEmpty() && state.latestItems.isEmpty() -> LoadingState()
            state.items.isEmpty() && state.latestItems.isEmpty() -> {
                Column(Modifier.fillMaxSize()) {
                    EmptyState(state.error ?: "Katalog belum tersedia. Periksa koneksi, lalu muat ulang.")
                    OutlinedButton(
                        onClick = { viewModel.load(state.category) },
                        modifier = Modifier.align(androidx.compose.ui.Alignment.CenterHorizontally),
                    ) { Text("Coba lagi") }
                }
            }
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (featured != null) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            SectionTitle("Pilihan hari ini", "Unggulan")
                            FeaturedCard(featured) { onOpen(featured.sourceId, featured.id) }
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Lagi ramai dibaca", "Populer")
                        if (popularItems.isEmpty()) {
                            Text(
                                if (selectedGenre == "Semua Genre") "Belum ada judul untuk kategori ini."
                                else "Belum ada judul dengan genre $selectedGenre.",
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        } else {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                items(popularItems, key = { "${it.sourceId}:${it.id}" }) { item ->
                                    ContentCard(
                                        item = item,
                                        onClick = { onOpen(item.sourceId, item.id) },
                                        modifier = Modifier.width(142.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Bab dan judul yang baru masuk", "Update terbaru")
                        if (state.latestItems.isEmpty()) {
                            Text(
                                "Belum ada update terbaru dari sumber aktif.",
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        } else {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                items(state.latestItems, key = { "${it.sourceId}:${it.id}" }) { item ->
                                    ContentCard(
                                        item = item,
                                        onClick = { onOpen(item.sourceId, item.id) },
                                        modifier = Modifier.width(142.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun SectionTitle(subtitle: String, title: String) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun FeaturedCard(item: ContentSummary, onClick: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(206.dp)
            .clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick),
    ) {
        SubcomposeAsyncImage(
            model = item.coverUrl,
            contentDescription = item.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            loading = {
                Box(Modifier.fillMaxSize().background(Color(0xFF111A27)), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF9DBBFF), strokeWidth = 2.dp)
                }
            },
            error = {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(
                    listOf(Color(0xFF17263B), Color(0xFF090D14)))))
            },
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(Color(0xF507090D), Color(0xB807090D), Color(0x1707090D))),
            ),
        )
        Column(
            modifier = Modifier.align(Alignment.CenterStart).fillMaxWidth(0.78f).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(6.dp)) {
                Text("REKOMENDASI", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall)
            }
            Text(item.title, style = MaterialTheme.typography.headlineMedium, color = Color.White,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                "${item.mediaType.name.lowercase().replaceFirstChar { it.uppercase() }}  ·  ${item.status.name.lowercase().replaceFirstChar { it.uppercase() }}",
                style = MaterialTheme.typography.bodySmall, color = Color(0xFFD3D9E4), maxLines = 1,
            )
            Text("Lihat detail  →", style = MaterialTheme.typography.labelLarge, color = Color(0xFF9DBBFF))
        }
    }
}
