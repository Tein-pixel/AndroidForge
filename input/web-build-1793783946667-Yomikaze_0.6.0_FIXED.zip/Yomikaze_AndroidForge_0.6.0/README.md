# Yomikaze 0.6.0

Aplikasi Android Compose untuk membaca manga, manhwa, manhua, comic, dan novel. Antarmuka menggunakan tema AMOLED black dengan aksen biru/cyan, katalog multi-sumber, detail judul, koleksi, progres baca, dan reader horizontal/vertikal.

## Build APK

- JDK: 17
- Android Gradle Plugin: 8.7.2
- Gradle: 8.9
- Kotlin: 2.1.10
- compileSdk: 35 · minSdk: 24 · targetSdk: 35

Perintah build:

```bash
gradle --no-daemon :app:assembleDebug
```

APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

Di AndroidForge, buka repository pada root proyek lalu jalankan **Build Android APK**. Jika wrapper belum tersedia, gunakan mekanisme regenerasi wrapper dari AndroidForge; versi wrapper yang disiapkan adalah Gradle 8.9.

## Fitur

- Beranda gelap: kartu unggulan, jelajah kategori, filter genre, katalog populer, dan update terbaru.
- Pencarian multi-sumber dengan prioritas katalog Indonesia ketika sumber menandainya sebagai `id` atau berasal dari sumber Indonesia.
- Detail judul, sinopsis, genre, daftar chapter, lanjut baca, koleksi lokal, progres baca, dan unduhan chapter melalui WorkManager.
- Reader halaman horizontal untuk manga dan scroll vertikal untuk manhwa/webtoon; reader teks untuk novel.
- Tema AMOLED black dengan aksen biru elektrik dan cyan.

## Katalog dan adapter sumber

Registry memuat adapter berikut:

- **MangaDex** — REST API.
- **MangaHub** — GraphQL; parsing halaman mendukung array maupun object berindeks.
- **WeebCentral** — HTML parser berbasis Jsoup.
- **Kiryuu** — HTML parser berbasis Jsoup.
- **NovelFire** — HTML parser untuk novel dan reader teks.
- **Manytoon** — sumber khusus yang hanya aktif saat Mode Lanjutan diaktifkan.
- **Sanka API** — REST JSON; adapter mencoba `/search`, `/popular`, `/latest`, dan beberapa pola detail/chapter.
- **Anikuro** — REST JSON melalui endpoint `/manga`, dengan adapter pemetaan respons tersendiri.
- **Komiku** — HTML parser berbasis Jsoup dengan selector cadangan.

Catatan integrasi: endpoint Sanka/Anikuro dan selector Komiku ditulis toleran terhadap beberapa variasi respons karena kontrak JSON/HTML aktual tidak disertakan bersama source. Konektivitas dan struktur respons live tetap perlu diuji saat build/runtime; penyesuaian endpoint/selector dapat dilakukan pada file masing-masing di `app/src/main/java/app/yomikaze/sources/`.

## GitHub Actions

Workflow `Android APK` tersedia melalui tab **Actions** dan dapat dijalankan manual (`workflow_dispatch`). Hasil APK akan disimpan sebagai artifact `Yomikaze-debug-apk`.
