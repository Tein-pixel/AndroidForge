#!/usr/bin/env python3
"""Static pre-build checks for TeinTools Android 10. Does not replace Gradle/device tests."""
from pathlib import Path
from collections import Counter
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app/src/main"
MAIN = APP / "java/com/teinzz/teintools/MainActivity.java"
SERVICE = APP / "java/com/teinzz/teintools/CacheCleanerAccessibilityService.java"
GRADLE = ROOT / "app/build.gradle"
MANIFEST = APP / "AndroidManifest.xml"
WORKFLOW = ROOT / ".github/workflows/build.yml"
ACCESS_XML = APP / "res/xml/cache_cleaner_accessibility.xml"
ART = APP / "res/drawable-nodpi/hero_liquid.webp"
ICON_FOREGROUND = APP / "res/drawable-nodpi/launcher_foreground.png"
ERRORS = []
CHECKS = []


def check(name: str, condition: bool, detail: str = "") -> None:
    CHECKS.append(name)
    if condition:
        print(f"PASS: {name}")
    else:
        ERRORS.append(f"FAIL: {name}" + (f" — {detail}" if detail else ""))


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


check("required app, service, icon and CI files exist", all(p.is_file() for p in [MAIN, SERVICE, GRADLE, MANIFEST, WORKFLOW, ACCESS_XML, ART, ICON_FOREGROUND]))
g = read(GRADLE)
root_gradle = read(ROOT / "build.gradle")
check("Android 10 minimum SDK", bool(re.search(r"minSdk\s+29\b", g)))
check("Android 10 target SDK", bool(re.search(r"targetSdk\s+29\b", g)))
check("compile SDK 34", bool(re.search(r"compileSdk\s+34\b", g)))
check("AGP 8.7.3 pinned", "version '8.7.3'" in root_gradle)
check("TeinTools 1.3.1 version", "versionName '1.3.1'" in g and "versionCode 5" in g)
check("namespace and application ID align", "namespace 'com.teinzz.teintools'" in g and "applicationId 'com.teinzz.teintools'" in g)

manifest_text = read(MANIFEST)
main_text = read(MAIN)
service_text = read(SERVICE)
access_text = read(ACCESS_XML)
if MANIFEST.exists():
    try:
        mtree = ET.parse(MANIFEST)
        mroot = mtree.getroot()
        ans = "{http://schemas.android.com/apk/res/android}"
        tools = "{http://schemas.android.com/tools}"
        app = mroot.find("application")
        launcher = None
        for activity in app.findall("activity") if app is not None else []:
            acts = [n.get(ans + "name") for filt in activity.findall("intent-filter") for n in filt.findall("action")]
            cats = [n.get(ans + "name") for filt in activity.findall("intent-filter") for n in filt.findall("category")]
            if "android.intent.action.MAIN" in acts and "android.intent.category.LAUNCHER" in cats:
                launcher = activity
        check("manifest XML parses", True)
        check("launcher exported for Android 12+ validation", launcher is not None and launcher.get(ans + "exported") == "true")
        check("hardware acceleration enabled", app is not None and app.get(ans + "hardwareAccelerated") == "true")
        check("manifest declares accessibility cleaner service", app is not None and any(s.get(ans + "name") == ".CacheCleanerAccessibilityService" for s in app.findall("service")))
        check("AccessibilityService protected by BIND permission", "android.permission.BIND_ACCESSIBILITY_SERVICE" in manifest_text)
        check("ZXing manifest conflict override retained", 'tools:replace="android:screenOrientation,android:theme"' in manifest_text)
        check("legacy storage scope pinned to Android 10", 'android:requestLegacyExternalStorage="true"' in manifest_text and 'android:maxSdkVersion="29"' in manifest_text)
        check("no Android 11 MANAGE_EXTERNAL_STORAGE claim", "MANAGE_EXTERNAL_STORAGE" not in manifest_text)
    except ET.ParseError as exc:
        check("manifest XML parses", False, str(exc))

# Parse every XML resource including adaptive icons and accessibility metadata.
xml_files = list((APP / "res").rglob("*.xml"))
xml_errors = []
for path in xml_files:
    try:
        ET.parse(path)
    except ET.ParseError as exc:
        xml_errors.append(f"{path.relative_to(ROOT)}: {exc}")
check("all resource XML files parse", not xml_errors, "; ".join(xml_errors))
check("AccessibilityService XML requests visible labels only", "android:canRetrieveWindowContent=\"true\"" in access_text and "android:canPerformGestures=\"false\"" in access_text)
check("service not marked as disability accessibility tool", "isAccessibilityTool" not in access_text and "isAccessibilityTool" not in manifest_text)

if MAIN.exists():
    required = [
        "showSplashScreen()", "liquidBackground()", "buildRamBoosterPage", "buildCleanerPage",
        "buildStorageCleanerPage", "buildBatteryPage", "buildThermalPage", "buildAnimationTunerPage", "buildSensorPage",
        "buildPermissionsPage", "buildNetworkPage", "buildQrPage", "buildFlashPage",
        "buildNotesPage", "buildTimerPage", "scanCachedApps", "StorageStatsManager",
        "killBackgroundProcesses", "getRamWhitelist", "clearDirectoryContents(getCacheDir())",
    ]
    check("boost, maintenance and utility features are present", all(x in main_text for x in required), ", ".join(x for x in required if x not in main_text))
    routed_builders = set(re.findall(r'case\s+"[^"]+"\s*:\s*(build\w+)\(pageBody\)', main_text))
    declared_builders = set(re.findall(r'^\s*private\s+void\s+(build\w+)\s*\(\s*LinearLayout\s+\w+\s*\)', main_text, re.M))
    check("all page builders routed from renderPage are declared", routed_builders <= declared_builders, ", ".join(sorted(routed_builders - declared_builders)))
    check("permission center covers six feature-specific access items", all(x in main_text for x in ["Accessibility automation", "Usage Access", "Storage read/write", "Modify System Settings", "Do Not Disturb access", "Camera permission"]))
    check("cache scan uses measured StorageStatsManager data", "queryStatsForPackage" in main_text and "stats.getCacheBytes()" in main_text)
    collect_block = main_text.split("private List<CachedApp> collectCachedApps", 1)[-1].split("private boolean isProtectedSystemPackage", 1)[0]
    check("cache scan includes apps without launcher icons", "getLaunchIntentForPackage" not in collect_block)
    check("cache cleanup rescans and reports measured before/after cache", "verification_pending" in main_text and "estimated reduction" in main_text and "cache_before_bytes" in main_text)
    check("Animation Tuner only opens official Android settings", "Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS" in main_text and "WRITE_SECURE_SETTINGS" in main_text)
    check("RAM cleaner excludes whitelist and system apps", "keep.contains(packageName)" in main_text and "ApplicationInfo.FLAG_SYSTEM" in main_text and "killBackgroundProcesses(packageName)" in main_text)
    check("RAM boost reports measurement rather than guaranteed score", "available RAM rose by" in main_text and "guaranteed RAM gain" in main_text)
    check("one-tap cleaner requires usage + accessibility access", "hasUsageStatsAccess()" in main_text and "isCacheAccessibilityEnabled()" in main_text and "Start 1-Tap cache cleanup?" in main_text)
    check("user-confirmation shown before cache automation", "Start cleaning" in main_text and "new AlertDialog.Builder(this).setTitle(\"Start 1-Tap cache cleanup?\")" in main_text)
    check("accessibility disclosure explains visible Settings automation", "Disclosure: Cache Cleaner uses Accessibility" in main_text and "I understand · Open settings" in main_text)
    check("safe storage scan limits deletion to temp/thumbnail candidates", ".tmp" in main_text and ".temp" in main_text and ".part" in main_text and ".thumbnails" in main_text)
    check("feature icons and themes use black-blue-white liquid glass", "class LineIconView" in main_text and "Black + Blue" in main_text and "White + Blue" in main_text and "Color.rgb(91, 183, 255)" in main_text)
    check("no fake Android 11 global cache API", "ACTION_CLEAR_APP_CACHE" not in main_text)
    check("system Back preserves in-app page history", "private void navigateBack()" in main_text and "pageHistory.removeLast()" in main_text and "@Override public void onBackPressed()" in main_text)
    check("main tabs reset route history", "private void openRootPage(String page)" in main_text and "pageHistory.clear()" in main_text)
    check("home billboard uses fixed height without overlapping actions", "body.addView(hero, marginParams(-1, dp(138)" in main_text and "body.addView(heroActions" not in main_text)
    check("tool tiles are compact", "marginParams(-1, dp(126)" in main_text and "iconBadge(iconForTarget(tool.target), 32, 17)" in main_text)
    check("balanced Java braces in MainActivity", main_text.count("{") == main_text.count("}"), f"{main_text.count('{')} opening / {main_text.count('}')} closing")
    names = re.findall(r'^\s*(?:private|public|protected)\s+(?:static\s+)?[\w<>\[\], ?]+\s+(\w+)\s*\(', main_text, re.M)
    duplicates = {k: v for k, v in Counter(names).items() if v > 1 and k not in {"label", "join"}}
    check("no accidental duplicate MainActivity methods", not duplicates, str(duplicates))
    icon_switch = main_text.split("private String iconForTarget", 1)[-1].split("private FrameLayout iconBadge", 1)[0]
    icon_cases = re.findall(r'case\s+"([^"]+)"', icon_switch)
    icon_duplicates = {k: v for k, v in Counter(icon_cases).items() if v > 1}
    check("no duplicate target-icon switch cases", not icon_duplicates, str(icon_duplicates))

if SERVICE.exists():
    check("service allows only system settings/OEM settings packages", all(x in service_text for x in ["com.android.settings", "com.coloros.settings", "com.oplus.settings"]))
    check("cache buttons are exact labels only", all(f'"{x}"' in service_text for x in ["clear cache", "hapus cache", "bersihkan cache"]))
    # The service may mention Clear data in its safety comments/disclosure, but it must never match it as a clickable label.
    labels_match = re.search(r"CLEAR_CACHE_LABELS\s*=\s*Arrays\.asList\((.*?)\);", service_text, re.S)
    check("no Clear data label in automation match set", labels_match is not None and not re.search(r"clear data|hapus data|clear storage|hapus penyimpanan", labels_match.group(1), re.I))
    check("service has timeout and stop-aware queue", "STEP_TIMEOUT_MS" in service_text and 'getBoolean("active", false)' in service_text and "finishRun()" in service_text)
    check("cache run uses a live in-app progress overlay", "TYPE_ACCESSIBILITY_OVERLAY" in service_text and "Membersihkan cache" in service_text and "stopAutomationAndReturn()" in service_text)
    check("progress overlay has explicit stop and no input focus", "HENTIKAN" in service_text and "FLAG_NOT_FOCUSABLE" in service_text and "Stopped by user" in service_text)
    check("overlay discloses cache-only behavior", "Hapus data tidak disentuh" in service_text and "Clear data" not in re.search(r"CLEAR_CACHE_LABELS\s*=\s*Arrays\.asList\((.*?)\);", service_text, re.S).group(1))
    check("service balanced Java braces", service_text.count("{") == service_text.count("}"), f"{service_text.count('{')} opening / {service_text.count('}')} closing")
    service_names = re.findall(r'^\s*(?:private|public|protected)\s+(?:static\s+)?[\w<>\[\], ?]+\s+(\w+)\s*\(', service_text, re.M)
    service_duplicates = {k: v for k, v in Counter(service_names).items() if v > 1}
    check("no accidental duplicate service methods", not service_duplicates, str(service_duplicates))

if WORKFLOW.exists():
    w = read(WORKFLOW)
    check("CI pins JDK 17 and Gradle 8.9", "java-version: '17'" in w and "gradle-version: '8.9'" in w)
    check("CI runs source checks before build", "python3 scripts/verify_project.py" in w and w.index("python3 scripts/verify_project.py") < w.index("assembleDebug"))
    check("CI verifies and uploads APK", "test -s app/build/outputs/apk/debug/app-debug.apk" in w and "actions/upload-artifact@v4" in w)

try:
    import struct
    with ICON_FOREGROUND.open("rb") as f:
        head = f.read(26)
    png_valid = head[:8] == b"\x89PNG\r\n\x1a\n" and struct.unpack(">II", head[16:24])[0] >= 256 and struct.unpack(">II", head[16:24])[1] >= 256
    check("premium launcher foreground is a valid high-resolution PNG", png_valid)
    icon_vector = read(APP / "res/drawable/ic_launcher.xml")
    check("launcher icon uses black-blue-white palette", "#70BEFF" in icon_vector and "#FFFFFF" in icon_vector and "#040811" in icon_vector)
except Exception as exc:
    check("premium launcher foreground is a valid high-resolution PNG", False, str(exc))
check("hero artwork bundled for the billboard only", ART.exists() and 5000 < ART.stat().st_size < 500000)
feature_text = "\n".join([main_text, service_text]).lower()
check("no gaming / Game Space feature entries in TeinTools", not re.search(r"game\s?space|game booster|gaming|game mode", feature_text))

if ERRORS:
    print("\n".join(ERRORS), file=sys.stderr)
    print(f"\n{len(ERRORS)} failure(s), {len(CHECKS)} checks.", file=sys.stderr)
    sys.exit(1)
print(f"\nAll {len(CHECKS)} project contract checks passed. This is static validation, not a Gradle/device test.")
