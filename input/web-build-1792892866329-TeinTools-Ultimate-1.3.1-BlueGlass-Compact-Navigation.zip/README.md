# TeinTools Ultimate 1.3.1 — Android 10 maintenance toolbox

TeinTools is a native Java toolbox for Android 10 (API 29) focused on maintenance and diagnostics: RAM/process management, app-cache measurement, a user-started accessibility-assisted cache-clean pass, safe temporary-file cleanup, battery/thermal readings, networking tests, a permission center and everyday utilities. It does **not** contain Game Space or gaming features.

## Maintenance features

- **RAM Booster:** reads Android's actual available memory, shows a user-configurable whitelist and asks Android to stop eligible launchable non-system apps reported as background. The app reports the before/after available-RAM delta. Android can restart background processes, so memory gain is not guaranteed.
- **1-Tap App Cache Cleaner:** reads per-app cache sizes using `StorageStatsManager` after the user grants Usage Access. After a clear disclosure and explicit confirmation, an optional `AccessibilityService` navigates visible Settings pages and clicks only an exact `Clear cache` / `Hapus cache` label. It never clicks `Clear data`, `Hapus data` or `Clear storage`. It only runs after the user starts it and can be stopped from the app. Results are reported as attempted/unsupported actions, and a new Usage Access scan is recommended to confirm the actual sizes.
- **Important OEM limitation:** Android/ColorOS settings layouts and labels vary by OS version and vendor. The service supports a small allowlist of Settings package names and may skip unsupported apps; it cannot promise every app's cache is cleared on every firmware. It is a visible UI automation, not a privileged system cache API.
- **Accessibility and distribution:** the service is not marked as a disability accessibility tool. It requests access only for a user-started deterministic task and displays disclosure before opening Accessibility settings. Distribution through Google Play would require review against the current Accessibility API policy and the relevant declaration/consent requirements; sideloading does not remove the user's need to understand the access.
- **Junk Cleaner:** scans only old `.tmp`, `.temp`, `.part` files in Downloads and old `.thumbnails` content in selected public folders. The user chooses candidates and confirms deletion. It does not delete photos, documents, APKs, app databases or arbitrary files.
- **Battery & Focus:** reports battery level/temperature, optionally toggles DND after notification-policy access and explicit confirmation, and offers a reversible low-brightness/short-timeout display profile after Modify System Settings access.
- **Thermal Monitor:** shows thermal status only when Android/vendor exposes it. It does not physically cool the device.
- **Permission Center:** explains six feature-related accesses: Accessibility automation, Usage Access, legacy shared-storage access on Android 10, Modify System Settings, DND policy access and Camera. They are contextual—not all are required for every feature.

## Android 10 limits

Android 10 does not expose Android 11's `MANAGE_EXTERNAL_STORAGE` switch, and normal apps cannot directly erase other apps' private cache directories using a public universal cache API. TeinTools uses measured cache stats plus a manually started Settings UI automation where supported. Apps that block accessibility-tree access, have different translations or use custom Settings screens can be skipped. Never use a Cleaner to tap `Clear data` or `Erase storage`—this removes app state and can log users out or erase offline content.

## Design

Black + Blue and White + Blue modes, blue-silver liquid-glass surfaces, a custom high-resolution blue-silver orb launcher icon, transparent artwork in selected hero/splash areas (not every tile), spaced feature groups, line icons, page-entry motion and loading feedback. The visual style uses Android 10-compatible gradient/highlight layers rather than depending on Android 12+ native window blur.

## Build setup

- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9 (pinned by `.github/workflows/build.yml`)
- compileSdk 34, minSdk 29, targetSdk 29
- Application ID: `com.teinzz.teintools`

The included GitHub Actions workflow runs the static source contract checker, builds `assembleDebug`, verifies the APK file exists, and uploads it as a 14-day artifact. Static checks are not a substitute for compiling, installing, and testing on the target OPPO/ColorOS Android 10 device. This ZIP has not been device-tested and does not claim a successful APK build until Actions completes successfully.

## Sources

- Android runtime permission guidance: https://developer.android.com/training/permissions/requesting
- Android 10 storage changes: https://developer.android.com/about/versions/10/privacy/changes
- StorageStatsManager: https://developer.android.com/reference/android/app/usage/StorageStatsManager
- AccessibilityService API: https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
- Google Play Accessibility API policy: https://support.google.com/googleplay/android-developer/answer/10964491
- ActivityManager background process termination: https://developer.android.com/reference/android/app/ActivityManager#killBackgroundProcesses(java.lang.String)


## v1.3.1 interface and navigation update
- Black/navy + blue + white color palette; White + Blue mode remains available.
- Compact cards, compact labels, and smaller icon badges.
- Home hero is a fixed-height billboard so the transparent artwork no longer overlaps quick actions.
- System Back uses an in-app navigation history; Back at Home backgrounds the task so the session can be resumed from Recents. Android Home and Recents remain operating-system actions and are not intercepted.
- Accessibility cache automation is deterministic and user-started. During the pass, a visible full-screen progress overlay covers the Settings workflow, shows app counts/status, and offers Stop. The disclosure states that Settings is being automated; no public Android 10 API clears every other app cache silently.
