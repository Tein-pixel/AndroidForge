package com.teinzz.teintools;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.ContentResolver;
import android.content.ComponentName;
import android.content.res.ColorStateList;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.UserHandle;
import android.os.storage.StorageManager;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "tein_tools_settings";
    private static final int REQ_CAMERA = 712;
    private static final int REQ_STORAGE = 713;
    private static final int REQ_OPEN_FILE = 4101;
    private static final int REQ_CREATE_FILE = 4102;
    private static final int REQ_OPEN_IMAGE = 4103;
    private static final int SPLASH_DURATION_MS = 1450;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private String currentPage = "home";
    private String themeMode = "dark";
    private String accentMode = "blue";
    private final ArrayDeque<String> pageHistory = new ArrayDeque<>();
    private boolean suppressHistoryRecording = false;
    private boolean torchOn = false;
    private boolean pendingTorchOn = false;
    private boolean pendingQrScan = false;
    private boolean pendingPermissionRefresh = false;
    private boolean pendingStorageScan = false;
    private boolean includeSystemCacheApps = false;
    private String initialPage = "home";
    private List<CachedApp> cachedApps = new ArrayList<>();
    private LinearLayout cachedAppRows;
    private TextView cachedSummaryText;
    private TextView junkStatusText;
    private LinearLayout junkRows;
    private final List<File> junkCandidateFiles = new ArrayList<>();
    private boolean cacheScanRunning = false;
    private boolean autoCacheScanAttempted = false;
    private boolean cacheScanIncludedSystem = false;
    private boolean junkScanRunning = false;

    private LinearLayout screenColumn;
    private LinearLayout pageBody;
    private LinearLayout networkResultCard;
    private TextView networkResultText;
    private ProgressBar networkProgress;
    private TextView cacheStatusText;
    private ProgressBar cacheProgress;
    private String cleanerFeedback = "Ready · TeinTools cache only. System storage settings manage other apps.";
    private boolean cleaningCache = false;
    private TextView timerDisplay;
    private TextView stopwatchDisplay;
    private EditText qrInputField;
    private ImageView qrPreview;
    private EditText fileContentField;
    private Bitmap lastQrBitmap;
    private List<ApplicationInfo> installedAppsCache = new ArrayList<>();

    private String calcExpression = "";
    private long stopwatchStartedAt = 0L;
    private long stopwatchAccumulated = 0L;
    private boolean stopwatchRunning = false;
    private boolean timerRunning = false;
    private long timerEndsAt = 0L;
    private long timerOriginalDuration = 0L;

    private final Runnable splashComplete = new Runnable() {
        @Override public void run() { if (!isFinishing()) renderPage(initialPage); }
    };

    private final Runnable stopwatchTick = new Runnable() {
        @Override public void run() {
            if (stopwatchRunning && "stopwatch".equals(currentPage) && stopwatchDisplay != null) {
                long elapsed = stopwatchAccumulated + (SystemClock.elapsedRealtime() - stopwatchStartedAt);
                stopwatchDisplay.setText(formatStopwatch(elapsed));
            }
            if (stopwatchRunning) handler.postDelayed(this, 100L);
        }
    };

    private final Runnable timerTick = new Runnable() {
        @Override public void run() {
            if (!timerRunning) return;
            long remaining = Math.max(0L, timerEndsAt - SystemClock.elapsedRealtime());
            if (timerDisplay != null) timerDisplay.setText(formatTimer(remaining));
            if (remaining <= 0L) {
                timerRunning = false;
                if (timerDisplay != null) timerDisplay.setText("00:00");
                Toast.makeText(MainActivity.this, "Timer selesai", Toast.LENGTH_LONG).show();
                return;
            }
            handler.postDelayed(this, 250L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        themeMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString("theme", "dark");
        if (!"dark".equals(themeMode) && !"light".equals(themeMode) && !"system".equals(themeMode)) themeMode = "dark";
        includeSystemCacheApps = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("include_system_cache", false);
        String requestedPage = getIntent() == null ? null : getIntent().getStringExtra("show_page");
        if (requestedPage != null && !requestedPage.trim().isEmpty()) initialPage = requestedPage;
        // Keep a restrained blue accent in both black-glass and white-glass themes.
        accentMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString("accent", "blue");
        if (!"blue".equals(accentMode)) accentMode = "blue";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("accent", "blue").apply();
        showSplashScreen();
        handler.postDelayed(splashComplete, SPLASH_DURATION_MS);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String page = intent == null ? null : intent.getStringExtra("show_page");
        if (page != null && !page.trim().isEmpty()) {
            initialPage = page;
            if ("cleaner".equals(page)) autoCacheScanAttempted = false;
            handler.removeCallbacks(splashComplete);
            renderPage(page);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // Refresh the Inspector if the user returns from Android's permission settings.
        if (pageBody != null && ("permissions".equals(currentPage) || "cleaner".equals(currentPage) || "storage".equals(currentPage))) renderPage(currentPage);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(splashComplete);
        handler.removeCallbacks(stopwatchTick);
        handler.removeCallbacks(timerTick);
        if (torchOn) setTorch(false);
        super.onDestroy();
    }

    private void showSplashScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(liquidBackground());
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(28), dp(24), dp(28), dp(24));

        ImageView artwork = new ImageView(this);
        artwork.setImageResource(R.drawable.hero_liquid);
        artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);
        artwork.setAdjustViewBounds(true);
        artwork.setContentDescription(null);
        artwork.setAlpha(0.0f);
        artwork.setScaleX(0.94f);
        artwork.setScaleY(0.94f);
        content.addView(artwork, new LinearLayout.LayoutParams(dp(236), dp(236)));

        TextView title = label("TeinTools", 30, textColor(), true);
        title.setGravity(Gravity.CENTER);
        title.setAlpha(0f);
        content.addView(title, marginParams(-1, -2, 0, dp(8), 0, 0));
        TextView subtitle = label("LIQUID GLASS  ·  ULTIMATE TOOLBOX", 10, muted(), true);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setAlpha(0f);
        content.addView(subtitle, marginParams(-1, -2, 0, dp(5), 0, dp(22)));

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
        progress.setProgressTintList(ColorStateList.valueOf(accent()));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.argb(70, 180, 190, 230)));
        content.addView(progress, new LinearLayout.LayoutParams(dp(156), dp(3)));
        TextView loading = label("PREPARING YOUR WORKSPACE", 9, muted(), true);
        loading.setGravity(Gravity.CENTER);
        loading.setLetterSpacing(0.12f);
        loading.setAlpha(0f);
        content.addView(loading, marginParams(-1, -2, 0, dp(13), 0, 0));
        root.addView(content, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        setContentView(root);

        artwork.animate().alpha(1f).scaleX(1f).scaleY(1f).setInterpolator(new AccelerateDecelerateInterpolator()).setDuration(720L).start();
        title.animate().alpha(1f).setStartDelay(180L).setDuration(460L).start();
        subtitle.animate().alpha(1f).setStartDelay(280L).setDuration(460L).start();
        loading.animate().alpha(1f).setStartDelay(430L).setDuration(400L).start();
    }

    private boolean isLight() {
        if ("light".equals(themeMode)) return true;
        if ("dark".equals(themeMode)) return false;
        int mask = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return mask != android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }
    // Restrained liquid-glass palette: black/navy surfaces, blue accents, white typography.
    private int accent() { return isLight() ? Color.rgb(16, 105, 214) : Color.rgb(91, 183, 255); }
    private int bg() { return isLight() ? Color.rgb(246, 249, 253) : Color.rgb(4, 8, 16); }
    private int surface() { return isLight() ? Color.argb(226, 255, 255, 255) : Color.argb(188, 12, 23, 39); }
    private int surfaceRaised() { return isLight() ? Color.argb(242, 255, 255, 255) : Color.argb(220, 18, 36, 57); }
    private int textColor() { return isLight() ? Color.rgb(20, 29, 42) : Color.rgb(244, 248, 255); }
    private int muted() { return isLight() ? Color.rgb(91, 105, 122) : Color.rgb(157, 174, 194); }
    private int borderColor() { return isLight() ? Color.argb(115, 20, 105, 214) : Color.argb(112, 91, 183, 255); }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    /** Layered gradients provide an Android 10-compatible liquid-glass illusion without API-31-only blur. */
    private Drawable liquidBackground() {
        int baseTop = isLight() ? Color.rgb(252, 253, 255) : Color.rgb(4, 8, 17);
        int baseBottom = isLight() ? Color.rgb(235, 242, 250) : Color.rgb(7, 17, 31);
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{baseTop, baseBottom});
        GradientDrawable violetGlow = new GradientDrawable();
        violetGlow.setShape(GradientDrawable.RECTANGLE);
        violetGlow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        violetGlow.setGradientCenter(0.94f, 0.08f);
        violetGlow.setGradientRadius(dp(430));
        violetGlow.setColors(new int[]{Color.argb(isLight() ? 46 : 43, 48, 139, 230), Color.TRANSPARENT});
        GradientDrawable cyanGlow = new GradientDrawable();
        cyanGlow.setShape(GradientDrawable.RECTANGLE);
        cyanGlow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        cyanGlow.setGradientCenter(0.04f, 0.78f);
        cyanGlow.setGradientRadius(dp(380));
        cyanGlow.setColors(new int[]{Color.argb(isLight() ? 28 : 24, 32, 118, 205), Color.TRANSPARENT});
        return new LayerDrawable(new Drawable[]{base, violetGlow, cyanGlow});
    }

    private void renderPage(String page) {
        if (page == null || page.trim().isEmpty()) page = "home";
        if (!page.equals(currentPage) && !suppressHistoryRecording) {
            if (isPrimaryPage(page)) {
                // Home/Tools/Settings act as root tabs, not intermediate destinations.
                pageHistory.clear();
            } else if (isKnownPage(currentPage)) {
                if (pageHistory.size() >= 24) pageHistory.removeFirst();
                pageHistory.addLast(currentPage);
            }
        }
        suppressHistoryRecording = false;
        currentPage = page;
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        window.setStatusBarColor(bg());
        window.setNavigationBarColor(bg());
        int flags = isLight() ? (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : 0;
        window.getDecorView().setSystemUiVisibility(flags);

        FrameLayout root = new FrameLayout(this);
        root.setBackground(liquidBackground());
        screenColumn = new LinearLayout(this);
        screenColumn.setOrientation(LinearLayout.VERTICAL);
        root.addView(screenColumn, new FrameLayout.LayoutParams(-1, -1));

        screenColumn.addView(makeTopBar(page), new LinearLayout.LayoutParams(-1, dp(68)));
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(false);
        scrollView.setClipToPadding(false);
        scrollView.setVerticalScrollBarEnabled(false);
        pageBody = new LinearLayout(this);
        pageBody.setOrientation(LinearLayout.VERTICAL);
        pageBody.setPadding(dp(16), dp(8), dp(16), dp(24));
        scrollView.addView(pageBody, new ScrollView.LayoutParams(-1, -2));
        screenColumn.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1));

        switch (page) {
            case "home": buildHome(pageBody); break;
            case "tools": buildTools(pageBody); break;
            case "settings": buildSettings(pageBody); break;
            case "device": buildDevicePage(pageBody); break;
            case "ram": buildRamBoosterPage(pageBody); break;
            case "storage": buildStorageCleanerPage(pageBody); break;
            case "battery": buildBatteryPage(pageBody); break;
            case "thermal": buildThermalPage(pageBody); break;
            case "animations": buildAnimationTunerPage(pageBody); break;
            case "network": buildNetworkPage(pageBody); break;
            case "flash": buildFlashPage(pageBody); break;
            case "calculator": buildCalculatorPage(pageBody); break;
            case "notes": buildNotesPage(pageBody); break;
            case "qr": buildQrPage(pageBody); break;
            case "stopwatch": buildStopwatchPage(pageBody); break;
            case "timer": buildTimerPage(pageBody); break;
            case "converter": buildConverterPage(pageBody); break;
            case "files": buildFilesPage(pageBody); break;
            case "apps": buildAppsPage(pageBody); break;
            case "system": buildSystemPage(pageBody); break;
            case "cleaner": buildCleanerPage(pageBody); break;
            case "sensors": buildSensorPage(pageBody); break;
            case "permissions": buildPermissionsPage(pageBody); break;
            default: buildHome(pageBody); break;
        }
        if (isPrimaryPage(page)) {
            View nav = makeBottomNav(page);
            LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(-1, dp(64));
            navParams.setMargins(dp(8), dp(2), dp(8), dp(5));
            screenColumn.addView(nav, navParams);
        }
        setContentView(root);
        screenColumn.setAlpha(0f);
        screenColumn.setTranslationY(dp(5));
        screenColumn.animate().alpha(1f).translationY(0f).setInterpolator(new AccelerateDecelerateInterpolator()).setDuration(320L).start();
        for (int i = 0; i < pageBody.getChildCount(); i++) {
            View child = pageBody.getChildAt(i);
            child.setAlpha(0f);
            child.setTranslationY(dp(13));
            child.animate().alpha(1f).translationY(0f).setInterpolator(new AccelerateDecelerateInterpolator())
                    .setStartDelay(Math.min(i * 42L, 300L)).setDuration(360L).start();
        }
        if ("stopwatch".equals(page) && stopwatchRunning) { handler.removeCallbacks(stopwatchTick); handler.post(stopwatchTick); }
        if ("timer".equals(page) && timerRunning) {
            updateTimerLabel();
            handler.removeCallbacks(timerTick);
            handler.post(timerTick);
        }
    }

    private boolean isKnownPage(String page) {
        return page != null && (isPrimaryPage(page) || java.util.Arrays.asList(
                "device", "ram", "storage", "battery", "thermal", "animations", "network", "flash",
                "calculator", "notes", "qr", "stopwatch", "timer", "converter", "files", "apps",
                "system", "cleaner", "sensors", "permissions").contains(page));
    }

    private void openRootPage(String page) {
        pageHistory.clear();
        suppressHistoryRecording = true;
        renderPage(page);
    }

    private void navigateBack() {
        if (!pageHistory.isEmpty()) {
            String previous = pageHistory.removeLast();
            suppressHistoryRecording = true;
            renderPage(previous);
            return;
        }
        if (!"home".equals(currentPage)) {
            suppressHistoryRecording = true;
            renderPage("home");
            return;
        }
        // Android 10 normally finishes a launcher activity on Back. Move the task to
        // the background instead so users can resume the current screen from Recents.
        if (!moveTaskToBack(true)) super.onBackPressed();
    }

    @Override public void onBackPressed() {
        navigateBack();
    }

    private boolean isPrimaryPage(String page) {
        return "home".equals(page) || "tools".equals(page) || "settings".equals(page);
    }

    private View makeTopBar(String page) {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(5), dp(16), dp(4));
        if (isPrimaryPage(page)) {
            ImageView mark = new ImageView(this);
            mark.setImageResource(R.drawable.ic_launcher);
            mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
            mark.setContentDescription("TeinTools logo");
            bar.addView(mark, new LinearLayout.LayoutParams(dp(42), dp(42)));
            LinearLayout brand = new LinearLayout(this);
            brand.setOrientation(LinearLayout.VERTICAL);
            brand.setPadding(dp(9), 0, 0, 0);
            brand.addView(label("TeinTools", 20, textColor(), true));
            TextView sub = label("ULTIMATE TOOLBOX", 9, muted(), true);
            sub.setLetterSpacing(0.10f);
            brand.addView(sub, marginParams(-1, -2, 0, dp(2), 0, 0));
            bar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
            bar.addView(iconButton("system", "System tools", 38, () -> renderPage("system")));
        } else {
            bar.addView(iconButton("back", "Back", 38, this::navigateBack));
            LinearLayout titleBox = new LinearLayout(this);
            titleBox.setOrientation(LinearLayout.VERTICAL);
            titleBox.setPadding(dp(12), 0, 0, 0);
            titleBox.addView(label(pageTitle(page), 17, textColor(), true));
            titleBox.addView(label(pageSubtitle(page), 10, muted(), false));
            bar.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
            bar.addView(iconButton("more", "Settings", 38, () -> openRootPage("settings")));
        }
        return bar;
    }

    private View iconButton(String iconName, String description, int size, Runnable action) {
        FrameLayout button = new FrameLayout(this);
        button.setContentDescription(description);
        button.setMinimumWidth(dp(size));
        button.setMinimumHeight(dp(size));
        button.setFocusable(true);
        button.setClickable(true);
        button.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        LineIconView icon = new LineIconView(this, iconName, accent());
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(21), dp(21), Gravity.CENTER);
        button.addView(icon, ip);
        button.setOnClickListener(v -> {
            v.animate().cancel();
            v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70L).withEndAction(() -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(130L).start();
                action.run();
            }).start();
        });
        return button;
    }

    private String pageTitle(String page) {
        switch (page) {
            case "device": return "Device Monitor";
            case "ram": return "RAM Booster";
            case "storage": return "Storage & Junk";
            case "battery": return "Battery & Focus";
            case "thermal": return "Thermal Monitor";
            case "animations": return "Animation Tuner";
            case "network": return "Network Lab";
            case "flash": return "Flashlight";
            case "calculator": return "Calculator";
            case "notes": return "Quick Notes";
            case "qr": return "QR Studio";
            case "stopwatch": return "Stopwatch";
            case "timer": return "Countdown Timer";
            case "converter": return "Unit Converter";
            case "files": return "File Hub";
            case "apps": return "Installed Apps";
            case "system": return "System Shortcuts";
            case "cleaner": return "Cache Cleaner";
            case "sensors": return "Sensor Lab";
            case "permissions": return "Permission Center";
            default: return "TeinTools";
        }
    }
    private String pageSubtitle(String page) {
        switch (page) {
            case "device": return "Live stats";
            case "ram": return "RAM and processes";
            case "storage": return "Storage";
            case "battery": return "Battery and focus";
            case "thermal": return "Temperature";
            case "animations": return "System animations";
            case "network": return "Network test";
            case "flash": return "Hardware torch control";
            case "calculator": return "Fast, local arithmetic";
            case "notes": return "Saved only on this device";
            case "qr": return "Scan, create, and save QR";
            case "stopwatch": return "Precise elapsed time";
            case "timer": return "Simple countdown";
            case "converter": return "Common unit conversions";
            case "files": return "Android document picker";
            case "apps": return "Open app settings quickly";
            case "system": return "Native Android settings";
            case "cleaner": return "Cache cleanup";
            case "sensors": return "Hardware sensors reported by Android";
            case "permissions": return "Check this app’s permissions";
            default: return "Appearance and preferences";
        }
    }

    private View makeBottomNav(String selected) {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(10), dp(7), dp(10), dp(7));
        nav.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        String[][] items = {{"home", "Home", "home"}, {"apps", "Tools", "tools"}, {"settings", "Settings", "settings"}};
        for (String[] item : items) {
            boolean active = selected.equals(item[2]);
            LinearLayout cell = new LinearLayout(this);
            cell.setGravity(Gravity.CENTER);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setPadding(dp(12), dp(5), dp(12), dp(2));
            if (active) cell.setBackground(solid(roundRect(isLight() ? Color.argb(85, 20, 22, 27) : Color.argb(65, 255, 255, 255), dp(20), Color.TRANSPARENT)));
            LineIconView icon = new LineIconView(this, item[0], active ? accent() : muted());
            cell.addView(icon, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView text = label(item[1], 10, active ? textColor() : muted(), active);
            text.setGravity(Gravity.CENTER);
            cell.addView(text, marginParams(-1, -2, 0, dp(3), 0, 0));
            cell.setContentDescription(item[1]);
            cell.setOnClickListener(v -> openRootPage(item[2]));
            nav.addView(cell, new LinearLayout.LayoutParams(0, -1, 1));
        }
        nav.setElevation(dp(8));
        return nav;
    }

    private void buildHome(LinearLayout body) {
        addSectionTitle(body, "DEVICE STATUS", null);
        ActivityManager.MemoryInfo memory = currentMemoryInfo();
        int ramUsed = memory.totalMem <= 0 ? 0 : Math.max(0, Math.min(100, (int)Math.round((memory.totalMem - memory.availMem) * 100.0 / memory.totalMem)));
        StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
        long totalStorage = stat.getTotalBytes();
        long freeStorageNow = stat.getAvailableBytes();
        int storageUsed = totalStorage <= 0 ? 0 : (int)Math.round((totalStorage - freeStorageNow) * 100.0 / totalStorage);
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery == null ? 100 : battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int batteryPct = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
        int temp = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        String condition = storageUsed >= 92 ? "Storage almost full" : ramUsed >= 92 ? "High memory use" : (temp >= 430 ? "Battery warm" : "Device ready");

        // A single, fixed-height billboard prevents artwork/text/action overlap on short screens.
        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(backgroundGradient(isLight() ? Color.rgb(245, 249, 255) : Color.rgb(8, 19, 36),
                isLight() ? Color.rgb(255, 255, 255) : Color.rgb(5, 11, 22), 2));
        hero.setClipToOutline(true);
        ImageView orb = new ImageView(this);
        orb.setImageResource(R.drawable.hero_liquid);
        orb.setScaleType(ImageView.ScaleType.FIT_CENTER);
        orb.setContentDescription(null);
        orb.setAlpha(isLight() ? 0.58f : 0.72f);
        FrameLayout.LayoutParams art = new FrameLayout.LayoutParams(dp(128), dp(128), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        art.setMargins(0, 0, dp(2), 0);
        hero.addView(orb, art);

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(Gravity.CENTER_VERTICAL);
        copy.setPadding(dp(15), dp(12), dp(78), dp(12));
        copy.addView(label(condition.toUpperCase(Locale.ROOT), 9, accent(), true));
        copy.addView(label(deviceName(), 20, textColor(), true), marginParams(-1, -2, 0, dp(5), 0, 0));
        TextView version = pill("ANDROID 10 · API 29", surfaceRaised(), textColor(), 27);
        version.setTextSize(9);
        version.setGravity(Gravity.CENTER);
        copy.addView(version, marginParams(-2, -2, 0, dp(7), 0, 0));
        hero.addView(copy, new FrameLayout.LayoutParams(-1, -1, Gravity.TOP | Gravity.LEFT));
        body.addView(hero, marginParams(-1, dp(138), 0, 0, 0, dp(13)));

        addSectionTitle(body, "DEVICE SNAPSHOT", null);
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        View ramTile = statTile("RAM USED", ramUsed + "%", formatBytes(memory.availMem) + " free", "memory");
        View storageTile = statTile("STORAGE", storageUsed + "%", formatBytes(freeStorageNow) + " free", "files");
        View batteryTile = statTile("BATTERY", batteryPct < 0 ? "—" : batteryPct + "%", temp < 0 ? "Temp unavailable" : String.format(Locale.US, "%.1f °C", temp / 10f), "battery");
        addWithHorizontalGap(stats, ramTile, 84, false, true);
        addWithHorizontalGap(stats, storageTile, 84, true, true);
        addWithHorizontalGap(stats, batteryTile, 84, true, false);
        body.addView(stats, marginParams(-1, -2, 0, 0, 0, dp(16)));

        addSectionTitle(body, "QUICK TOOLS", null);
        addToolGrid(body, new Tool[]{
                new Tool("", "RAM Booster", "Background apps", "ram"),
                new Tool("", "Cache Cleaner", "App cache", "cleaner"),
                new Tool("", "Junk Cleaner", "Temporary files", "storage"),
                new Tool("", "Battery & Focus", "Power and DND", "battery"),
                new Tool("", "Thermal Monitor", "Device temperature", "thermal"),
                new Tool("", "Permission Center", "App access", "permissions")
        });
    }

    private void addWithHorizontalGap(LinearLayout row, View child, int height, boolean gapLeft, boolean gapRight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(height), 1f);
        lp.setMargins(gapLeft ? dp(4) : 0, 0, gapRight ? dp(4) : 0, 0);
        row.addView(child, lp);
    }

    private void buildTools(LinearLayout body) {
        addSectionTitle(body, "Boost & battery", null);
        addToolGrid(body, new Tool[]{
                new Tool("", "RAM Booster", "Background process pass", "ram"),
                new Tool("", "Device Monitor", "CPU cores, RAM, storage", "device"),
                new Tool("", "Battery & Focus", "Power profile and DND", "battery"),
                new Tool("", "Thermal Monitor", "Thermal and battery temp", "thermal"),
                new Tool("", "Animation Tuner", "Open system animation settings", "animations")
        });

        addSectionTitle(body, "Cleaning & network", null);
        addToolGrid(body, new Tool[]{
                new Tool("", "1-Tap Cache Cleaner", "Per-app cache in Settings", "cleaner"),
                new Tool("", "Junk Cleaner", "Old temporary files", "storage"),
                new Tool("", "Network Lab", "HTTPS, DNS, TCP, speed", "network"),
                new Tool("", "App Manager", "Launch apps or open App Info", "apps")
        });

        addSectionTitle(body, "Permissions & system", null);
        addToolGrid(body, new Tool[]{
                new Tool("", "Permission Center", "Accessibility, usage, storage", "permissions"),
                new Tool("", "System Shortcuts", "Wi-Fi, display, device info", "system"),
                new Tool("", "Storage Overview", "Capacity and safe scan", "storage"),
                new Tool("", "Sensor Lab", "Hardware sensor inventory", "sensors")
        });

        addSectionTitle(body, "Utilities", null);
        addToolGrid(body, new Tool[]{
                new Tool("", "Flashlight", "Camera torch", "flash"),
                new Tool("", "QR Studio", "Scan and create QR", "qr"),
                new Tool("", "Calculator", "Arithmetic", "calculator"),
                new Tool("", "Quick Notes", "Private local notes", "notes"),
                new Tool("", "Stopwatch", "Elapsed time", "stopwatch"),
                new Tool("", "Countdown", "Timer", "timer"),
                new Tool("", "Unit Converter", "Length, temp, data", "converter"),
                new Tool("", "File Hub", "System document picker", "files")
        });
        
    }

    private void buildSettings(LinearLayout body) {
        addSectionTitle(body, "Appearance", null);
        LinearLayout themeCard = card(null, null, false);
        themeCard.addView(label("Theme mode", 16, textColor(), true));
        
        LinearLayout themeRow = new LinearLayout(this);
        themeRow.setOrientation(LinearLayout.HORIZONTAL);
        addChoice(themeRow, "System", "system".equals(themeMode), () -> { themeMode = "system"; saveAppearance(); renderPage("settings"); });
        addChoice(themeRow, "Black + Blue", "dark".equals(themeMode), () -> { themeMode = "dark"; saveAppearance(); renderPage("settings"); });
        addChoice(themeRow, "White + Blue", "light".equals(themeMode), () -> { themeMode = "light"; saveAppearance(); renderPage("settings"); });
        themeCard.addView(themeRow, marginParams(-1, -2, 0, dp(15), 0, 0));
        body.addView(themeCard, marginParams(-1, -2, 0, 0, 0, dp(16)));

        LinearLayout preview = card(null, null, true);
        LinearLayout toneRow = new LinearLayout(this);
        toneRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout mini = new LinearLayout(this);
        mini.setOrientation(LinearLayout.VERTICAL);
        mini.addView(label("BLACK · BLUE · WHITE", 9, accent(), true));
        mini.addView(label("Liquid glass", 11, muted(), true), marginParams(-1, -2, 0, dp(3), 0, 0));
        toneRow.addView(mini, new LinearLayout.LayoutParams(0, -2, 1));
        ImageView orb = new ImageView(this);
        orb.setImageResource(R.drawable.hero_liquid);
        orb.setScaleType(ImageView.ScaleType.FIT_CENTER);
        toneRow.addView(orb, new LinearLayout.LayoutParams(dp(88), dp(88)));
        preview.addView(toneRow);
        body.addView(preview, marginParams(-1, -2, 0, 0, 0, dp(17)));

        LinearLayout access = card("Permissions and privacy", "Each feature requests access only when the permission is genuinely required. System permissions are never requested just to make the app look more powerful.", false);
        body.addView(access, marginParams(-1, -2, 0, 0, 0, dp(10)));
        addActionButton(body, "Permission Inspector", "Review camera access, system-managed access, and features that need no permission", () -> renderPage("permissions"));
        addActionButton(body, "System shortcuts", "Open Android settings pages directly", () -> renderPage("system"));
        LinearLayout about = card("About TeinTools", "Version 1.3.1 · Android 10+", false);
        body.addView(about, marginParams(-1, -2, 0, dp(7), 0, dp(24)));
    }

    private void addChoice(LinearLayout row, String label, boolean selected, Runnable action) {
        TextView t = pill(label, selected ? blend(accent(), surface(), isLight() ? 0.82f : 0.74f) : surfaceRaised(), selected ? textColor() : muted(), 40);
        t.setTextSize(10);
        t.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
        lp.setMargins(0, 0, dp(6), 0);
        row.addView(t, lp);
    }

    private void addColorChoice(LinearLayout row, String name, String value, int color) {
        LinearLayout cell = new LinearLayout(this);
        cell.setGravity(Gravity.CENTER);
        cell.setOrientation(LinearLayout.VERTICAL);
        View dot = new View(this);
        GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color);
        if (accentMode.equals(value)) d.setStroke(dp(3), textColor());
        dot.setBackground(d);
        cell.addView(dot, new LinearLayout.LayoutParams(dp(27), dp(27)));
        TextView txt = label(name, 9, accentMode.equals(value) ? textColor() : muted(), accentMode.equals(value));
        txt.setGravity(Gravity.CENTER);
        cell.addView(txt, marginParams(-1, -2, 0, dp(5), 0, 0));
        cell.setOnClickListener(v -> { accentMode = value; saveAppearance(); renderPage("settings"); });
        row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void saveAppearance() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("theme", themeMode).putString("accent", accentMode).apply();
    }

    private void buildRamBoosterPage(LinearLayout body) {
        ActivityManager.MemoryInfo mi = currentMemoryInfo();
        int usedPct = mi.totalMem <= 0 ? 0 : Math.max(0, Math.min(100, (int)Math.round((mi.totalMem - mi.availMem) * 100.0 / mi.totalMem)));
        LinearLayout hero = card(null, null, true);
        addText(hero, "RAM IN USE", 10, muted(), true, 0);
        hero.addView(label(usedPct + "%", 38, textColor(), true), marginParams(-1, -2, 0, dp(5), 0, 0));
        ProgressBar ramBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        ramBar.setMax(100); ramBar.setProgress(usedPct);
        ramBar.setProgressTintList(ColorStateList.valueOf(accent()));
        ramBar.setProgressBackgroundTintList(ColorStateList.valueOf(blend(surface(), Color.BLACK, 0.30f)));
        hero.addView(ramBar, marginParams(-1, dp(5), 0, dp(7), 0, dp(10)));
        addKeyValue(hero, "Available", formatBytes(mi.availMem));
        addKeyValue(hero, "Total RAM reported", formatBytes(mi.totalMem));
        addActionButton(hero, "Boost RAM safely", "Ask Android to stop eligible background processes; no force-stop or root", this::confirmRamBoost);
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(16)));

        addSectionTitle(body, "Protected apps", "Keep messaging, keyboard, launcher, or apps you need running out of the boost pass");
        LinearLayout whitelistCard = card(null, null, false);
        Set<String> protectedPackages = getRamWhitelist();
        List<ApplicationInfo> userApps = getLaunchableUserApps();
        if (userApps.isEmpty()) {
            whitelistCard.addView(label("No launchable user apps were reported.", 12, muted(), false));
        } else {
            int limit = Math.min(userApps.size(), 18);
            for (int i = 0; i < limit; i++) {
                ApplicationInfo app = userApps.get(i);
                String packageName = app.packageName;
                CheckBox box = new CheckBox(this);
                box.setText(String.valueOf(getPackageManager().getApplicationLabel(app)));
                box.setTextColor(textColor()); box.setTextSize(13); box.setButtonTintList(ColorStateList.valueOf(accent()));
                box.setPadding(0, dp(3), 0, dp(3));
                box.setChecked(protectedPackages.contains(packageName));
                box.setOnCheckedChangeListener((button, checked) -> {
                    Set<String> updated = getRamWhitelist();
                    if (checked) updated.add(packageName); else updated.remove(packageName);
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet("ram_whitelist", updated).apply();
                });
                whitelistCard.addView(box, new LinearLayout.LayoutParams(-1, -2));
            }
            if (userApps.size() > limit) addText(whitelistCard, "Showing the first " + limit + " user apps. Apps outside this list are still protected by system process-importance checks.", 10, muted(), false, dp(5));
        }
        body.addView(whitelistCard, marginParams(-1, -2, 0, 0, 0, dp(14)));
        body.addView(card("How the boost works", "TeinTools only asks Android to stop user-app processes that Android reports as background and that are not on your protected list. Android may restart them and the available-RAM value can move up or down. The measured before/after reading is shown; no fake score or guaranteed RAM gain is used.", false), marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private ActivityManager.MemoryInfo currentMemoryInfo() {
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        ActivityManager manager = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        if (manager != null) manager.getMemoryInfo(info);
        return info;
    }

    private Set<String> getRamWhitelist() {
        Set<String> saved = getSharedPreferences(PREFS, MODE_PRIVATE).getStringSet("ram_whitelist", Collections.emptySet());
        return new HashSet<>(saved == null ? Collections.emptySet() : saved);
    }

    private List<ApplicationInfo> getLaunchableUserApps() {
        List<ApplicationInfo> result = new ArrayList<>();
        try {
            for (ApplicationInfo app : getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA)) {
                if (getPackageName().equals(app.packageName)) continue;
                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                if (getPackageManager().getLaunchIntentForPackage(app.packageName) != null) result.add(app);
            }
            Collections.sort(result, Comparator.comparing(a -> String.valueOf(getPackageManager().getApplicationLabel(a)).toLowerCase(Locale.ROOT)));
        } catch (Exception ignored) { }
        return result;
    }

    private void confirmRamBoost() {
        new AlertDialog.Builder(this)
                .setTitle("Boost RAM safely?")
                .setMessage("TeinTools will request Android to stop eligible user apps reported as background. Protected apps are excluded. Android may restart processes, so the free-RAM change is not guaranteed.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Boost RAM", (d, w) -> runRamBoost())
                .show();
    }

    private void runRamBoost() {
        ActivityManager manager = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        if (manager == null) { toast("Android did not provide process information."); return; }
        ActivityManager.MemoryInfo beforeInfo = currentMemoryInfo();
        long before = beforeInfo.availMem;
        Set<String> keep = getRamWhitelist();
        int[] attempted = {0};
        new Thread(() -> {
            try {
                List<ActivityManager.RunningAppProcessInfo> processes = manager.getRunningAppProcesses();
                if (processes != null) {
                    Set<String> visited = new HashSet<>();
                    for (ActivityManager.RunningAppProcessInfo process : processes) {
                        if (process == null || process.importance < ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND || process.pkgList == null) continue;
                        for (String packageName : process.pkgList) {
                            if (packageName == null || packageName.equals(getPackageName()) || keep.contains(packageName) || !visited.add(packageName)) continue;
                            try {
                                ApplicationInfo app = getPackageManager().getApplicationInfo(packageName, 0);
                                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                                if (getPackageManager().getLaunchIntentForPackage(packageName) == null) continue;
                                manager.killBackgroundProcesses(packageName);
                                attempted[0]++;
                            } catch (Exception ignored) { }
                        }
                    }
                }
            } catch (Exception ignored) { }
            handler.postDelayed(() -> {
                long after = currentMemoryInfo().availMem;
                long delta = after - before;
                String deltaText = delta >= 0 ? "available RAM rose by " + formatBytes(delta) : "available RAM fell by " + formatBytes(-delta);
                toast("Boost pass finished · " + attempted[0] + " background package(s) requested · " + deltaText + ".");
                if ("ram".equals(currentPage)) renderPage("ram");
                else if ("home".equals(currentPage)) renderPage("home");
            }, 1200L);
        }, "tein-ram-booster").start();
    }

    private void buildStorageCleanerPage(LinearLayout body) {
        StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
        long free = stat.getAvailableBytes();
        long total = stat.getTotalBytes();
        long used = Math.max(0L, total - free);
        int percent = total <= 0 ? 0 : (int)Math.round(used * 100.0 / total);
        LinearLayout hero = card(null, null, true);
        addText(hero, "INTERNAL STORAGE USED", 10, muted(), true, 0);
        hero.addView(label(percent + "%", 34, textColor(), true), marginParams(-1, -2, 0, dp(4), 0, 0));
        addKeyValue(hero, "Used", formatBytes(used));
        addKeyValue(hero, "Free", formatBytes(free));
        addKeyValue(hero, "Total", formatBytes(total));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addSectionTitle(body, "Safe junk scan", "Only thumbnails and old temporary download files are candidates; nothing is deleted during scanning");
        LinearLayout scan = card(null, null, false);
        junkStatusText = label(junkScanRunning ? "Scanning selected folders…" : "Scan has not been run yet.", 12, muted(), false);
        scan.addView(junkStatusText);
        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true); progress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
        progress.setVisibility(junkScanRunning ? View.VISIBLE : View.GONE);
        scan.addView(progress, marginParams(dp(24), dp(24), 0, dp(8), 0, 0));
        body.addView(scan, marginParams(-1, -2, 0, 0, 0, dp(10)));
        addActionButton(body, "Scan safe temporary files", "Requests Android 10 storage permission only when needed", this::requestStorageThenScan);

        junkRows = new LinearLayout(this); junkRows.setOrientation(LinearLayout.VERTICAL);
        body.addView(junkRows, new LinearLayout.LayoutParams(-1, -2));
        renderJunkRows();
        addActionButton(body, "Delete selected candidates", "Review first; only checked files will be removed", this::confirmDeleteJunk);
        addActionButton(body, "Open Android storage settings", "Review app storage and system cache using Android Settings", this::openStorageSettings);
        body.addView(card("Safety boundary", "TeinTools does not delete photos, documents, APKs, or app data as junk. It only offers old .tmp/.temp/.part files in Downloads and thumbnail-cache files for your review. Android 10 does not let a normal app directly wipe every other app's private cache.", false), marginParams(-1, -2, 0, dp(12), 0, dp(20)));
    }

    private void requestStorageThenScan() {
        if (!hasStorageRuntimePermission()) {
            pendingStorageScan = true;
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        scanSafeJunkFiles();
    }

    private boolean hasStorageRuntimePermission() {
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void scanSafeJunkFiles() {
        if (junkScanRunning) return;
        if (!hasStorageRuntimePermission()) { requestStorageThenScan(); return; }
        junkScanRunning = true;
        if (junkStatusText != null) junkStatusText.setText("Scanning Downloads and thumbnail cache…");
        new Thread(() -> {
            List<File> found = new ArrayList<>();
            long now = System.currentTimeMillis();
            File root = Environment.getExternalStorageDirectory();
            File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            scanJunkTree(downloads, 0, now - 7L * 24L * 60L * 60L * 1000L, found, false, new int[]{0});
            scanJunkTree(new File(root, "DCIM/.thumbnails"), 0, now - 24L * 60L * 60L * 1000L, found, true, new int[]{0});
            scanJunkTree(new File(root, "Pictures/.thumbnails"), 0, now - 24L * 60L * 60L * 1000L, found, true, new int[]{0});
            scanJunkTree(new File(root, "Movies/.thumbnails"), 0, now - 24L * 60L * 60L * 1000L, found, true, new int[]{0});
            found.sort(Comparator.comparingLong(File::length).reversed());
            runOnUiThread(() -> {
                junkScanRunning = false;
                junkCandidateFiles.clear(); junkCandidateFiles.addAll(found);
                selectedJunkPaths.clear();
                if (junkStatusText != null) {
                    long bytes = 0L; for (File file : found) bytes += file.length();
                    junkStatusText.setText(found.size() + " candidate file(s) · " + formatBytes(bytes) + " found. Select what to remove.");
                }
                renderJunkRows();
                if ("storage".equals(currentPage)) renderPage("storage");
            });
        }, "tein-safe-junk-scan").start();
    }

    private final Set<String> selectedJunkPaths = new HashSet<>();

    private void scanJunkTree(File directory, int depth, long cutoff, List<File> output, boolean thumbnails, int[] visited) {
        if (directory == null || !directory.exists() || depth > 4 || visited[0] > 1800 || output.size() >= 80) return;
        visited[0]++;
        File[] files = directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (output.size() >= 80 || visited[0] > 1800) return;
            if (file.isDirectory()) {
                if (thumbnails || file.getName().equalsIgnoreCase(".thumbnails")) scanJunkTree(file, depth + 1, cutoff, output, true, visited);
                else if (!thumbnails) scanJunkTree(file, depth + 1, cutoff, output, false, visited);
            } else if (file.isFile() && file.length() > 0 && file.lastModified() > 0 && file.lastModified() < cutoff) {
                String name = file.getName().toLowerCase(Locale.ROOT);
                boolean candidate = thumbnails || name.endsWith(".tmp") || name.endsWith(".temp") || name.endsWith(".part");
                if (candidate && !output.contains(file)) output.add(file);
            }
        }
    }

    private void renderJunkRows() {
        if (junkRows == null) return;
        junkRows.removeAllViews();
        if (junkCandidateFiles.isEmpty()) {
            junkRows.addView(card(null, "No candidates loaded. Scan safe folders first.", false), marginParams(-1, -2, 0, dp(6), 0, dp(8)));
            return;
        }
        int max = Math.min(30, junkCandidateFiles.size());
        for (int i = 0; i < max; i++) {
            File file = junkCandidateFiles.get(i);
            LinearLayout row = card(null, null, false);
            CheckBox checkbox = new CheckBox(this);
            checkbox.setButtonTintList(ColorStateList.valueOf(accent()));
            checkbox.setText(file.getName()); checkbox.setTextColor(textColor()); checkbox.setTextSize(12);
            checkbox.setChecked(selectedJunkPaths.contains(file.getAbsolutePath()));
            checkbox.setOnCheckedChangeListener((button, checked) -> {
                if (checked) selectedJunkPaths.add(file.getAbsolutePath()); else selectedJunkPaths.remove(file.getAbsolutePath());
            });
            row.addView(checkbox);
            addText(row, shorten(file.getParent(), 72) + " · " + formatBytes(file.length()), 9, muted(), false, dp(1));
            junkRows.addView(row, marginParams(-1, -2, 0, 0, 0, dp(6)));
        }
        if (junkCandidateFiles.size() > max) junkRows.addView(card(null, "Showing " + max + " of " + junkCandidateFiles.size() + " candidate files. Only visible checked items can be selected for this pass.", false), marginParams(-1, -2, 0, 0, 0, dp(8)));
    }

    private void confirmDeleteJunk() {
        List<File> chosen = new ArrayList<>();
        for (File file : junkCandidateFiles) if (selectedJunkPaths.contains(file.getAbsolutePath())) chosen.add(file);
        if (chosen.isEmpty()) { toast("Select at least one candidate first."); return; }
        long bytes = 0L; for (File file : chosen) bytes += file.length();
        new AlertDialog.Builder(this).setTitle("Delete selected temporary files?")
                .setMessage("Selected: " + chosen.size() + " file(s), " + formatBytes(bytes) + ". Only the checked files in Downloads or thumbnail-cache folders will be removed.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete files", (d, w) -> deleteSelectedJunk(chosen))
                .show();
    }

    private void deleteSelectedJunk(List<File> chosen) {
        long removed = 0L; int count = 0;
        for (File file : chosen) {
            if (file != null && file.isFile()) {
                long size = file.length();
                if (file.delete()) { removed += size; count++; }
            }
        }
        selectedJunkPaths.clear();
        junkCandidateFiles.removeIf(file -> file == null || !file.exists());
        if (junkStatusText != null) junkStatusText.setText("Removed " + count + " selected file(s) · " + formatBytes(removed) + ".");
        renderJunkRows();
        toast("Removed " + count + " selected file(s).");
    }

    private void buildBatteryPage(LinearLayout body) {
        Intent batt = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = batt == null ? -1 : batt.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batt == null ? 100 : batt.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int percent = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
        int temp = batt == null ? -1 : batt.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        LinearLayout hero = card(null, null, true);
        addText(hero, "BATTERY LEVEL", 10, muted(), true, 0);
        hero.addView(label(percent < 0 ? "—" : percent + "%", 36, textColor(), true), marginParams(-1, -2, 0, dp(4), 0, 0));
        addKeyValue(hero, "Temperature", temp < 0 ? "Not reported" : String.format(Locale.US, "%.1f °C", temp / 10f));
        addKeyValue(hero, "Status", batt == null ? "Unavailable" : batteryHealth(batt.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) + " · " + batteryChargingStatus(batt.getIntExtra(BatteryManager.EXTRA_STATUS, -1)));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addSectionTitle(body, "Power controls", "Use the controls only when you choose to apply them");
        addActionButton(body, "Open Android Battery Saver", "Native power controls remain under Android's control", () -> launchSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        addActionButton(body, "Apply quiet display profile", "With Modify System Settings access: lower brightness and set 30-second screen timeout", this::confirmQuietDisplayProfile);
        addActionButton(body, "Restore previous display settings", "Available after a quiet display profile was applied", this::restoreQuietDisplayProfile);
        addActionButton(body, currentDndFilterIsNone() ? "Turn off Focus mode (DND)" : "Turn on Focus mode (DND)", "Requires notification policy access; Android may suppress calls/alerts", this::toggleFocusMode);
        addActionButton(body, "Configure Do Not Disturb access", "Open Android's permission screen", this::openDndAccessSettings);
        body.addView(card("No fake cooling", "Battery Saver asks Android to manage power. Thermal Monitor reads the device's thermal state. Neither app code nor a cleaner can physically cool the processor; reduce heavy workload and let the device cool naturally when temperature is high.", false), marginParams(-1, -2, 0, dp(12), 0, dp(20)));
    }

    private String batteryChargingStatus(int status) {
        if (status == BatteryManager.BATTERY_STATUS_CHARGING) return "Charging";
        if (status == BatteryManager.BATTERY_STATUS_FULL) return "Full";
        if (status == BatteryManager.BATTERY_STATUS_DISCHARGING) return "Discharging";
        return "Not charging / unknown";
    }

    private void confirmQuietDisplayProfile() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            new AlertDialog.Builder(this).setTitle("Allow display control?")
                    .setMessage("This optional feature changes only the screen brightness and screen-off timeout after you confirm. Android requires a separate Modify System Settings grant.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Open permission", (d, w) -> {
                        try { startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))); }
                        catch (Exception e) { toast("Could not open Modify System Settings."); }
                    }).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Apply quiet display profile?")
                .setMessage("Set brightness to 35/255 and screen timeout to 30 seconds. The previous values are saved so you can restore them here.")
                .setNegativeButton("Cancel", null).setPositiveButton("Apply", (d, w) -> applyQuietDisplayProfile()).show();
    }

    private void applyQuietDisplayProfile() {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            if (!prefs.getBoolean("quiet_display_active", false)) {
                int oldBrightness = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
                int oldTimeout = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 60000);
                prefs.edit().putInt("old_brightness", oldBrightness).putInt("old_timeout", oldTimeout).apply();
            }
            boolean b = Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 35);
            boolean t = Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 30000);
            prefs.edit().putBoolean("quiet_display_active", b || t).apply();
            toast((b || t) ? "Quiet display profile applied. Restore it from this page any time." : "Android did not accept the display settings.");
            renderPage("battery");
        } catch (Exception e) { toast("Could not apply display profile: " + safeMessage(e)); }
    }

    private void restoreQuietDisplayProfile() {
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("quiet_display_active", false)) { toast("No saved display profile to restore."); return; }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            catch (Exception e) { toast("Open Modify System Settings to restore the saved values."); }
            return;
        }
        boolean b = false, t = false;
        try { b = Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, prefs.getInt("old_brightness", 128)); } catch (Exception ignored) { }
        try { t = Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, prefs.getInt("old_timeout", 60000)); } catch (Exception ignored) { }
        prefs.edit().putBoolean("quiet_display_active", false).apply();
        toast((b || t) ? "Saved display values restored." : "Android did not accept the restore request.");
        renderPage("battery");
    }

    private void buildAnimationTunerPage(LinearLayout body) {
        addSectionTitle(body, "System Animation Tuner", "A safe shortcut to Android's own animation controls");
        LinearLayout hero = card(null, null, true);
        hero.addView(new LineIconView(this, "settings", accent()), new LinearLayout.LayoutParams(dp(48), dp(48)));
        hero.addView(label("Make transitions feel quicker", 21, textColor(), true), marginParams(-1, -2, 0, dp(10), 0, 0));
        addText(hero, "Android 10 keeps the official animation scale controls inside Developer options. TeinTools will not silently write protected settings or force hidden system values.", 12, muted(), false, dp(8));
        addActionButton(hero, "Open Developer options", "You can set these controls yourself", () -> {
            try {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
                if (intent.resolveActivity(getPackageManager()) != null) startActivity(intent);
                else launchSettings(Settings.ACTION_SETTINGS);
            } catch (Exception e) { launchSettings(Settings.ACTION_SETTINGS); }
        });
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));
        addSectionTitle(body, "Suggested settings", "Apply only if you prefer shorter motion");
        body.addView(card("Window animation scale", "Try 0.5x for shorter window transitions, or Off to disable them.", false), marginParams(-1, -2, 0, 0, 0, dp(8)));
        body.addView(card("Transition animation scale", "Try 0.5x to shorten movement between activities.", false), marginParams(-1, -2, 0, 0, 0, dp(8)));
        body.addView(card("Animator duration scale", "Try 0.5x if you prefer shorter view animations. Some interfaces may feel less smooth with all scales Off.", false), marginParams(-1, -2, 0, 0, 0, dp(8)));
        body.addView(card("Permission note", "No root, WRITE_SECURE_SETTINGS or Accessibility permission is needed for this shortcut. Changes are made by you in Android Developer options.", false), marginParams(-1, -2, 0, 0, 0, dp(22)));
    }

    private boolean hasDndAccess() {
        if (Build.VERSION.SDK_INT < 23) return false;
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        return manager != null && manager.isNotificationPolicyAccessGranted();
    }

    private boolean currentDndFilterIsNone() {
        try {
            NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            return manager != null && manager.getCurrentInterruptionFilter() == NotificationManager.INTERRUPTION_FILTER_NONE;
        } catch (SecurityException ignored) { return false; }
    }

    private void openDndAccessSettings() {
        try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); }
        catch (Exception e) { toast("Do Not Disturb access settings are unavailable on this device."); }
    }

    private void toggleFocusMode() {
        if (!hasDndAccess()) {
            new AlertDialog.Builder(this).setTitle("Do Not Disturb access")
                    .setMessage("TeinTools needs special access to turn Focus mode on or off. It does not enable this access automatically.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Open settings", (d, w) -> openDndAccessSettings()).show();
            return;
        }
        boolean turnOn = !currentDndFilterIsNone();
        new AlertDialog.Builder(this).setTitle(turnOn ? "Turn Focus mode on?" : "Turn Focus mode off?")
                .setMessage(turnOn ? "Android may silence calls and notifications while Focus mode is active." : "Restore normal notification delivery by switching the interruption filter to All.")
                .setNegativeButton("Cancel", null).setPositiveButton(turnOn ? "Turn on" : "Turn off", (d, w) -> {
                    try {
                        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                        if (manager != null) manager.setInterruptionFilter(turnOn ? NotificationManager.INTERRUPTION_FILTER_NONE : NotificationManager.INTERRUPTION_FILTER_ALL);
                        toast(turnOn ? "Focus mode enabled." : "Focus mode disabled.");
                        renderPage("battery");
                    } catch (Exception e) { toast("Android refused the Focus mode change: " + safeMessage(e)); }
                }).show();
    }

    private void buildThermalPage(LinearLayout body) {
        addSectionTitle(body, "Device thermal status", "The state reported by Android; actual sensors differ by device");
        LinearLayout status = card(null, null, true);
        String state = "Not reported";
        String advice = "Use the phone normally and keep ventilation clear.";
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                PowerManager manager = getSystemService(PowerManager.class);
                int value = manager == null ? PowerManager.THERMAL_STATUS_NONE : manager.getCurrentThermalStatus();
                state = thermalStatus(value);
                if (value >= PowerManager.THERMAL_STATUS_SEVERE) advice = "High thermal status: pause heavy work, unplug charging if safe, and let the phone cool in a ventilated place.";
                else if (value >= PowerManager.THERMAL_STATUS_MODERATE) advice = "Thermal pressure is elevated. Reduce heavy workload and check again shortly.";
            } catch (Exception ignored) { state = "Not exposed by the vendor"; }
        }
        status.addView(label(state, 27, textColor(), true));
        addText(status, advice, 12, muted(), false, dp(6));
        body.addView(status, marginParams(-1, -2, 0, 0, 0, dp(14)));
        Intent batt = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int temp = batt == null ? -1 : batt.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        LinearLayout readings = card(null, null, false);
        addKeyValue(readings, "Battery temperature", temp < 0 ? "Not available" : String.format(Locale.US, "%.1f °C", temp / 10f));
        addKeyValue(readings, "Thermal status API", Build.VERSION.SDK_INT >= 29 ? "Available; values vendor-dependent" : "Not available on this Android version");
        body.addView(readings, marginParams(-1, -2, 0, 0, 0, dp(12)));
        addActionButton(body, "Open battery usage", "Review the apps consuming power in Android settings", () -> launchSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        addActionButton(body, "Review running background apps", "Use RAM Booster to review eligible background processes", () -> renderPage("ram"));
        body.addView(card("Thermal Monitor is not a cooler", "TeinTools does not overclock, underclock, change CPU governor, or promise artificial temperature drops. It displays supported readings and gives safe system shortcuts.", false), marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void buildDevicePage(LinearLayout body) {
        LinearLayout hero = card(null, null, true);
        hero.addView(label(deviceName(), 21, Color.WHITE, true));
        addText(hero, Build.MANUFACTURER + " · " + Build.MODEL, 12, Color.argb(220,255,255,255), false, dp(5));
        TextView refresh = pill("Refresh readings", Color.argb(38,255,255,255), Color.WHITE, 42);
        refresh.setOnClickListener(v -> renderPage("device"));
        hero.addView(refresh, marginParams(-1, -2, 0, dp(14), 0, 0));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addSectionTitle(body, "Memory and storage", "Available capacity reported by Android");
        LinearLayout memory = card(null, null, false);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        addKeyValue(memory, "Available RAM", formatBytes(mi.availMem));
        addKeyValue(memory, "Total RAM", formatBytes(mi.totalMem));
        addKeyValue(memory, "Low-memory state", mi.lowMemory ? "System reports low memory" : "Normal");
        StatFs s = new StatFs(Environment.getDataDirectory().getAbsolutePath());
        addKeyValue(memory, "Internal storage free", formatBytes(s.getAvailableBytes()));
        addKeyValue(memory, "Internal storage total", formatBytes(s.getTotalBytes()));
        body.addView(memory, marginParams(-1, -2, 0, 0, 0, dp(15)));

        addSectionTitle(body, "Battery and temperature", "Values supplied by the device");
        LinearLayout battery = card(null, null, false);
        Intent intent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (intent != null) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int percent = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
            addKeyValue(battery, "Battery level", percent >= 0 ? percent + "%" : "Unavailable");
            int temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            addKeyValue(battery, "Battery temperature", temp >= 0 ? String.format(Locale.US, "%.1f °C", temp / 10f) : "Unavailable");
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            addKeyValue(battery, "Charging", status == BatteryManager.BATTERY_STATUS_CHARGING ? "Charging" : status == BatteryManager.BATTERY_STATUS_FULL ? "Full" : "Not charging");
            int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            addKeyValue(battery, "Battery health", batteryHealth(health));
        } else addKeyValue(battery, "Battery status", "Unavailable");
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                PowerManager pm = getSystemService(PowerManager.class);
                addKeyValue(battery, "Thermal status", pm == null ? "Unavailable" : thermalStatus(pm.getCurrentThermalStatus()));
            } catch (Exception ex) { addKeyValue(battery, "Thermal status", "Not exposed by this device"); }
        }
        body.addView(battery, marginParams(-1, -2, 0, 0, 0, dp(15)));

        addSectionTitle(body, "System profile", "Static device and OS details");
        LinearLayout details = card(null, null, false);
        addKeyValue(details, "Android version", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        addKeyValue(details, "Build fingerprint", shorten(Build.FINGERPRINT, 62));
        addKeyValue(details, "CPU ABI", join(Build.SUPPORTED_ABIS, ", "));
        addKeyValue(details, "Available CPU cores", String.valueOf(Runtime.getRuntime().availableProcessors()));
        addKeyValue(details, "App target SDK", "29 (Android 10 compatibility target)");
        body.addView(details, marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void buildSensorPage(LinearLayout body) {
        SensorManager manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensors = manager == null
                ? Collections.emptyList()
                : manager.getSensorList(Sensor.TYPE_ALL);

        LinearLayout hero = card(null, null, true);
        hero.addView(label("Sensor Lab", 21, textColor(), true));
        addText(hero, sensors.size() + " sensor(s) reported by Android", 12, muted(), false, dp(5));
        TextView refresh = pill("Refresh inventory", isLight() ? Color.rgb(228, 230, 233) : Color.argb(38, 255, 255, 255), textColor(), 42);
        refresh.setOnClickListener(v -> renderPage("sensors"));
        hero.addView(refresh, marginParams(-1, -2, 0, dp(14), 0, 0));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addSectionTitle(body, "Hardware sensor inventory", "The list is supplied by Android and varies by device and firmware");
        if (sensors.isEmpty()) {
            body.addView(card("No sensors reported", "Android did not return a sensor inventory for this device.", false),
                    marginParams(-1, -2, 0, 0, 0, dp(12)));
        } else {
            for (Sensor sensor : sensors) {
                if (sensor == null) continue;
                String title = sensor.getName() == null || sensor.getName().trim().isEmpty()
                        ? sensorTypeLabel(sensor.getType()) : sensor.getName();
                LinearLayout item = card(title, sensorTypeLabel(sensor.getType()), false);
                addKeyValue(item, "Vendor", blankFallback(sensor.getVendor(), "Not reported"));
                addKeyValue(item, "Type", sensor.getStringType() + " · ID " + sensor.getType());
                addKeyValue(item, "Maximum range", String.format(Locale.US, "%.3f", sensor.getMaximumRange()));
                addKeyValue(item, "Resolution", String.format(Locale.US, "%.5f", sensor.getResolution()));
                addKeyValue(item, "Power", String.format(Locale.US, "%.3f mA", sensor.getPower()));
                addKeyValue(item, "Minimum delay", sensor.getMinDelay() > 0 ? sensor.getMinDelay() + " µs" : "On-change / not reported");
                addKeyValue(item, "Wake-up sensor", sensor.isWakeUpSensor() ? "Yes" : "No");
                body.addView(item, marginParams(-1, -2, 0, 0, 0, dp(9)));
            }
        }
        body.addView(card("Reading limitations", "This page lists sensor metadata only; it does not record live measurements. Sensor availability, reported ranges and power values can be vendor-specific. Some entries may be logical or fused sensors rather than separate physical chips.", false),
                marginParams(-1, -2, 0, dp(4), 0, dp(20)));
    }

    private String sensorTypeLabel(int type) {
        switch (type) {
            case Sensor.TYPE_ACCELEROMETER: return "Accelerometer";
            case Sensor.TYPE_MAGNETIC_FIELD: return "Magnetic field";
            case Sensor.TYPE_ORIENTATION: return "Orientation (legacy)";
            case Sensor.TYPE_GYROSCOPE: return "Gyroscope";
            case Sensor.TYPE_LIGHT: return "Ambient light";
            case Sensor.TYPE_PRESSURE: return "Air pressure";
            case Sensor.TYPE_TEMPERATURE: return "Temperature (legacy)";
            case Sensor.TYPE_PROXIMITY: return "Proximity";
            case Sensor.TYPE_GRAVITY: return "Gravity";
            case Sensor.TYPE_LINEAR_ACCELERATION: return "Linear acceleration";
            case Sensor.TYPE_ROTATION_VECTOR: return "Rotation vector";
            case Sensor.TYPE_RELATIVE_HUMIDITY: return "Relative humidity";
            case Sensor.TYPE_AMBIENT_TEMPERATURE: return "Ambient temperature";
            case Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED: return "Magnetic field (uncalibrated)";
            case Sensor.TYPE_GAME_ROTATION_VECTOR: return "Game rotation vector";
            case Sensor.TYPE_GYROSCOPE_UNCALIBRATED: return "Gyroscope (uncalibrated)";
            case Sensor.TYPE_SIGNIFICANT_MOTION: return "Significant motion";
            case Sensor.TYPE_STEP_DETECTOR: return "Step detector";
            case Sensor.TYPE_STEP_COUNTER: return "Step counter";
            case Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR: return "Geomagnetic rotation vector";
            case Sensor.TYPE_HEART_RATE: return "Heart rate";
            case Sensor.TYPE_POSE_6DOF: return "6-DoF pose";
            case Sensor.TYPE_STATIONARY_DETECT: return "Stationary detection";
            case Sensor.TYPE_MOTION_DETECT: return "Motion detection";
            case Sensor.TYPE_HEART_BEAT: return "Heart beat";
            case Sensor.TYPE_LOW_LATENCY_OFFBODY_DETECT: return "Off-body detection";
            case Sensor.TYPE_HINGE_ANGLE: return "Hinge angle";
            default: return "Sensor type " + type;
        }
    }

    private String blankFallback(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }

    private void buildNetworkPage(LinearLayout body) {
        addSectionTitle(body, "Connection overview", "Current network as seen by Android");
        LinearLayout info = card(null, null, false);
        addKeyValue(info, "Connectivity", networkSummary());
        addKeyValue(info, "Wi-Fi details", wifiSummary());
        addKeyValue(info, "Downstream estimate", networkBandwidth());
        body.addView(info, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addSectionTitle(body, "Run diagnostics", "Each test runs only when selected");
        LinearLayout results = card(null, null, false);
        networkProgress = new ProgressBar(this);
        networkProgress.setIndeterminate(true);
        networkProgress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
        networkProgress.setVisibility(View.GONE);
        results.addView(networkProgress, marginParams(dp(24), dp(24), 0, 0, 0, dp(8)));
        networkResultText = label("Ready. Choose a test below.", 12, muted(), false);
        results.addView(networkResultText);
        body.addView(results, marginParams(-1, -2, 0, 0, 0, dp(13)));

        addActionButton(body, "Test HTTPS connectivity", "Checks a public connectivity endpoint", () -> runNetworkTest("HTTPS", this::testHttps));
        addActionButton(body, "Resolve DNS", "Resolves example.com through the configured resolver", () -> runNetworkTest("DNS", this::testDns));
        addActionButton(body, "TCP latency", "Measures a TCP connection to 1.1.1.1:443", () -> runNetworkTest("TCP", this::testTcp));
        addActionButton(body, "Estimate download speed", "Downloads a small test payload; data usage applies", () -> runNetworkTest("Speed", this::testDownloadSpeed));
        addActionButton(body, "Open Wi-Fi settings", "Use Android's native network controls", () -> launchSettings(Settings.ACTION_WIFI_SETTINGS));
        addText(body, "Note: ICMP ping and Wi-Fi scans can be blocked or throttled on Android. These tests use HTTPS, DNS, and TCP instead of reporting unreliable fake ping values.", 10, muted(), false, dp(16));
    }

    private void runNetworkTest(String label, NetworkTest test) {
        if (networkResultText != null) networkResultText.setText(label + " · checking connection…");
        if (networkProgress != null) networkProgress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            String result;
            try { result = test.run(); }
            catch (Exception ex) { result = "Failed: " + safeMessage(ex); }
            final String finalResult = result;
            runOnUiThread(() -> {
                if (networkProgress != null) networkProgress.setVisibility(View.GONE);
                if (networkResultText != null) networkResultText.setText(label + "\n" + finalResult);
            });
        }, "tein-network-test").start();
    }

    private String testHttps() throws Exception {
        long start = SystemClock.elapsedRealtime();
        HttpURLConnection c = (HttpURLConnection)new URL("https://connectivitycheck.gstatic.com/generate_204").openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(7000); c.setInstanceFollowRedirects(false); c.setRequestMethod("GET");
        int code = c.getResponseCode();
        long elapsed = SystemClock.elapsedRealtime() - start;
        c.disconnect();
        return "HTTP " + code + " in " + elapsed + " ms" + (code == 204 ? " · Internet reachable" : " · Endpoint replied");
    }

    private String testDns() throws Exception {
        long start = SystemClock.elapsedRealtime();
        InetAddress[] addresses = InetAddress.getAllByName("example.com");
        long elapsed = SystemClock.elapsedRealtime() - start;
        String ip = addresses.length > 0 ? addresses[0].getHostAddress() : "No address returned";
        return "example.com → " + ip + "\nResolved in " + elapsed + " ms";
    }

    private String testTcp() throws Exception {
        long start = SystemClock.elapsedRealtime();
        Socket socket = new Socket();
        socket.connect(new InetSocketAddress("1.1.1.1", 443), 6000);
        long elapsed = SystemClock.elapsedRealtime() - start;
        socket.close();
        return "TCP connect succeeded in " + elapsed + " ms";
    }

    private String testDownloadSpeed() throws Exception {
        URLConnection c = new URL("https://speed.cloudflare.com/__down?bytes=2000000").openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(10000);
        long start = SystemClock.elapsedRealtime();
        long bytes = 0L;
        byte[] buffer = new byte[32768];
        try (InputStream in = c.getInputStream()) {
            int n;
            while ((n = in.read(buffer)) != -1) bytes += n;
        }
        long elapsed = Math.max(1L, SystemClock.elapsedRealtime() - start);
        double mbps = (bytes * 8.0) / (elapsed / 1000.0) / 1_000_000.0;
        return String.format(Locale.US, "Received %s in %.2f s\nEstimated throughput: %.2f Mbps", formatBytes(bytes), elapsed / 1000.0, mbps);
    }

    private interface NetworkTest { String run() throws Exception; }

    private void buildFlashPage(LinearLayout body) {
        LinearLayout hero = card(null, null, true);
        FrameLayout icon = iconBadge("flash", 78, 38);
        icon.setAlpha(torchOn ? 1f : 0.82f);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(78), dp(78));
        iconLp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(icon, iconLp);
        TextView state = label(torchOn ? "Flashlight is ON" : "Flashlight is OFF", 19, Color.WHITE, true);
        state.setGravity(Gravity.CENTER);
        hero.addView(state, marginParams(-1, -2, 0, dp(3), 0, 0));
        TextView toggle = pill(torchOn ? "Turn off" : "Turn on", Color.argb(45, 255,255,255), Color.WHITE, 46);
        toggle.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                pendingTorchOn = true;
                requestCameraPermissionWithRationale("flashlight control");
            } else {
                setTorch(!torchOn);
                renderPage("flash");
            }
        });
        hero.addView(toggle, marginParams(-1, -2, 0, dp(18), dp(6), dp(4)));
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(15)));
        LinearLayout note = card("Compatibility", "The torch is controlled through Android's Camera2 API. Some devices cannot turn on the torch when another app is using the camera, and some devices do not have a flash.", false);
        body.addView(note, marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void setTorch(boolean enabled) {
        try {
            CameraManager manager = (CameraManager)getSystemService(CAMERA_SERVICE);
            String selected = null;
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Boolean hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(hasFlash)) {
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { selected = id; break; }
                    if (selected == null) selected = id;
                }
            }
            if (selected == null) { toast("This device does not report a camera flash."); return; }
            manager.setTorchMode(selected, enabled);
            torchOn = enabled;
        } catch (Exception ex) {
            toast("Cannot control torch: " + safeMessage(ex));
            torchOn = false;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            boolean writeGranted = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
            pendingStorageScan = false;
            if (granted && writeGranted) {
                if ("storage".equals(currentPage)) scanSafeJunkFiles();
                else toast("Storage permission granted.");
            } else {
                toast("Storage permission was declined. Storage scan remains disabled.");
                if ("permissions".equals(currentPage) || "storage".equals(currentPage)) renderPage(currentPage);
            }
            return;
        }
        if (requestCode != REQ_CAMERA) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        boolean doTorch = pendingTorchOn;
        boolean doQr = pendingQrScan;
        boolean refreshInspector = pendingPermissionRefresh;
        pendingTorchOn = false;
        pendingQrScan = false;
        pendingPermissionRefresh = false;
        if (granted) {
            if (doTorch) {
                setTorch(true);
                renderPage("flash");
            } else if (doQr) {
                launchQrScanner();
            } else if (refreshInspector && "permissions".equals(currentPage)) {
                renderPage("permissions");
            } else {
                toast("Camera permission granted.");
            }
        } else {
            toast("Camera permission was not granted. Other tools remain available.");
            if ("permissions".equals(currentPage)) renderPage("permissions");
        }
    }

    private void buildCalculatorPage(LinearLayout body) {
        LinearLayout panel = card(null, null, false);
        EditText display = new EditText(this);
        display.setSingleLine(false);
        display.setMinLines(2);
        display.setMaxLines(3);
        display.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        display.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        display.setTextColor(textColor());
        display.setHintTextColor(muted());
        display.setHint("0");
        display.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        display.setPadding(dp(10), dp(15), dp(10), dp(15));
        display.setBackground(solid(roundRect(surfaceRaised(), dp(18), borderColor())));
        display.setText(calcExpression);
        panel.addView(display, marginParams(-1, dp(100), 0, 0, 0, dp(14)));
        String[][] keys = {{"C", "⌫", "%", "÷"}, {"7", "8", "9", "×"}, {"4", "5", "6", "−"}, {"1", "2", "3", "+"}, {"(", "0", ".", ")"}, {"±", "="}};
        for (String[] rowKeys : keys) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (String key : rowKeys) {
                TextView button = pill(key, isOperator(key) ? blend(accent(), surface(), isLight() ? 0.82f : 0.66f) : surfaceRaised(), isOperator(key) ? accent() : textColor(), 52);
                button.setTextSize(19);
                button.setOnClickListener(v -> {
                    String newExpression = display.getText().toString();
                    switch (key) {
                        case "C": newExpression = ""; break;
                        case "⌫": if (!newExpression.isEmpty()) newExpression = newExpression.substring(0, newExpression.length() - 1); break;
                        case "=":
                            try { double value = new ExpressionParser(newExpression).parse(); newExpression = formatNumber(value); }
                            catch (Exception e) { newExpression = "Error"; }
                            break;
                        case "±":
                            if (!newExpression.isEmpty() && !"Error".equals(newExpression)) newExpression = "(" + newExpression + ")*-1";
                            break;
                        default:
                            if ("Error".equals(newExpression)) newExpression = "";
                            newExpression += key.equals("×") ? "*" : key.equals("÷") ? "/" : key.equals("−") ? "-" : key;
                    }
                    calcExpression = newExpression;
                    display.setText(newExpression);
                    display.setSelection(display.getText().length());
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                row.addView(button, lp);
            }
            panel.addView(row);
        }
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(16)));
        addText(body, "Supports +, −, ×, ÷, parentheses, and %. Calculations run locally.", 10, muted(), false, dp(14));
    }

    private boolean isOperator(String s) { return "+".equals(s) || "−".equals(s) || "×".equals(s) || "÷".equals(s) || "=".equals(s) || "%".equals(s); }

    private static class ExpressionParser {
        private final String s; private int pos = -1; private int ch;
        ExpressionParser(String input) { s = input.replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", ""); }
        void nextChar() { ch = (++pos < s.length()) ? s.charAt(pos) : -1; }
        boolean eat(int c) { while (ch == ' ') nextChar(); if (ch == c) { nextChar(); return true; } return false; }
        double parse() { nextChar(); double x = parseExpression(); if (pos < s.length()) throw new RuntimeException("Unexpected character"); if (Double.isNaN(x) || Double.isInfinite(x)) throw new RuntimeException("Invalid result"); return x; }
        double parseExpression() { double x = parseTerm(); for (;;) { if (eat('+')) x += parseTerm(); else if (eat('-')) x -= parseTerm(); else return x; } }
        double parseTerm() { double x = parseFactor(); for (;;) { if (eat('*')) x *= parseFactor(); else if (eat('/')) { double d = parseFactor(); if (d == 0) throw new RuntimeException("Divide by zero"); x /= d; } else if (eat('%')) { double d = parseFactor(); if (d == 0) throw new RuntimeException("Divide by zero"); x %= d; } else return x; } }
        double parseFactor() {
            if (eat('+')) return parseFactor();
            if (eat('-')) return -parseFactor();
            double x; int start = this.pos;
            if (eat('(')) { x = parseExpression(); if (!eat(')')) throw new RuntimeException("Missing )"); }
            else if ((ch >= '0' && ch <= '9') || ch == '.') { while ((ch >= '0' && ch <= '9') || ch == '.') nextChar(); x = Double.parseDouble(s.substring(start, this.pos)); }
            else throw new RuntimeException("Number expected");
            return x;
        }
    }

    private void buildNotesPage(LinearLayout body) {
        LinearLayout panel = card(null, null, false);
        addText(panel, "Notes are stored locally on this device.", 12, muted(), false, dp(6));
        EditText editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setTextSize(15);
        editor.setTextColor(textColor());
        editor.setHintTextColor(muted());
        editor.setHint("Write a reminder or idea…");
        editor.setMinLines(10);
        editor.setMaxLines(20);
        editor.setPadding(dp(13), dp(13), dp(13), dp(13));
        editor.setBackground(solid(roundRect(surfaceRaised(), dp(16), borderColor())));
        editor.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString("notes", ""));
        panel.addView(editor, marginParams(-1, -2, 0, dp(12), 0, 0));
        TextView status = label("Saved automatically", 10, muted(), false);
        panel.addView(status, marginParams(-1, -2, 0, dp(8), 0, 0));
        editor.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("notes", s.toString()).apply();
                status.setText("Saved locally · " + s.length() + " characters");
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addActionButton(body, "Share note", "Open Android share sheet", () -> shareText("TeinTools note", editor.getText().toString()));
    }

    private void buildQrPage(LinearLayout body) {
        LinearLayout scanCard = card(null, null, false);
        scanCard.addView(label("Scan a QR code", 16, textColor(), true));
        addText(scanCard, "The camera opens only after you press Scan.", 11, muted(), false, dp(5));
        TextView scan = pill("Scan QR code", accent(), Color.WHITE, 46);
        scan.setOnClickListener(v -> startQrScan());
        scanCard.addView(scan, marginParams(-1, -2, 0, dp(14), 0, 0));
        body.addView(scanCard, marginParams(-1, -2, 0, 0, 0, dp(14)));

        LinearLayout gen = card(null, null, false);
        gen.addView(label("Create a QR code", 16, textColor(), true));
        qrInputField = editField("Text or URL to encode", false);
        gen.addView(qrInputField, marginParams(-1, dp(54), 0, dp(10), 0, 0));
        TextView generate = pill("Generate QR", blend(accent(), surface(), isLight() ? 0.78f : 0.65f), accent(), 44);
        generate.setOnClickListener(v -> generateQr());
        gen.addView(generate, marginParams(-1, -2, 0, dp(10), 0, 0));
        qrPreview = new ImageView(this);
        qrPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrPreview.setPadding(dp(12), dp(12), dp(12), dp(12));
        qrPreview.setBackground(solid(roundRect(Color.WHITE, dp(18), borderColor())));
        gen.addView(qrPreview, marginParams(-1, dp(260), dp(12), dp(4), dp(12), dp(4)));
        TextView save = pill("Save QR to Pictures/TeinTools", surfaceRaised(), textColor(), 44);
        save.setOnClickListener(v -> saveQrBitmap());
        gen.addView(save, marginParams(-1, -2, 0, dp(9), 0, 0));
        body.addView(gen, marginParams(-1, -2, 0, 0, 0, dp(20)));
    }

    private void generateQr() {
        if (qrInputField == null || qrInputField.getText().toString().trim().isEmpty()) { toast("Enter some text or a URL first."); return; }
        try {
            String text = qrInputField.getText().toString().trim();
            BitMatrix matrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 600, 600);
            int width = matrix.getWidth(), height = matrix.getHeight();
            int[] pixels = new int[width * height];
            for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) pixels[y * width + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
            lastQrBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            lastQrBitmap.setPixels(pixels, 0, width, 0, 0, width, height);
            qrPreview.setImageBitmap(lastQrBitmap);
        } catch (WriterException e) { toast("QR could not be generated."); }
    }

    private void saveQrBitmap() {
        if (lastQrBitmap == null) { toast("Generate a QR code first."); return; }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "TeinTools-QR-" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TeinTools");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            ContentResolver resolver = getContentResolver();
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("Could not create image entry");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("Could not open image output");
                lastQrBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            ContentValues done = new ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING, 0); resolver.update(uri, done, null, null);
            toast("QR saved to Pictures/TeinTools");
        } catch (Exception e) { toast("Could not save QR: " + safeMessage(e)); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanResult != null) {
            if (scanResult.getContents() != null) {
                String contents = scanResult.getContents();
                renderPage("qr");
                if (qrInputField != null) qrInputField.setText(contents);
                toast("QR scanned: " + shorten(contents, 100));
            } else toast("Scan cancelled.");
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_CREATE_FILE) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("No file stream");
                String content = fileContentField == null ? "Created with TeinTools\n" : fileContentField.getText().toString();
                out.write(content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                toast("File saved successfully.");
            } catch (Exception e) { toast("Could not write file: " + safeMessage(e)); }
        } else if (requestCode == REQ_OPEN_FILE || requestCode == REQ_OPEN_IMAGE) {
            toast("Selected: " + queryDisplayName(uri));
        }
    }

    private void buildStopwatchPage(LinearLayout body) {
        LinearLayout panel = card(null, null, true);
        stopwatchDisplay = label(formatStopwatch(stopwatchAccumulated + (stopwatchRunning ? SystemClock.elapsedRealtime() - stopwatchStartedAt : 0L)), 42, Color.WHITE, true);
        stopwatchDisplay.setGravity(Gravity.CENTER);
        stopwatchDisplay.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        panel.addView(stopwatchDisplay, new LinearLayout.LayoutParams(-1, dp(132)));
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView start = pill(stopwatchRunning ? "Pause" : "Start", Color.argb(48,255,255,255), Color.WHITE, 48);
        start.setOnClickListener(v -> {
            if (stopwatchRunning) {
                stopwatchAccumulated += SystemClock.elapsedRealtime() - stopwatchStartedAt;
                stopwatchRunning = false;
            } else {
                stopwatchStartedAt = SystemClock.elapsedRealtime();
                stopwatchRunning = true;
            }
            handler.removeCallbacks(stopwatchTick);
            renderPage("stopwatch");
        });
        TextView reset = pill("Reset", Color.argb(28,255,255,255), Color.WHITE, 48);
        reset.setOnClickListener(v -> { stopwatchRunning = false; stopwatchAccumulated = 0L; stopwatchStartedAt = 0L; handler.removeCallbacks(stopwatchTick); renderPage("stopwatch"); });
        actions.addView(start, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(reset, new LinearLayout.LayoutParams(0, dp(48), 1));
        panel.addView(actions, marginParams(-1, -2, 0, dp(5), 0, 0));
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addText(body, "Uses Android's monotonic elapsed-realtime clock. The stopwatch continues while the app process remains active.", 10, muted(), false, dp(12));
    }

    private void buildTimerPage(LinearLayout body) {
        LinearLayout panel = card(null, null, true);
        timerDisplay = label(formatTimer(timerRunning ? timerEndsAt - SystemClock.elapsedRealtime() : timerOriginalDuration), 42, Color.WHITE, true);
        timerDisplay.setGravity(Gravity.CENTER);
        timerDisplay.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        panel.addView(timerDisplay, new LinearLayout.LayoutParams(-1, dp(122)));
        EditText mins = editField("Minutes", true);
        mins.setText("5");
        panel.addView(mins, marginParams(-1, dp(52), 0, dp(8), 0, 0));
        EditText secs = editField("Seconds", true);
        secs.setText("0");
        panel.addView(secs, marginParams(-1, dp(52), 0, dp(8), 0, 0));
        TextView start = pill(timerRunning ? "Restart timer" : "Start timer", Color.argb(48,255,255,255), Color.WHITE, 47);
        start.setOnClickListener(v -> {
            try {
                long m = Long.parseLong(mins.getText().toString().trim().isEmpty() ? "0" : mins.getText().toString().trim());
                long s = Long.parseLong(secs.getText().toString().trim().isEmpty() ? "0" : secs.getText().toString().trim());
                long duration = Math.max(0L, m * 60_000L + s * 1000L);
                if (duration <= 0L || duration > 24L * 60L * 60L * 1000L) { toast("Set a duration between 1 second and 24 hours."); return; }
                timerOriginalDuration = duration;
                timerEndsAt = SystemClock.elapsedRealtime() + duration;
                timerRunning = true;
                handler.removeCallbacks(timerTick); handler.post(timerTick);
                renderPage("timer");
            } catch (NumberFormatException ex) { toast("Enter a valid number of minutes and seconds."); }
        });
        panel.addView(start, marginParams(-1, -2, 0, dp(14), 0, 0));
        TextView cancel = pill("Cancel / reset", Color.argb(25,255,255,255), Color.WHITE, 43);
        cancel.setOnClickListener(v -> { timerRunning = false; timerEndsAt = 0L; timerOriginalDuration = 0L; handler.removeCallbacks(timerTick); renderPage("timer"); });
        panel.addView(cancel, marginParams(-1, -2, 0, dp(8), 0, 0));
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addText(body, "The timer is active while the app process is alive. Closing or force-stopping the app can end the countdown; it is not an alarm-clock service.", 10, muted(), false, dp(12));
    }

    private void updateTimerLabel() {
        if (timerDisplay != null) timerDisplay.setText(formatTimer(timerRunning ? timerEndsAt - SystemClock.elapsedRealtime() : timerOriginalDuration));
    }

    private void buildConverterPage(LinearLayout body) {
        LinearLayout panel = card(null, null, false);
        panel.addView(label("Convert a value", 16, textColor(), true));
        EditText amount = editField("Enter value", true);
        amount.setText("1");
        panel.addView(amount, marginParams(-1, dp(54), 0, dp(11), 0, 0));
        String[] conversions = {"m → km", "km → m", "cm → m", "m → cm", "°C → °F", "°F → °C", "MB → GB", "GB → MB", "km/h → mph", "mph → km/h"};
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, conversions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        panel.addView(spinner, marginParams(-1, dp(52), 0, dp(9), 0, 0));
        TextView output = label("Result appears here", 18, accent(), true);
        output.setPadding(dp(5), dp(17), dp(5), dp(17));
        panel.addView(output);
        TextView convert = pill("Convert", blend(accent(), surface(), isLight() ? 0.78f : 0.66f), accent(), 46);
        convert.setOnClickListener(v -> {
            try {
                double x = Double.parseDouble(amount.getText().toString().trim());
                double y;
                String unit = (String)spinner.getSelectedItem();
                switch (unit) {
                    case "m → km": y = x / 1000; break;
                    case "km → m": y = x * 1000; break;
                    case "cm → m": y = x / 100; break;
                    case "m → cm": y = x * 100; break;
                    case "°C → °F": y = x * 9 / 5 + 32; break;
                    case "°F → °C": y = (x - 32) * 5 / 9; break;
                    case "MB → GB": y = x / 1000; break;
                    case "GB → MB": y = x * 1000; break;
                    case "km/h → mph": y = x * 0.621371; break;
                    default: y = x / 0.621371; break;
                }
                output.setText(formatNumber(y) + "   " + unit.substring(unit.indexOf('→') + 1).trim());
            } catch (Exception e) { output.setText("Enter a valid number."); }
        });
        panel.addView(convert, marginParams(-1, -2, 0, dp(6), 0, 0));
        body.addView(panel, marginParams(-1, -2, 0, 0, 0, dp(15)));
        addText(body, "Data size conversions use decimal units (1 GB = 1000 MB).", 10, muted(), false, dp(12));
    }

    private void buildFilesPage(LinearLayout body) {
        LinearLayout info = card("Storage Access Framework", "Files are chosen with Android's system document picker. TeinTools does not request full-storage access.", false);
        body.addView(info, marginParams(-1, -2, 0, 0, 0, dp(14)));
        addActionButton(body, "Open a file", "Select a document from a provider on this device", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i, REQ_OPEN_FILE);
        });
        addActionButton(body, "Pick an image", "Choose an image using Android's picker", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i, REQ_OPEN_IMAGE);
        });
        LinearLayout content = card(null, null, false);
        content.addView(label("Create a text file", 15, textColor(), true));
        fileContentField = editField("Text to save…", false);
        fileContentField.setMinLines(5);
        fileContentField.setGravity(Gravity.TOP | Gravity.START);
        content.addView(fileContentField, marginParams(-1, dp(150), 0, dp(10), 0, 0));
        TextView save = pill("Save with Android picker", accent(), Color.WHITE, 45);
        save.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TITLE, "TeinTools-note.txt"); startActivityForResult(i, REQ_CREATE_FILE);
        });
        content.addView(save, marginParams(-1, -2, 0, dp(9), 0, 0));
        body.addView(content, marginParams(-1, -2, 0, 0, 0, dp(18)));
    }

    private void buildAppsPage(LinearLayout body) {
        addText(body, "Open Android's App Info screen to manage permissions, battery use, or storage for a selected app. TeinTools does not force-stop other apps.", 11, muted(), false, dp(10));
        EditText search = editField("Search installed apps", false);
        body.addView(search, marginParams(-1, dp(52), 0, dp(5), 0, dp(10)));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list, new LinearLayout.LayoutParams(-1, -2));
        try {
            installedAppsCache = getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA);
            Collections.sort(installedAppsCache, Comparator.comparing(a -> String.valueOf(getPackageManager().getApplicationLabel(a)).toLowerCase(Locale.ROOT)));
        } catch (Exception e) { installedAppsCache = new ArrayList<>(); }
        Runnable update = () -> {
            list.removeAllViews();
            String query = search.getText().toString().toLowerCase(Locale.ROOT).trim();
            int count = 0;
            for (ApplicationInfo app : installedAppsCache) {
                boolean system = (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                String name = String.valueOf(getPackageManager().getApplicationLabel(app));
                if (system && !query.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(query)) continue;
                if (system && query.isEmpty()) continue;
                if (!name.toLowerCase(Locale.ROOT).contains(query) && !app.packageName.toLowerCase(Locale.ROOT).contains(query)) continue;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(13), dp(12), dp(13), dp(12));
                row.setBackground(solid(roundRect(surface(), dp(15), borderColor())));
                LinearLayout labels = new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL);
                labels.addView(label(name, 13, textColor(), true));
                labels.addView(label(app.packageName, 9, muted(), false));
                row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
                row.addView(new LineIconView(this, "back", accent()), new LinearLayout.LayoutParams(dp(18), dp(18)));
                row.setOnClickListener(v -> {
                    try { Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.packageName)); startActivity(i); }
                    catch (Exception e) { toast("Cannot open app settings."); }
                });
                LinearLayout.LayoutParams rp = marginParams(-1, -2, 0, dp(3), 0, dp(3));
                list.addView(row, rp);
                count++;
                if (count >= 80) break;
            }
            if (count == 0) addText(list, "No matching apps found.", 12, muted(), false, dp(12));
        };
        update.run();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { update.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void buildCleanerPage(LinearLayout body) {
        android.content.SharedPreferences runPrefs = getSharedPreferences(CacheCleanerAccessibilityService.PREFS, MODE_PRIVATE);
        boolean active = runPrefs.getBoolean("active", false);
        boolean usage = hasUsageStatsAccess();
        boolean service = isCacheAccessibilityEnabled();
        addSectionTitle(body, "1-Tap Cache Cleaner", "Per-app cache via Android Settings · locally automated by your explicit action");

        LinearLayout hero = card(null, null, true);
        hero.addView(label(cachedApps.isEmpty() ? "—" : formatBytes(totalMeasuredCache()), 34, textColor(), true));
        addText(hero, usage ? (cachedApps.size() + " apps with measurable cache in the latest scan") : "Usage Access is needed to measure per-app cache sizes.", 11, muted(), false, dp(5));
        ProgressBar scanProgress = new ProgressBar(this);
        scanProgress.setIndeterminate(true); scanProgress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
        scanProgress.setVisibility(cacheScanRunning ? View.VISIBLE : View.GONE);
        hero.addView(scanProgress, marginParams(dp(24), dp(24), 0, dp(8), 0, 0));
        addActionButton(hero, cacheScanRunning ? "Scanning app cache…" : "Scan app cache sizes", "Uses Usage Access; scanning can take several seconds", this::scanCachedApps);
        body.addView(hero, marginParams(-1, -2, 0, 0, 0, dp(13)));

        LinearLayout access = card(null, null, false);
        addPermissionStatusLine(access, "Accessibility automation", service);
        addPermissionStatusLine(access, "Usage Access (cache sizes)", usage);
        addText(access, "The cleaner navigates App info → Storage → Clear cache using exact visible labels. It never clicks Clear data/Erase storage. Some system/OEM pages may be skipped when their layout is different.", 11, muted(), false, dp(8));
        body.addView(access, marginParams(-1, -2, 0, 0, 0, dp(12)));

        CheckBox includeSystem = new CheckBox(this);
        includeSystem.setText("Include system apps (advanced)");
        includeSystem.setTextSize(12); includeSystem.setTextColor(textColor());
        includeSystem.setButtonTintList(ColorStateList.valueOf(accent()));
        includeSystem.setChecked(includeSystemCacheApps);
        includeSystem.setOnCheckedChangeListener((button, checked) -> {
            includeSystemCacheApps = checked;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("include_system_cache", checked).apply();
            cachedApps.clear(); cacheScanIncludedSystem = !checked; autoCacheScanAttempted = false;
            if ("cleaner".equals(currentPage)) renderPage("cleaner");
        });
        body.addView(includeSystem, marginParams(-1, -2, 0, dp(2), 0, dp(4)));

        if (active) {
            int index = runPrefs.getInt("index", 0) + 1;
            int total = runPrefs.getInt("total", 0);
            String current = runPrefs.getString("current", "");
            LinearLayout running = card("Cleaning in progress · " + Math.min(index, total) + "/" + total,
                    current.isEmpty() ? "Navigating system settings…" : "Current app: " + current, false);
            ProgressBar progress = new ProgressBar(this); progress.setIndeterminate(true);
            progress.setIndeterminateTintList(ColorStateList.valueOf(accent()));
            running.addView(progress, marginParams(dp(25), dp(25), 0, dp(9), 0, 0));
            body.addView(running, marginParams(-1, -2, 0, dp(5), 0, dp(6)));
            addActionButton(body, "Stop cache cleaning", "Stop the automation before the next app is handled", this::stopCacheAutomation);
        } else {
            String status = runPrefs.getString("status", cleanerFeedback);
            if (status == null || status.trim().isEmpty()) status = cleanerFeedback;
            body.addView(card("Last run", status, false), marginParams(-1, -2, 0, dp(3), 0, dp(7)));
            addActionButton(body, cacheScanRunning ? "Scanning cache sizes…" : "Start 1-Tap Clear All App Cache", "Requires Usage Access + Accessibility consent; only Clear cache labels are clicked", this::startCacheAutomation);
        }
        addActionButton(body, "Open Permission Center", "Enable only the special access required by features you use", () -> renderPage("permissions"));
        addActionButton(body, "Clear TeinTools' own cache", "Separate fallback; clears only files owned by this app", this::cleanOwnCache);
        addActionButton(body, "Open Android storage manager", "Manual fallback for apps/settings pages that cannot be automated", this::openStorageSettings);

        addSectionTitle(body, "Largest detected app caches", usage ? "Measured by Android StorageStatsManager" : "Grant Usage Access and run a scan to populate this list");
        cachedAppRows = new LinearLayout(this); cachedAppRows.setOrientation(LinearLayout.VERTICAL);
        body.addView(cachedAppRows, new LinearLayout.LayoutParams(-1, -2));
        renderCachedAppRows();
        body.addView(card("Privacy and limits", "This is a deterministic, user-started automation. The service inspects only the current Settings accessibility tree and looks for exact Storage and Clear cache labels; it does not send screen contents over the network. It may skip apps when ColorOS changes its wording or layout. After the pass, TeinTools rescans cache sizes and reports the measured difference.", false), marginParams(-1, -2, 0, dp(10), 0, dp(22)));
        if (usage && !autoCacheScanAttempted && !cacheScanRunning) {
            autoCacheScanAttempted = true;
            body.post(this::scanCachedApps);
        }
    }

    private void cleanOwnCache() {
        if (cleaningCache) { toast("Cache cleanup is already running."); return; }
        cleaningCache = true;
        cleanerFeedback = "Cleaning temporary files safely…";
        if (cacheStatusText != null) cacheStatusText.setText(cleanerFeedback);
        if (cacheProgress != null) cacheProgress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            long before = cacheSize();
            long attempted = clearDirectoryContents(getCacheDir());
            File ext = getExternalCacheDir();
            if (ext != null) attempted += clearDirectoryContents(ext);
            final long removedEstimate = Math.min(before, attempted);
            runOnUiThread(() -> {
                cleaningCache = false;
                cleanerFeedback = before == 0L
                        ? "Already clean · no temporary cache files were found."
                        : "Cleanup complete · " + formatBytes(removedEstimate) + " temporary data removed.";
                if ("cleaner".equals(currentPage)) renderPage("cleaner");
                toast(before == 0L ? "TeinTools cache is already clear." : "Removed " + formatBytes(removedEstimate) + " of TeinTools cache.");
            });
        }, "tein-cache-cleaner").start();
    }

    private long cacheSize() {
        long total = directorySize(getCacheDir());
        File ext = getExternalCacheDir();
        if (ext != null) total += directorySize(ext);
        return total;
    }

    private long directorySize(File file) {
        if (file == null || !file.exists()) return 0L;
        if (file.isFile()) return file.length();
        long total = 0L;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) total += directorySize(child);
        return total;
    }

    private long clearDirectoryContents(File directory) {
        if (directory == null || !directory.exists() || !directory.isDirectory()) return 0L;
        long removed = 0L;
        File[] children = directory.listFiles();
        if (children == null) return 0L;
        for (File child : children) {
            long size = directorySize(child);
            if (deleteRecursively(child)) removed += size;
        }
        return removed;
    }

    private boolean deleteRecursively(File file) {
        if (file == null || !file.exists()) return true;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        return file.delete() || !file.exists();
    }

    private void openStorageSettings() {
        // This is a user-controlled system screen, not a hidden global-cache permission.
        try {
            Intent manageStorage = new Intent(android.os.storage.StorageManager.ACTION_MANAGE_STORAGE);
            if (manageStorage.resolveActivity(getPackageManager()) != null) { startActivity(manageStorage); return; }
        } catch (Exception ignored) { }
        try {
            Intent intent = new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
            if (intent.resolveActivity(getPackageManager()) != null) { startActivity(intent); return; }
        } catch (Exception ignored) { }
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
            if (intent.resolveActivity(getPackageManager()) != null) { startActivity(intent); return; }
        } catch (Exception ignored) { }
        launchSettings(Settings.ACTION_SETTINGS);
    }

    private void addPermissionStatusLine(LinearLayout parent, String label, boolean granted) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = label(label, 12, textColor(), true);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView status = pill(granted ? "ACTIVE" : "NEEDED", granted ? (isLight() ? Color.rgb(226, 238, 232) : Color.rgb(28, 47, 40)) : surfaceRaised(), granted ? (isLight() ? Color.rgb(25, 105, 68) : Color.rgb(157, 235, 196)) : muted(), 28);
        row.addView(status);
        parent.addView(row, marginParams(-1, -2, 0, dp(5), 0, dp(5)));
    }

    private void renderCachedAppRows() {
        if (cachedAppRows == null) return;
        cachedAppRows.removeAllViews();
        if (cachedApps.isEmpty()) {
            String msg = hasUsageStatsAccess() ? "No measured cache list yet. Tap Scan app cache sizes." : "Usage Access is off. Enable it in Permission Center to read per-app cache sizes.";
            cachedAppRows.addView(card(null, msg, false), marginParams(-1, -2, 0, 0, 0, dp(12)));
            return;
        }
        int shown = Math.min(15, cachedApps.size());
        for (int i = 0; i < shown; i++) {
            CachedApp app = cachedApps.get(i);
            LinearLayout row = card(null, null, false);
            LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
            ImageView icon = new ImageView(this); icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            try { icon.setImageDrawable(getPackageManager().getApplicationIcon(app.packageName)); } catch (Exception e) { icon.setImageResource(R.drawable.ic_launcher); }
            line.addView(icon, new LinearLayout.LayoutParams(dp(38), dp(38)));
            LinearLayout text = new LinearLayout(this); text.setOrientation(LinearLayout.VERTICAL); text.setPadding(dp(11), 0, dp(5), 0);
            text.addView(label(app.label, 13, textColor(), true));
            text.addView(label(app.packageName, 9, muted(), false), marginParams(-1, -2, 0, dp(2), 0, 0));
            line.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
            line.addView(label(formatBytes(app.cacheBytes), 12, textColor(), true));
            row.addView(line);
            row.setOnClickListener(v -> openAppInfo(app.packageName));
            cachedAppRows.addView(row, marginParams(-1, -2, 0, 0, 0, dp(7)));
        }
        if (cachedApps.size() > shown) cachedAppRows.addView(card(null, "Showing the " + shown + " largest caches. The clear-all pass includes all " + cachedApps.size() + " measured apps in the latest scan.", false), marginParams(-1, -2, 0, 0, 0, dp(8)));
    }

    private long totalMeasuredCache() {
        long total = 0L; for (CachedApp app : cachedApps) total += Math.max(0L, app.cacheBytes); return total;
    }

    private boolean hasUsageStatsAccess() {
        try {
            AppOpsManager ops = (AppOpsManager)getSystemService(APP_OPS_SERVICE);
            return ops != null && ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) { return false; }
    }

    private boolean isCacheAccessibilityEnabled() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null) return false;
            String target = new ComponentName(this, CacheCleanerAccessibilityService.class).flattenToString();
            for (String component : enabled.split(":")) if (target.equalsIgnoreCase(component.trim())) return true;
        } catch (Exception ignored) { }
        return false;
    }

    private boolean hasStorageAccess() { return hasStorageRuntimePermission(); }
    private boolean hasModifySettingsAccess() { return Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(this); }

    private void openUsageAccessSettings() {
        try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
        catch (Exception e) { toast("Usage Access settings are unavailable on this device."); }
    }

    private void requestAccessibilitySettingsWithDisclosure() {
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean("cache_accessibility_disclosure_accepted", false)) {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception e) { toast("Accessibility settings are unavailable."); }
            return;
        }
        new AlertDialog.Builder(this).setTitle("Disclosure: Cache Cleaner uses Accessibility")
                .setMessage("If you enable this optional service, TeinTools will inspect visible Android Settings control labels during a cleanup you start manually. It will navigate to app Storage and tap only an exact Clear cache/Hapus cache control. It will not click Clear data/Hapus data, uninstall apps, read typed content, or send screen text to a server. Android can show different layouts, so some apps may be skipped. TeinTools is not an accessibility tool for users with disabilities; this service is an optional deterministic automation. Continue only if you understand and agree.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("I understand · Open settings", (d, w) -> {
                    prefs.edit().putBoolean("cache_accessibility_disclosure_accepted", true).apply();
                    try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                    catch (Exception e) { toast("Accessibility settings are unavailable."); }
                }).show();
    }

    private void openModifySettings() {
        try { startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))); }
        catch (Exception e) { toast("Modify System Settings access is unavailable."); }
    }

    private void openDndAccessSettingsFromCenter() { openDndAccessSettings(); }

    private void requestStorageAccessFromCenter() {
        if (hasStorageRuntimePermission()) { toast("Storage read/write permission is already granted."); return; }
        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
    }

    private void openNextPermission() {
        if (!isCacheAccessibilityEnabled()) { requestAccessibilitySettingsWithDisclosure(); return; }
        if (!hasUsageStatsAccess()) { openUsageAccessSettings(); return; }
        if (!hasStorageAccess()) { requestStorageAccessFromCenter(); return; }
        if (!hasModifySettingsAccess()) { openModifySettings(); return; }
        if (!hasDndAccess()) { openDndAccessSettingsFromCenter(); return; }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { requestCameraForDashboard(); return; }
        toast("All six tracked access items are active.");
    }

    private void addAccessCard(LinearLayout body, String iconName, String title, String detail, boolean granted, String actionText, Runnable action) {
        LinearLayout item = card(null, null, false);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(iconBadge(iconName, 42, 21), new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout titleBox = new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL); titleBox.setPadding(dp(12), 0, dp(8), 0);
        titleBox.addView(label(title, 14, textColor(), true));
        titleBox.addView(label(granted ? "Active" : "Not enabled", 10, granted ? (isLight() ? Color.rgb(44, 115, 83) : Color.rgb(155, 227, 188)) : muted(), true), marginParams(-1, -2, 0, dp(3), 0, 0));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1f));
        item.addView(top);
        addText(item, detail, 11, muted(), false, dp(10));
        if (actionText != null) addActionButton(item, actionText, granted ? "Review in Android settings" : "Android will ask you to enable this access", action);
        body.addView(item, marginParams(-1, -2, 0, 0, 0, dp(10)));
    }

    private void buildPermissionsPage(LinearLayout body) {
        addSectionTitle(body, "Permission Center", "Status is checked from Android; enabling an access is always your choice");
        boolean[] states = new boolean[]{isCacheAccessibilityEnabled(), hasUsageStatsAccess(), hasStorageAccess(), hasModifySettingsAccess(), hasDndAccess(), checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED};
        int activeCount = 0; for (boolean state : states) if (state) activeCount++;
        LinearLayout summary = card(null, null, true);
        summary.addView(label(activeCount + " of 6 access items active", 21, textColor(), true));
        addText(summary, "Use Activate next to walk through missing access screens. Grant only the permissions for features you plan to use; not every feature needs every permission.", 11, muted(), false, dp(5));
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(6); bar.setProgress(activeCount); bar.setProgressTintList(ColorStateList.valueOf(accent()));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(surfaceRaised()));
        summary.addView(bar, marginParams(-1, dp(5), 0, dp(12), 0, dp(6)));
        addActionButton(summary, "Activate next", "Opens the next missing permission/access screen", this::openNextPermission);
        body.addView(summary, marginParams(-1, -2, 0, 0, 0, dp(14)));

        addAccessCard(body, "permissions", "Accessibility automation", "Used only by the manually started cache cleaner to find Storage and exact Clear cache buttons. The service is not labelled as an accessibility tool.", states[0], states[0] ? "Open Accessibility settings" : "Review disclosure and enable", this::requestAccessibilitySettingsWithDisclosure);
        addAccessCard(body, "apps", "Usage Access", "Needed to measure cache sizes of other installed apps with Android StorageStatsManager. No app usage is uploaded.", states[1], states[1] ? "Review Usage Access" : "Open Usage Access settings", this::openUsageAccessSettings);
        addAccessCard(body, "files", "Storage read/write", "Android 10 legacy scoped-storage mode for scanning old temporary files and thumbnail caches in shared storage. It cannot grant access to private app caches.", states[2], states[2] ? "Permission already granted" : "Grant storage permission", this::requestStorageAccessFromCenter);
        addAccessCard(body, "settings", "Modify System Settings", "Only used when you apply/restore the optional quiet-display profile (brightness and screen timeout).", states[3], states[3] ? "Open settings" : "Grant Modify System Settings", this::openModifySettings);
        addAccessCard(body, "network", "Do Not Disturb access", "Optional Focus mode toggles Android's interruption filter after a separate confirmation. It may silence notifications.", states[4], states[4] ? "Review DND access" : "Open DND access settings", this::openDndAccessSettingsFromCenter);
        addAccessCard(body, "camera", "Camera permission", "Requested when you use QR scanning or the flashlight. No camera background service is used.", states[5], states[5] ? "Review app permission" : "Request camera permission", this::requestCameraForDashboard);

        addActionButton(body, "Open TeinTools app settings", "Review or revoke permissions managed by Android", () -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            catch (Exception e) { toast("Could not open app settings."); }
        });
        body.addView(card("Android 10 note", "Android 10 does not have Android 11's MANAGE_EXTERNAL_STORAGE all-files switch. TeinTools requests legacy read/write storage only for its optional safe shared-storage scan. Cache automation is a separate accessibility service, and you can turn it off at any time in Android Accessibility settings.", false), marginParams(-1, -2, 0, dp(10), 0, dp(22)));
    }

    private void scanCachedApps() {
        if (cacheScanRunning) { toast("Cache scan already running."); return; }
        if (!hasUsageStatsAccess()) {
            new AlertDialog.Builder(this).setTitle("Usage Access required")
                    .setMessage("Android protects per-app cache-size statistics. Open Usage Access, enable TeinTools, return here, then scan again.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Open settings", (d, w) -> openUsageAccessSettings()).show();
            return;
        }
        cacheScanRunning = true;
        autoCacheScanAttempted = true;
        if ("cleaner".equals(currentPage)) renderPage("cleaner");
        new Thread(() -> {
            List<CachedApp> result = collectCachedApps(includeSystemCacheApps);
            runOnUiThread(() -> {
                cachedApps.clear(); cachedApps.addAll(result);
                cacheScanIncludedSystem = includeSystemCacheApps;
                cacheScanRunning = false;
                android.content.SharedPreferences runPrefs = getSharedPreferences(CacheCleanerAccessibilityService.PREFS, MODE_PRIVATE);
                if (runPrefs.getBoolean("verification_pending", false) && !runPrefs.getBoolean("active", false)) {
                    long before = runPrefs.getLong("cache_before_bytes", totalMeasuredCache());
                    long after = totalMeasuredCache();
                    long reduction = Math.max(0L, before - after);
                    String prior = runPrefs.getString("status", "Cache pass finished.");
                    String verification = "Measured cache before " + formatBytes(before) + ", after " + formatBytes(after)
                            + "; estimated reduction " + formatBytes(reduction) + ".";
                    runPrefs.edit().putString("status", prior + " " + verification)
                            .putBoolean("verification_pending", false).remove("cache_before_bytes").apply();
                }
                if ("cleaner".equals(currentPage)) renderPage("cleaner");
                toast("Cache scan finished · " + result.size() + " apps with cache data.");
            });
        }, "tein-cache-stats").start();
    }

    private List<CachedApp> collectCachedApps(boolean includeSystem) {
        List<CachedApp> result = new ArrayList<>();
        StorageStatsManager manager = getSystemService(StorageStatsManager.class);
        if (manager == null) return result;
        List<ApplicationInfo> apps;
        try { apps = getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA); }
        catch (Exception e) { return result; }
        for (ApplicationInfo app : apps) {
            if (app == null || app.packageName == null || app.packageName.equals(getPackageName()) || isProtectedSystemPackage(app.packageName)) continue;
            boolean system = (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            if (system && !includeSystem) continue;
            try {
                        StorageStats stats = manager.queryStatsForPackage(StorageManager.UUID_DEFAULT, app.packageName, Process.myUserHandle());
                long cache = stats.getCacheBytes();
                if (cache > 0L) result.add(new CachedApp(app.packageName, String.valueOf(getPackageManager().getApplicationLabel(app)), cache, system));
            } catch (IOException | PackageManager.NameNotFoundException | SecurityException ignored) { }
        }
        result.sort((a, b) -> Long.compare(b.cacheBytes, a.cacheBytes));
        return result;
    }

    private boolean isProtectedSystemPackage(String name) {
        String p = name.toLowerCase(Locale.ROOT);
        return p.equals("android") || p.equals("com.android.settings") || p.equals("com.android.systemui")
                || p.equals("com.android.phone") || p.equals("com.android.server.telecom")
                || p.equals("com.android.providers.settings") || p.equals("com.android.providers.media")
                || p.contains("inputmethod") || p.contains("keyboard") || p.contains("launcher");
    }

    private void startCacheAutomation() {
        if (cacheScanRunning) { toast("Cache scan is still running. Start cleaning when it finishes."); return; }
        if (getSharedPreferences(CacheCleanerAccessibilityService.PREFS, MODE_PRIVATE).getBoolean("active", false)) {
            toast("Cache automation is already running."); return;
        }
        if (!hasUsageStatsAccess()) { scanCachedApps(); return; }
        if (!isCacheAccessibilityEnabled()) {
            requestAccessibilitySettingsWithDisclosure();
            toast("Enable TeinTools Cache Cleaner in Accessibility settings, return here, then start again.");
            return;
        }
        if (cachedApps.isEmpty() || cacheScanIncludedSystem != includeSystemCacheApps) {
            scanCachedApps(); toast("Scan app cache sizes first. Then tap Start 1-Tap again."); return;
        }
        List<String> queue = new ArrayList<>();
        for (CachedApp app : cachedApps) if (app.cacheBytes > 0 && !isProtectedSystemPackage(app.packageName)) queue.add(app.packageName);
        if (queue.isEmpty()) { toast("No eligible app caches were measured. Rescan or use Android Storage settings."); return; }
        new AlertDialog.Builder(this).setTitle("Start 1-Tap cache cleanup?")
                .setMessage("TeinTools will process " + queue.size() + " apps using a visible progress screen while it navigates Android Settings underneath. It will only tap exact Clear cache/Hapus cache controls and will never tap Clear data/Hapus data. Different ColorOS layouts may cause apps to be skipped. You can stop the run at any time.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Start cleaning", (d, w) -> launchCacheAutomation(queue))
                .show();
    }

    private void launchCacheAutomation(List<String> queue) {
        if (queue == null || queue.isEmpty()) return;
        android.content.SharedPreferences prefs = getSharedPreferences(CacheCleanerAccessibilityService.PREFS, MODE_PRIVATE);
        String serialized = join(queue, "\n");
        prefs.edit().putBoolean("active", true).putBoolean("verification_pending", true)
                .putLong("cache_before_bytes", totalMeasuredCache()).putString("queue", serialized).putInt("index", 0)
                .putInt("total", queue.size()).putInt("cleared", 0).putInt("already_clean", 0).putInt("failed", 0)
                .putString("current", queue.get(0)).putString("step", "app_info")
                .putString("status", "Starting cache-clean pass…").putLong("started_at", System.currentTimeMillis()).apply();
        // Give the connected AccessibilityService a short moment to show the progress overlay
        // before the system-owned App info activity is started underneath it.
        handler.postDelayed(() -> {
            if (getSharedPreferences(CacheCleanerAccessibilityService.PREFS, MODE_PRIVATE).getBoolean("active", false)) {
                openAppInfo(queue.get(0));
            }
        }, 420L);
    }

    private String join(List<String> values, String separator) {
        StringBuilder builder = new StringBuilder();
        for (String value : values) { if (builder.length() > 0) builder.append(separator); builder.append(value); }
        return builder.toString();
    }

    private void stopCacheAutomation() {
        android.content.SharedPreferences prefs = getSharedPreferences(CacheCleanerAccessibilityService.PREFS, MODE_PRIVATE);
        prefs.edit().putBoolean("active", false).putBoolean("verification_pending", false).putString("step", "stopped")
                .putString("status", "Stopped by user. No further app screens will be opened.").putString("current", "").apply();
        toast("Cache automation stopped.");
        renderPage("cleaner");
    }

    private void openAppInfo(String packageName) {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))); }
        catch (Exception e) {
            android.content.SharedPreferences prefs = getSharedPreferences(CacheCleanerAccessibilityService.PREFS, MODE_PRIVATE);
            if (prefs.getBoolean("active", false)) {
                prefs.edit().putBoolean("active", false).putBoolean("verification_pending", false)
                        .putString("step", "interrupted").putString("status", "Could not open App info for " + packageName + ". The cache pass was stopped safely.").apply();
            }
            toast("Could not open App info for " + packageName + ".");
        }
    }

    private void requestCameraForDashboard() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            toast("Camera permission is already granted.");
            return;
        }
        pendingPermissionRefresh = true;
        requestCameraPermissionWithRationale("camera tools");
    }

    private void requestCameraPermissionWithRationale(String feature) {
        if (Build.VERSION.SDK_INT >= 23 && shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            new AlertDialog.Builder(this)
                    .setTitle("Camera permission")
                    .setMessage("TeinTools uses the camera only for " + feature + ". It is not used in the background.")
                    .setNegativeButton("Not now", (d, w) -> { pendingPermissionRefresh = false; pendingQrScan = false; pendingTorchOn = false; })
                    .setPositiveButton("Continue", (d, w) -> requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA))
                    .show();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private void startQrScan() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingQrScan = true;
            requestCameraPermissionWithRationale("QR scanning");
            return;
        }
        launchQrScanner();
    }

    private void launchQrScanner() {
        try {
            new IntentIntegrator(MainActivity.this).setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
                    .setPrompt("Align the code inside the frame").setBeepEnabled(false)
                    .setOrientationLocked(false).initiateScan();
        } catch (Exception e) {
            toast("Could not open the QR scanner: " + safeMessage(e));
        }
    }

    private void buildSystemPage(LinearLayout body) {
        addSectionTitle(body, "Native Android controls", "Opens system pages; no hidden changes");
        addActionButton(body, "Wi-Fi settings", "Choose a network or change Wi-Fi options", () -> launchSettings(Settings.ACTION_WIFI_SETTINGS));
        addActionButton(body, "Display settings", "Brightness, display size, and sleep", () -> launchSettings(Settings.ACTION_DISPLAY_SETTINGS));
        addActionButton(body, "Battery settings", "Battery usage and power controls", () -> launchSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        addActionButton(body, "Installed app settings", "Manage apps and their permissions manually", () -> launchSettings(Settings.ACTION_APPLICATION_SETTINGS));
        addActionButton(body, "Device information", "Open the system device information page", () -> launchSettings(Settings.ACTION_DEVICE_INFO_SETTINGS));
        addActionButton(body, "General settings", "Open Android Settings", () -> launchSettings(Settings.ACTION_SETTINGS));
        addActionButton(body, "Share device diagnostics", "Share a text summary of Android, battery, network, and storage", this::shareDiagnostics);
        LinearLayout warning = card("No fake boost button", "Android prevents ordinary apps from controlling privileged system services. Use these official settings to make changes safely, rather than trusting an app to claim it has increased CPU performance.", false);
        body.addView(warning, marginParams(-1, -2, 0, dp(8), 0, dp(18)));
    }

    private void shareDiagnostics() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent battery = registerReceiver(null, filter);
        int level = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery == null ? 100 : battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int percent = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
        String report = "TeinTools device report\n" +
                "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "Battery: " + (percent < 0 ? "unavailable" : percent + "%") + "\n" +
                "Network: " + networkSummary() + "\n" +
                "Wi-Fi: " + wifiSummary() + "\n" +
                "Available RAM: " + formatBytes(availableRam()) + "\n" +
                "Free storage: " + formatBytes(freeStorage()) + "\n" +
                "Generated locally by TeinTools.";
        shareText("Share device diagnostics", report);
    }

    private void launchSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { toast("This settings page is not available on this device."); }
    }

    private String networkSummary() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            Network net = cm.getActiveNetwork();
            if (net == null) return "No active network";
            NetworkCapabilities caps = cm.getNetworkCapabilities(net);
            if (caps == null) return "Network state unavailable";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "Wi-Fi · internet validated" : "Wi-Fi · not validated";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "Mobile data · internet validated" : "Mobile data · not validated";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN transport";
            return "Connected · transport type unavailable";
        } catch (Exception e) { return "Unavailable"; }
    }

    private String wifiSummary() {
        try {
            WifiManager wm = (WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) return "Wi-Fi is off or unavailable";
            WifiInfo info = wm.getConnectionInfo();
            if (info == null || info.getNetworkId() == -1) return "Not connected to Wi-Fi";
            int freq = info.getFrequency();
            String band = freq >= 4900 && freq < 5900 ? "5 GHz" : freq >= 2400 && freq < 2500 ? "2.4 GHz" : "band unavailable";
            return band + " · " + freq + " MHz · " + info.getLinkSpeed() + " Mbps link rate · RSSI " + info.getRssi() + " dBm";
        } catch (Exception e) { return "Details not exposed by this device"; }
    }

    private String networkBandwidth() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork(); NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            if (c == null) return "Unavailable";
            int kbps = c.getLinkDownstreamBandwidthKbps();
            return kbps >= 1000 ? String.format(Locale.US, "Reported link %d Mbps", kbps / 1000) : "Reported link " + kbps + " kbps";
        } catch (Exception e) { return "Unavailable"; }
    }

    private String batteryHealth(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Good";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Overheating";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Dead";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Over voltage";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Cold";
            default: return "Unknown / unavailable";
        }
    }

    private String thermalStatus(int status) {
        switch (status) {
            case PowerManager.THERMAL_STATUS_NONE: return "No reported thermal throttling";
            case PowerManager.THERMAL_STATUS_LIGHT: return "Light";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Moderate";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Severe";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Critical";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Emergency";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Shutdown threshold reported";
            default: return "Unknown";
        }
    }

    private long availableRam() {
        try { ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(info); return info.availMem; }
        catch (Exception e) { return 0L; }
    }
    private long freeStorage() { try { return new StatFs(Environment.getDataDirectory().getAbsolutePath()).getAvailableBytes(); } catch (Exception e) { return 0L; } }
    private String deviceName() { String model = Build.MODEL == null ? "Android device" : Build.MODEL; return model.trim().isEmpty() ? "Android device" : model; }
    private String formatBytes(long bytes) {
        if (bytes < 0) return "Unavailable";
        if (bytes < 1024) return bytes + " B";
        double val = bytes; String[] units = {"B", "KB", "MB", "GB", "TB"}; int unit = 0;
        while (val >= 1024 && unit < units.length - 1) { val /= 1024.0; unit++; }
        return String.format(Locale.US, "%.1f %s", val, units[unit]);
    }
    private String formatNumber(double value) {
        if (Math.abs(value) < 0.000000001) value = 0;
        if (Math.abs(value - Math.rint(value)) < 0.000000001 && Math.abs(value) < 1e12) return String.format(Locale.US, "%.0f", value);
        return new DecimalFormat("0.########").format(value);
    }
    private String formatStopwatch(long millis) {
        long tenths = millis / 100L; long hours = tenths / 36000L; long minutes = (tenths / 600L) % 60L; long seconds = (tenths / 10L) % 60L; long fraction = tenths % 10L;
        return String.format(Locale.US, "%02d:%02d:%02d.%d", hours, minutes, seconds, fraction);
    }
    private String formatTimer(long millis) {
        long sec = Math.max(0L, millis) / 1000L;
        return String.format(Locale.US, "%02d:%02d", sec / 60L, sec % 60L);
    }
    private String join(String[] array, String separator) { if (array == null || array.length == 0) return "Unavailable"; StringBuilder s = new StringBuilder(); for (String x : array) { if (s.length() > 0) s.append(separator); s.append(x); } return s.toString(); }
    private String shorten(String s, int max) { if (s == null) return "Unavailable"; return s.length() <= max ? s : s.substring(0, max - 1) + "…"; }
    private String safeMessage(Exception e) { String s = e.getMessage(); return s == null || s.trim().isEmpty() ? e.getClass().getSimpleName() : shorten(s, 110); }

    private String queryDisplayName(Uri uri) {
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) { int i = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (i >= 0) return cursor.getString(i); }
        } catch (Exception ignored) { } finally { if (cursor != null) cursor.close(); }
        return uri.getLastPathSegment() == null ? "selected file" : uri.getLastPathSegment();
    }

    private void shareText(String title, String text) {
        Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text); startActivity(Intent.createChooser(i, title));
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }

    private void addToolGrid(LinearLayout body, Tool[] tools) {
        for (int i = 0; i < tools.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setClipChildren(false);
            row.setClipToPadding(false);
            row.addView(makeToolTile(tools[i]), gridTileParams());
            if (i + 1 < tools.length) row.addView(makeToolTile(tools[i + 1]), gridTileParams());
            else row.addView(new View(this), gridTileParams());
            body.addView(row, marginParams(-1, dp(126), 0, 0, 0, dp(8)));
        }
    }

    private LinearLayout.LayoutParams gridTileParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private View makeToolTile(Tool tool) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.TOP | Gravity.START);
        tile.setPadding(dp(12), dp(11), dp(11), dp(9));
        tile.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        tile.setElevation(dp(2));
        tile.setClipToOutline(true);
        FrameLayout badge = iconBadge(iconForTarget(tool.target), 32, 17);
        tile.addView(badge, new LinearLayout.LayoutParams(dp(32), dp(32)));
        tile.addView(label(tool.name, 12, textColor(), true), marginParams(-1, -2, 0, dp(8), 0, 0));
        TextView desc = label(tool.description, 10, muted(), false);
        desc.setMaxLines(1);
        desc.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tile.addView(desc, marginParams(-1, -2, 0, dp(2), 0, 0));
        tile.setOnClickListener(v -> {
            v.animate().cancel();
            v.animate().scaleX(0.985f).scaleY(0.985f).setDuration(80L).withEndAction(() -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(130L).start();
                renderPage(tool.target);
            }).start();
        });
        return tile;
    }

    private String iconForTarget(String target) {
        switch (target) {
            case "device": return "device";
            case "ram": case "boost": return "memory";
            case "storage": return "files";
            case "battery": return "battery";
            case "thermal": return "thermal";
            case "animations": return "animations";
            case "network": return "network";
            case "flash": return "flash";
            case "calculator": return "calculator";
            case "stopwatch": return "stopwatch";
            case "timer": return "timer";
            case "qr": return "qr";
            case "notes": case "note": return "notes";
            case "converter": return "converter";
            case "files": return "files";
            case "apps": return "apps";
            case "cleaner": return "cleaner";
            case "sensors": return "sensors";
            case "permissions": return "permissions";
            case "system": case "settings": return "settings";
            default: return "device";
        }
    }

    private FrameLayout iconBadge(String iconName, int size, int iconSize) {
        FrameLayout badge = new FrameLayout(this);
        int glass = isLight() ? Color.argb(150, 218, 236, 255) : Color.argb(120, 52, 128, 207);
        badge.setBackground(backgroundGradient(blend(glass, surface(), 0.18f), surfaceRaised(), 1));
        LineIconView icon = new LineIconView(this, iconName, accent());
        badge.addView(icon, new FrameLayout.LayoutParams(dp(iconSize), dp(iconSize), Gravity.CENTER));
        return badge;
    }

    private static class Tool {
        final String icon, name, description, target;
        Tool(String icon, String name, String description, String target) { this.icon = icon; this.name = name; this.description = description; this.target = target; }
    }

    private static final class CachedApp {
        final String packageName, label;
        final long cacheBytes;
        final boolean system;
        CachedApp(String packageName, String label, long cacheBytes, boolean system) {
            this.packageName = packageName; this.label = label; this.cacheBytes = cacheBytes; this.system = system;
        }
    }

    private View statTile(String title, String value, String footer, String symbol) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(10), dp(9), dp(8), dp(8));
        tile.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        tile.setElevation(dp(1));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(new LineIconView(this, symbol, muted()), new LinearLayout.LayoutParams(dp(14), dp(14)));
        TextView titleText = label(title, 8.5f, muted(), true);
        titleText.setLetterSpacing(0.035f);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleParams.setMargins(dp(6), 0, 0, 0);
        head.addView(titleText, titleParams);
        tile.addView(head);
        tile.addView(label(value, 14, textColor(), true), marginParams(-1, -2, 0, dp(7), 0, 0));
        tile.addView(label(footer, 8, muted(), false), marginParams(-1, -2, 0, dp(2), 0, 0));
        return tile;
    }

    private void addSectionTitle(LinearLayout parent, String title, String subtitle) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(label(title, 18, textColor(), true));
        if (subtitle != null) box.addView(label(subtitle, 11, muted(), false), marginParams(-1, -2, 0, dp(5), 0, 0));
        parent.addView(box, marginParams(-1, -2, 0, dp(3), 0, dp(10)));
    }

    private LinearLayout card(String title, String subtitle, boolean hero) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(13), dp(14), dp(13));
        if (hero) c.setBackground(backgroundGradient(isLight() ? Color.rgb(235, 244, 255) : Color.rgb(13, 30, 51), isLight() ? Color.rgb(255, 255, 255) : Color.rgb(6, 13, 25), 2));
        else c.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        c.setElevation(dp(2));
        if (title != null) c.addView(label(title, 15, textColor(), true));
        if (subtitle != null) addText(c, subtitle, 11, muted(), false, dp(7));
        return c;
    }

    private void addActionButton(LinearLayout parent, String title, String subtitle, Runnable action) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(11), dp(12), dp(10));
        box.setBackground(backgroundGradient(surface(), surfaceRaised(), 1));
        box.addView(label(title, 13, textColor(), true));
        if (subtitle != null && !subtitle.trim().isEmpty()) {
            TextView detail = label(subtitle, 9, muted(), false);
            detail.setMaxLines(1);
            detail.setEllipsize(android.text.TextUtils.TruncateAt.END);
            box.addView(detail, marginParams(-1, -2, 0, dp(2), 0, 0));
        }
        box.setOnClickListener(v -> {
            v.animate().cancel();
            v.animate().scaleX(0.99f).scaleY(0.99f).setDuration(70L).withEndAction(() -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(100L).start();
                action.run();
            }).start();
        });
        box.setElevation(dp(2));
        parent.addView(box, marginParams(-1, -2, 0, dp(4), 0, dp(5)));
    }

    private void addKeyValue(LinearLayout parent, String key, String value) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(8), 0, dp(8));
        TextView left = label(key, 11, muted(), false);
        TextView right = label(value, 11, textColor(), true); right.setGravity(Gravity.END);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        parent.addView(row);
        View line = new View(this); line.setBackgroundColor(borderColor());
        parent.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setIncludeFontPadding(true); t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private TextView label(String text, float size, int color, boolean bold, int topMargin) {
        TextView t = label(text, size, color, bold); t.setLayoutParams(marginParams(-1, -2, 0, topMargin, 0, 0)); return t;
    }
    private void addText(LinearLayout parent, String text, float size, int color, boolean bold, int topMargin) {
        parent.addView(label(text, size, color, bold), marginParams(-1, -2, 0, topMargin, 0, 0));
    }
    private TextView pill(String text, int background, int color, int height) {
        TextView t = label(text, 12, color, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(12), 0, dp(12), 0);
        t.setBackground(solid(roundRect(background, dp(16), borderColor())));
        t.setMinHeight(dp(height)); return t;
    }
    private EditText editField(String hint, boolean numeric) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true); edit.setTextSize(14); edit.setTextColor(textColor()); edit.setHintTextColor(muted()); edit.setHint(hint);
        edit.setPadding(dp(13), 0, dp(13), 0); edit.setBackground(solid(roundRect(surfaceRaised(), dp(15), borderColor())));
        if (numeric) edit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        return edit;
    }

    /** Dimensions passed to this helper are already px when wrapped in dp(), or -1/-2 layout constants.
     * Margins are likewise converted by callers. Do not density-scale sizes a second time. */
    private LinearLayout.LayoutParams marginParams(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, height);
        lp.setMargins(left, top, right, bottom);
        return lp;
    }

    private GradientDrawable roundRect(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(dp(1), stroke); return d;
    }
    private GradientDrawable solid(GradientDrawable d) { return d; }
    private GradientDrawable backgroundGradient(int first, int second, int style) {
        int specular = blend(first, Color.WHITE, style == 2 ? 0.13f : 0.055f);
        int lower = blend(second, isLight() ? Color.WHITE : Color.BLACK, style == 2 ? 0.06f : 0.025f);
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{specular, first, lower});
        d.setCornerRadius(dp(style == 2 ? 30 : 23));
        d.setStroke(dp(1), style == 2 ? Color.argb(isLight() ? 145 : 100, 242, 243, 246) : borderColor());
        // Slight translucency lets the backdrop read through the surface, without API-31 blur.
        d.setAlpha(isLight() ? (style == 2 ? 242 : 228) : (style == 2 ? 232 : 214));
        d.setDither(true);
        return d;
    }
    private int blend(int a, int b, float ratioB) {
        ratioB = Math.max(0f, Math.min(1f, ratioB));
        float ratioA = 1f - ratioB;
        return Color.rgb(Math.round(Color.red(a)*ratioA + Color.red(b)*ratioB), Math.round(Color.green(a)*ratioA + Color.green(b)*ratioB), Math.round(Color.blue(a)*ratioA + Color.blue(b)*ratioB));
    }

    /** Small original line icons drawn as vectors at runtime, avoiding emoji/sticker-like glyphs. */
    private static final class LineIconView extends View {
        private final String kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF r = new RectF();
        private int tint;
        LineIconView(Context context, String kind, int tint) {
            super(context);
            this.kind = kind == null ? "device" : kind;
            this.tint = tint;
            p.setColor(tint);
            p.setStrokeWidth(1.7f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStyle(Paint.Style.STROKE);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float unit = Math.min(getWidth(), getHeight()) / 24f;
            if (unit <= 0f) return;
            canvas.save();
            canvas.translate((getWidth() - 24f * unit) / 2f, (getHeight() - 24f * unit) / 2f);
            canvas.scale(unit, unit);
            p.setColor(tint);
            p.setStrokeWidth(1.7f);
            p.setStyle(Paint.Style.STROKE);
            switch (kind) {
                case "home":
                    path.reset(); path.moveTo(3, 10.5f); path.lineTo(12, 3.5f); path.lineTo(21, 10.5f); path.moveTo(5.5f, 9.5f); path.lineTo(5.5f, 20); path.lineTo(10, 20); path.lineTo(10, 14); path.lineTo(14, 14); path.lineTo(14, 20); path.lineTo(18.5f, 20); path.lineTo(18.5f, 9.5f); canvas.drawPath(path, p); break;
                case "back":
                    path.reset(); path.moveTo(15.5f, 4.5f); path.lineTo(8, 12); path.lineTo(15.5f, 19.5f); canvas.drawPath(path, p); break;
                case "more":
                    p.setStyle(Paint.Style.FILL); canvas.drawCircle(12, 5, 1.35f, p); canvas.drawCircle(12, 12, 1.35f, p); canvas.drawCircle(12, 19, 1.35f, p); break;
                case "refresh":
                    r.set(4, 4, 20, 20); canvas.drawArc(r, 42, 280, false, p); path.reset(); path.moveTo(17, 3.8f); path.lineTo(20.5f, 4.5f); path.lineTo(19.2f, 8); canvas.drawPath(path, p); break;
                case "network":
                    r.set(3, 4, 21, 22); canvas.drawArc(r, 218, 104, false, p); r.set(6.5f, 8, 17.5f, 19); canvas.drawArc(r, 220, 100, false, p); r.set(10, 12, 14, 16); p.setStyle(Paint.Style.FILL); canvas.drawCircle(12, 19, 1.45f, p); break;
                case "camera":
                    r.set(3, 6, 21, 19); canvas.drawRoundRect(r, 2, 2, p); path.reset(); path.moveTo(7, 6); path.lineTo(9, 3.5f); path.lineTo(15, 3.5f); path.lineTo(17, 6); canvas.drawPath(path, p); canvas.drawCircle(12, 12.5f, 4, p); canvas.drawCircle(12, 12.5f, 1.6f, p); break;
                case "flash":
                    p.setStyle(Paint.Style.FILL); path.reset(); path.moveTo(13.7f, 2); path.lineTo(5.7f, 13); path.lineTo(10.8f, 13); path.lineTo(9.5f, 22); path.lineTo(18.6f, 9.7f); path.lineTo(13.1f, 9.7f); path.close(); canvas.drawPath(path, p); break;
                case "calculator":
                    r.set(5, 2.5f, 19, 21.5f); canvas.drawRoundRect(r, 2, 2, p); canvas.drawLine(8, 7, 16, 7, p); for (int y=11; y<=17; y+=3) for (int x=8; x<=16; x+=4) canvas.drawCircle(x, y, 0.65f, p); break;
                case "stopwatch":
                    r.set(4.5f, 5.5f, 19.5f, 20.5f); canvas.drawArc(r, 0, 360, false, p); canvas.drawLine(12, 2.5f, 12, 5.5f, p); canvas.drawLine(9, 2.5f, 15, 2.5f, p); canvas.drawLine(17.5f, 6.5f, 19.5f, 4.5f, p); canvas.drawLine(12, 13, 12, 9, p); canvas.drawLine(12, 13, 15, 15, p); break;
                case "timer":
                    r.set(3.5f, 3.5f, 20.5f, 20.5f); canvas.drawArc(r, 0, 360, false, p); canvas.drawLine(12, 12, 12, 7, p); canvas.drawLine(12, 12, 16, 14, p); canvas.drawLine(9, 2, 15, 2, p); canvas.drawLine(12, 2, 12, 3.5f, p); break;
                case "qr":
                    canvas.drawRect(3, 3, 9, 9, p); canvas.drawRect(15, 3, 21, 9, p); canvas.drawRect(3, 15, 9, 21, p); canvas.drawRect(5, 5, 7, 7, p); canvas.drawRect(17, 5, 19, 7, p); canvas.drawRect(5, 17, 7, 19, p); canvas.drawRect(14, 14, 17, 17, p); canvas.drawRect(19, 18, 21, 21, p); canvas.drawLine(18, 14, 21, 14, p); break;
                case "notes":
                    r.set(5, 2.5f, 19, 21.5f); canvas.drawRoundRect(r, 2, 2, p); canvas.drawLine(8, 8, 16, 8, p); canvas.drawLine(8, 12, 16, 12, p); canvas.drawLine(8, 16, 14, 16, p); break;
                case "converter":
                    path.reset(); path.moveTo(3, 8); path.lineTo(19.5f, 8); path.lineTo(16, 4.5f); path.moveTo(19.5f, 8); path.lineTo(16, 11.5f); path.moveTo(21, 16); path.lineTo(4.5f, 16); path.lineTo(8, 12.5f); path.moveTo(4.5f, 16); path.lineTo(8, 19.5f); canvas.drawPath(path, p); break;
                case "files":
                    path.reset(); path.moveTo(3, 7); path.lineTo(9, 7); path.lineTo(11, 9); path.lineTo(21, 9); path.lineTo(19.5f, 19); path.lineTo(4.5f, 19); path.close(); canvas.drawPath(path, p); canvas.drawLine(3, 7, 4, 5, p); canvas.drawLine(4, 5, 10, 5, p); break;
                case "apps":
                    for (int y=4; y<=16; y+=8) for (int x=4; x<=16; x+=8) { r.set(x, y, x+4, y+4); canvas.drawRoundRect(r, 0.7f, 0.7f, p); } break;
                case "cleaner":
                    path.reset(); path.moveTo(12, 2.5f); path.lineTo(13.6f, 9.5f); path.lineTo(20.5f, 12); path.lineTo(13.6f, 13.7f); path.lineTo(12, 20.5f); path.lineTo(10.2f, 13.7f); path.lineTo(3.5f, 12); path.lineTo(10.2f, 9.5f); path.close(); canvas.drawPath(path, p); canvas.drawLine(18.5f, 2.5f, 18.5f, 6, p); canvas.drawLine(16.8f, 4.2f, 20.2f, 4.2f, p); break;
                case "sensors":
                    path.reset(); path.moveTo(2.5f, 13); path.lineTo(6, 13); path.lineTo(8.2f, 7); path.lineTo(11, 18); path.lineTo(14, 9); path.lineTo(16.5f, 13); path.lineTo(21.5f, 13); canvas.drawPath(path, p); break;
                case "permissions":
                    path.reset(); path.moveTo(12, 2.5f); path.lineTo(20, 5.5f); path.lineTo(19, 13); path.cubicTo(18.4f, 16.5f, 15.4f, 19.5f, 12, 21); path.cubicTo(8.6f, 19.5f, 5.6f, 16.5f, 5, 13); path.lineTo(4, 5.5f); path.close(); canvas.drawPath(path, p); path.reset(); path.moveTo(8.5f, 11.5f); path.lineTo(11, 14); path.lineTo(15.8f, 9); canvas.drawPath(path, p); break;
                case "settings": case "system":
                    r.set(6, 6, 18, 18); canvas.drawCircle(12, 12, 6.5f, p); canvas.drawCircle(12, 12, 2.5f, p); for (int a=0; a<8; a++) { double theta = Math.PI * a / 4.0; float x1= (float)(12+7*Math.cos(theta)), y1=(float)(12+7*Math.sin(theta)); float x2=(float)(12+9*Math.cos(theta)), y2=(float)(12+9*Math.sin(theta)); canvas.drawLine(x1,y1,x2,y2,p); } break;
                case "memory":
                    r.set(5, 5, 19, 19); canvas.drawRoundRect(r, 1.5f, 1.5f, p); for (int i=7; i<=17; i+=5) { canvas.drawLine(i, 2.5f, i, 5, p); canvas.drawLine(i, 19, i, 21.5f, p); canvas.drawLine(2.5f, i, 5, i, p); canvas.drawLine(19, i, 21.5f, i, p); } break;
                case "battery":
                    r.set(4, 5, 19, 20); canvas.drawRoundRect(r, 2, 2, p); canvas.drawRoundRect(new RectF(9, 2.5f, 14, 5), 1, 1, p); p.setStyle(Paint.Style.FILL); canvas.drawRect(7, 8, 9, 11, p); canvas.drawRect(11, 8, 13, 11, p); canvas.drawRect(15, 8, 17, 11, p); canvas.drawRect(7, 13, 9, 16, p); canvas.drawRect(11, 13, 13, 16, p); break;
                case "thermal":
                    r.set(8, 3, 16, 16); canvas.drawRoundRect(r, 4, 4, p); canvas.drawLine(12, 7, 12, 16, p); canvas.drawCircle(12, 18, 3, p); canvas.drawLine(18.5f, 5, 21, 5, p); canvas.drawLine(18.5f, 9, 20.5f, 9, p); break;
                case "animations":
                    canvas.drawLine(3, 6, 21, 6, p); canvas.drawCircle(8, 6, 2.2f, p);
                    canvas.drawLine(3, 12, 21, 12, p); canvas.drawCircle(16, 12, 2.2f, p);
                    canvas.drawLine(3, 18, 21, 18, p); canvas.drawCircle(11, 18, 2.2f, p); break;
                default:
                    r.set(4, 4, 20, 20); canvas.drawRoundRect(r, 3, 3, p); canvas.drawCircle(12, 12, 3, p); break;
            }
            canvas.restore();
        }
    }

}
