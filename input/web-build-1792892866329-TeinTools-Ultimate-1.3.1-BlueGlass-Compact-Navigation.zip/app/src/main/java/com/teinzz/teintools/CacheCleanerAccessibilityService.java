package com.teinzz.teintools;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Typeface;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Explicit, user-started and deterministic Settings navigator for Android 10 cache cleanup.
 * It only looks for exact Storage and Clear cache labels. It never matches Clear data/storage,
 * sends no screen text to a network endpoint, and does not declare itself an accessibility tool.
 */
public final class CacheCleanerAccessibilityService extends AccessibilityService {
    static final String PREFS = "tein_tools_cache_automation";
    private static final long STEP_TIMEOUT_MS = 7500L;
    private static final long PAGE_SETTLE_MS = 650L;

    private static final List<String> STORAGE_LABELS = Arrays.asList(
            "storage", "storage & cache", "storage and cache", "storage usage", "app storage",
            "penyimpanan", "penyimpanan & cache", "penyimpanan dan cache", "penggunaan penyimpanan",
            "ruang penyimpanan", "pemakaian penyimpanan", "penyimpanan aplikasi"
    );
    private static final List<String> CLEAR_CACHE_LABELS = Arrays.asList(
            "clear cache", "hapus cache", "bersihkan cache", "hapus tembolok", "bersihkan tembolok"
    );
    private static final List<String> CACHE_ZERO_HINTS = Arrays.asList(
            "cache is empty", "cache kosong", "0 b cache", "cache: 0 b", "cache 0 b", "cache 0 kb"
    );

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable stepTimeout = this::handleTimeout;
    private boolean handlingEvent;
    private String timeoutArmedStep = "";
    private WindowManager overlayManager;
    private View progressOverlay;
    private TextView overlayStatus;
    private TextView overlayCount;
    private ProgressBar overlayProgress;
    private SharedPreferences watchedPrefs;
    private final Runnable hideOverlayRunnable = this::hideProgressOverlay;
    private final SharedPreferences.OnSharedPreferenceChangeListener progressListener = (prefs, key) ->
            handler.post(this::syncProgressOverlay);

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        watchedPrefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        watchedPrefs.registerOnSharedPreferenceChangeListener(progressListener);
        syncProgressOverlay();
    }

    /**
     * When a user-started cache pass runs, cover the Settings pages with a truthful
     * progress surface. The service still inspects the underlying Settings window;
     * this is an accessibility overlay, not a normal app overlay permission.
     */
    private void syncProgressOverlay() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean("active", false)) {
            handler.removeCallbacks(hideOverlayRunnable);
            showProgressOverlay();
            updateProgressOverlay(prefs);
            return;
        }
        if (progressOverlay == null) return;
        String step = prefs.getString("step", "");
        if ("done".equals(step) || "stopped".equals(step) || "interrupted".equals(step)) {
            updateProgressOverlay(prefs);
            handler.removeCallbacks(hideOverlayRunnable);
            handler.postDelayed(hideOverlayRunnable, 1100L);
        } else {
            hideProgressOverlay();
        }
    }

    private int overlayDp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView overlayText(String value, float size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER);
        text.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setIncludeFontPadding(false);
        return text;
    }

    private GradientDrawable overlayShape(int fill, int stroke) {
        GradientDrawable shape = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{fill, Color.rgb(7, 18, 34)});
        shape.setCornerRadius(overlayDp(26));
        shape.setStroke(overlayDp(1), stroke);
        return shape;
    }

    private void showProgressOverlay() {
        if (progressOverlay != null) return;
        try {
            overlayManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (overlayManager == null) return;
            FrameLayout root = new FrameLayout(this);
            GradientDrawable backdrop = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    new int[]{Color.rgb(3, 7, 15), Color.rgb(7, 19, 35)});
            root.setBackground(backdrop);
            root.setPadding(overlayDp(22), overlayDp(18), overlayDp(22), overlayDp(18));

            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setGravity(Gravity.CENTER_HORIZONTAL);
            panel.setPadding(overlayDp(21), overlayDp(23), overlayDp(21), overlayDp(20));
            panel.setBackground(overlayShape(Color.rgb(12, 26, 45), Color.rgb(65, 143, 224)));
            panel.setElevation(overlayDp(10));

            ImageView artwork = new ImageView(this);
            artwork.setImageResource(R.drawable.hero_liquid);
            artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);
            artwork.setContentDescription(null);
            panel.addView(artwork, new LinearLayout.LayoutParams(overlayDp(112), overlayDp(88)));

            TextView brand = overlayText("TeinTools", 19, Color.WHITE, true);
            panel.addView(brand, margin(0, overlayDp(7), 0, 0));
            TextView title = overlayText("Membersihkan cache", 15, Color.WHITE, true);
            panel.addView(title, margin(0, overlayDp(18), 0, 0));

            ProgressBar spinner = new ProgressBar(this);
            spinner.setIndeterminate(true);
            spinner.setIndeterminateTintList(ColorStateList.valueOf(Color.rgb(91, 183, 255)));
            panel.addView(spinner, new LinearLayout.LayoutParams(overlayDp(42), overlayDp(42)));

            overlayStatus = overlayText("Menyiapkan aplikasi…", 12, Color.rgb(193, 211, 231), false);
            panel.addView(overlayStatus, margin(0, overlayDp(14), 0, 0));
            overlayProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            overlayProgress.setMax(100);
            overlayProgress.setProgressTintList(ColorStateList.valueOf(Color.rgb(91, 183, 255)));
            overlayProgress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(31, 49, 70)));
            LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, overlayDp(4));
            progressParams.setMargins(0, overlayDp(18), 0, 0);
            panel.addView(overlayProgress, progressParams);
            overlayCount = overlayText("Menunggu…", 10, Color.rgb(151, 177, 203), false);
            panel.addView(overlayCount, margin(0, overlayDp(9), 0, 0));

            TextView explanation = overlayText("TeinTools sedang menjalankan langkah cache yang kamu setujui. Hanya tombol Hapus cache yang dipilih; Hapus data tidak disentuh.", 11, Color.rgb(155, 176, 198), false);
            explanation.setLineSpacing(overlayDp(3), 1.0f);
            panel.addView(explanation, margin(0, overlayDp(19), 0, 0));

            TextView stop = overlayText("HENTIKAN", 12, Color.WHITE, true);
            stop.setPadding(overlayDp(16), overlayDp(13), overlayDp(16), overlayDp(13));
            stop.setBackground(overlayShape(Color.rgb(22, 75, 132), Color.rgb(91, 183, 255)));
            stop.setClickable(true);
            stop.setFocusable(true);
            stop.setOnClickListener(v -> stopAutomationAndReturn());
            LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, -2);
            stopParams.setMargins(0, overlayDp(20), 0, 0);
            panel.addView(stop, stopParams);

            FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
            root.addView(panel, panelParams);

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            overlayManager.addView(root, params);
            progressOverlay = root;
        } catch (Exception e) {
            // Never open hidden Settings automation if the in-app progress surface cannot be shown.
            hideProgressOverlay();
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            prefs.edit().putBoolean("active", false).putBoolean("verification_pending", false)
                    .putString("step", "interrupted").putString("current", "")
                    .putString("status", "Cleanup stopped safely: the in-app progress screen could not be displayed on this device.").apply();
            try {
                Intent back = new Intent(this, MainActivity.class);
                back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                back.putExtra("show_page", "cleaner");
                startActivity(back);
            } catch (Exception ignored) { }
        }
    }

    private LinearLayout.LayoutParams margin(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(left, top, right, bottom);
        return params;
    }

    private void updateProgressOverlay(SharedPreferences prefs) {
        if (progressOverlay == null) return;
        int total = Math.max(0, prefs.getInt("total", 0));
        int index = Math.max(0, prefs.getInt("index", 0));
        String step = prefs.getString("step", "app_info");
        boolean active = prefs.getBoolean("active", false);
        String current = prefs.getString("current", "");
        String label = current;
        if (!current.isEmpty()) {
            try {
                android.content.pm.ApplicationInfo info = getPackageManager().getApplicationInfo(current, 0);
                label = String.valueOf(getPackageManager().getApplicationLabel(info));
            } catch (Exception ignored) { }
        }
        String status;
        if ("done".equals(step)) status = "Selesai";
        else if ("stopped".equals(step)) status = "Dihentikan";
        else if ("interrupted".equals(step)) status = "Terhenti";
        else if ("storage".equals(step)) status = "Memeriksa tombol Hapus cache…";
        else if ("moving".equals(step) || "after_clear".equals(step)) status = "Berpindah ke aplikasi berikutnya…";
        else status = label.isEmpty() ? "Menyiapkan aplikasi…" : "Memproses " + label;
        overlayStatus.setText(status);
        overlayCount.setText((active && total > 0 ? Math.min(total, index + 1) : Math.min(total, index)) + " / " + total + " aplikasi · "
                + prefs.getInt("cleared", 0) + " dibersihkan · " + prefs.getInt("failed", 0) + " dilewati");
        overlayProgress.setProgress(total > 0 ? Math.min(100, Math.max(0, (int) Math.round(index * 100.0 / total))) : 0);
    }

    private void hideProgressOverlay() {
        handler.removeCallbacks(hideOverlayRunnable);
        if (progressOverlay != null && overlayManager != null) {
            try { overlayManager.removeView(progressOverlay); } catch (Exception ignored) { }
        }
        progressOverlay = null;
        overlayStatus = null;
        overlayCount = null;
        overlayProgress = null;
    }

    private void stopAutomationAndReturn() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putBoolean("active", false).putBoolean("verification_pending", false)
                .putString("step", "stopped").putString("current", "")
                .putString("status", "Stopped by user. Apps already processed stay as they are; remaining apps were skipped.").apply();
        handler.removeCallbacks(stepTimeout);
        timeoutArmedStep = "";
        try {
            Intent back = new Intent(this, MainActivity.class);
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            back.putExtra("show_page", "cleaner");
            startActivity(back);
        } catch (Exception ignored) { }
        handler.removeCallbacks(hideOverlayRunnable);
        handler.postDelayed(this::hideProgressOverlay, 900L);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || handlingEvent) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        CharSequence eventPackage = event.getPackageName();
        String packageName = eventPackage == null ? "" : eventPackage.toString();
        if (!isKnownSettingsPackage(packageName)) return;

        String step = prefs.getString("step", "app_info");
        if ("moving".equals(step) || "after_clear".equals(step) || "done".equals(step)) return;
        // Arm the timeout even if Android has not exposed the active window tree yet.
        armTimeoutForStep(step);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        handlingEvent = true;
        try {
            if ("app_info".equals(step)) {
                // Some OEM settings surfaces expose Clear cache directly. Exact label only.
                NodeMatch directCache = findExact(root, CLEAR_CACHE_LABELS);
                if (directCache != null) {
                    if (!directCache.node.isEnabled()) markCacheAction("already_clean");
                    else if (clickNodeOrClickableParent(directCache.node)) markCacheAction("cleared");
                    else markCacheAction("failed");
                    return;
                }
                NodeMatch storage = findExact(root, STORAGE_LABELS);
                if (storage != null && storage.node.isEnabled() && clickNodeOrClickableParent(storage.node)) {
                    prefs.edit().putString("step", "storage").apply();
                    armTimeoutForStep("storage");
                }
            } else if ("storage".equals(step)) {
                NodeMatch cache = findExact(root, CLEAR_CACHE_LABELS);
                if (cache != null) {
                    if (!cache.node.isEnabled()) markCacheAction("already_clean");
                    else if (clickNodeOrClickableParent(cache.node)) markCacheAction("cleared");
                    else markCacheAction("failed");
                } else if (containsAnyText(root, CACHE_ZERO_HINTS)) {
                    markCacheAction("already_clean");
                }
            }
        } finally {
            handlingEvent = false;
        }
    }

    @Override public void onInterrupt() { /* No continuous feedback or gestures are used. */ }

    @Override public boolean onUnbind(Intent intent) {
        handler.removeCallbacksAndMessages(null);
        if (watchedPrefs != null) watchedPrefs.unregisterOnSharedPreferenceChangeListener(progressListener);
        hideProgressOverlay();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean("active", false)) {
            prefs.edit().putBoolean("active", false).putBoolean("verification_pending", false)
                    .putString("step", "interrupted").putString("current", "")
                    .putString("status", "Automation interrupted because Accessibility disconnected. Some apps may be untouched; rescan before trying again.").apply();
        }
        return super.onUnbind(intent);
    }

    private boolean isKnownSettingsPackage(String name) {
        String p = name.toLowerCase(Locale.ROOT);
        return p.equals("com.android.settings")
                || p.equals("com.coloros.safecenter")
                || p.equals("com.coloros.settings")
                || p.equals("com.oplus.safecenter")
                || p.equals("com.oplus.settings");
    }

    private void armTimeoutForStep(String step) {
        if (step == null || step.equals(timeoutArmedStep)) return;
        timeoutArmedStep = step;
        handler.removeCallbacks(stepTimeout);
        handler.postDelayed(stepTimeout, STEP_TIMEOUT_MS);
    }

    private void handleTimeout() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        String step = prefs.getString("step", "app_info");
        if ("app_info".equals(step) || "storage".equals(step)) {
            prefs.edit().putInt("failed", prefs.getInt("failed", 0) + 1).putString("step", "after_clear").apply();
            advanceToNext();
        }
    }

    private void markCacheAction(String result) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false) || "after_clear".equals(prefs.getString("step", ""))) return;
        SharedPreferences.Editor edit = prefs.edit().putString("step", "after_clear");
        if ("cleared".equals(result)) edit.putInt("cleared", prefs.getInt("cleared", 0) + 1);
        else if ("already_clean".equals(result)) edit.putInt("already_clean", prefs.getInt("already_clean", 0) + 1);
        else edit.putInt("failed", prefs.getInt("failed", 0) + 1);
        edit.apply();
        handler.removeCallbacks(stepTimeout);
        timeoutArmedStep = "";
        handler.postDelayed(this::advanceToNext, PAGE_SETTLE_MS);
    }

    private void advanceToNext() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        handler.removeCallbacks(stepTimeout);
        String queueRaw = prefs.getString("queue", "");
        String[] queue = queueRaw.isEmpty() ? new String[0] : queueRaw.split("\\n");
        int next = prefs.getInt("index", 0) + 1;
        prefs.edit().putInt("index", next).putString("step", "moving").apply();
        timeoutArmedStep = "";

        // Leave storage screen, then App info. Launch the next package's system-owned App info.
        handler.postDelayed(() -> {
            if (!getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("active", false)) return;
            performGlobalAction(GLOBAL_ACTION_BACK);
            handler.postDelayed(() -> {
                if (!getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("active", false)) return;
                performGlobalAction(GLOBAL_ACTION_BACK);
                handler.postDelayed(() -> {
                    if (!getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("active", false)) return;
                    if (next >= queue.length) finishRun();
                    else openQueueItem(queue, next);
                }, 350L);
            }, 350L);
        }, 350L);
    }

    private void openQueueItem(String[] queue, int index) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (index < 0 || index >= queue.length) { finishRun(); return; }
        String packageName = queue[index].trim();
        if (packageName.isEmpty()) {
            prefs.edit().putInt("failed", prefs.getInt("failed", 0) + 1).putString("step", "moving").apply();
            handler.postDelayed(this::advanceToNext, 150L);
            return;
        }
        prefs.edit().putString("current", packageName).putString("step", "app_info").apply();
        timeoutArmedStep = "";
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            armTimeoutForStep("app_info");
        } catch (Exception e) {
            prefs.edit().putInt("failed", prefs.getInt("failed", 0) + 1).putString("step", "moving").apply();
            handler.postDelayed(this::advanceToNext, 150L);
        }
    }

    private void finishRun() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        int total = prefs.getInt("total", 0);
        int cleared = prefs.getInt("cleared", 0);
        int clean = prefs.getInt("already_clean", 0);
        int failed = prefs.getInt("failed", 0);
        String summary = "Finished · Clear-cache taps accepted: " + cleared + " · already clean: " + clean
                + " · skipped/unsupported: " + failed + " · apps queued: " + total
                + ". Rescan cache sizes to verify the result.";
        prefs.edit().putBoolean("active", false).putBoolean("verification_pending", true).putString("step", "done")
                .putString("status", summary).putString("current", "").putLong("finished_at", System.currentTimeMillis()).apply();
        handler.removeCallbacks(stepTimeout);
        timeoutArmedStep = "";
        handler.postDelayed(() -> {
            Intent back = new Intent(this, MainActivity.class);
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            back.putExtra("show_page", "cleaner");
            try { startActivity(back); } catch (Exception ignored) { }
            handler.removeCallbacks(hideOverlayRunnable);
            handler.postDelayed(this::hideProgressOverlay, 750L);
        }, 120L);
    }

    private NodeMatch findExact(AccessibilityNodeInfo node, List<String> labels) {
        if (node == null) return null;
        CharSequence text = node.getText();
        if (text != null) {
            String value = normalize(text.toString());
            for (String label : labels) if (value.equals(normalize(label))) return new NodeMatch(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            NodeMatch match = findExact(node.getChild(i), labels);
            if (match != null) return match;
        }
        return null;
    }

    private boolean containsAnyText(AccessibilityNodeInfo node, List<String> labels) {
        if (node == null) return false;
        CharSequence text = node.getText();
        if (text != null) {
            String value = normalize(text.toString());
            for (String label : labels) if (value.contains(normalize(label))) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) if (containsAnyText(node.getChild(i), labels)) return true;
        return false;
    }

    private String normalize(String text) {
        return text == null ? "" : text.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private boolean clickNodeOrClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int depth = 0; current != null && depth < 5; depth++) {
            if (current.isEnabled() && current.isClickable()) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            current = current.getParent();
        }
        return false;
    }

    private static final class NodeMatch {
        final AccessibilityNodeInfo node;
        NodeMatch(AccessibilityNodeInfo node) { this.node = node; }
    }
}
