package com.rw.autoscraper.database

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "servers")
data class ServerConfig(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hostname: String,
    val ip: String,
    val port: Int,
    val countryLong: String,
    val countryShort: String,
    val configRaw: String,
    val proto: String,
    val ping: String,
    val pingMs: Int = 9999,
    val speed: Long,
    val isLowPop: Boolean,
    val sequenceStep: Int = -1
)

@Dao
interface ServerConfigDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(config: ServerConfig): Long

    @Query("SELECT * FROM servers ORDER BY isLowPop DESC, countryLong ASC, speed DESC")
    fun getAllServers(): Flow<List<ServerConfig>>

    @Query("SELECT * FROM servers WHERE sequenceStep >= 0 ORDER BY sequenceStep ASC LIMIT 2")
    suspend fun getSequenceServers(): List<ServerConfig>

    @Query("UPDATE servers SET sequenceStep = :step WHERE id = :id")
    suspend fun updateSequenceStep(id: Int, step: Int)

    @Query("UPDATE servers SET sequenceStep = -1")
    suspend fun clearSequence()

    @Query("DELETE FROM servers")
    suspend fun deleteAll()

    @Query("UPDATE servers SET pingMs = :pingMs, ping = :pingStr WHERE id = :id")
    suspend fun updatePing(id: Int, pingMs: Int, pingStr: String)
}