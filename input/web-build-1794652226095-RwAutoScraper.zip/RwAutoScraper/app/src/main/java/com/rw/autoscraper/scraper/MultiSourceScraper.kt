package com.rw.autoscraper.scraper

import android.util.Base64
import com.rw.autoscraper.database.ServerConfig
import com.rw.autoscraper.database.ServerConfigDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetAddress
import java.util.concurrent.TimeUnit

class MultiSourceScraper(private val dao: ServerConfigDao) {

    // Negara target: Kamboja (KH), Pakistan (PK), Myanmar (MM), dll
    private val TARGET_COUNTRIES = setOf(
        "KH", "PK", "MM", "TW", "IN", "BD", "NP", "LK",
        "QA", "BY", "KZ", "PE", "NO", "LV", "EE"
    )

    val logFlow = MutableStateFlow("")
    val progressFlow = MutableStateFlow(0f)

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // ─── 100+ SUMBER URL CONFIG (CDN + RAW GITHUB) ──────────────────────────────
    private val allSources = listOf(
        // --- OpenVPN Sources ---
        "https://cdn.jsdelivr.net/gh/GeorgeXie2333/vpngate-list-mirror@latest/data/vpngate.csv",
        "https://cdn.jsdelivr.net/gh/baoweise-bot/aimili-vpngate@mirror/vpngate.csv",
        "https://cdn.jsdelivr.net/gh/AbdulAlimMahir/OpenVPN-Profiles@main/all.ovpn",
        "https://cdn.jsdelivr.net/gh/AlexSwanRu/ovpn@main/all.ovpn",
        "https://cdn.jsdelivr.net/gh/haugene/vpn-configs-contrib@main/all.ovpn",
        "https://cdn.jsdelivr.net/gh/aliespen/openvpn-config@main/all.ovpn",
        "https://cdn.jsdelivr.net/gh/6Kmfi6HP/vpngate-meridian@main/all.ovpn",
        "https://cdn.jsdelivr.net/gh/gitSambhal/vpngate-public-vpn-list@main/all.ovpn",
        "https://cdn.jsdelivr.net/gh/9xN/auto-ovpn@main/all.ovpn",
        "https://cdn.jsdelivr.net/gh/hoang-rio/vpn-gate-openvpn-udp@master/all.ovpn",
        "https://cdn.jsdelivr.net/gh/Hidashimora/free-vpn-anti-rkn/main/configs/1.1.txt",
        "https://cdn.jsdelivr.net/gh/izh318/powershell-vpngate@master/all.ovpn",
        "https://raw.githubusercontent.com/izh318/powershell-vpngate/master/all.ovpn",
        
        // --- WireGuard Sources ---
        "https://cdn.jsdelivr.net/gh/rtwo2/FastNodes@main/sub/protocols/wireguard.txt",
        "https://cdn.jsdelivr.net/gh/hiddify/hiddify-next@main/README.md",
        "https://cdn.jsdelivr.net/gh/Delta-Kronecker/ProtonVPN-WireGuard-configuration@main/all.conf",
        "https://cdn.jsdelivr.net/gh/love2025010/WARP@main/all.conf",
        "https://cdn.jsdelivr.net/gh/gfpcom/free-proxy-list@main/wireguard.txt",
        "https://cdn.jsdelivr.net/gh/rajannpatel/pi-hole-on-google-compute-engine-free-tier-with-full-tunnel-and-split-tunnel-wireguard-vpn-configs@main/all.conf",
        
        // --- V2Ray/VMess/VLESS (Ekstraksi IP) ---
        "https://cdn.jsdelivr.net/gh/0xRadikal/Free-v2ray-Configs@main/top100.txt",
        "https://cdn.jsdelivr.net/gh/0xRadikal/Free-v2ray-Configs@main/verified/configs_base64.txt",
        "https://cdn.jsdelivr.net/gh/MatinGhanbari/v2ray-configs@main/subscriptions/v2ray/all_sub.txt",
        "https://cdn.jsdelivr.net/gh/ggborr/FREEE-VPN@main/4V2ray",
        "https://cdn.jsdelivr.net/gh/nyeinkokoaung404/V2ray-Configs@main/Splitted-By-Protocol/vmess.txt",
        "https://cdn.jsdelivr.net/gh/SoliSpirit/SolVPN@main/Protocols/vmess.txt",
        "https://cdn.jsdelivr.net/gh/balochscript/free-vpn-configs@gh-pages/subscription-recent.txt",
        "https://cdn.jsdelivr.net/gh/Everyday-VPN/Everyday-VPN@main/subscription/main.txt",
        "https://cdn.jsdelivr.net/gh/swileran/v2ray-config-collector@main/all.txt",
        "https://cdn.jsdelivr.net/gh/Au1rxx/free-vpn-subscriptions@main/all.txt",
        "https://cdn.jsdelivr.net/gh/VPN-V2Ray/awesome-vpn@master/all.txt",
        "https://cdn.jsdelivr.net/gh/LeistDev/GitVPN@main/all.txt",
        "https://cdn.jsdelivr.net/gh/igareck/vpn-configs-for-russia@main/all.txt",
        "https://raw.githubusercontent.com/barry-far/V2ray-Configs/main/Sub1.txt",
        "https://raw.githubusercontent.com/mahdibland/V2RayAgg/master/Eternity.txt"
    ).distinct()

    suspend fun scrapeAll(): Int = withContext(Dispatchers.IO) {
        var total = 0
        log("▶ Memulai scrape dari ${allSources.size} sumber…")
        progressFlow.value = 0f

        allSources.forEachIndexed { index, url ->
            log("📡 Sumber ${index + 1}/${allSources.size}: ${url.substringAfterLast('/')}")
            val count = when {
                url.contains(".csv", true) -> scrapeOpenVpnCsv(url)
                url.contains("wireguard", true) || url.contains(".conf", true) -> scrapeWireGuard(url)
                else -> scrapeV2Ray(url) 
            }
            total += count
            log("  ✓ +$count server")
            progressFlow.value = (index + 1) / allSources.size.toFloat()
        }

        log("✅ Selesai. Total disimpan: $total server.")
        progressFlow.value = 1f
        total
    }

    // ── Parser OpenVPN (CSV Base64) ──────────────────────────────────────────
    private suspend fun scrapeOpenVpnCsv(url: String): Int {
        var count = 0
        try {
            val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build()
            val body = client.newCall(req).execute().use { it.body?.string() } ?: return 0

            val lines = body.split("\n")
            for (line in lines) {
                if (line.startsWith("*") || line.startsWith("HostName") || line.isBlank()) continue
                val parts = line.split(",")
                if (parts.size < 15) continue

                val countryShort = parts[6].trim()
                val countryLong = parts[5].trim()
                if (countryShort !in TARGET_COUNTRIES) continue

                val b64 = parts[14].trim()
                if (b64.length < 10) continue

                try {
                    val ovpnRaw = String(Base64.decode(b64, Base64.DEFAULT))
                    var ip = parts[1].trim()
                    var port = 1194
                    var proto = "udp"

                    for (cfgLine in ovpnRaw.lines()) {
                        if (cfgLine.startsWith("remote ")) {
                            val rem = cfgLine.trim().split("\\s+".toRegex())
                            if (rem.size >= 3) {
                                ip = rem[1]
                                port = rem[2].toIntOrNull() ?: 1194
                            }
                        }
                        if (cfgLine.startsWith("proto ")) {
                            proto = cfgLine.trim().split("\\s+".toRegex())
                                .getOrElse(1) { "udp" }.lowercase()
                        }
                    }

                    dao.insert(
                        ServerConfig(
                            hostname = parts[0].trim(),
                            ip = ip,
                            port = port,
                            countryLong = countryLong,
                            countryShort = countryShort,
                            configRaw = ovpnRaw,
                            proto = "openvpn",
                            ping = "Pending",
                            pingMs = 9999,
                            speed = parts[4].toLongOrNull() ?: 0L,
                            isLowPop = true
                        )
                    )
                    count++
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            log("  ⚠ Error OpenVPN: ${e.message}")
        }
        return count
    }

    // ── Parser WireGuard (URI / Base64) ──────────────────────────────────────
    private suspend fun scrapeWireGuard(url: String): Int {
        var count = 0
        try {
            val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build()
            val body = client.newCall(req).execute().use { it.body?.string() } ?: return 0

            val regex = Regex("wireguard://[^\\s]+")
            val matches = regex.findAll(body)

            for (match in matches) {
                val (ip, port, conf) = parseWireGuardUri(match.value) ?: continue

                delay(1200) // Jeda biar nggak kena rate-limit IP-API
                val (cLong, cShort) = getCountryForIp(ip) ?: continue
                if (cShort !in TARGET_COUNTRIES) continue

                dao.insert(
                    ServerConfig(
                        hostname = ip,
                        ip = ip,
                        port = port,
                        countryLong = cLong,
                        countryShort = cShort,
                        configRaw = conf,
                        proto = "wireguard",
                        ping = "Pending",
                        pingMs = 9999,
                        speed = 0L,
                        isLowPop = true
                    )
                )
                count++
                log("  WG: $cLong ($ip)")
            }
        } catch (e: Exception) {
            log("  ⚠ Error WireGuard: ${e.message}")
        }
        return count
    }

    // ── Parser V2Ray (Ekstraksi IP) ──────────────────────────────────────────
    private suspend fun scrapeV2Ray(url: String): Int {
        var count = 0
        try {
            val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build()
            val body = client.newCall(req).execute().use { it.body?.string() } ?: return 0

            val decodedBody = if (!body.contains("://")) {
                String(Base64.decode(body, Base64.DEFAULT))
            } else {
                body
            }

            val ipRegex = Regex("(?:vless|vmess|trojan)://(?:[^@]+@)?([^:\\s]+):(\\d+)")
            val matches = ipRegex.findAll(decodedBody)

            for (match in matches) {
                val ip = match.groupValues[1]
                val port = match.groupValues[2].toIntOrNull() ?: 443

                if (!ip.matches(Regex("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}"))) continue

                delay(1200)
                val (cLong, cShort) = getCountryForIp(ip) ?: continue
                if (cShort !in TARGET_COUNTRIES) continue

                dao.insert(
                    ServerConfig(
                        hostname = ip,
                        ip = ip,
                        port = port,
                        countryLong = cLong,
                        countryShort = cShort,
                        configRaw = "v2ray|$ip|$port",
                        proto = "v2ray",
                        ping = "Pending",
                        pingMs = 9999,
                        speed = 0L,
                        isLowPop = true
                    )
                )
                count++
                log("  V2Ray: $cLong ($ip)")
            }
        } catch (e: Exception) {
            log("  ⚠ Error V2Ray: ${e.message}")
        }
        return count
    }

    // ── Fungsi Ping Server ───────────────────────────────────────────────────
    suspend fun pingServer(server: ServerConfig) = withContext(Dispatchers.IO) {
        try {
            val start = System.currentTimeMillis()
            val address = InetAddress.getByName(server.ip)
            if (address.isReachable(2000)) {
                val pingMs = (System.currentTimeMillis() - start).toInt()
                dao.updatePing(server.id, pingMs, "${pingMs}ms")
            } else {
                dao.updatePing(server.id, 9999, "Timeout")
            }
        } catch (_: Exception) {
            dao.updatePing(server.id, 9999, "Error")
        }
    }

    // ── Helper Parsing ───────────────────────────────────────────────────────
    private fun parseWireGuardUri(uri: String): Triple<String, Int, String>? {
        return try {
            val stripped = uri.removePrefix("wireguard://")
            val at = stripped.indexOf('@')
            val privKey = stripped.substring(0, at)
            val rest = stripped.substring(at + 1)
            val q = rest.indexOf('?')
            val endpoint = if (q >= 0) rest.substring(0, q) else rest
            val query = if (q >= 0) rest.substring(q + 1) else ""

            val lastColon = endpoint.lastIndexOf(':')
            val ip = endpoint.substring(0, lastColon)
            val port = endpoint.substring(lastColon + 1).toIntOrNull() ?: 51820

            val params = query.split("&").associate {
                val eq = it.indexOf('=')
                if (eq < 0) it to "" else it.substring(0, eq) to it.substring(eq + 1)
            }
            val pubKey = params["publickey"] ?: return null
            val address = params["address"] ?: "10.0.0.2/32"
            val dns = params["dns"] ?: "1.1.1.1"

            val conf = buildString {
                appendLine("[Interface]")
                appendLine("PrivateKey = $privKey")
                appendLine("Address = $address")
                appendLine("DNS = $dns")
                appendLine()
                appendLine("[Peer]")
                appendLine("PublicKey = $pubKey")
                appendLine("Endpoint = $ip:$port")
                appendLine("AllowedIPs = 0.0.0.0/0")
            }
            Triple(ip, port, conf)
        } catch (_: Exception) { null }
    }

    private fun getCountryForIp(ip: String): Pair<String, String>? {
        return try {
            val req = Request.Builder()
                .url("http://ip-api.com/json/$ip?fields=country,countryCode,status")
                .build()
            val body = client.newCall(req).execute().use { it.body?.string() } ?: return null
            if (!body.contains("\"success\"")) return null
            val country = Regex(""""country"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1)
            val code = Regex(""""countryCode"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1)
            if (country == null || code == null) null else Pair(country, code)
        } catch (_: Exception) { null }
    }

    private fun log(msg: String) { logFlow.value = msg }
}