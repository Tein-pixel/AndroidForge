// File: app/src/main/java/com/scanpr/ultra/MainActivity.kt
package com.scanpr.ultra

import android.Manifest
import android.content.Intent
import android.speech.RecognizerIntent
import android.view.inputmethod.EditorInfo
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageContractOptions
import com.canhub.cropper.CropImageOptions
import com.canhub.cropper.CropImageView.Guidelines
import com.scanpr.ultra.databinding.ActivityMainBinding
import com.scanpr.ultra.utils.AiKeyStore
import com.scanpr.ultra.utils.NetworkUtils
import com.scanpr.ultra.utils.PermissionUtils
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null
    private var callbackRegistered = false
    private val mainViewModel: MainViewModel by viewModels()
    private val connectivityManager by lazy { getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = runOnUiThread { updateNetworkStatus() }
        override fun onLost(network: Network) = runOnUiThread { updateNetworkStatus() }
        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) = runOnUiThread { updateNetworkStatus() }
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else Toast.makeText(this, "Izin kamera dibutuhkan untuk scan. Kamu masih bisa memilih gambar dari galeri.", Toast.LENGTH_LONG).show()
    }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) launchCrop(uri) }
    private val speechInput = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) binding.questionInput.setText(spoken)
        }
    }
    private val cropImage = registerForActivityResult(CropImageContract()) { result ->
        if (result.isSuccessful) {
            val croppedUri = result.uriContent
            if (croppedUri != null) processCroppedImage(croppedUri)
            else Toast.makeText(this, "Gambar hasil crop tidak ditemukan. Coba pilih gambar lagi.", Toast.LENGTH_LONG).show()
        } else if (result.error != null) {
            Toast.makeText(this, "Gagal memotong gambar: ${result.error?.localizedMessage ?: "coba ulangi"}", Toast.LENGTH_LONG).show()
        }
        // If the user presses Cancel, remain on the camera screen without starting OCR.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.shutterOuter.setOnClickListener { capture() }
        binding.galleryButton.setOnClickListener { pickImage.launch("image/*") }
        binding.sendQuestionButton.setOnClickListener { submitTypedQuestion() }
        binding.questionInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitTypedQuestion(); true } else false
        }
        binding.voiceInputButton.setOnClickListener { startVoiceInput() }
        binding.historyButton.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        binding.settingsButton.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        updateNetworkStatus()
        // Let text-entry work immediately; request camera permission only when the camera is used.
        if (PermissionUtils.hasCamera(this)) startCamera()
    }

    override fun onStart() {
        super.onStart()
        if (!callbackRegistered) {
            runCatching {
                connectivityManager.registerDefaultNetworkCallback(networkCallback)
                callbackRegistered = true
            }
        }
        updateNetworkStatus()
    }

    override fun onStop() {
        if (callbackRegistered) {
            runCatching { connectivityManager.unregisterNetworkCallback(networkCallback) }
            callbackRegistered = false
        }
        super.onStop()
    }

    private fun updateNetworkStatus() {
        if (!::binding.isInitialized) return
        val online = NetworkUtils.isOnline(this)
        if (!online) {
            binding.networkStatusChip.text = "OFFLINE · Solver lokal"
            binding.networkStatusChip.contentDescription = binding.networkStatusChip.text
            return
        }
        binding.networkStatusChip.text = "ONLINE · Memeriksa konfigurasi AI…"
        binding.networkStatusChip.contentDescription = binding.networkStatusChip.text
        // Credential-store initialization can touch Android Keystore, so do it off the UI thread.
        lifecycleScope.launch {
            val hasKeys = withContext(Dispatchers.IO) { AiKeyStore.hasAnyKey(this@MainActivity) }
            if (NetworkUtils.isOnline(this@MainActivity) && ::binding.isInitialized) {
                binding.networkStatusChip.text = if (hasKeys) {
                    "ONLINE · AI siap dicoba"
                } else {
                    "ONLINE · Atur API AI di Pengaturan"
                }
                binding.networkStatusChip.contentDescription = binding.networkStatusChip.text
            }
        }
    }

    private fun submitTypedQuestion() {
        val question = binding.questionInput.text?.toString()?.trim().orEmpty()
        if (question.isBlank()) {
            Toast.makeText(this, "Ketik soal terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, ResultActivity::class.java).putExtra(ResultActivity.EXTRA_OCR, question)
        startActivity(intent)
        binding.questionInput.setText("")
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan soal atau pertanyaan")
        runCatching { speechInput.launch(intent) }.onFailure {
            Toast.makeText(this, "Input suara tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show()
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            }.onFailure { Toast.makeText(this, "Kamera tidak dapat dibuka: ${it.localizedMessage ?: "error"}", Toast.LENGTH_LONG).show() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun capture() {
        if (!PermissionUtils.hasCamera(this)) { cameraPermission.launch(Manifest.permission.CAMERA); return }
        val capture = imageCapture ?: run { Toast.makeText(this, "Kamera sedang disiapkan. Coba lagi sebentar.", Toast.LENGTH_SHORT).show(); startCamera(); return }
        val dir = File(cacheDir, "scans").apply { mkdirs() }
        val file = File(dir, "scan_${System.currentTimeMillis()}.jpg")
        binding.cameraProgress.visibility = android.view.View.VISIBLE
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                binding.cameraProgress.visibility = android.view.View.GONE
                launchCrop(Uri.fromFile(file))
            }
            override fun onError(exception: ImageCaptureException) {
                binding.cameraProgress.visibility = android.view.View.GONE
                Toast.makeText(this@MainActivity, "Gagal memotret: ${exception.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    /** Both captured and gallery images go through crop selection before OCR. */
    private fun launchCrop(uri: Uri) {
        runCatching {
            cropImage.launch(
                CropImageContractOptions(
                    uri = uri,
                    cropImageOptions = CropImageOptions().apply {
                        guidelines = Guidelines.ON
                        outputCompressFormat = Bitmap.CompressFormat.JPEG
                        outputCompressQuality = 92
                    }
                )
            )
        }.onFailure {
            Toast.makeText(this, "Editor crop tidak dapat dibuka: ${it.localizedMessage ?: "error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun processCroppedImage(uri: Uri) {
        binding.cameraProgress.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val text = runCatching { mainViewModel.recognize(this@MainActivity, uri) }.getOrDefault("")
            binding.cameraProgress.visibility = android.view.View.GONE
            startActivity(
                Intent(this@MainActivity, ResultActivity::class.java)
                    .putExtra(ResultActivity.EXTRA_OCR, text)
                    .putExtra(ResultActivity.EXTRA_IMAGE_URI, uri.toString())
            )
        }
    }
}
