package com.scanpr.ultra

import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.scanpr.ultra.databinding.ActivityStudyBinding
import com.scanpr.ultra.utils.AiProvider
import com.scanpr.ultra.utils.NetworkUtils
import com.scanpr.ultra.utils.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Interactive AI-generated quiz and flashcards. The source question is never silently substituted. */
class StudyActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_MODE = "study_mode"
        const val EXTRA_CONTEXT = "study_context"
        private const val MODE_QUIZ = "quiz"
        private const val MODE_CARDS = "cards"
    }

    private data class QuizItem(val prompt: String, val options: List<String>, val correct: Int, val explanation: String)
    private data class Flashcard(val front: String, val back: String)

    private lateinit var binding: ActivityStudyBinding
    private var mode = MODE_QUIZ
    private var studyContext = ""
    private var quizTitle = "Latihan"
    private var questions: List<QuizItem> = emptyList()
    private var cards: List<Flashcard> = emptyList()
    private var selected = IntArray(0)
    private var checked = BooleanArray(0)
    private var index = 0
    private var showBack = false

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityStudyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mode = if (intent.getStringExtra(EXTRA_MODE) == MODE_CARDS) MODE_CARDS else MODE_QUIZ
        studyContext = intent.getStringExtra(EXTRA_CONTEXT).orEmpty().trim()
        binding.studyToolbar.title = if (mode == MODE_CARDS) "Flashcard" else "Latihan kuis"
        binding.studyToolbar.setNavigationOnClickListener { finish() }
        binding.studyActionButton.setOnClickListener { onAction() }
        binding.studyNextButton.setOnClickListener { nextItem() }
        binding.studyRetryButton.setOnClickListener { generate() }
        generate()
    }

    private fun generate() {
        if (!NetworkUtils.isOnline(this)) {
            showError("Pembuatan kuis/flashcard interaktif memerlukan koneksi internet dan provider AI yang aktif. Mode offline tetap tersedia untuk soal aritmetika yang didukung.")
            return
        }
        binding.studyProgress.visibility = View.VISIBLE
        binding.studyQuestionCard.visibility = View.GONE
        binding.studyErrorText.visibility = View.GONE
        binding.studyRetryButton.visibility = View.GONE
        binding.studyActionButton.isEnabled = false
        binding.studyNextButton.isEnabled = false
        binding.studySubtitle.text = "Meminta AI menyusun materi…"
        val prompt = if (mode == MODE_CARDS) {
            "Buat tepat 8 flashcard belajar berdasarkan materi berikut. Ringkas tetapi akurat; jangan mengarang fakta di luar materi, dan bila materi tidak cukup umumkan keterbatasannya. Jawaban_akhir harus berupa STRING yang isinya JSON valid persis dengan skema: {\"title\":\"judul\",\"cards\":[{\"front\":\"pertanyaan/istilah\",\"back\":\"jawaban dan penjelasan singkat\"}]}. Pastikan tanda kutip di-escape sesuai JSON string, tanpa markdown fence. Materi: $studyContext"
        } else {
            "Buat tepat 5 soal pilihan ganda untuk latihan berdasarkan materi berikut. Setiap soal memiliki 4 opsi yang masuk akal, satu jawaban paling tepat, dan pembahasan singkat yang benar. Jangan memakai fakta eksternal jika materi tidak menyediakan informasi cukup. Jawaban_akhir harus berupa STRING yang isinya JSON valid persis dengan skema: {\"title\":\"judul\",\"questions\":[{\"question\":\"teks soal\",\"options\":[\"opsi A\",\"opsi B\",\"opsi C\",\"opsi D\"],\"correct_index\":0,\"explanation\":\"alasan\"}]}. correct_index harus bilangan 0 sampai 3. Pastikan tanda kutip di-escape sesuai JSON string, tanpa markdown fence. Materi: $studyContext"
        }
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { AiProvider(applicationContext).solveAuto(prompt) }.getOrNull() }
            binding.studyProgress.visibility = View.GONE
            binding.studyActionButton.isEnabled = true
            binding.studyNextButton.isEnabled = true
            val raw = result?.jawabanAkhir.orEmpty()
            val parsed = runCatching { parseGenerated(raw) }.getOrNull()
            if (parsed == null) {
                showError("AI belum berhasil membuat data latihan terstruktur. Coba ulangi, periksa koneksi/API key, atau kembali ke hasil soal. Respons offline biasa tidak cukup untuk membuat kuis interaktif tanpa menebak opsi.")
            } else {
                binding.studySubtitle.text = "Model: ${result?.modelUsed ?: "AI"} · Periksa pembahasan setelah menjawab."
                binding.studyTitle.text = quizTitle
                binding.studyQuestionCard.visibility = View.VISIBLE
                binding.studyErrorText.visibility = View.GONE
                binding.studyRetryButton.visibility = View.GONE
                index = 0
                showBack = false
                if (mode == MODE_CARDS) renderCard() else renderQuestion()
            }
        }
    }

    private fun parseGenerated(raw: String): Boolean {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        require(start >= 0 && end > start) { "JSON flashcard/kuis tidak ditemukan" }
        val obj = JSONObject(raw.substring(start, end + 1))
        quizTitle = obj.optString("title", if (mode == MODE_CARDS) "Flashcard" else "Latihan kuis").ifBlank { "Latihan" }
        if (mode == MODE_CARDS) {
            val array = obj.optJSONArray("cards") ?: JSONArray()
            val parsed = (0 until array.length()).mapNotNull { i ->
                val item = array.optJSONObject(i) ?: return@mapNotNull null
                val front = item.optString("front").trim()
                val back = item.optString("back").trim()
                if (front.isBlank() || back.isBlank()) null else Flashcard(front, back)
            }
            require(parsed.size >= 4) { "Flashcard kurang dari 4" }
            cards = parsed
            return true
        }
        val array = obj.optJSONArray("questions") ?: JSONArray()
        val parsed = (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val prompt = item.optString("question").trim()
            val optionsArray = item.optJSONArray("options") ?: JSONArray()
            val options = (0 until optionsArray.length()).map { optionsArray.optString(it).trim() }.filter { it.isNotBlank() }
            val correct = item.optInt("correct_index", -1)
            val explanation = item.optString("explanation").trim()
            if (prompt.isBlank() || options.size != 4 || correct !in 0..3 || explanation.isBlank()) null
            else QuizItem(prompt, options, correct, explanation)
        }
        require(parsed.size >= 4) { "Soal pilihan ganda valid kurang dari 4" }
        questions = parsed
        selected = IntArray(questions.size) { -1 }
        checked = BooleanArray(questions.size)
        return true
    }

    private fun renderQuestion() {
        val item = questions.getOrNull(index) ?: return showError("Soal latihan tidak tersedia.")
        binding.studyTitle.text = quizTitle
        binding.studyQuestionCard.visibility = View.VISIBLE
        binding.studyErrorText.visibility = View.GONE
        binding.studyCounter.text = "Soal ${index + 1} dari ${questions.size}"
        binding.studyQuestionText.text = item.prompt
        binding.studyOptionsGroup.visibility = View.VISIBLE
        binding.studyCardFace.visibility = View.GONE
        binding.studyFeedback.visibility = if (checked[index]) View.VISIBLE else View.GONE
        binding.studyOptionsGroup.removeAllViews()
        item.options.forEachIndexed { optionIndex, option ->
            val button = RadioButton(this).apply {
                text = option
                textSize = 16f
                setPadding(8, 14, 8, 14)
                id = View.generateViewId()
                isChecked = selected[index] == optionIndex
                isEnabled = !checked[index]
            }
            binding.studyOptionsGroup.addView(button)
            button.setOnClickListener { selected[index] = optionIndex }
        }
        binding.studyOptionsGroup.setOnCheckedChangeListener { group, checkedId ->
            if (!checked[index]) {
                val childIndex = (0 until group.childCount).firstOrNull { group.getChildAt(it).id == checkedId }
                if (childIndex != null) selected[index] = childIndex
            }
        }
        binding.studyFeedback.text = if (checked[index]) {
            (if (selected[index] == item.correct) "Benar. " else "Belum tepat. Jawaban yang benar: ${item.options[item.correct]}. ") + item.explanation
        } else ""
        binding.studyActionButton.text = if (checked[index]) "Sudah diperiksa" else "Periksa jawaban"
        binding.studyActionButton.isEnabled = !checked[index]
        binding.studyNextButton.text = if (index == questions.lastIndex) "Lihat nilai" else "Berikutnya"
        binding.studyNextButton.isEnabled = checked[index]
    }

    private fun renderCard() {
        val item = cards.getOrNull(index) ?: return showError("Flashcard tidak tersedia.")
        binding.studyTitle.text = quizTitle
        binding.studyQuestionCard.visibility = View.VISIBLE
        binding.studyErrorText.visibility = View.GONE
        binding.studyCounter.text = "Kartu ${index + 1} dari ${cards.size}"
        binding.studyQuestionText.text = "Ketuk tombol untuk membalik kartu"
        binding.studyOptionsGroup.visibility = View.GONE
        binding.studyCardFace.visibility = View.VISIBLE
        binding.studyFeedback.visibility = View.GONE
        binding.studyCardFace.text = if (showBack) item.back else item.front
        binding.studyActionButton.text = if (showBack) "Lihat depan" else "Lihat jawaban"
        binding.studyActionButton.isEnabled = true
        binding.studyNextButton.text = if (index == cards.lastIndex) "Mulai ulang kartu" else "Berikutnya"
        binding.studyNextButton.isEnabled = true
    }

    private fun onAction() {
        if (mode == MODE_CARDS) {
            showBack = !showBack
            renderCard()
            return
        }
        if (questions.isEmpty() || checked.getOrNull(index) == true) return
        if (selected[index] !in 0..3) {
            Toast.makeText(this, "Pilih satu jawaban terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        checked[index] = true
        renderQuestion()
    }

    private fun nextItem() {
        if (mode == MODE_CARDS) {
            index = if (index >= cards.lastIndex) 0 else index + 1
            showBack = false
            renderCard()
            return
        }
        if (!checked.getOrNull(index).orFalse()) {
            Toast.makeText(this, "Periksa jawaban terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        if (index < questions.lastIndex) {
            index++
            renderQuestion()
        } else showScore()
    }

    private fun showScore() {
        val score = questions.indices.count { checked[it] && selected[it] == questions[it].correct }
        val total = questions.size
        val percentage = if (total == 0) 0 else score * 100 / total
        binding.studyQuestionCard.visibility = View.GONE
        binding.studyTitle.text = "Nilai: $score dari $total ($percentage%)"
        binding.studyCounter.text = "Latihan selesai"
        binding.studyErrorText.visibility = View.VISIBLE
        binding.studyErrorText.text = questions.indices.joinToString("\n\n") { i ->
            val q = questions[i]
            "${i + 1}. ${q.prompt}\nJawaban benar: ${q.options[q.correct]}\n${q.explanation}"
        }
        binding.studyActionButton.text = "Ulangi kuis"
        binding.studyActionButton.isEnabled = true
        binding.studyNextButton.text = "Kembali"
        binding.studyNextButton.isEnabled = true
        binding.studyActionButton.setOnClickListener {
            selected = IntArray(questions.size) { -1 }
            checked = BooleanArray(questions.size)
            index = 0
            binding.studyQuestionCard.visibility = View.VISIBLE
            binding.studyErrorText.visibility = View.GONE
            binding.studyActionButton.setOnClickListener { onAction() }
            renderQuestion()
        }
        binding.studyNextButton.setOnClickListener { finish() }
    }

    private fun showError(message: String) {
        binding.studyProgress.visibility = View.GONE
        binding.studyQuestionCard.visibility = View.GONE
        binding.studyErrorText.visibility = View.VISIBLE
        binding.studyErrorText.text = message
        binding.studyRetryButton.visibility = View.VISIBLE
        binding.studyActionButton.isEnabled = false
        binding.studyNextButton.isEnabled = false
    }

    private fun Boolean?.orFalse(): Boolean = this ?: false
}
