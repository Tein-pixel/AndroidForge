package com.scanpr.ultra.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Minimal OpenAI-compatible client used for Groq and Cerebras; IDs are discovered from /models. */
class OpenAiCompatibleApi(private val baseUrl: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).callTimeout(10, TimeUnit.SECONDS).build()

    suspend fun listModels(apiKey: String): List<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext emptyList()
        runCatching {
            val request = Request.Builder().url("${baseUrl.trimEnd('/')}/models").header("Authorization", "Bearer $apiKey").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use emptyList()
                val data = JSONObject(response.body?.string().orEmpty()).optJSONArray("data") ?: JSONArray()
                (0 until data.length()).mapNotNull { i -> data.optJSONObject(i)?.optString("id")?.takeIf(String::isNotBlank) }.distinct()
            }
        }.getOrDefault(emptyList())
    }

    suspend fun ask(prompt: String, apiKey: String, model: String): String? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || model.isBlank()) return@withContext null
        runCatching {
            val body = JSONObject()
                .put("model", model)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                .put("temperature", 0.15)
                .put("max_tokens", 4096)
                .toString()
            val request = Request.Builder().url("${baseUrl.trimEnd('/')}/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                JSONObject(response.body?.string().orEmpty()).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.takeIf(String::isNotBlank)
            }
        }.getOrNull()
    }
}
