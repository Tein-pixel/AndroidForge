// File: app/src/main/java/com/scanpr/ultra/utils/ImageUtils.kt
package com.scanpr.ultra.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.ImageView
import com.bumptech.glide.Glide
import java.io.ByteArrayOutputStream

object ImageUtils {
    data class EncodedImage(val mimeType: String, val base64: String)

    fun show(context: Context, uri: Uri?, target: ImageView) {
        if (uri == null) { target.setImageDrawable(null); return }
        runCatching { Glide.with(context).load(uri).centerCrop().into(target) }
    }

    /**
     * Compresses a cropped image in memory before sending it to a vision-capable API.
     * The image is never written to a new permanent file. Returns null if it cannot be read
     * or remains too large; the caller may then fall back to OCR text only.
     */
    fun encodeForAi(context: Context, uri: Uri): EncodedImage? {
        var bitmap: Bitmap? = null
        return try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sampleSize = 1
            val longestSide = maxOf(bounds.outWidth, bounds.outHeight)
            while (longestSide / sampleSize > 1800) sampleSize *= 2
            val options = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                ?: return null

            var output = ByteArrayOutputStream()
            bitmap!!.compress(Bitmap.CompressFormat.JPEG, 82, output)
            var bytes = output.toByteArray()
            if (bytes.size > 2 * 1024 * 1024) {
                val old = bitmap!!
                val scale = minOf(1f, 1200f / maxOf(old.width, old.height).coerceAtLeast(1))
                val resized = Bitmap.createScaledBitmap(old,
                    (old.width * scale).toInt().coerceAtLeast(1),
                    (old.height * scale).toInt().coerceAtLeast(1), true)
                if (resized !== old) old.recycle()
                bitmap = resized
                output = ByteArrayOutputStream()
                bitmap!!.compress(Bitmap.CompressFormat.JPEG, 74, output)
                bytes = output.toByteArray()
            }
            if (bytes.isEmpty() || bytes.size > 2 * 1024 * 1024) return null
            EncodedImage("image/jpeg", Base64.encodeToString(bytes, Base64.NO_WRAP))
        } catch (_: Exception) {
            null
        } finally {
            bitmap?.let { if (!it.isRecycled) it.recycle() }
        }
    }
}
