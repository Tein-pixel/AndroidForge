package com.scanpr.ultra.utils

import android.content.Context

object AiPreferences {
    const val AUTO = "AUTO"
    const val GEMINI = "GEMINI"
    const val OPENROUTER = "OPENROUTER"
    const val GROQ = "GROQ"
    const val CEREBRAS = "CEREBRAS"
    private const val PREFS = "scanpr_ai_options"
    private const val PRIORITY = "provider_priority"

    fun getPriority(context: Context): String = context.applicationContext
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(PRIORITY, AUTO) ?: AUTO

    fun setPriority(context: Context, value: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PRIORITY, value).apply()
    }

    /** Gemini and OpenRouter free routes first; alternate providers are tried only after those fail.
     * Providers without a saved key are skipped by AiProvider. Free quotas and plan conditions vary.
     */
    fun providerOrder(context: Context): List<String> = when (getPriority(context)) {
        GROQ -> listOf(GROQ, GEMINI, OPENROUTER, CEREBRAS)
        CEREBRAS -> listOf(CEREBRAS, GEMINI, OPENROUTER, GROQ)
        OPENROUTER -> listOf(OPENROUTER, GEMINI, GROQ, CEREBRAS)
        GEMINI -> listOf(GEMINI, OPENROUTER, GROQ, CEREBRAS)
        else -> listOf(GEMINI, OPENROUTER)
    }
}
