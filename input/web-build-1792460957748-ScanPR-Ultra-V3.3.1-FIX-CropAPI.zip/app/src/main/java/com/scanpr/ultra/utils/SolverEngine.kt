package com.scanpr.ultra.utils

import java.util.Locale
import kotlin.math.abs

/** Honest offline solver: only returns numerical results for expressions it can fully parse. */
object SolverEngine {
    fun solveOffline(text: String): AiResult {
        val original = text.trim()
        if (original.isBlank()) return AiResult("Teks soal kosong.", listOf("Ketik soal atau ambil foto, lalu periksa hasil OCR."), "Umum", "Offline", emptyList(), "Belum ada teks yang bisa diproses.")
        val input = original.replace(',', '.').replace('×', '*').replace('÷', '/')

        val percent = Regex("(?i)([-+]?\\d+(?:\\.\\d+)?)\\s*%\\s*(?:dari|of)\\s*([-+]?\\d+(?:\\.\\d+)?)").find(input)
        if (percent != null) {
            val p = percent.groupValues[1].toDoubleOrNull()
            val n = percent.groupValues[2].toDoubleOrNull()
            if (p != null && n != null) {
                val result = p / 100.0 * n
                return AiResult(fmt(result), listOf("Ubah persen menjadi desimal: ${fmt(p)}% = ${fmt(p / 100.0)}.", "Kalikan dengan nilai dasar: ${fmt(p / 100.0)} × ${fmt(n)} = ${fmt(result)}."), "Matematika", "Solver offline", emptyList(), "Hasil operasi persen dihitung secara lokal. Cocokkan apakah nilai dasar pada soal terbaca benar.")
            }
        }

        if ('=' in input && Regex("(?i)(?:^|[^a-z])x(?:$|[^a-z])|\\d\\s*x|x\\s*[+\\-=/]").containsMatchIn(input)) {
            val parts = input.split('=', limit = 2)
            if (parts.size == 2) {
                val left = linear(parts[0])
                val right = linear(parts[1])
                if (left != null && right != null) {
                    val a = left.first - right.first
                    val b = right.second - left.second
                    if (abs(a) > 1e-9) {
                        val x = b / a
                        return AiResult("x = ${fmt(x)}", listOf("Gabungkan suku yang memuat x di satu sisi.", "Susun persamaan menjadi ${fmt(a)}x = ${fmt(b)}.", "Bagi kedua sisi dengan ${fmt(a)}: x = ${fmt(b)} ÷ ${fmt(a)} = ${fmt(x)}.", "Pemeriksaan: substitusi x = ${fmt(x)} ke persamaan asli dan pastikan kedua sisi sama."), "Matematika", "Solver offline", emptyList(), "Solver lokal hanya mendukung persamaan linear satu variabel dengan operasi dasar. Pastikan persamaan OCR tidak terpotong.")
                    }
                    if (abs(b) < 1e-9) return AiResult("Banyak solusi (identitas).", listOf("Setelah suku disederhanakan, kedua sisi sama untuk semua nilai x."), "Matematika", "Solver offline", emptyList())
                    return AiResult("Tidak ada solusi.", listOf("Setelah suku disederhanakan, diperoleh persamaan konstanta yang tidak mungkin benar."), "Matematika", "Solver offline", emptyList())
                }
            }
        }

        val candidate = input
            .replace(Regex("(?i)\\b(berapa|hitunglah|hitung|hasil dari|nilai dari|adalah)\\b"), " ")
            .trim().trimEnd('?', '.', '=')
        if (candidate.isNotBlank() && candidate.all { it.isDigit() || it in "+-*/^().% \t" }) {
            val normalized = candidate.replace("%", "/100")
            val parsed = runCatching { ExpressionParser(normalized).parse() }.getOrNull()
            if (parsed != null && parsed.isFinite()) {
                return AiResult(fmt(parsed), listOf("Ekspresi yang dihitung: $candidate.", "Urutan operasi diterapkan sesuai prioritas matematika (kurung, pangkat, kali/bagi, tambah/kurang).", "Hasil perhitungan: ${fmt(parsed)}."), "Matematika", "Solver offline", emptyList(), "Periksa kembali operator dan tanda desimal yang dibaca dari foto. Solver offline tidak menyelesaikan soal cerita atau simbol aljabar umum.")
            }
        }

        return AiResult(
            "Mode offline belum dapat menyelesaikan soal ini secara otomatis.",
            listOf("Teks yang terbaca: $original", "Periksa ejaan, angka, satuan, serta informasi yang diketahui dan ditanyakan.", "Hubungkan internet dan siapkan kunci AI di Pengaturan untuk mencoba model online, atau kerjakan dengan rumus dari materi pelajaran."),
            detectSubject(original), "Offline terbatas", emptyList(),
            "Tidak ada jawaban pasti yang dihitung secara offline untuk tipe soal ini. Aplikasi sengaja tidak menebak jawaban."
        )
    }

    private fun detectSubject(text: String): String {
        val s = text.lowercase(Locale.ROOT)
        return when {
            listOf("persamaan", "integral", "turunan", "keliling", "luas", "akar", "pecahan", "sudut", "x =").any { it in s } -> "Matematika"
            listOf("gaya", "kecepatan", "massa", "energi", "newton", "listrik", "arus", "tegangan").any { it in s } -> "Fisika"
            listOf("atom", "mol", "reaksi", "unsur", "senyawa", "asam", "basa", "ph").any { it in s } -> "Kimia"
            listOf("sel", "fotosintesis", "ekosistem", "organ", "genetik", "biologi").any { it in s } -> "Biologi"
            listOf("proklamasi", "kerajaan", "kolonial", "sejarah").any { it in s } -> "Sejarah"
            listOf("pancasila", "uud 1945", "hak dan kewajiban", "ppkn", "kewarganegaraan").any { it in s } -> "PPKn"
            listOf("translate", "grammar", "tenses", "synonym", "antonym").any { it in s } -> "Bahasa Inggris"
            listOf("gagasan pokok", "majas", "paragraf", "antonim", "sinonim").any { it in s } -> "Bahasa Indonesia"
            else -> "Umum"
        }
    }

    private fun linear(side: String): Pair<Double, Double>? = runCatching {
        val s = side.replace(" ", "").lowercase(Locale.US).replace("-", "+-")
        if (s.isBlank()) return@runCatching null
        var a = 0.0
        var b = 0.0
        for (term in s.split('+').filter { it.isNotBlank() }) {
            if ('x' in term) {
                if (term.count { it == 'x' } != 1 || term.substringAfter('x').isNotBlank()) return@runCatching null
                val coeff = term.substringBefore('x')
                a += when (coeff) { "", "+" -> 1.0; "-" -> -1.0; else -> coeff.toDouble() }
            } else b += term.toDouble()
        }
        a to b
    }.getOrNull()

    private fun fmt(value: Double): String {
        if (!value.isFinite()) return "tidak terdefinisi"
        val rounded = if (abs(value - value.toLong().toDouble()) < 1e-9) value.toLong().toString()
        else String.format(Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
        return rounded.replace('.', ',')
    }

    private class ExpressionParser(private val source: String) {
        private var pos = 0
        fun parse(): Double {
            val value = expression()
            skipSpaces()
            require(pos == source.length) { "Karakter tidak dikenali" }
            return value
        }
        private fun expression(): Double {
            var v = term()
            while (true) {
                skipSpaces()
                v = when (peek()) {
                    '+' -> { pos++; v + term() }
                    '-' -> { pos++; v - term() }
                    else -> return v
                }
            }
        }
        private fun term(): Double {
            var v = unary()
            while (true) {
                skipSpaces()
                v = when (peek()) {
                    '*' -> { pos++; v * unary() }
                    '/' -> { pos++; val d = unary(); require(abs(d) > 1e-12) { "Pembagian dengan nol" }; v / d }
                    else -> return v
                }
            }
        }
        private fun unary(): Double {
            skipSpaces()
            return when (peek()) {
                '+' -> { pos++; unary() }
                '-' -> { pos++; -unary() }
                else -> power()
            }
        }
        private fun power(): Double {
            var v = primary()
            skipSpaces()
            if (peek() == '^') { pos++; v = Math.pow(v, unary()) }
            return v
        }
        private fun primary(): Double {
            skipSpaces()
            return if (peek() == '(') {
                pos++; val v = expression(); skipSpaces(); require(peek() == ')') { "Kurung tidak seimbang" }; pos++; v
            } else number()
        }
        private fun number(): Double {
            skipSpaces()
            val start = pos
            var dots = 0
            while (pos < source.length && (source[pos].isDigit() || source[pos] == '.')) {
                if (source[pos] == '.') dots++
                require(dots <= 1) { "Format desimal tidak valid" }
                pos++
            }
            require(pos > start) { "Angka diharapkan" }
            return source.substring(start, pos).toDouble()
        }
        private fun peek(): Char? = source.getOrNull(pos)
        private fun skipSpaces() { while (pos < source.length && source[pos].isWhitespace()) pos++ }
    }
}
