package com.scanpr.ultra

import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.scanpr.ultra.databinding.ActivitySettingsBinding
import com.scanpr.ultra.utils.AiKeyStore
import com.scanpr.ultra.utils.AiPreferences
import com.scanpr.ultra.utils.GeminiApi
import com.scanpr.ultra.utils.NetworkUtils
import com.scanpr.ultra.utils.OpenAiCompatibleApi
import com.scanpr.ultra.utils.OpenRouterApi
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.utils.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private var updating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.settingsToolbar.setNavigationOnClickListener { finish() }

        lifecycleScope.launch {
            val mode = ThemeManager.getMode(this@SettingsActivity).first()
            updating = true
            binding.themeRadioGroup.check(when (mode) { ThemeMode.LIGHT -> R.id.radio_light; ThemeMode.DARK -> R.id.radio_dark; ThemeMode.SYSTEM -> R.id.radio_system })
            updating = false
        }
        binding.themeRadioGroup.setOnCheckedChangeListener { _, checked ->
            if (updating || checked == -1) return@setOnCheckedChangeListener
            val mode = when (checked) { R.id.radio_light -> ThemeMode.LIGHT; R.id.radio_dark -> ThemeMode.DARK; else -> ThemeMode.SYSTEM }
            lifecycleScope.launch { ThemeManager.saveMode(this@SettingsActivity, mode); ThemeManager.applyTheme(mode); recreate() }
        }
        val priorityLabels = listOf("Otomatis · Gemini free-tier + OpenRouter free", "Gemini Flash · free tier", "OpenRouter · varian :free", "Groq · kuota akun perlu dicek", "Cerebras · kuota akun perlu dicek")
        val priorityValues = listOf(AiPreferences.AUTO, AiPreferences.GEMINI, AiPreferences.OPENROUTER, AiPreferences.GROQ, AiPreferences.CEREBRAS)
        binding.aiProviderPrioritySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, priorityLabels)
        val initialPriority = AiPreferences.getPriority(this)
        binding.aiProviderPrioritySpinner.setSelection(priorityValues.indexOf(initialPriority).coerceAtLeast(0), false)
        binding.aiProviderPrioritySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                AiPreferences.setPriority(this@SettingsActivity, priorityValues[position])
            }
        }
        lifecycleScope.launch {
            val keys = withContext(Dispatchers.IO) {
                listOf(AiKeyStore.geminiKey(this@SettingsActivity), AiKeyStore.openRouterKey(this@SettingsActivity), AiKeyStore.groqKey(this@SettingsActivity), AiKeyStore.cerebrasKey(this@SettingsActivity))
            }
            binding.editGeminiKey.setText(keys[0]); binding.editOpenrouterKey.setText(keys[1]); binding.editGroqKey.setText(keys[2]); binding.editCerebrasKey.setText(keys[3])
        }
        binding.saveAiKeysButton.setOnClickListener { saveKeys() }
        binding.testAiKeysButton.setOnClickListener { testProviders() }
    }

    private fun saveKeys() {
        val gemini = binding.editGeminiKey.text?.toString().orEmpty()
        val openRouter = binding.editOpenrouterKey.text?.toString().orEmpty()
        val groq = binding.editGroqKey.text?.toString().orEmpty()
        val cerebras = binding.editCerebrasKey.text?.toString().orEmpty()
        binding.saveAiKeysButton.isEnabled = false
        binding.aiKeysStatus.visibility = View.VISIBLE
        binding.aiKeysStatus.text = "Menyimpan kunci secara terenkripsi…"
        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) { runCatching { AiKeyStore.save(this@SettingsActivity, gemini, openRouter, groq, cerebras) } }
            binding.saveAiKeysButton.isEnabled = true
            binding.aiKeysStatus.text = if (saved.isSuccess) {
                if (listOf(gemini, openRouter, groq, cerebras).all { it.isBlank() }) "Semua kunci dikosongkan. Aplikasi akan menggunakan solver offline terbatas." else "Kunci tersimpan. Tekan ‘Tes koneksi dan model tersedia’ untuk memeriksa provider yang bisa diakses."
            } else "Gagal menyimpan kunci terenkripsi. Periksa dukungan keamanan perangkat dan coba lagi."
        }
    }

    private fun testProviders() {
        binding.testAiKeysButton.isEnabled = false
        binding.aiKeysStatus.visibility = View.VISIBLE
        binding.aiKeysStatus.text = if (NetworkUtils.isOnline(this)) "Memeriksa provider dan katalog model…" else "Perangkat sedang offline. Hubungkan internet untuk menguji API."
        if (!NetworkUtils.isOnline(this)) { binding.testAiKeysButton.isEnabled = true; return }
        lifecycleScope.launch {
            val report = withContext(Dispatchers.IO) {
                val lines = mutableListOf<String>()
                val g = AiKeyStore.geminiKey(this@SettingsActivity)
                if (g.isNotBlank()) {
                    val count = try { GeminiApi().listModels(g).size } catch (_: Exception) { 0 }
                    lines.add("Gemini: $count model free-tier terdaftar")
                }
                val gr = AiKeyStore.groqKey(this@SettingsActivity)
                if (gr.isNotBlank()) {
                    val count = try { OpenAiCompatibleApi("https://api.groq.com/openai/v1").listModels(gr).size } catch (_: Exception) { 0 }
                    lines.add("Groq: $count model tersedia; gunakan hanya pada akun dengan kuota gratis aktif dan periksa dashboard akun")
                }
                val ce = AiKeyStore.cerebrasKey(this@SettingsActivity)
                if (ce.isNotBlank()) {
                    val count = try { OpenAiCompatibleApi("https://api.cerebras.ai/v1").listModels(ce).size } catch (_: Exception) { 0 }
                    lines.add("Cerebras: $count model tersedia; kuota/biaya bergantung paket akun—bukan jaminan gratis tanpa batas")
                }
                val o = AiKeyStore.openRouterKey(this@SettingsActivity)
                if (o.isNotBlank()) {
                    val count = try { OpenRouterApi().listFreeModels(o).size } catch (_: Exception) { 0 }
                    lines.add("OpenRouter: $count varian :free terdeteksi; router openrouter/free juga dicoba otomatis")
                }
                if (lines.isEmpty()) lines.add("Belum ada kunci yang disimpan.")
                lines.joinToString("\n")
            }
            binding.aiKeysStatus.text = report + "\n\nCatatan: kuota gratis dapat berubah. Jangan simpan API key dari akun dengan billing aktif bila ingin menghindari biaya."
            binding.testAiKeysButton.isEnabled = true
        }
    }
}
