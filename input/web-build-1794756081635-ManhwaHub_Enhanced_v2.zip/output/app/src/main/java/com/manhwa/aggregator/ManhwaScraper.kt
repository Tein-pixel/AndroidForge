package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ManhwaScraper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val proxyBase = "https://api.allorigins.win/raw?url="

    private val domains = listOf(
        "https://kiryuu.to/manga/?m_orderby=latest"            to "Kiryuu",
        "https://komikcast.mom/daftar-komik/?order=update"     to "Komikcast",
        "https://asuracomic.net/series?order=update"           to "Asura"
    )

    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> =
        withContext(Dispatchers.IO) {
            // Each source is isolated: one unavailable website must not cancel the others.
            supervisorScope {
                val requests = domains.map { (baseUrl, sourceName) ->
                    async {
                        runCatching { fetchFromSource(baseUrl, sourceName, query, genre) }
                            .getOrDefault(emptyList())
                    }
                }
                requests.flatMap { it.await() }.distinctBy { it.link }
            }
        }

    private fun fetchFromSource(
        baseUrl: String,
        sourceName: String,
        query: String,
        genre: String
    ): List<Manhwa> {
        var targetUrl = baseUrl
        if (query.isNotBlank()) {
            // Preserve each configured source URL/domain; only construct its search query.
            val uri = java.net.URI(baseUrl)
            val sourceRoot = "${uri.scheme}://${uri.host}/"
            targetUrl = sourceRoot + "?s=" + URLEncoder.encode(query.trim(), "UTF-8")
        } else if (genre.isNotBlank() && genre != "Semua") {
            val root = baseUrl.substringBefore("?").substringBeforeLast("/")
            targetUrl = "$root/genre/${genre.lowercase().replace(" ", "-")}/?m_orderby=latest"
        }

        val html = fetchHtmlWithFallback(targetUrl)
        val doc = Jsoup.parse(html, targetUrl)
        val elements = doc.select(
            ".listupd .bs, .bsx, .page-item-detail, .manga__item, .grid > div"
        )
        return elements.mapNotNull { el ->
            val anchor = el.select(
                ".tt h3 a, .tt h4 a, .post-title h3 a, .manga__item-title a, .text-white"
            ).firstOrNull() ?: el.selectFirst("a[href]")
            val title = anchor?.text()?.trim().orEmpty()
            val link = if (anchor == null) "" else anchor.absUrl("href").ifBlank { anchor.attr("href") }
            val image = el.selectFirst("img")
            val rawImage = image?.let {
                listOf("data-src", "data-lazy-src", "data-original", "src")
                    .firstNotNullOfOrNull { key -> it.attr(key).takeIf(String::isNotBlank) }
            }.orEmpty()
            val imageUrl = if (rawImage.isBlank()) "" else try {
                java.net.URI(targetUrl).resolve(rawImage).toString()
            } catch (_: Exception) { rawImage }
            val latestChapter = el.select(
                ".epxs, .chapter-item .btn-link, .chapter-item a"
            ).firstOrNull()?.text()?.trim() ?: "Chapter Baru"
            if (title.isBlank() || !link.startsWith("http") || !imageUrl.startsWith("http")) null
            else Manhwa(title, link, imageUrl, latestChapter, sourceName)
        }
    }

    /** Existing AllOrigins proxy remains primary; direct source access is a fallback only. */
    private fun fetchHtmlWithFallback(targetUrl: String): String {
        val proxied = proxyBase + URLEncoder.encode(targetUrl, "UTF-8")
        return runCatching { executeRequest(proxied) }.getOrElse { proxyError ->
            runCatching { executeRequest(targetUrl) }.getOrElse { directError ->
                throw IllegalStateException("Proxy dan sumber gagal: ${directError.message ?: proxyError.message}")
            }
        }
    }

    private fun executeRequest(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
            return response.body?.string().orEmpty()
        }
    }

}
