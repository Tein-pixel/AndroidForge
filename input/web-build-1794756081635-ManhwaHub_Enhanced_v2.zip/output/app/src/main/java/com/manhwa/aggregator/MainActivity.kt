package com.manhwa.aggregator

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.chip.Chip
import com.manhwa.aggregator.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scraper = ManhwaScraper()
    private val library by lazy { LibraryStore(this) }
    private var currentQuery = ""
    private var currentGenre = ""
    private var loadJob: Job? = null
    private var currentMode = Mode.HOME
    private var currentLibraryFilter = "Semua"

    private val exportBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                    it.write(library.exportBackup())
                } ?: throw IllegalStateException("File tujuan tidak dapat dibuka")
                Toast.makeText(this, "Backup berhasil disimpan", Toast.LENGTH_LONG).show()
            } catch (error: Exception) {
                Toast.makeText(this, "Backup gagal: ${error.localizedMessage ?: "kesalahan file"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val importBackupLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("File backup tidak dapat dibaca")
                if (library.importBackup(raw)) {
                    currentLibraryFilter = "Semua"
                    currentMode = Mode.LIBRARY
                    binding.bottomNavigation.selectedItemId = R.id.nav_library
                    updateHeader()
                    loadData()
                    Toast.makeText(this, "Backup berhasil dipulihkan", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "File backup tidak valid atau tidak didukung", Toast.LENGTH_LONG).show()
                }
            } catch (error: Exception) {
                Toast.makeText(this, "Restore gagal: ${error.localizedMessage ?: "kesalahan file"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private enum class Mode { HOME, DISCOVER, LIBRARY, HISTORY }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupRecyclerView()
        setupSearch()
        setupChips()
        setupSwipeRefresh()
        setupNavigation()
        setupTools()
        binding.tvSectionSubtitle.setOnClickListener {
            if (currentMode == Mode.LIBRARY) showLibraryFilter()
        }
        setupEntranceAnimations()
        updateHeader()
        loadData()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && (currentMode == Mode.LIBRARY || currentMode == Mode.HISTORY)) loadData()
    }

    private fun setupTools() {
        binding.btnTools.setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menu.add(0, 1, 0, "Backup koleksi")
            popup.menu.add(0, 2, 1, "Pulihkan backup")
            popup.menu.add(0, 3, 2, "Filter koleksi")
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> {
                        exportBackupLauncher.launch("manhwa-hub-backup-${System.currentTimeMillis()}.json")
                        true
                    }
                    2 -> {
                        importBackupLauncher.launch(arrayOf("application/json", "text/plain"))
                        true
                    }
                    3 -> {
                        showLibraryFilter()
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    private fun showLibraryFilter() {
        val filters = arrayOf("Semua", "Sedang dibaca", "Rencana baca", "Selesai", "Ditunda", "Dihentikan")
        AlertDialog.Builder(this)
            .setTitle("Filter koleksi")
            .setSingleChoiceItems(filters, filters.indexOf(currentLibraryFilter).coerceAtLeast(0)) { dialog, which ->
                currentLibraryFilter = filters[which]
                if (currentMode != Mode.LIBRARY) {
                    currentMode = Mode.LIBRARY
                    binding.bottomNavigation.selectedItemId = R.id.nav_library
                }
                updateHeader()
                loadData()
                dialog.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun setupRecyclerView() {
        binding.rvManhwa.layoutManager = GridLayoutManager(this, 2)
        binding.rvManhwa.setHasFixedSize(true)
        binding.rvManhwa.setItemViewCacheSize(8)
    }

    private fun setupSearch() {
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                currentQuery = binding.etSearch.text.toString().trim()
                currentGenre = ""
                currentMode = Mode.DISCOVER
                binding.chipGroupGenre.setOnCheckedStateChangeListener(null)
                binding.chipAll.isChecked = true
                allChips().forEach { applyChipStyle(it, it.id == R.id.chipAll) }
                reattachChipListener()
                updateHeader()
                loadData()
                true
            } else false
        }
        binding.etSearch.setOnFocusChangeListener { view, hasFocus ->
            view.background = ContextCompat.getDrawable(this,
                if (hasFocus) R.drawable.glass_search_focused else R.drawable.glass_search)
            view.animate().scaleX(if (hasFocus) 1.012f else 1f).scaleY(if (hasFocus) 1.012f else 1f)
                .setDuration(180).start()
        }
    }

    private fun setupChips() {
        allChips().forEach { chip ->
            applyChipStyle(chip, chip.isChecked)
            chip.setOnCheckedChangeListener { _, checked ->
                applyChipStyle(chip, checked)
                if (checked) chip.animate().scaleX(1.035f).scaleY(1.035f).setDuration(90)
                    .withEndAction { chip.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
            }
        }
        reattachChipListener()
    }

    private fun reattachChipListener() {
        binding.chipGroupGenre.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                currentQuery = ""
                binding.etSearch.text.clear()
                currentMode = Mode.DISCOVER
                currentGenre = when (checkedIds[0]) {
                    R.id.chipAction -> "Action"
                    R.id.chipFantasy -> "Fantasy"
                    R.id.chipRomance -> "Romance"
                    R.id.chipMartial -> "Martial Arts"
                    else -> "Semua"
                }
                updateHeader()
                loadData()
            }
        }
    }

    private fun setupNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            currentQuery = ""
            currentGenre = ""
            binding.etSearch.text.clear()
            binding.chipGroupGenre.setOnCheckedStateChangeListener(null)
            binding.chipAll.isChecked = true
            allChips().forEach { applyChipStyle(it, it.id == R.id.chipAll) }
            reattachChipListener()
            when (item.itemId) {
                R.id.nav_home -> currentMode = Mode.HOME
                R.id.nav_discover -> currentMode = Mode.DISCOVER
                R.id.nav_library -> currentMode = Mode.LIBRARY
                R.id.nav_history -> currentMode = Mode.HISTORY
                else -> return@setOnItemSelectedListener false
            }
            updateHeader()
            loadData()
            true
        }
    }

    private fun updateHeader() {
        when (currentMode) {
            Mode.HOME -> {
                binding.tvSectionTitle.text = "Pilihan untukmu"
                binding.tvSectionSubtitle.text = "Update terbaru dari sumber favorit"
                binding.chipGroupGenre.visibility = View.VISIBLE
            }
            Mode.DISCOVER -> {
                binding.tvSectionTitle.text = if (currentGenre.isNotBlank() && currentGenre != "Semua") currentGenre else "Jelajahi komik"
                binding.tvSectionSubtitle.text = if (currentQuery.isNotBlank()) "Hasil pencarian: $currentQuery" else "Temukan cerita berikutnya"
                binding.chipGroupGenre.visibility = View.VISIBLE
            }
            Mode.LIBRARY -> {
                binding.tvSectionTitle.text = "Koleksi saya"
                binding.tvSectionSubtitle.text = "Filter: $currentLibraryFilter  ·  Ketuk untuk memilih"
                binding.chipGroupGenre.visibility = View.GONE
            }
            Mode.HISTORY -> {
                binding.tvSectionTitle.text = "Terakhir dibaca"
                binding.tvSectionSubtitle.text = "Lanjutkan dari tempat terakhir"
                binding.chipGroupGenre.visibility = View.GONE
            }
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener { loadData(isRefresh = true) }
        binding.swipeRefresh.setColorSchemeColors(Color.parseColor("#72F5D5"), Color.parseColor("#7BA8FF"))
    }

    private fun setupEntranceAnimations() {
        binding.topBar.apply {
            translationY = -28f
            alpha = 0f
            animate().translationY(0f).alpha(1f).setDuration(420).start()
        }
    }

    private fun allChips(): List<Chip> = listOf(
        binding.chipAll, binding.chipAction, binding.chipFantasy, binding.chipRomance, binding.chipMartial
    )

    private fun applyChipStyle(chip: Chip, checked: Boolean) {
        val density = resources.displayMetrics.density
        chip.chipBackgroundColor = android.content.res.ColorStateList.valueOf(
            if (checked) Color.parseColor("#303E8D83") else Color.parseColor("#161D2B")
        )
        chip.chipStrokeColor = android.content.res.ColorStateList.valueOf(
            if (checked) Color.parseColor("#8872F5D5") else Color.parseColor("#20FFFFFF")
        )
        chip.chipStrokeWidth = density
        chip.isCheckedIconVisible = false
        chip.setTextColor(if (checked) Color.parseColor("#A3FFE9") else Color.parseColor("#AAB4C5"))
        chip.chipCornerRadius = density * 22f
    }

    private fun loadData(isRefresh: Boolean = false) {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            if (!isRefresh) {
                delay(80)
                binding.progressBar.visibility = View.VISIBLE
                binding.tvEmpty.visibility = View.GONE
            }
            try {
                val list = when (currentMode) {
                    Mode.HOME, Mode.DISCOVER -> scraper.fetchLatest(currentQuery, currentGenre)
                    Mode.LIBRARY -> library.libraryItems(currentLibraryFilter)
                    Mode.HISTORY -> library.history()
                }.filterNot { it.source == "System" }.map { ManhwaUrlResolver.resolveItem(it) }

                binding.rvManhwa.adapter = ManhwaAdapter(list) { openDetails(it) }
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                binding.tvEmpty.text = when (currentMode) {
                    Mode.LIBRARY -> "Belum ada judul di kategori ini.\nBuka detail komik lalu pilih status bacaan."
                    Mode.HISTORY -> "Riwayat bacaan masih kosong.\nKomik yang kamu buka akan muncul di sini."
                    else -> "Belum ada hasil yang bisa ditampilkan.\nCoba sumber lain atau muat ulang."
                }
            } catch (e: Exception) {
                binding.tvEmpty.text = "Tidak dapat memuat katalog. Periksa koneksi lalu coba lagi."
                binding.tvEmpty.visibility = View.VISIBLE
                Toast.makeText(this@MainActivity, "Gagal memuat: ${e.localizedMessage ?: "koneksi"}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.progressBar.visibility = View.GONE
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun openDetails(item: Manhwa) {
        library.addToHistory(item)
        startActivity(Intent(this, ManhwaDetailActivity::class.java).apply {
            putExtra(ManhwaDetailActivity.EXTRA_TITLE, item.title)
            putExtra(ManhwaDetailActivity.EXTRA_LINK, item.link)
            putExtra(ManhwaDetailActivity.EXTRA_IMAGE, item.imageUrl)
            putExtra(ManhwaDetailActivity.EXTRA_CHAPTER, item.latestChapter)
            putExtra(ManhwaDetailActivity.EXTRA_SOURCE, item.source)
        })
    }
}
