// DisplayAccessService.java : java, Android 29+, com.media.access
// Renamed from TextExtractorService. Generic name in Accessibility settings.
//
// Two jobs:
//   1. Hide this app's task from system recents on window-state change.
//   2. On CROP_CONFIRM (LocalBroadcast) → extract text from crop rect.
//      Path A (all API): walk accessibility node tree → collect text from nodes in rect.
//      Path B (API 30+ only, fallback when A is empty): takeScreenshot() → crop bitmap
//        → ML Kit OCR → result. Handles canvas/image content that has no accessible nodes.
//
// All broadcasts use LocalBroadcastManager — completely invisible to other apps.
package com.media.access;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.ArrayList;
import java.util.List;

public class DisplayAccessService extends AccessibilityService {

    // ── broadcast actions (intra-process only via LocalBroadcastManager) ─────

    /** BubbleService → this service: user confirmed crop area. */
    public static final String ACTION_CROP_CONFIRM   = "da.CROP_CONFIRM";
    /** This service → BubbleService: extracted text ready. */
    public static final String ACTION_TEXT_EXTRACTED = "da.TEXT_EXTRACTED";

    public static final String EXTRA_RECT_LEFT   = "rl";
    public static final String EXTRA_RECT_TOP    = "rt";
    public static final String EXTRA_RECT_RIGHT  = "rr";
    public static final String EXTRA_RECT_BOTTOM = "rb";
    public static final String EXTRA_TEXT        = "tx";

    // ── lifecycle ─────────────────────────────────────────────────────────────

    private BroadcastReceiver cropReceiver;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        cropReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (!ACTION_CROP_CONFIRM.equals(intent.getAction())) return;
                Rect rect = new Rect(
                        intent.getIntExtra(EXTRA_RECT_LEFT,   0),
                        intent.getIntExtra(EXTRA_RECT_TOP,    0),
                        intent.getIntExtra(EXTRA_RECT_RIGHT,  0),
                        intent.getIntExtra(EXTRA_RECT_BOTTOM, 0));
                handleCrop(rect);
            }
        };
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(cropReceiver, new IntentFilter(ACTION_CROP_CONFIRM));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cropReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(cropReceiver);
        }
    }

    // ── crop handling ─────────────────────────────────────────────────────────

    private void handleCrop(Rect rect) {
        // Path A: accessibility tree (works for any text rendered as UI nodes)
        String accessText = extractFromRect(rect);
        if (!accessText.isEmpty()) {
            broadcastResult(accessText);
            return;
        }

        // Path B: pixel-level OCR via takeScreenshot (API 30+ only)
        // Handles canvas renders, PDF views, games, exam portals drawing to Canvas.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY,
                    getMainExecutor(),
                    new TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(ScreenshotResult result) {
                            Bitmap full = null;
                            Bitmap cropped = null;
                            try {
                                // ScreenshotResult has no getBitmap(). The public API
                                // (API 30+) only exposes getHardwareBuffer() + getColorSpace().
                                // Wrap HardwareBuffer → hardware-backed Bitmap, then copy to
                                // software ARGB_8888 so ML Kit can access the pixels directly.
                                android.hardware.HardwareBuffer hb = result.getHardwareBuffer();
                                Bitmap hwBitmap = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
                                hb.close();
                                result.close();
                                if (hwBitmap == null) { broadcastResult(""); return; }
                                full = hwBitmap.copy(Bitmap.Config.ARGB_8888, false);
                                hwBitmap.recycle();
                                // clamp rect to bitmap bounds
                                int bw = full.getWidth();
                                int bh = full.getHeight();
                                int l = Math.max(0, Math.min(rect.left,   bw - 1));
                                int t = Math.max(0, Math.min(rect.top,    bh - 1));
                                int r = Math.max(1, Math.min(rect.right,  bw));
                                int b = Math.max(1, Math.min(rect.bottom, bh));
                                if (r <= l || b <= t) {
                                    broadcastResult("");
                                    return;
                                }
                                cropped = Bitmap.createBitmap(full, l, t, r - l, b - t);
                                final Bitmap ocrInput = cropped;
                                ScreenOcrHelper.runOcr(ocrInput, text -> {
                                    ocrInput.recycle();
                                    broadcastResult(text);
                                });
                            } catch (Exception e) {
                                if (cropped != null && !cropped.isRecycled()) cropped.recycle();
                                broadcastResult("");
                            } finally {
                                if (full != null && !full.isRecycled()) full.recycle();
                            }
                        }

                        @Override
                        public void onFailure(int errorCode) {
                            broadcastResult("");
                        }
                    });
        } else {
            // Android 10 (API 29): no pixel capture without MediaProjection.
            // Return empty; BubbleService will show camera-suggestion toast.
            broadcastResult("");
        }
    }

    private void broadcastResult(String text) {
        Intent reply = new Intent(ACTION_TEXT_EXTRACTED);
        reply.putExtra(EXTRA_TEXT, text);
        LocalBroadcastManager.getInstance(this).sendBroadcast(reply);
    }

    // ── accessibility tree extraction ─────────────────────────────────────────

    private String extractFromRect(Rect sel) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "";
        List<String> pieces = new ArrayList<>();
        collectText(root, sel, pieces);
        root.recycle();
        return join(pieces);
    }

    private void collectText(AccessibilityNodeInfo node, Rect sel, List<String> out) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (!Rect.intersects(bounds, sel)) {
            node.recycle();
            return;
        }
        if (node.getChildCount() == 0) {
            CharSequence text = node.getText();
            CharSequence desc = node.getContentDescription();
            String content = (text != null && text.length() > 0)
                    ? text.toString().trim()
                    : (desc != null ? desc.toString().trim() : "");
            if (!content.isEmpty()) out.add(content);
        } else {
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) collectText(child, sel, out);
            }
        }
    }

    private static String join(List<String> parts) {
        if (parts.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(p);
        }
        return sb.toString();
    }

    // ── recents hider ─────────────────────────────────────────────────────────

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (!getPackageName().equals(event.getPackageName())) return;
        hideOwnTask();
    }

    private void hideOwnTask() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return;
        for (ActivityManager.AppTask t : am.getAppTasks()) {
            try { t.setExcludeFromRecents(true); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onInterrupt() {}

    // ── static helper ─────────────────────────────────────────────────────────

    /**
     * Returns true when this service is active in system accessibility settings.
     * Uses the new class name: DisplayAccessService.
     */
    public static boolean isEnabled(Context ctx) {
        String myComp = ctx.getPackageName() + "/" + DisplayAccessService.class.getName();
        String enabled = Settings.Secure.getString(
                ctx.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.contains(myComp);
    }
}
