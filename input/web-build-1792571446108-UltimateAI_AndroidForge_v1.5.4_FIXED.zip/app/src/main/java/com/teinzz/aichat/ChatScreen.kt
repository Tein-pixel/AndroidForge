package com.teinzz.aichat

import android.net.Uri
import android.content.Intent
import android.app.Activity
import android.speech.RecognizerIntent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.teinzz.aichat.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onSettings: () -> Unit, onCamera: () -> Unit, onArtifacts: () -> Unit) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val conversations by vm.conversations.collectAsState()
    var showModels by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var attachedPath by remember { mutableStateOf<String?>(null) }
    var attachmentName by remember { mutableStateOf<String?>(null) }
    var fileContext by remember { mutableStateOf<String?>(null) }
    var isImage by remember { mutableStateOf(false) }
    var busyAttachment by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val messages = vm.messages
    val listState = rememberLazyListState()
    val snack = remember { SnackbarHostState() }
    var showAppMenu by remember { mutableStateOf(false) }
    var pendingExportText by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri: Uri? ->
        if (uri != null) scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val output = context.contentResolver.openOutputStream(uri) ?: error("File tujuan tidak bisa dibuka")
                    output.use { it.write(pendingExportText.toByteArray(Charsets.UTF_8)) }
                }
            }
            snack.showSnackbar(if (result.isSuccess) "Percakapan berhasil diekspor." else "Ekspor gagal: ${result.exceptionOrNull()?.message ?: "error"}")
        }
    }

    fun transcript(): String = buildString {
        append("# Ultimate AI — Percakapan\n\n")
        messages.forEach { message ->
            append(if (message.role == "user") "## Kamu\n\n" else "## Ultimate AI\n\n")
            if (message.imagePath != null) append("[Lampiran gambar: ${message.fileName ?: "gambar"}]\n\n")
            else if (!message.fileName.isNullOrBlank()) append("[Lampiran: ${message.fileName}]\n\n")
            append(message.content).append("\n\n---\n\n")
        }
    }

    fun exportConversation() {
        if (messages.isEmpty()) return
        pendingExportText = transcript()
        val source = messages.firstOrNull { it.role == "user" }?.content.orEmpty()
        val safeName = source.take(28).replace(Regex("[^A-Za-z0-9_-]+"), "_").trim('_').ifBlank { "Chat" }
        exportLauncher.launch("UltimateAI_$safeName.md")
    }

    fun shareConversation() {
        if (messages.isEmpty()) return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Percakapan Ultimate AI")
            putExtra(Intent.EXTRA_TEXT, transcript())
        }
        runCatching { context.startActivity(Intent.createChooser(intent, "Bagikan percakapan")) }
            .onFailure { scope.launch { snack.showSnackbar("Tidak ada aplikasi untuk membagikan percakapan.") } }
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) draft = listOf(draft.trim(), spoken).filter { it.isNotBlank() }.joinToString(" ")
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busyAttachment = true
            runCatching { withContext(Dispatchers.IO) { ImageCompressor.fromGallery(context, uri) } }
                .onSuccess { attachedPath = it.absolutePath; attachmentName = "Image.jpg"; isImage = true; fileContext = null }
                .onFailure { snack.showSnackbar("Gambar gagal dibuka: ${it.message ?: "format tidak didukung"}") }
            busyAttachment = false
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busyAttachment = true
            val name = withContext(Dispatchers.IO) {
                context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else "attachment" } ?: "attachment"
            }
            runCatching { withContext(Dispatchers.IO) { AttachmentTools.copyAndExtract(context, uri, name) } }
                .onSuccess { (file, extracted) -> attachedPath = file.absolutePath; attachmentName = name; fileContext = extracted; isImage = false }
                .onFailure { snack.showSnackbar("File gagal dibaca: ${it.message ?: "error"}") }
            busyAttachment = false
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.content) {
        if (messages.isNotEmpty()) {
            // Streaming updates use an immediate scroll instead of queuing a new animation for every token.
            if (vm.isGenerating.value) listState.scrollToItem(messages.lastIndex)
            else listState.animateScrollToItem(messages.lastIndex)
        }
    }
    LaunchedEffect(vm.errorMessage.value) { vm.errorMessage.value?.let { snack.showSnackbar(it) } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth(0.86f)) {
                HistoryDrawerContent(conversations, onNewChat = { vm.newChat(); draft = ""; scope.launch { drawerState.close() } },
                    onSelect = { vm.selectConversation(it); draft = ""; scope.launch { drawerState.close() } },
                    onRename = vm::renameConversation, onDelete = vm::deleteConversation,
                    onSettings = { scope.launch { drawerState.close() }; onSettings() })
            }
        }
    ) {
        Scaffold(
            // Combined with windowSoftInputMode=adjustResize, this keeps the composer above the IME
            // on Android 10 and newer instead of allowing the keyboard to cover the text field.
            modifier = Modifier.fillMaxSize().imePadding(),
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Outlined.Menu, contentDescription = "Open history") }
                        TextButton(onClick = { showModels = true }, modifier = Modifier.weight(1f)) {
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (vm.isModelReady()) vm.currentModel.value.name else "Pilih model AI", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Icon(Icons.Outlined.ExpandMore, contentDescription = "Choose model")
                        }
                        IconButton(onClick = { vm.newChat(); draft = ""; attachedPath = null; attachmentName = null; fileContext = null; isImage = false }) { Icon(Icons.Outlined.Edit, contentDescription = "Chat baru") }
                        Box {
                            IconButton(onClick = { showAppMenu = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = "Menu lainnya") }
                            DropdownMenu(expanded = showAppMenu, onDismissRequest = { showAppMenu = false }) {
                                DropdownMenuItem(text = { Text("Ekspor percakapan (.md)") }, leadingIcon = { Icon(Icons.Outlined.FileDownload, null) }, enabled = messages.isNotEmpty(), onClick = { showAppMenu = false; exportConversation() })
                                DropdownMenuItem(text = { Text("Salin seluruh percakapan") }, leadingIcon = { Icon(Icons.Outlined.ContentCopy, null) }, enabled = messages.isNotEmpty(), onClick = { showAppMenu = false; clipboard.setText(AnnotatedString(transcript())); scope.launch { snack.showSnackbar("Percakapan disalin.") } })
                                DropdownMenuItem(text = { Text("Bagikan percakapan") }, leadingIcon = { Icon(Icons.Outlined.Share, null) }, enabled = messages.isNotEmpty(), onClick = { showAppMenu = false; shareConversation() })
                                DropdownMenuItem(text = { Text("Artifacts / ruang kerja") }, leadingIcon = { Icon(Icons.Outlined.Code, null) }, onClick = { showAppMenu = false; onArtifacts() })
                                DropdownMenuItem(text = { Text("Pengaturan") }, leadingIcon = { Icon(Icons.Outlined.Settings, null) }, onClick = { showAppMenu = false; onSettings() })
                            }
                        }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (messages.isEmpty()) {
                        WelcomePanel(onSuggestion = { draft = it })
                    }
                    if (messages.isNotEmpty()) {
                        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                            items(messages, key = { if (it.id == 0L) "${it.role}-${it.createdAt}" else it.id }) { msg ->
                                val lastUserId = messages.lastOrNull { item -> item.role == "user" }?.id
                                val lastAssistantId = messages.lastOrNull { item -> item.role == "assistant" }?.id
                                val canEdit = msg.role == "user" && msg.id == lastUserId && !vm.isGenerating.value && msg.imagePath == null && msg.fileName == null
                                val canRegenerate = msg.role == "assistant" && msg.id == lastAssistantId && !vm.isGenerating.value && vm.isModelReady() && messages.any { item -> item.role == "user" }
                                MessageRow(
                                    msg,
                                    streaming = vm.isGenerating.value && msg.id == messages.lastOrNull()?.id,
                                    modifier = Modifier.animateItem(),
                                    onEdit = if (canEdit) ({ draft = msg.content; vm.editLastExchange(msg.id) }) else null,
                                    onRegenerate = if (canRegenerate) ({ vm.regenerateLastResponse() }) else null
                                )
                            }
                            if (vm.isGenerating.value && (messages.lastOrNull()?.content.isNullOrBlank())) item { TypingIndicator() }
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    if (isImage && attachedPath != null && !vm.currentModel.value.vision) {
                        Text("Model ini tidak mendukung gambar. Pilih model berlabel GAMBAR dari pemilih model.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
                    }
                    if (attachedPath != null || busyAttachment) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (isImage && attachedPath != null) AsyncImage(model = File(attachedPath!!), contentDescription = "Image preview", modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
                            else Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) { Icon(Icons.Outlined.AttachFile, null, Modifier.padding(13.dp)) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (busyAttachment) "Reading attachment…" else attachmentName ?: "Attachment", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                                Text(if (isImage) "Image will be sent to a vision model" else if (fileContext != null) "Text extracted and ready" else "File attached", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { attachedPath = null; attachmentName = null; fileContext = null; isImage = false }) { Icon(Icons.Outlined.Close, contentDescription = "Remove attachment") }
                        }
                    }
                    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth().animateContentSize()) {
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                            BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), minLines = 1, maxLines = 4,
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface, lineHeight = 24.sp),
                                decorationBox = { inner -> Box { if (draft.isEmpty()) Text("Tanyakan apa saja…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge); inner() } })
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                var showAttachMenu by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(onClick = { showAttachMenu = true }, enabled = !busyAttachment) {
                                        Icon(Icons.Outlined.Add, contentDescription = "Lampiran dan mode", modifier = Modifier.size(26.dp))
                                    }
                                    DropdownMenu(expanded = showAttachMenu, onDismissRequest = { showAttachMenu = false }) {
                                        DropdownMenuItem(
                                            text = { Text("File atau dokumen") },
                                            leadingIcon = { Icon(Icons.Outlined.AttachFile, contentDescription = null) },
                                            onClick = { showAttachMenu = false; filePicker.launch(arrayOf("application/pdf", "text/plain", "text/csv", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Ambil foto dengan kamera") },
                                            leadingIcon = { Icon(Icons.Outlined.PhotoCamera, contentDescription = null) },
                                            onClick = { showAttachMenu = false; onCamera() }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Pilih foto dari galeri") },
                                            leadingIcon = { Icon(Icons.Outlined.Image, contentDescription = null) },
                                            onClick = { showAttachMenu = false; gallery.launch("image/*") }
                                        )
                                        HorizontalDivider()
                                        DropdownMenuItem(
                                            text = { Text(if (vm.chatMode.value == ChatMode.THINK_HARDER) "Matikan berpikir lebih keras" else "Berpikir lebih keras") },
                                            leadingIcon = { Icon(Icons.Outlined.Psychology, contentDescription = null) },
                                            trailingIcon = { if (vm.chatMode.value == ChatMode.THINK_HARDER) Icon(Icons.Outlined.Check, contentDescription = "Aktif") },
                                            onClick = { showAttachMenu = false; vm.setChatMode(if (vm.chatMode.value == ChatMode.THINK_HARDER) ChatMode.NORMAL else ChatMode.THINK_HARDER) }
                                        )
                                        DropdownMenuItem(
                                            enabled = vm.currentModel.value.provider in setOf(Provider.GEMINI, Provider.OPENROUTER),
                                            text = { Text(if (vm.chatMode.value == ChatMode.DEEP_RESEARCH) "Matikan riset mendalam" else "Riset mendalam") },
                                            leadingIcon = { Icon(Icons.Outlined.TravelExplore, contentDescription = null) },
                                            trailingIcon = { if (vm.chatMode.value == ChatMode.DEEP_RESEARCH) Icon(Icons.Outlined.Check, contentDescription = "Aktif") },
                                            onClick = { showAttachMenu = false; vm.setChatMode(if (vm.chatMode.value == ChatMode.DEEP_RESEARCH) ChatMode.NORMAL else ChatMode.DEEP_RESEARCH) }
                                        )
                                    }
                                }
                                IconButton(onClick = {
                                    val voiceIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan pesan")
                                    }
                                    runCatching { voiceLauncher.launch(voiceIntent) }
                                        .onFailure { scope.launch { snack.showSnackbar("Dikte suara tidak tersedia di perangkat ini.") } }
                                }, enabled = !busyAttachment && !vm.isGenerating.value) {
                                    Icon(Icons.Outlined.Mic, contentDescription = "Dikte suara", modifier = Modifier.size(22.dp))
                                }
                                Spacer(Modifier.weight(1f))
                                if (vm.isGenerating.value) {
                                    IconButton(onClick = vm::stopGenerating) { Icon(Icons.Outlined.StopCircle, contentDescription = "Stop generating") }
                                } else {
                                    IconButton(onClick = {
                                        val finalText = if (!isImage && fileContext != null) buildString { append(draft); append("\n\n[Attached file: ${attachmentName ?: "file"}]\n"); append(fileContext) } else draft
                                        val modelReady = vm.isModelReady()
                                        vm.send(finalText, if (isImage) attachedPath else null, attachmentName)
                                        // Keep the user's draft if no authenticated live model is ready yet.
                                        if (modelReady) {
                                            draft = ""; attachedPath = null; attachmentName = null; fileContext = null; isImage = false
                                        }
                                    }, enabled = (draft.isNotBlank() || attachedPath != null) && !busyAttachment && (!isImage || vm.currentModel.value.vision), modifier = Modifier.size(42.dp).background(if ((draft.isNotBlank() || attachedPath != null) && !busyAttachment) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant, CircleShape)) {
                                        Icon(Icons.Outlined.ArrowUpward, contentDescription = "Send", tint = MaterialTheme.colorScheme.surface, modifier = Modifier.size(22.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showModels) {
            ModalBottomSheet(onDismissRequest = { showModels = false }, containerColor = MaterialTheme.colorScheme.surface) {
                ModelChooser(vm = vm, onSelect = { vm.selectModel(it); showModels = false })
            }
        }
    }
}

@Composable
private fun WelcomePanel(onSuggestion: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(62.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.AutoAwesome, contentDescription = null, modifier = Modifier.size(32.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        Text("Ada yang bisa saya bantu?", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(24.dp))
        val suggestions = listOf("Prompt gambar" to Icons.Outlined.Image, "Analisis foto" to Icons.Outlined.Visibility, "Bantu coding" to Icons.Outlined.Code, "Rangkum file" to Icons.Outlined.Description)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            suggestions.chunked(2).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { (label, icon) ->
                        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), modifier = Modifier.weight(1f).clickable { onSuggestion(when (label) { "Prompt gambar" -> "Bantu aku merancang prompt gambar yang detail untuk generator gambar: "; "Analisis foto" -> "Analisis foto ini dan jelaskan detail pentingnya."; "Bantu coding" -> "Bantu aku menulis dan memperbaiki kode. Jelaskan solusinya."; else -> "Rangkum isi file yang aku lampirkan." }) }.padding(horizontal = 12.dp, vertical = 15.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)); Text(label, style = MaterialTheme.typography.bodyMedium, maxLines = 2) }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ModelChooser(vm: ChatViewModel, onSelect: (AiModel) -> Unit) {
    var search by remember { mutableStateOf("") }
    val allModels = vm.modelCatalog.value
    val readyProviders = vm.availableModelProviders.value
    // ModelDiscovery adds a provider only after its saved key and live catalogue succeed.
    // Do not initialize encrypted key storage again during Compose recomposition.
    val providersWithSavedKeys = readyProviders
    val models = allModels.filter { model ->
        model.provider.active && model.provider in providersWithSavedKeys &&
            (vm.showPaidModels.value || model.freeTier) &&
            (search.isBlank() || model.name.contains(search, true) || model.id.contains(search, true) || model.provider.title.contains(search, true))
    }

    Column(
        Modifier.fillMaxWidth().fillMaxHeight(0.90f).padding(horizontal = 18.dp).padding(bottom = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("Pilih model", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
                Text("${models.size} tersedia", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { vm.refreshModelCatalog() }, enabled = !vm.isRefreshingModelCatalog.value) {
                if (vm.isRefreshingModelCatalog.value) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp)
                else Icon(Icons.Outlined.Refresh, contentDescription = "Perbarui model")
            }
            IconButton(onClick = vm::testSelectedModel, enabled = vm.isModelReady() && !vm.isTestingModel.value && !vm.isGenerating.value && !vm.isGeneratingArtifact.value) {
                if (vm.isTestingModel.value) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Icon(Icons.Outlined.CheckCircle, contentDescription = "Tes model")
            }
        }
        OutlinedTextField(
            value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, placeholder = { Text("Cari model…") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            trailingIcon = { if (search.isNotBlank()) IconButton(onClick = { search = "" }) { Icon(Icons.Outlined.Close, contentDescription = "Hapus pencarian") } }
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Tampilkan model berbayar", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = vm.showPaidModels.value, onCheckedChange = vm::setPaidVisible)
        }
        if (vm.modelTestStatus.value.isNotBlank()) {
            val testText = vm.modelTestStatus.value
            Text(
                when {
                    testText.startsWith("BERHASIL") -> "Tes berhasil"
                    testText.startsWith("GAGAL") -> testText.substringBefore(":").take(70)
                    else -> "Menguji model…"
                },
                style = MaterialTheme.typography.labelSmall,
                color = if (testText.startsWith("BERHASIL")) MaterialTheme.colorScheme.primary else if (testText.startsWith("GAGAL")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        if (models.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (vm.isRefreshingModelCatalog.value) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Spacer(Modifier.height(10.dp))
                Text(
                    if (vm.isRefreshingModelCatalog.value) "Memuat model…" else "Simpan API key yang valid, lalu tekan Perbarui.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Provider.values().filter { provider -> models.any { it.provider == provider } }.forEach { provider ->
                    val providerModels = models.filter { it.provider == provider }
                    item(key = "provider_${provider.name}") {
                        Text(
                            provider.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 3.dp)
                        )
                    }
                    items(providerModels, key = { it.storageKey }) { model ->
                        val selected = vm.currentModel.value.storageKey == model.storageKey
                        val recommendation = modelRecommendation(model)
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
                                .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                                .then(if (selected) Modifier.border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), RoundedCornerShape(13.dp)) else Modifier)
                                .clickable { onSelect(model) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        model.name,
                                        modifier = Modifier.weight(1f, fill = false),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    if (recommendation != null) {
                                        Spacer(Modifier.width(7.dp))
                                        Text(recommendation, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    ModelMetaBadge(model.badge)
                                    if (model.vision) ModelMetaBadge("GAMBAR")
                                }
                            }
                            if (selected) {
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Outlined.CheckCircle, contentDescription = "Dipilih", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun modelRecommendation(model: AiModel): String? {
    val id = model.id.lowercase()
    val name = model.name.lowercase()
    return when {
        id == "openrouter/auto" -> "Otomatis"
        id == "openrouter/free" -> "Rute gratis*"
        id == "gemini-4-argon" -> "Reasoning premium"
        id == "gemini-3.8-flash" || "gemini 3.8 flash" in name -> "Utama · serbaguna"
        id == "gemini-3.6-flash" || "gemini 3.6 flash" in name -> "Alternatif cepat"
        "flash-lite" in id || "flash-lite" in name -> "Cepat & ringan"
        "gpt-oss-120b" in id -> "Coding & analisis"
        "gpt-oss-20b" in id -> "Kerja ringan"
        "nemotron-3.5-super-vl" in id -> "Analisis gambar"
        else -> null
    }
}

@Composable
private fun ModelMetaBadge(label: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageRow(
    message: MessageEntity,
    streaming: Boolean,
    onEdit: (() -> Unit)? = null,
    onRegenerate: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    val clipboard = LocalClipboardManager.current
    var showActions by remember(message.id) { mutableStateOf(false) }
    val bubbleShape = if (isUser) RoundedCornerShape(22.dp) else RoundedCornerShape(4.dp)

    // A user bubble must size to its content. Do not put a fillMaxWidth() action row inside it:
    // that was making even a one-word message stretch into a large empty pill.
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val bubbleLimit = if (isUser) maxWidth * 0.84f else maxWidth
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.Top
        ) {
            Column(
                Modifier.widthIn(max = bubbleLimit)
                    .then(if (isUser) Modifier.wrapContentWidth(Alignment.End) else Modifier.fillMaxWidth())
                    .clip(bubbleShape)
                    .background(if (isUser) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                    .combinedClickable(
                        enabled = !streaming,
                        onClick = {},
                        onLongClick = { showActions = true }
                    )
                    .padding(if (isUser) 13.dp else 0.dp)
            ) {
                if (message.imagePath != null) {
                    AsyncImage(
                        model = File(message.imagePath),
                        contentDescription = "Gambar terkirim",
                        modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(16.dp))
                    )
                    if (message.content.isNotBlank()) Spacer(Modifier.height(8.dp))
                }
                if (message.content.isNotBlank()) {
                    if (isUser) {
                        Text(
                            message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    } else {
                        RichMarkdown(message.content + if (streaming) "▍" else "")
                    }
                }
                if (!message.fileName.isNullOrBlank() && message.imagePath == null) {
                    Text(
                        "Lampiran: ${message.fileName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isUser) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 5.dp)
                    )
                }

                // Keep compact response controls outside user bubbles; user messages use a long-press menu.
                if (!isUser && !streaming && (message.content.isNotBlank() || message.imagePath != null)) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 3.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { clipboard.setText(AnnotatedString(message.content)) }, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = "Salin jawaban", modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (onRegenerate != null) {
                            IconButton(onClick = onRegenerate, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Outlined.Refresh, contentDescription = "Buat ulang jawaban", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                DropdownMenu(expanded = showActions, onDismissRequest = { showActions = false }) {
                    if (isUser && onEdit != null) {
                        DropdownMenuItem(
                            text = { Text("Edit pesan") },
                            leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                            onClick = { showActions = false; onEdit.invoke() }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Salin teks") },
                        leadingIcon = { Icon(Icons.Outlined.ContentCopy, contentDescription = null) },
                        onClick = { showActions = false; clipboard.setText(AnnotatedString(message.content)) }
                    )
                    if (!isUser && onRegenerate != null) {
                        DropdownMenuItem(
                            text = { Text("Buat ulang jawaban") },
                            leadingIcon = { Icon(Icons.Outlined.Refresh, contentDescription = null) },
                            onClick = { showActions = false; onRegenerate.invoke() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RichMarkdown(markdown: String) {
    val clipboard = LocalClipboardManager.current
    val uriHandler = LocalUriHandler.current
    val blocks = remember(markdown) {
        val result = mutableListOf<Pair<Boolean, String>>()
        val regex = Regex("```([^\\n]*)\\n([\\s\\S]*?)```")
        var cursor = 0
        regex.findAll(markdown).forEach { match ->
            if (match.range.first > cursor) result.add(false to markdown.substring(cursor, match.range.first))
            result.add(true to (match.groupValues[1].trim() + "\n" + match.groupValues[2].trimEnd()))
            cursor = match.range.last + 1
        }
        if (cursor < markdown.length) result.add(false to markdown.substring(cursor))
        result
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        blocks.forEach { (code, content) ->
            if (code) {
                val codeText = content.substringAfter('\n', "")
                Surface(color = Color(0xFF0D1117), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(Modifier.fillMaxWidth().background(Color(0xFF171B22)).padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(content.substringBefore('\n').ifBlank { "code" }, style = MaterialTheme.typography.labelSmall, color = Color(0xFFB7C0CC), modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(codeText)) }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) { Icon(Icons.Outlined.ContentCopy, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("Copy", fontSize = 12.sp) }
                        }
                        Text(syntaxHighlight(codeText), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(14.dp), color = Color(0xFFE6EDF3), fontSize = 13.sp, lineHeight = 19.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    }
                }
            } else if (content.isNotBlank()) {
                val lines = content.lines()
                var lineIndex = 0
                while (lineIndex < lines.size) {
                    val line = lines[lineIndex]
                    val trimmed = line.trim()

                    // Render Markdown tables as native Compose rows instead of showing raw pipes.
                    if (trimmed.contains('|') && lineIndex + 1 < lines.size && isMarkdownTableDivider(lines[lineIndex + 1])) {
                        val tableRows = mutableListOf(line, lines[lineIndex + 1])
                        var next = lineIndex + 2
                        while (next < lines.size && lines[next].contains('|') && lines[next].isNotBlank()) {
                            tableRows.add(lines[next])
                            next++
                        }
                        MarkdownTable(tableRows)
                        lineIndex = next
                        continue
                    }

                    // Display math is rendered in a compact, horizontally scrollable formula surface.
                    if (trimmed == "\$\$" || trimmed == "\\[") {
                        val closing = if (trimmed == "\$\$") "\$\$" else "\\]"
                        var closeIndex = lineIndex + 1
                        while (closeIndex < lines.size && lines[closeIndex].trim() != closing) closeIndex++
                        val formula = lines.subList(lineIndex + 1, closeIndex.coerceAtMost(lines.size)).joinToString(" ")
                        MarkdownMathBlock(formula)
                        lineIndex = if (closeIndex < lines.size) closeIndex + 1 else lines.size
                        continue
                    }
                    if ((trimmed.startsWith("\$\$") && trimmed.endsWith("\$\$") && trimmed.length > 4) || (trimmed.startsWith("\\[") && trimmed.endsWith("\\]") && trimmed.length > 4)) {
                        MarkdownMathBlock(trimmed)
                        lineIndex++
                        continue
                    }

                    val bullet = trimmed.startsWith("- ") || trimmed.startsWith("* ") || Regex("^\\d+\\. ").containsMatchIn(trimmed)
                    val displayLine = if (bullet) "•  " + trimmed.removePrefix("- ").removePrefix("* ").replaceFirst(Regex("^\\d+\\. "), "") else line
                    val annotated = styledMarkdown(displayLine, MaterialTheme.colorScheme.surfaceVariant)
                    ClickableText(
                        text = annotated,
                        style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface, lineHeight = 27.sp),
                        onClick = { offset ->
                            annotated.getStringAnnotations("URL", offset, offset).firstOrNull()?.let { annotation ->
                                runCatching { uriHandler.openUri(annotation.item) }
                            }
                        }
                    )
                    lineIndex++
                }
            }
        }
    }
}

private fun styledMarkdown(line: String, inlineCodeBackground: Color): AnnotatedString = buildAnnotatedString {
    val token = Regex("""\[[^\]]+\]\(https?://[^)]+\)|\$\$[^$]+\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|\$[^$\n]+\$|\*\*.+?\*\*|(?<!\*)\*[^*]+\*|`[^`]+`""")
    var cursor = 0
    token.findAll(line).forEach { match ->
        append(line.substring(cursor, match.range.first))
        val raw = match.value
        when {
            raw.startsWith("[") && raw.contains("](") -> {
                val split = raw.indexOf("](")
                val label = raw.substring(1, split)
                val url = raw.substring(split + 2, raw.length - 1)
                pushStringAnnotation(tag = "URL", annotation = url)
                pushStyle(SpanStyle(color = Color(0xFF2F80ED), textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline))
                append(label)
                pop(); pop()
            }
            raw.startsWith("\$\$") || raw.startsWith("\$") || raw.startsWith("\\(") || raw.startsWith("\\[") -> {
                pushStyle(SpanStyle(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, background = inlineCodeBackground.copy(alpha = 0.75f)))
                append(formatMath(raw)); pop()
            }
            raw.startsWith("**") -> { pushStyle(SpanStyle(fontWeight = FontWeight.Bold)); append(raw.substring(2, raw.length - 2)); pop() }
            raw.startsWith("*") -> { pushStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)); append(raw.substring(1, raw.length - 1)); pop() }
            else -> { pushStyle(SpanStyle(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, background = inlineCodeBackground)); append(raw.substring(1, raw.length - 1)); pop() }
        }
        cursor = match.range.last + 1
    }
    append(line.substring(cursor))
}

private fun splitMarkdownTableRow(line: String): List<String> = line.trim().removePrefix("|").removeSuffix("|").split('|').map { it.trim() }

private fun isMarkdownTableDivider(line: String): Boolean {
    val cells = splitMarkdownTableRow(line)
    return cells.isNotEmpty() && cells.all { Regex(":?-{3,}:?").matches(it.replace(" ", "")) }
}

@Composable
private fun MarkdownTable(lines: List<String>) {
    val rows = lines.filterNot { isMarkdownTableDivider(it) }.map(::splitMarkdownTableRow)
    if (rows.isEmpty()) return
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(1.dp)) {
            Column {
                rows.forEachIndexed { rowIndex, row ->
                    Row(verticalAlignment = Alignment.Top) {
                        row.forEach { cell ->
                            Text(
                                cell,
                                modifier = Modifier.widthIn(min = 92.dp, max = 220.dp).padding(horizontal = 10.dp, vertical = 9.dp),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (rowIndex == 0) FontWeight.SemiBold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    if (rowIndex == 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
    }
}

@Composable
private fun MarkdownMathBlock(raw: String) {
    val formula = formatMath(raw)
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(formula, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

private fun formatMath(raw: String): String {
    var value = raw.trim()
        .removePrefix("\$\$").removeSuffix("\$\$")
        .removePrefix("\\[").removeSuffix("\\]")
        .removePrefix("\\(").removeSuffix("\\)")
        .trim()
    value = value.replace(Regex("\\\\frac\\{([^{}]+)}\\{([^{}]+)}"), "($1)/($2)")
        .replace(Regex("\\\\sqrt\\{([^{}]+)}"), "√($1)")
        .replace("\\times", "×").replace("\\cdot", "·").replace("\\div", "÷")
        .replace("\\pi", "π").replace("\\theta", "θ").replace("\\alpha", "α").replace("\\beta", "β")
        .replace("\\leq", "≤").replace("\\geq", "≥").replace("\\neq", "≠").replace("\\approx", "≈")
        .replace("\\infty", "∞").replace("\\sum", "∑").replace("\\int", "∫").replace("\\pm", "±")
        .replace("\\left", "").replace("\\right", "").replace("\\cdots", "…").replace("\\ldots", "…")
    val superscript = mapOf('0' to '⁰', '1' to '¹', '2' to '²', '3' to '³', '4' to '⁴', '5' to '⁵', '6' to '⁶', '7' to '⁷', '8' to '⁸', '9' to '⁹', '+' to '⁺', '-' to '⁻', '=' to '⁼', 'n' to 'ⁿ', 'i' to 'ⁱ')
    val subscript = mapOf('0' to '₀', '1' to '₁', '2' to '₂', '3' to '₃', '4' to '₄', '5' to '₅', '6' to '₆', '7' to '₇', '8' to '₈', '9' to '₉', '+' to '₊', '-' to '₋', '=' to '₌', 'n' to 'ₙ', 'i' to 'ᵢ')
    value = Regex("\\^\\{([^{}]+)}").replace(value) { m -> m.groupValues[1].map { superscript[it] ?: it }.joinToString("") }
    value = Regex("_\\{([^{}]+)}").replace(value) { m -> m.groupValues[1].map { subscript[it] ?: it }.joinToString("") }
    value = Regex("\\^([0-9+n=\\-])").replace(value) { m -> superscript[m.groupValues[1][0]]?.toString() ?: m.value }
    value = Regex("_([0-9ni])").replace(value) { m -> subscript[m.groupValues[1][0]]?.toString() ?: m.value }
    return value.replace("\\{", "").replace("\\}", "").replace("\\,", " ").trim()
}

private fun syntaxHighlight(code: String): AnnotatedString = buildAnnotatedString {
    append(code)
    val keywords = Regex("\\b(fun|val|var|class|object|return|if|else|when|for|while|suspend|data|private|public|import|package|const|let|function|async|await|def|from|as|try|catch|throw|new|true|false|null)\\b")
    keywords.findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFFFF7B72), fontWeight = FontWeight.Medium), it.range.first, it.range.last + 1) }
    Regex("\"[^\"]*\"|'[^']*'").findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFFA5D6FF)), it.range.first, it.range.last + 1) }
    Regex("//[^\\n]*|#[^\\n]*").findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFF8B949E)), it.range.first, it.range.last + 1) }
}

@Composable
private fun TypingIndicator() {
    val transition = rememberInfiniteTransition(label = "typing-indicator")
    val first by transition.animateFloat(0.22f, 0.9f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "dot-1")
    val second by transition.animateFloat(0.22f, 0.9f, infiniteRepeatable(tween(650, delayMillis = 160), RepeatMode.Reverse), label = "dot-2")
    val third by transition.animateFloat(0.22f, 0.9f, infiniteRepeatable(tween(650, delayMillis = 320), RepeatMode.Reverse), label = "dot-3")
    Row(Modifier.padding(start = 2.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf(first, second, third).forEach { alpha ->
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha), modifier = Modifier.padding(end = 5.dp).size(6.dp)) {}
        }
    }
}
