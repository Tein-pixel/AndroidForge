package com.teinzz.aichat

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit, onManageKeys: () -> Unit) {
    val scope = rememberCoroutineScope()
    val theme by vm.themeManager.theme.collectAsState(initial = vm.themeManager.getInitialTheme())
    val showPaid = vm.showPaidModels.value
    var customInstructions by remember { mutableStateOf(vm.themeManager.getCustomInstructions()) }
    var instructionsSaved by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Pengaturan") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("Tema aplikasi", style = MaterialTheme.typography.titleMedium)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp)).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(ThemeMode.DARK, ThemeMode.LIGHT, ThemeMode.GRAY, ThemeMode.CUSTOM, ThemeMode.SYSTEM).forEach { mode ->
                    val selected = theme == mode
                    val label = when (mode) {
                        ThemeMode.DARK -> "Black"
                        ThemeMode.GRAY -> "Gray"
                        ThemeMode.CUSTOM -> "Blue"
                        ThemeMode.LIGHT -> "White"
                        ThemeMode.SYSTEM -> "System"
                    }
                    Box(
                        Modifier.widthIn(min = 66.dp)
                            .background(if (selected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                            .clickable { scope.launch { vm.themeManager.setTheme(mode) } }
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                }
            }
            if (theme == ThemeMode.CUSTOM) {
                Text("Warna aksen", style = MaterialTheme.typography.titleSmall)
                val accents = listOf<Pair<String, Int>>(
                    "Biru" to 0xFF8AB4F8.toInt(), "Ungu" to 0xFFC4A7FF.toInt(), "Teal" to 0xFF70D6C7.toInt(), "Oranye" to 0xFFFFB86B.toInt(), "Hijau" to 0xFFA6D98A.toInt()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    accents.forEach { (label, value) ->
                        val selected = vm.themeManager.accentColor.value == value
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Surface(color = Color(value), shape = CircleShape, modifier = Modifier.size(34.dp).clickable { vm.themeManager.setAccentColor(value) }, border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.onSurface) else null) {
                                if (selected) Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Check, contentDescription = null, tint = Color(0xFF101014), modifier = Modifier.size(18.dp)) }
                            }
                            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            HorizontalDivider()
            Text("Instruksi khusus", style = MaterialTheme.typography.titleMedium)
            Text("Atur gaya jawaban lintas percakapan. Instruksi ini dikirim bersama permintaan ke provider AI terpilih. Maksimal 2.000 karakter.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(
                value = customInstructions,
                onValueChange = { customInstructions = it.take(2000); instructionsSaved = false },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 6,
                placeholder = { Text("Contoh: Jawab dalam bahasa Indonesia, langsung ke inti, gunakan contoh sederhana.") },
                supportingText = { Text("${customInstructions.length}/2000") }
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { vm.themeManager.setCustomInstructions(customInstructions); instructionsSaved = true }, modifier = Modifier.weight(1f)) { Text("Simpan instruksi") }
                if (instructionsSaved) Text("Tersimpan", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
            }
            HorizontalDivider()
            Card(
                onClick = onManageKeys,
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                        Icon(Icons.Outlined.Key, contentDescription = null, modifier = Modifier.padding(11.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Provider & API keys", style = MaterialTheme.typography.titleSmall)
                        Text("Kelola key dan tes koneksi di halaman terpisah", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(Icons.Outlined.ChevronRight, contentDescription = "Kelola API keys")
                }
            }
            HorizontalDivider()
            Text("Akses model", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Tampilkan model berbayar")
                    Text("Nonaktif: tampilkan model dengan tier gratis saja. Kuota akun tetap terbatas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = showPaid, onCheckedChange = vm::setPaidVisible)
            }
            Text("Harga dan kuota mengikuti kebijakan masing-masing provider; akses gratis tidak dijamin untuk semua akun.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
        }
    }
}

