package com.teinzz.aichat.network

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.teinzz.aichat.ThemeManager
import com.teinzz.aichat.data.AiModel
import com.teinzz.aichat.data.Provider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Provider-owned live catalogues; explicit price metadata wins over broad provider free-tier heuristics. */
data class ModelDiscoveryResult(
    val modelsByProvider: Map<Provider, List<AiModel>>,
    val refreshedProviders: Set<Provider>,
    val messages: List<String>
)

class ModelDiscovery(private val keys: ThemeManager) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun discover(): ModelDiscoveryResult = coroutineScope {
        val configured = Provider.values().mapNotNull { provider ->
            val key = keys.getApiKey(provider)
            val auxiliary = keys.getAuxiliary(provider)
            val auxiliaryReady = provider.auxiliaryLabel.isBlank() || auxiliary.isNotBlank()
            // A provider only participates when its API key has been saved. This prevents public
            // catalogues or offline placeholders from appearing as usable models without credentials.
            if (provider.active && auxiliaryReady && key.isNotBlank()) provider to key else null
        }
        val attempts = configured.map { (provider, key) ->
            async(Dispatchers.IO) {
                runCatching { provider to fetch(provider, key) }
                    .fold(
                        onSuccess = { DiscoveryAttempt(provider, it.second, null) },
                        onFailure = { DiscoveryAttempt(provider, emptyList(), it.message ?: "Gagal memuat katalog") }
                    )
            }
        }.awaitAll()
        ModelDiscoveryResult(
            modelsByProvider = attempts.filter { it.error == null }.associate { it.provider to it.models },
            refreshedProviders = attempts.filter { it.error == null }.map { it.provider }.toSet(),
            messages = buildList {
                attempts.filter { it.error != null }.forEach { add("${it.provider.title}: katalog gagal dimuat (${it.error}). Periksa key, izin, dan data tambahan provider di Settings.") }
                attempts.filter { it.error == null }.forEach {
                    val freeCount = it.models.count(AiModel::freeTier)
                    add("${it.provider.title}: ${it.models.size} model dari katalog live berhasil dimuat; $freeCount bertanda gratis/kuota.")
                }
                if (attempts.isEmpty()) add("Belum ada API key tersimpan. Simpan key provider yang valid di Settings agar modelnya muncul.")
            }
        )
    }

    private data class DiscoveryAttempt(val provider: Provider, val models: List<AiModel>, val error: String?)

    private fun fetch(provider: Provider, key: String): List<AiModel> {
        if (key.isBlank()) throw IllegalStateException("API key belum disimpan.")
        val auxiliary = keys.getAuxiliary(provider)
        if (provider.auxiliaryLabel.isNotBlank() && auxiliary.isBlank()) {
            throw IllegalStateException("${provider.auxiliaryLabel} diperlukan untuk memuat model.")
        }
        val url = provider.resolvedModelsUrl(auxiliary)
        val builder = Request.Builder().url(url).get()
        if (key.isNotBlank() && provider != Provider.GEMINI) builder.header("Authorization", "Bearer $key")
        if (provider == Provider.GEMINI) builder.header("x-goog-api-key", key)
        if (provider == Provider.OPENROUTER) {
            builder.header("HTTP-Referer", OpenRouterService.REFERER).header("X-Title", OpenRouterService.APP_TITLE)
        }
        client.newCall(builder.build()).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}; cek API key/izin endpoint")
            val root = JsonParser.parseString(response.body?.string().orEmpty()).takeIf { it.isJsonObject }?.asJsonObject
                ?: throw IllegalStateException("Format katalog tidak dikenali")
            val parsed = if (provider == Provider.GEMINI) parseGemini(root) else parseGeneric(provider, root).toMutableList().apply {
                // OpenRouter documents these two server-side routes independently of its model list.
                // Add them only after the authenticated live catalogue endpoint returns HTTP 200.
                if (provider == Provider.OPENROUTER) {
                    if (none { it.id == "openrouter/auto" }) add(AiModel(
                        "openrouter/auto", "Auto Router", Provider.OPENROUTER, "AUTO ROUTER", false,
                        vision = true, description = "OpenRouter memilih model sesuai tugas; biaya mengikuti model yang dirutekan."
                    ))
                    if (none { it.id == "openrouter/free" }) add(AiModel(
                        "openrouter/free", "Free Router", Provider.OPENROUTER, "FREE ROUTER*", true,
                        vision = false, description = "Memilih model bertanda gratis yang tersedia; kuota dan kapasitas tetap terbatas."
                    ))
                }
            }
            if (parsed.isEmpty()) throw IllegalStateException("Katalog live tidak mengembalikan model chat yang kompatibel.")
            return parsed
        }
    }

    private fun parseGemini(root: JsonObject): List<AiModel> {
        val models = root.array("models") ?: return emptyList()
        // Prices/free-tier status comes from the current official pricing page, since the model-list
        // endpoint itself does not include per-account price metadata.
        val knownFreeNames = setOf(
            "gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite", "gemini-3-flash-preview", "gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite"
        )
        return models.mapNotNull { el ->
            if (!el.isJsonObject) return@mapNotNull null
            val item = el.asJsonObject
            val methods = item.array("supportedGenerationMethods")?.strings().orEmpty()
            if ("generateContent" !in methods) return@mapNotNull null
            val id = item.string("name").removePrefix("models/")
            val lower = id.lowercase()
            if (id.isBlank() || listOf("embedding", "tts", "-image", "-audio", "transcribe", "-live", "veo", "video").any(lower::contains)) return@mapNotNull null
            // Some older model IDs may still appear in the catalogue without being usable for a new
            // account, and Gemini 3.7/3.5 Flash route automatically to newer versions. Hide those
            // stale aliases so the model label reflects the endpoint the app intends to call.
            if (lower.startsWith("gemini-2.5-") || lower.startsWith("gemini-2.0-") ||
                lower == "gemini-3.7-flash" || lower == "gemini-3.5-flash" ||
                lower == "gemini-3-pro-preview" || lower == "gemini-3-flash-preview") return@mapNotNull null
            val free = id in knownFreeNames || (id.startsWith("gemma-") && (id.endsWith("-it") || id.contains("instruct")))
            AiModel(id, item.string("displayName").ifBlank { id }, Provider.GEMINI,
                if (free) "FREE TIER*" else "CHECK ACCESS", free,
                vision = id.startsWith("gemini-") || id.startsWith("gemma-3") || id.startsWith("gemma-4"),
                description = item.string("description").ifBlank { "Model Gemini di katalog akun aktif." }.take(145))
        }.distinctBy { it.id }.sortedWith(compareByDescending<AiModel> { it.freeTier }.thenBy { it.name.lowercase() })
    }

    private fun parseGeneric(provider: Provider, root: JsonObject): List<AiModel> {
        val models = root.array("data") ?: root.array("models") ?: root.array("result")
            ?: root.obj("result")?.array("data") ?: return emptyList()
        return models.mapNotNull { el ->
            if (!el.isJsonObject) return@mapNotNull null
            val item = el.asJsonObject
            val id = item.string("id").ifBlank { item.string("name") }
            if (id.isBlank()) return@mapNotNull null
            val lower = id.lowercase()
            if (item.has("is_deprecated") && item.bool("is_deprecated")) return@mapNotNull null
            if (item.has("is_ready") && !item.bool("is_ready")) return@mapNotNull null
            if (item.has("active") && !item.bool("active")) return@mapNotNull null
            val endpoints = item.array("endpoints")?.strings().orEmpty()
            if (endpoints.isNotEmpty() && endpoints.none { it.equals("chat", true) || it.contains("completion", true) || it.equals("responses", true) }) return@mapNotNull null
            val supportedEndpoints = item.array("supported_endpoints")?.strings().orEmpty()
            if (supportedEndpoints.isNotEmpty() && supportedEndpoints.none { it.contains("chat/completions", true) || it.contains("responses", true) }) return@mapNotNull null
            if (listOf("embedding", "rerank", "moderation", "prompt-guard", "llama-guard", "safeguard", "transcribe", "whisper", "tts", "speech-to-text", "text-to-speech", "image-generation", "video-generation").any(lower::contains)) return@mapNotNull null
            val architecture = item.obj("architecture")
            val modalities = item.obj("modalities")
            val inputs = modalities?.array("input")?.strings().orEmpty()
                .ifEmpty { architecture?.array("input_modalities")?.strings().orEmpty() }
                .ifEmpty { item.array("input_modalities")?.strings().orEmpty() }
            val outputs = modalities?.array("output")?.strings().orEmpty()
                .ifEmpty { architecture?.array("output_modalities")?.strings().orEmpty() }
                .ifEmpty { item.array("output_modalities")?.strings().orEmpty() }
            // Keep the chat picker focused on models that can return text, not image/video/audio generation-only models.
            if (outputs.isNotEmpty() && outputs.none { it.equals("text", true) }) return@mapNotNull null
            if (outputs.isEmpty() && listOf("-image", "-video", "-audio", "flux", "stable-diffusion", "ideogram").any(lower::contains)) return@mapNotNull null
            val pricing = item.obj("pricing")
            val priceIn = pricing?.numberAny("prompt", "input", "input_price")
            val priceOut = pricing?.numberAny("completion", "output", "output_price")
            val requestPrice = pricing?.numberAny("request", "image")
            val explicitFree = item.bool("free") || item.bool("is_free") || lower.endsWith(":free")
            val explicitPrice = priceIn != null || priceOut != null || requestPrice != null
            // Only call a catalogued model zero-priced when both input and output prices are explicitly zero.
            // A missing price field means unknown, not free.
            val priceFree = priceIn != null && priceOut != null && priceIn <= 0.0 && priceOut <= 0.0 && (requestPrice == null || requestPrice <= 0.0)
            val free = when {
                // Auto Router selects a destination whose token price applies, so it is never labeled free.
                provider == Provider.OPENROUTER && lower == "openrouter/auto" -> false
                provider == Provider.OPENROUTER && lower == "openrouter/free" -> true
                // Explicit non-zero price wins even if a model ID ends in :free or a stale flag says free.
                priceFree -> true
                explicitPrice -> false
                explicitFree -> true
                provider == Provider.LLM7 -> true
                provider == Provider.CLOUDFLARE -> !listOf("kimi-k2.6", "kimi-k2.7", "glm-5.2", "glm-5.3", "deepseek-v4-pro", "deepseek-v4-flash-0731").any(lower::contains)
                provider == Provider.CEREBRAS -> lower in setOf("gpt-oss-120b", "llama3.1-8b", "zai-glm-4.7", "qwen-3-235b-a22b-instruct-2507")
                provider == Provider.NVIDIA -> true // NVIDIA Developer Program offers prototype/test access; account entitlements apply
                provider == Provider.SAMBANOVA -> true
                provider == Provider.MISTRAL -> listOf("small", "ministral", "nemo", "codestral").any(lower::contains)
                // Groq's current public catalogue lists token prices for its mainstream text models;
                // its model-list response does not supply zero-price metadata, so do not label them free.
                provider == Provider.GROQ -> false
                provider == Provider.COHERE -> lower.contains("command-r") || lower.contains("command-a")
                provider == Provider.ZAI -> lower.contains("flash")
                else -> false
            }
            val parameters = item.array("supported_parameters")?.strings()?.toSet()
                ?: item.array("supported_sampling_parameters")?.strings()?.toSet().orEmpty()
            val name = item.string("name").ifBlank { item.string("display_name") }.ifBlank { id }
            val description = item.string("description").ifBlank {
                when {
                    provider == Provider.LLM7 -> "LLM7 free-token tier; current official limits are 100,000 input+output tokens per rolling day and rate limits apply."
                    free -> "Model di katalog provider dengan kuota/tier gratis; bukan jaminan uptime atau penggunaan tanpa batas."
                    explicitPrice -> "Harga terdeteksi dari katalog provider."
                    else -> "Harga/tier gratis tidak dipastikan oleh metadata endpoint; periksa dashboard provider."
                }
            }.take(145)
            val badge = when {
                provider == Provider.OPENROUTER && lower == "openrouter/auto" -> "AUTO ROUTER"
                provider == Provider.OPENROUTER && lower == "openrouter/free" -> "FREE ROUTER*"
                lower.endsWith(":free") || explicitFree || priceFree -> "FREE MODEL*"
                provider == Provider.LLM7 -> "FREE QUOTA*"
                free && provider == Provider.COHERE -> "TRIAL QUOTA*"
                free && provider == Provider.CLOUDFLARE -> "FREE QUOTA*"
                free -> "FREE TIER*"
                explicitPrice -> "USAGE-BASED"
                else -> "CHECK PRICE"
            }
            AiModel(id, name, provider, badge, free,
                vision = (provider == Provider.OPENROUTER && lower == "openrouter/auto") || "image" in inputs || "video" in inputs || lower.contains("vision") || lower.contains("vl"),
                description = description,
                supportedParameters = parameters)
        }.distinctBy { it.id }.sortedWith(compareByDescending<AiModel> { it.freeTier }.thenBy { it.name.lowercase() })
    }

    private fun JsonObject.array(key: String): JsonArray? = get(key)?.takeIf { it.isJsonArray }?.asJsonArray
    private fun JsonObject.obj(key: String): JsonObject? = get(key)?.takeIf { it.isJsonObject }?.asJsonObject
    private fun JsonObject.string(key: String): String = get(key)?.takeIf { it.isJsonPrimitive && !it.asJsonPrimitive.isBoolean }?.asString.orEmpty()
    private fun JsonObject.bool(key: String): Boolean = runCatching { get(key)?.asBoolean == true }.getOrDefault(false)
    private fun JsonObject.numberAny(vararg keys: String): Double? = keys.firstNotNullOfOrNull { key ->
        get(key)?.let { value -> runCatching { if (value.isJsonPrimitive) value.asString.toDoubleOrNull() else null }.getOrNull() }
    }
    private fun JsonArray.strings(): List<String> = mapNotNull { el -> if (el.isJsonPrimitive) runCatching { el.asString }.getOrNull() else null }
}
