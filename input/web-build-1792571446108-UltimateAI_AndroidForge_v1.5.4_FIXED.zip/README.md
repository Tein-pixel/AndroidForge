# Ultimate AI — AndroidForge project

**Source revision:** v1.5.4 · **Version code:** 11  
**Package:** `com.teinzz.aichat`  
**Project:** Native Android · Kotlin · Jetpack Compose · Material 3  
**Minimum Android:** 7.0 (API 24) · **Target SDK:** 34  
**Build target:** Android Gradle Plugin 8.7.3 · Gradle 8.9 · JDK 17

This ZIP is the Android source project for AndroidForge. It is **not an APK**. It contains no API keys or credentials.

## What changed in v1.5.4

- Fixed short user messages stretching into oversized empty bubbles: the bubble width now follows the text up to a responsive maximum, with no full-width edit toolbar inside it.
- Moved user-message actions to a long-press menu (Edit message / Copy text); assistant regeneration remains available below the latest answer and in the long-press menu.
- Added a distinct generated app icon and replaced the old launch mark with the new icon artwork on the splash background.
- Simplified theme choices to Black, White, Gray, Blue, and System; the strip can scroll on narrow devices, and the blue palette uses navy surfaces with readable contrast.
- Separated provider/API-key management into its own page under Settings instead of placing every API-key form on the main Settings screen.
- Filtered legacy Gemini 2.5 model IDs from selectable chat models because Google's current docs limit their availability for new users; saved legacy Gemini 2.5/2.0 and auto-routed Flash aliases are excluded from selectable models; old saved selections migrate to Gemini 3.8 Flash (the general-use default) or another current stable model available from the authenticated live catalogue.
- Added one bounded recovery attempt when a selected Gemini model returns HTTP 404: retry with another current Gemini model that was actually returned by the live catalogue. The selected model and conversation are updated only after the retry succeeds.
- Captured the model/mode at send time to prevent a concurrent model change from making the UI title disagree with the request. Streaming UI state updates are capped at about 20 per second to reduce recomposition jitter on slower Android phones; model discovery network timeouts were shortened.

## What changed in v1.5.3

- Added last-turn editing for text-only user prompts and response regeneration. Regeneration removes the previous user/assistant tail before resending, avoiding duplicate prompt history.
- Added copy-all, share, and export-to-Markdown actions in a compact overflow menu.
- Added optional Indonesian voice dictation through the device speech recognizer; this is speech-to-text, not live voice conversation or speech synthesis.
- Added saved custom instructions (up to 2,000 characters) that are included in the provider system message across chats and reasoning/research modes.
- Message rows have a restrained enter animation; streaming text no longer animates the entire bubble size for every token. Message history queries use the stable auto-increment ID order rather than millisecond timestamps.
- Image prompt suggestion is explicitly called “Prompt gambar” because image generation itself still depends on a dedicated image-generation endpoint and is not claimed as built-in in this release.

## Feature scope (important)

Ultimate AI is an independent multi-provider client, not a copy of the official ChatGPT, Gemini, or Claude apps. Core chat, reasoning modes, provider-backed web research, image understanding, document extraction, conversation tools, personal instructions, and a local Artifacts workspace are implemented where the selected API supports them. Consumer-app features that depend on their own hosted accounts/services—such as native live voice conversation, full service-side memory/projects, connected inbox/drive accounts, built-in image generation, scheduled tasks, or provider-specific cloud workspaces—are not automatically available through an API key and are not claimed as implemented here. Model features still depend on live provider/model entitlements.

## What changed in v1.5.2

- Integrated **15 active provider adapters** with separate API-key settings: Google Gemini, Groq, Cerebras, OpenRouter, Cloudflare Workers AI, NVIDIA NIM, Mistral, SambaNova, Hugging Face Inference, Cohere, Z.ai, LLM7, Pollinations, Vercel AI Gateway, and Reka AI.
- GitHub Models is shown as retired and cannot be selected; GitHub officially retired its model catalog and inference API on **30 July 2026**.
- The model picker hides every provider without a saved API key, including providers with public model catalogs. A provider only appears after its authenticated live model catalogue succeeds; bad keys, missing Cloudflare Account ID, or failed catalogue requests do not leave stale selectable model IDs on screen.
- Other provider catalogs refresh from their provider's model endpoint after the user saves a key. Cloudflare also requires the account ID.
- Model picker has search, provider-grouped sections, a free/paid filter, and an explicit **Test selected model** action that sends a tiny real completion. Settings' connection test probes the provider catalogue endpoint without generating text.
- Price metadata is preferred when present. Unknown pricing is not automatically treated as free. Labels such as `FREE TIER*` mean limited provider access may exist; they do not mean unlimited use, permanent access, or guaranteed availability.
- OpenAI-compatible provider requests share one stream adapter, with provider-specific URL/auth settings. Gemini uses its native streaming API. The selector now uses only models returned by the successful live provider catalogue, grouped under concise provider headings such as Gemini, Groq, Cerebras, and OpenRouter. The real-response test remains available to verify generation, because catalogue access alone cannot guarantee model entitlement or uptime.
- Fixed the chat composer being covered by the Android keyboard: the activity uses `adjustResize`, and the chat scaffold applies IME inset padding so the text field and send controls move above the keyboard. Removed the persistent missing-key banner from the chat body to keep the UI uncluttered.
- All live-listed models are shown by default; the free/limited-tier filter remains available. Model pricing and provider access vary, so check the provider account before choosing a usage-priced model.
- Cloudflare model discovery uses the account-scoped AI model search endpoint and requires both the API token and Account ID. Cohere model discovery uses its native `/v2/models` endpoint. The parser filters retired/not-ready models and non-chat-only models where the provider returns those fields. Static placeholder IDs remain for Settings connection checks only; they are not offered as selectable chat models.
- Request defaults are conservative: optional temperature is omitted unless model metadata declares it; Groq and Cerebras use `max_completion_tokens`. OpenRouter routes can retry transient 502/503/504 errors once and may try its free router for a failed `:free` route under normal text chat. The live-list parser omits non-chat safety tools such as prompt-guard models from the chat picker. Groq catalogue IDs are retrieved directly from its current `/models` endpoint rather than a hardcoded model list.
- Existing functionality is preserved: Black/White/Gray/Blue/System themes, compact `+` menu for file/camera/gallery/reasoning/research, conversations/history, image compression, PDF/TXT/CSV/DOCX text extraction, CameraX, and Artifacts workspace.

## Integrated provider settings

| Provider | Chat/API integration | Extra input or caveat |
|---|---|---|
| Google Gemini | Native Gemini stream API and model-list API | Free-tier features/grounding differ from paid tier. |
| Groq | OpenAI-compatible chat and model-list APIs | Per-model rate limits apply. |
| Cerebras | OpenAI-compatible chat and model-list APIs | Free developer access and promotional-credit terms can change; verify account eligibility. |
| OpenRouter | Chat completions and public model catalog | Public catalog does not remove the need for a key to chat. `:free` routes can still be overloaded. |
| Cloudflare Workers AI | OpenAI-compatible chat endpoint and account model-search API | Requires API token **and Account ID**. Free allocation: 10,000 Neurons/day; some models require paid billing. |
| NVIDIA NIM | OpenAI-compatible chat and model-list APIs | Hosted model access/entitlements depend on current NVIDIA account terms; developer access is not a production SLA. |
| Mistral | OpenAI-compatible chat and model-list APIs | Studio Free mode has limited usage and rate limits. |
| SambaNova | OpenAI-compatible chat and model-list APIs | Availability/free quota depends on the account and model. |
| Hugging Face Inference | Router OpenAI-compatible API | Free credits are limited; a model may be usage-priced. |
| Cohere | Compatibility API; native `/v2/models` catalogue | Trial/model access is limited and may be non-commercial. |
| Z.ai | OpenAI-compatible GLM API | Model IDs and Free Flash access must be confirmed by its live catalogue/account. |
| LLM7.io | OpenAI-compatible chat API | Requires an LLM7 API token; its free token budget/rate limits may change. |
| Pollinations | OpenAI-compatible API and unauthenticated public model list | Current generation requires a Pollinations key; use its official app-key/user-authorized flow for mobile clients. |
| Vercel AI Gateway | OpenAI-compatible gateway and model catalogue | A gateway key/credits do not make upstream model usage automatically free. |
| Reka AI | OpenAI-compatible chat and model-list APIs | Live catalogue provides model readiness, pricing, and supported parameters where available. |
| GitHub Models | **Retired / disabled** | Officially retired on 30 July 2026. |

The provider catalogues and account quotas change over time. A listed model means its provider lists it; it is **not a guarantee** that the key is authorized, the model has a free quota, or the upstream route is healthy. The real-completion test is the only in-app check that verifies an actual generation path at that moment.

## First run

1. Upload this ZIP to AndroidForge as an Android/Gradle project; the archive has `settings.gradle`, root `build.gradle`, and `app/` at the root.
2. Build with JDK 17 and compile SDK 35. The project targets Android SDK 34 and uses Android Gradle Plugin 8.7.3, compatible with Gradle 8.9. This ZIP intentionally omits Gradle wrapper JAR and Android SDK files for AndroidForge's system-Gradle workflow.
3. Install the generated APK, open **Settings → Provider & API keys**, and enter your own provider key. Cloudflare additionally requires the account ID.
4. Save the provider settings, refresh the model catalogue, choose a model marked free if that is your requirement, then use **Test selected model** before normal use. The generation test sends a real tiny prompt and may consume that provider's quota.

The source is designed for Android 10 and newer as well as Android 7.0+; the actual APK has not been built or run in this environment because Gradle and Android SDK are not installed here. Do not treat archive checks as a successful Android build; confirm AndroidForge's build output before installing.

## API key safety and pricing

- Keys are stored locally using AndroidX EncryptedSharedPreferences. Do not publish an APK preloaded with a personal API key. Mobile-side encryption does not provide the same secrecy as keeping the key on a private server.
- Each provider key is separate. Ultimate AI does not inherit ChatGPT, Gemini-app, or other consumer subscriptions and does not bypass provider quotas or billing.
- Free-tier labels are guidance based on provider metadata/current documented tiers, not a guarantee for every account. For providers that do not return price metadata, the app uses a conservative provider-specific classification and explains when account pricing must be checked.
- Check current terms/price pages before high-volume use. If a model returns 401/403, verify the key and model access; 402 often indicates no credit/paid entitlement; 429 indicates a rate/usage limit; 502/503/504 commonly indicates a temporary server/provider-route failure.

## Features preserved

- Chat UI themes: Black, White, Gray, Blue, and System; custom accent colors.
- Conversation history, search, rename, delete, model selection per conversation, streaming, Markdown/code display, copy response, regenerate response, long-press user bubbles to edit/copy the latest text prompt, export/share/copy-all conversation, and custom instructions.
- Single `+` composer menu for files, camera, gallery, **Berpikir Lebih Keras**, and **Riset Mendalam**; voice icon provides speech-to-text dictation only.
- CameraX camera preview, focus/zoom/flash/switch, retake/use photo; image compression and image-capability checks.
- PDF, TXT, CSV, and DOCX text extraction.
- Artifacts workspace for generating/editing local HTML/CSS/JavaScript pages, preview/code/split view, import/export and saving projects locally. The WebView disables file/content access and does not expose a JavaScript bridge to the host app.

## Research / official documentation

- Gemini models, lifecycle and price: https://ai.google.dev/gemini-api/docs/models · https://ai.google.dev/gemini-api/docs/deprecations · https://ai.google.dev/gemini-api/docs/pricing · live API model listing: https://ai.google.dev/api/models
- Android keyboard and Compose insets: https://developer.android.com/develop/ui/compose/system/setup-e2e · https://developer.android.com/develop/ui/compose/system/insets
- Groq models and limits: https://console.groq.com/docs/models · https://console.groq.com/docs/rate-limits
- Cerebras Inference: https://inference-docs.cerebras.ai/
- OpenRouter model catalogue: https://openrouter.ai/docs/api/api-reference/models/get-models · free models: https://openrouter.ai/collections/free-models
- Cloudflare OpenAI compatibility, model search and pricing: https://developers.cloudflare.com/workers-ai/configuration/open-ai-compatibility/ · https://developers.cloudflare.com/api/resources/ai/subresources/models/methods/list/ · https://developers.cloudflare.com/workers-ai/platform/pricing/
- NVIDIA NIM API: https://docs.nvidia.com/nim/large-language-models/latest/api-reference.html
- Mistral models and Free mode: https://docs.mistral.ai/api/endpoint/models · https://docs.mistral.ai/getting-started/quickstarts/studio/activate-and-generate-api-key
- Hugging Face Inference Providers: https://huggingface.co/docs/inference-providers
- Cohere compatibility and models: https://docs.cohere.com/docs/compatibility-api · https://docs.cohere.com/v2/reference/list-models
- Pollinations API: https://gen.pollinations.ai/docs
- Reka models and live catalogue: https://docs.reka.ai/chat/models · https://docs.reka.ai/chat/api-reference/list-models
- Vercel AI Gateway: https://vercel.com/docs/ai-gateway/openai-compat/rest-api
- GitHub Models retirement: https://github.blog/changelog/2026-07-30-github-models-is-now-retired/

## Build/validation status

- XML parsing and ZIP integrity are checked before publishing the source archive.
- A full Gradle/Android SDK build and live-provider test were **not performed** in this environment. API keys are user-specific, so provider success must be confirmed from Settings or **Test selected model** on the installed APK.
