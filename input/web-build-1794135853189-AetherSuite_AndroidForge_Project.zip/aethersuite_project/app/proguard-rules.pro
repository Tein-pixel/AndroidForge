# Keep Shizuku provider metadata intact.
-keep class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**
