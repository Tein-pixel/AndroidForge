#include "AetherNative.h"
#include <limits>

namespace aether {
namespace {
bool RangeValid(std::int32_t offset, std::int32_t count, std::size_t fileSize) {
    if (offset < 0 || count < 0) return false;
    const auto start = static_cast<std::size_t>(offset);
    const auto length = static_cast<std::size_t>(count);
    return start <= fileSize && length <= fileSize - start;
}
}

bool Il2CppMetadataInspector::ValidateHeader(const MetadataHeader& h, std::size_t fileSize, std::string* reason) {
    constexpr std::uint32_t kMetadataMagic = 0xFAB11BAF;
    auto fail = [reason](const char* message) {
        if (reason) *reason = message;
        return false;
    };
    if (h.sanity != kMetadataMagic) return fail("Invalid IL2CPP metadata signature");
    if (h.version < 16 || h.version > 100) return fail("Unsupported metadata version");
    if (!RangeValid(h.stringLiteralOffset, h.stringLiteralCount, fileSize) ||
        !RangeValid(h.stringLiteralDataOffset, h.stringLiteralDataCount, fileSize) ||
        !RangeValid(h.stringOffset, h.stringCount, fileSize)) {
        return fail("Metadata section range is outside the supplied file");
    }
    if (reason) reason->clear();
    return true;
}
}
