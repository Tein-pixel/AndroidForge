#include "AetherNative.h"
#include <mutex>
#include <set>

namespace aether {
namespace {
std::mutex gMutex;
std::set<std::string> gModules;
}

bool HookManager::RegisterModule(const std::string& name) {
    if (name.empty() || name.size() > 80) return false;
    std::lock_guard<std::mutex> lock(gMutex);
    return gModules.insert(name).second;
}

std::size_t HookManager::ModuleCount() {
    std::lock_guard<std::mutex> lock(gMutex);
    return gModules.size();
}
}
