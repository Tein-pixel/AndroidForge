#include <jni.h>
#include <android/log.h>
#include "AetherNative.h"
#include "imgui.h"

namespace {
constexpr const char* kTag = "AetherSuite";
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        __android_log_print(ANDROID_LOG_ERROR, kTag, "JNI environment unavailable");
        return JNI_ERR;
    }
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    aether::HookManager::RegisterModule("metadata-inspector");
    __android_log_print(ANDROID_LOG_INFO, kTag, "AetherSuite native layer initialized");
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT void JNICALL JNI_OnUnload(JavaVM*, void*) {
    if (ImGui::GetCurrentContext() != nullptr) ImGui::DestroyContext();
}
