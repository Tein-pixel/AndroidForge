#pragma once
#include <cstdint>
#include <string>

namespace aether {
struct MetadataHeader {
    std::uint32_t sanity;
    std::int32_t version;
    std::int32_t stringLiteralOffset;
    std::int32_t stringLiteralCount;
    std::int32_t stringLiteralDataOffset;
    std::int32_t stringLiteralDataCount;
    std::int32_t stringOffset;
    std::int32_t stringCount;
};

class Il2CppMetadataInspector {
public:
    static bool ValidateHeader(const MetadataHeader& header, std::size_t fileSize, std::string* reason);
};

class HookManager {
public:
    // Registry only: this class intentionally does not install hooks or modify other processes.
    static bool RegisterModule(const std::string& name);
    static std::size_t ModuleCount();
};
}
