package com.aether.suite.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import kotlin.math.roundToInt

 data class DeviceSnapshot(
    val model: String,
    val manufacturer: String,
    val androidVersion: String,
    val sdk: Int,
    val abi: String,
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val totalStorageBytes: Long,
    val freeStorageBytes: Long,
    val batteryPercent: Int
) {
    val ramUsedPercent: Int
        get() = percent(totalRamBytes - availableRamBytes, totalRamBytes)
    val storageUsedPercent: Int
        get() = percent(totalStorageBytes - freeStorageBytes, totalStorageBytes)

    companion object {
        private fun percent(used: Long, total: Long): Int =
            if (total <= 0L) 0 else ((used.toDouble() / total.toDouble()) * 100.0).roundToInt().coerceIn(0, 100)

        fun read(context: Context): DeviceSnapshot {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memory = ActivityManager.MemoryInfo()
            manager.getMemoryInfo(memory)

            val stat = StatFs(Environment.getDataDirectory().absolutePath)
            val totalStorage = stat.totalBytes.coerceAtLeast(0L)
            val freeStorage = stat.availableBytes.coerceIn(0L, totalStorage)

            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val battery = if (level >= 0 && scale > 0) ((level * 100f) / scale).roundToInt() else -1

            return DeviceSnapshot(
                model = Build.MODEL ?: "Unknown",
                manufacturer = Build.MANUFACTURER ?: "Android",
                androidVersion = Build.VERSION.RELEASE ?: "Unknown",
                sdk = Build.VERSION.SDK_INT,
                abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown",
                totalRamBytes = memory.totalMem.coerceAtLeast(0L),
                availableRamBytes = memory.availMem.coerceIn(0L, memory.totalMem.coerceAtLeast(0L)),
                totalStorageBytes = totalStorage,
                freeStorageBytes = freeStorage,
                batteryPercent = battery
            )
        }
    }
}

fun Long.toReadableSize(): String {
    if (this < 0L) return "—"
    val units = listOf("B", "KB", "MB", "GB", "TB")
    var size = this.toDouble()
    var index = 0
    while (size >= 1024.0 && index < units.lastIndex) {
        size /= 1024.0
        index++
    }
    return if (index == 0) "${size.toLong()} ${units[index]}" else String.format(java.util.Locale.US, "%.1f %s", size, units[index])
}
