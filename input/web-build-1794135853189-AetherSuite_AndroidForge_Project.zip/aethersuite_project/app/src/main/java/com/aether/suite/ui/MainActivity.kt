package com.aether.suite.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.suite.BuildConfig
import com.aether.suite.core.DeviceSnapshot
import com.aether.suite.core.ShizukuStatus
import com.aether.suite.core.toReadableSize
import com.aether.suite.ui.theme.AetherCard
import com.aether.suite.ui.theme.AetherCardBorder
import com.aether.suite.ui.theme.AetherCyan
import com.aether.suite.ui.theme.AetherDark
import com.aether.suite.ui.theme.AetherDarkSurf
import com.aether.suite.ui.theme.AetherGold
import com.aether.suite.ui.theme.AetherPink
import com.aether.suite.ui.theme.AetherPurple
import com.aether.suite.ui.theme.AetherSubText
import com.aether.suite.ui.theme.AetherText
import com.aether.suite.ui.theme.AetherTheme
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
        if (requestCode == 2108) runOnUiThread { recreate() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { Shizuku.addRequestPermissionResultListener(permissionListener) }
        setContent { AetherTheme { AetherApp() } }
    }

    override fun onResume() {
        super.onResume()
        // Returning from Android Settings refreshes the activity UI.
    }

    override fun onDestroy() {
        runCatching { Shizuku.removeRequestPermissionResultListener(permissionListener) }
        super.onDestroy()
    }
}

private enum class Page(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    TOOLS("Tools", Icons.Filled.Build),
    FEATURES("Features", Icons.Filled.Dashboard),
    SETTINGS("Settings", Icons.Filled.Settings)
}

@Composable
private fun AetherApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    var refreshToken by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val snapshot = remember(refreshToken) { DeviceSnapshot.read(context) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    BackHandler(enabled = page != Page.HOME) { page = Page.HOME }

    Scaffold(
        containerColor = AetherDark,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = AetherDarkSurf, tonalElevation = 0.dp) {
                Page.entries.forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 16.dp, end = 16.dp, top = 18.dp, bottom = 22.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { AppHeader(page) }
            when (page) {
                Page.HOME -> {
                    item { HeroCard(snapshot) }
                    item {
                        SectionTitle("DEVICE OVERVIEW", "Live system information")
                        Spacer(Modifier.height(8.dp))
                        MetricGrid(snapshot)
                    }
                    item {
                        SectionTitle("QUICK ACCESS", "Android system shortcuts")
                        Spacer(Modifier.height(8.dp))
                        QuickActions(
                            onWifi = { launchSettings(context, Settings.ACTION_WIFI_SETTINGS) },
                            onDisplay = { launchSettings(context, Settings.ACTION_DISPLAY_SETTINGS) },
                            onBattery = { launchSettings(context, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).action ?: Settings.ACTION_SETTINGS) }
                        )
                    }
                    item { ShizukuCard(onMessage = { scope.launch { snackbar.showSnackbar(it) } }, refreshToken = refreshToken) }
                }
                Page.TOOLS -> {
                    item { SectionTitle("SYSTEM TOOLS", "Read-only diagnostics and shortcuts") }
                    item { DetailMetricCard("Memory", snapshot.ramUsedPercent, "${(snapshot.totalRamBytes - snapshot.availableRamBytes).toReadableSize()} used", "${snapshot.totalRamBytes.toReadableSize()} total", Icons.Filled.Memory, AetherCyan) }
                    item { DetailMetricCard("Internal storage", snapshot.storageUsedPercent, "${(snapshot.totalStorageBytes - snapshot.freeStorageBytes).toReadableSize()} used", "${snapshot.totalStorageBytes.toReadableSize()} total", Icons.Filled.Storage, AetherPurple) }
                    item { 
                        ActionCard("Refresh device status", "Read RAM, storage, and battery again", Icons.Filled.Refresh) {
                            refreshToken++
                            scope.launch { snackbar.showSnackbar("Device information refreshed") }
                        }
                    }
                    item { ActionCard("Open app settings", "Manage AetherSuite permissions and storage", Icons.Filled.Settings) { launchAppSettings(context) } }
                    item { ActionCard("Battery settings", "Open Android battery controls", Icons.Filled.BatteryChargingFull) { launchSettings(context, Settings.ACTION_BATTERY_SAVER_SETTINGS) } }
                }
                Page.FEATURES -> {
                    item { SectionTitle("FEATURES", "AetherSuite modules") }
                    item { FeatureCard("System Monitor", "Displays device model, Android version, RAM, storage, and battery from Android system APIs.", Icons.Filled.Dashboard, AetherCyan, "ACTIVE") }
                    item { FeatureCard("Shizuku Connector", "Checks whether Shizuku is running and whether this app has been granted permission. No shell commands are executed.", Icons.Filled.Security, AetherPurple, "PERMISSION-BASED") }
                    item { FeatureCard("System Shortcuts", "Provides direct links to Wi-Fi, display, battery, and application settings.", Icons.Filled.DisplaySettings, AetherPink, "ACTIVE") }
                    item { FeatureCard("Native module", "The supplied HTML did not include the native C++ source files. Native patching and process-hook modules are therefore not included in this build.", Icons.Filled.Info, AetherGold, "SOURCE MISSING") }
                }
                Page.SETTINGS -> {
                    item { SectionTitle("SETTINGS", "Application information") }
                    item { InfoCard("Application", "AetherSuite") }
                    item { InfoCard("Package", "com.aether.suite") }
                    item { InfoCard("Version", "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})") }
                    item { InfoCard("Minimum Android", "Android 10 (API 29)") }
                    item { InfoCard("Architecture", "Native libraries are not bundled in this safe utility build") }
                    item {
                        ActionCard("Copy device report", "Copy device details to clipboard", Icons.Filled.ContentCopy) {
                            val report = deviceReport(snapshot)
                            clipboard.setText(androidx.compose.ui.text.AnnotatedString(report))
                            scope.launch { snackbar.showSnackbar("Device report copied") }
                        }
                    }
                    item { ActionCard("App information", "Open Android application details", Icons.Filled.Info) { launchAppSettings(context) } }
                    item { Text("AetherSuite • Project M", color = AetherSubText, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) }
                }
            }
        }
    }
}

@Composable
private fun AppHeader(page: Page) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(AetherPurple, AetherCyan))),
            contentAlignment = Alignment.Center
        ) {
            Text("A", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
        }
        Column(Modifier.weight(1f).padding(start = 11.dp)) {
            Text("AETHER SUITE", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = AetherText)
            Text("PROJECT M  /  ${page.label.uppercase()}", fontSize = 9.sp, letterSpacing = 1.5.sp, color = AetherSubText)
        }
        Box(Modifier.clip(CircleShape).background(AetherCard).padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text("v1.0", color = AetherCyan, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
    }
}

@Composable
private fun HeroCard(snapshot: DeviceSnapshot) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = AetherCard)
    ) {
        Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF24204D), Color(0xFF172D39), AetherCard))).padding(18.dp)) {
            Column {
                Text("CONTROL CENTER", color = AetherCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Spacer(Modifier.height(10.dp))
                Text(snapshot.model, color = AetherText, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${snapshot.manufacturer}  •  Android ${snapshot.androidVersion}", color = AetherSubText, fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniStat("BATTERY", if (snapshot.batteryPercent >= 0) "${snapshot.batteryPercent}%" else "N/A")
                    MiniStat("RAM", "${snapshot.ramUsedPercent}% USED")
                    MiniStat("STORAGE", "${snapshot.storageUsedPercent}% USED")
                }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0x1AFFFFFF)).padding(9.dp)) {
        Text(label, fontSize = 8.sp, color = AetherSubText, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = AetherText, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = AetherSubText, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text(subtitle, color = AetherText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MetricGrid(snapshot: DeviceSnapshot) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MetricCard("MEMORY", "${snapshot.ramUsedPercent}%", "${(snapshot.totalRamBytes - snapshot.availableRamBytes).toReadableSize()} / ${snapshot.totalRamBytes.toReadableSize()}", Icons.Filled.Memory, AetherCyan, Modifier.weight(1f))
            MetricCard("STORAGE", "${snapshot.storageUsedPercent}%", "${(snapshot.totalStorageBytes - snapshot.freeStorageBytes).toReadableSize()} / ${snapshot.totalStorageBytes.toReadableSize()}", Icons.Filled.Storage, AetherPurple, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MetricCard("BATTERY", if (snapshot.batteryPercent >= 0) "${snapshot.batteryPercent}%" else "N/A", "Current battery level", Icons.Filled.BatteryChargingFull, AetherGold, Modifier.weight(1f))
            MetricCard("ANDROID", "API ${snapshot.sdk}", "Version ${snapshot.androidVersion}", Icons.Filled.Info, AetherPink, Modifier.weight(1f))
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, note: String, icon: ImageVector, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = AetherCard)) {
        Column(Modifier.padding(13.dp)) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(12.dp))
            Text(value, color = AetherText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(title, color = AetherSubText, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(5.dp))
            Text(note, color = AetherSubText, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun DetailMetricCard(title: String, percent: Int, used: String, total: String, icon: ImageVector, tint: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = AetherCard), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = tint)
                Text(title, Modifier.weight(1f).padding(start = 10.dp), color = AetherText, fontWeight = FontWeight.SemiBold)
                Text("$percent%", color = tint, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(AetherDarkSurf)) {
                Box(Modifier.fillMaxWidth(percent / 100f).height(7.dp).clip(CircleShape).background(tint))
            }
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(used, color = AetherSubText, fontSize = 11.sp)
                Text(total, color = AetherSubText, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun QuickActions(onWifi: () -> Unit, onDisplay: () -> Unit, onBattery: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        QuickAction("Wi-Fi", Icons.Filled.Wifi, onWifi, Modifier.weight(1f))
        QuickAction("Display", Icons.Filled.DisplaySettings, onDisplay, Modifier.weight(1f))
        QuickAction("Battery", Icons.Filled.BatteryChargingFull, onBattery, Modifier.weight(1f))
    }
}

@Composable
private fun QuickAction(title: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = AetherCard)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = AetherCyan, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(6.dp))
            Text(title, color = AetherText, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ShizukuCard(onMessage: (String) -> Unit, refreshToken: Int) {
    val state = remember(refreshToken) { ShizukuStatus.read() }
    Card(colors = CardDefaults.cardColors(containerColor = AetherCard), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Security, null, tint = AetherPurple)
                Text("Shizuku connection", Modifier.weight(1f).padding(start = 9.dp), color = AetherText, fontWeight = FontWeight.SemiBold)
                Text(if (state.running) "RUNNING" else "OFFLINE", color = if (state.running) AetherCyan else AetherPink, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                when {
                    !state.running -> "Shizuku is not running. Start the Shizuku service, then refresh this page."
                    state.permissionGranted -> "Shizuku is connected and permission is granted to AetherSuite."
                    else -> "Shizuku is running, but AetherSuite has not been granted permission."
                }, color = AetherSubText, fontSize = 11.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        when {
                            !state.running -> onMessage("Start Shizuku first, then tap refresh.")
                            state.permissionGranted -> onMessage("Shizuku permission is already granted.")
                            else -> runCatching { ShizukuStatus.requestPermission() }
                                .onFailure { onMessage("Could not request Shizuku permission: ${it.message ?: "unknown error"}") }
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = AetherPurple)
                ) { Text(if (state.permissionGranted) "Permission granted" else "Request permission", fontSize = 11.sp) }
                TextButton(onClick = { onMessage("Status refresh requested. Use the refresh control in Tools.") }) { Text("Details", color = AetherCyan, fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = AetherCard), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(39.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x226C63FF)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = AetherCyan)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(title, color = AetherText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = AetherSubText, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun FeatureCard(title: String, description: String, icon: ImageVector, tint: Color, status: String) {
    Card(colors = CardDefaults.cardColors(containerColor = AetherCard), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = tint)
                Text(title, Modifier.weight(1f).padding(start = 10.dp), color = AetherText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(status, color = tint, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(description, color = AetherSubText, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = AetherCard), shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = AetherSubText, fontSize = 11.sp)
            Text(value, color = AetherText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun launchSettings(context: Context, action: String) {
    runCatching { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        .onFailure { launchAppSettings(context) }
}

private fun launchAppSettings(context: Context) {
    runCatching {
        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun deviceReport(snapshot: DeviceSnapshot): String = buildString {
    appendLine("AetherSuite device report")
    appendLine("Device: ${snapshot.manufacturer} ${snapshot.model}")
    appendLine("Android: ${snapshot.androidVersion} (API ${snapshot.sdk})")
    appendLine("ABI: ${snapshot.abi}")
    appendLine("RAM: ${(snapshot.totalRamBytes - snapshot.availableRamBytes).toReadableSize()} / ${snapshot.totalRamBytes.toReadableSize()}")
    appendLine("Storage: ${(snapshot.totalStorageBytes - snapshot.freeStorageBytes).toReadableSize()} / ${snapshot.totalStorageBytes.toReadableSize()}")
    appendLine("Battery: ${if (snapshot.batteryPercent >= 0) "${snapshot.batteryPercent}%" else "Unknown"}")
}
