package com.aether.suite.core

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

data class ShizukuState(val running: Boolean, val permissionGranted: Boolean)

object ShizukuStatus {
    fun read(): ShizukuState {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = running && runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        return ShizukuState(running, granted)
    }

    fun requestPermission(requestCode: Int = 2108) {
        Shizuku.requestPermission(requestCode)
    }
}
