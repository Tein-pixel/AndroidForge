package com.aether.suite.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AetherScheme = darkColorScheme(
    primary = AetherPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2D2B6B),
    secondary = AetherCyan,
    onSecondary = AetherDark,
    tertiary = AetherPink,
    background = AetherDark,
    surface = AetherDarkSurf,
    onBackground = AetherText,
    onSurface = AetherText,
    surfaceVariant = AetherCard,
    outlineVariant = AetherCardBorder
)

@Composable
fun AetherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AetherScheme, typography = Typography(), content = content)
}
