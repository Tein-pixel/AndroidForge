package com.aether.suite.ui.theme

import androidx.compose.ui.graphics.Color

val AetherPurple = Color(0xFF6C63FF)
val AetherPink = Color(0xFFFF6584)
val AetherCyan = Color(0xFF43E8D8)
val AetherOrange = Color(0xFFFF8C42)
val AetherGold = Color(0xFFFFD700)
val AetherDark = Color(0xFF0A0A14)
val AetherDarkSurf = Color(0xFF13131F)
val AetherCard = Color(0xFF1C1C2E)
val AetherCardBorder = Color(0xFF2E2E48)
val AetherText = Color(0xFFEAEAFF)
val AetherSubText = Color(0xFF8888AA)
