# AetherSuite — Android Project

Android application project based on the supplied AetherSuite HTML source.

## Stack
- Kotlin, Jetpack Compose, Material 3
- Shizuku API for connection/permission status
- Android NDK + CMake native layer
- arm64-v8a target, minSdk 29, targetSdk 34
- Dear ImGui and Dobby are declared as Git submodules

## Build
1. Push the complete project to GitHub.
2. Ensure the repository contains the `.gitmodules` file and both submodule entries.
3. Run **Actions → Build AetherSuite APK** (or push to `main`/`master`).
4. Download the `AetherSuite-debug-*` artifact.

For a local Git checkout, run `git submodule update --init --recursive` before building. GitHub Actions checks out submodules automatically.

## Native modules
- `main.cpp`: JNI/native initialization and ImGui context setup.
- `stealth.cpp`: retained diagnostics placeholder; no stealth/evasion behavior.
- `il2cpp/Il2cppResolver.cpp`: bounded IL2CPP metadata-header validation, not runtime process scanning.
- `il2cpp/HookManager.cpp`: module registry/lifecycle foundation, not a cross-process hook installer.
- Dobby and ImGui source dependencies are fetched through Git submodules during checkout.

## Source completeness
The supplied HTML referenced prior messages for several files and included placeholder comments instead of their implementations. This project fills those missing files with buildable foundations. It does not claim to reproduce unavailable source code or to provide fully implemented game-process instrumentation.
