@echo off
setlocal
set APP_HOME=%~dp0
if not exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  where gradle >nul 2>nul
  if errorlevel 1 (
    echo Gradle Wrapper JAR missing. Run this project in AndroidForge or install Gradle 8.9.
    exit /b 1
  )
  pushd "%APP_HOME%"
  gradle wrapper --gradle-version 8.9 --distribution-type bin
  popd
)
java %JAVA_OPTS% %GRADLE_OPTS% -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
endlocal
