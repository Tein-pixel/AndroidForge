package com.nightcore.floating;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_PROJECTION = 1001;
    private MediaProjectionManager mpm;
    private ObjectAnimator glowAnim;
    private BubbleShapeView preview;
    private final TextView[] shapeBtns = new TextView[4];
    private final View[] swatches = new View[BubblePrefs.COLORS.length];
    private TextView alphaVal, sizeVal;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        View glow = findViewById(R.id.glow);
        glowAnim = ObjectAnimator.ofPropertyValuesHolder(glow,
                PropertyValuesHolder.ofFloat("scaleX", 0.85f, 1.12f),
                PropertyValuesHolder.ofFloat("scaleY", 0.85f, 1.12f),
                PropertyValuesHolder.ofFloat("alpha", 1f, 0.35f));
        glowAnim.setDuration(1800);
        glowAnim.setRepeatCount(ObjectAnimator.INFINITE);
        glowAnim.setRepeatMode(ObjectAnimator.REVERSE);
        glowAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        glowAnim.start();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            // Android 10 ke bawah: butuh MediaProjection untuk screenshot.
            // Request hanya kalau belum ada token yang tersimpan.
            mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (!ScreenBridgeService.hasProjectionToken()) {
                requestMediaProjection();
            }
        }

        // Start → arahkan ke Accessibility Settings
        findViewById(R.id.btnStart).setOnClickListener(v -> {
            if (isServiceEnabled()) {
                Toast.makeText(this, "Service sudah aktif", Toast.LENGTH_SHORT).show();
                // Jika token belum ada (Android 10), minta lagi
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R
                        && !ScreenBridgeService.hasProjectionToken()) {
                    requestMediaProjection();
                }
            } else {
                Toast.makeText(this, "Aktifkan 'Display Helper Service' di halaman berikut",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });

        // Stop → nonaktifkan petunjuk (service dikelola sistem; user harus matikan manual)
        findViewById(R.id.btnStop).setOnClickListener(v -> {
            if (isServiceEnabled()) {
                Toast.makeText(this, "Nonaktifkan 'Display Helper Service' di Accessibility Settings",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } else {
                Toast.makeText(this, "Service tidak aktif", Toast.LENGTH_SHORT).show();
            }
        });

        setupSettings();
    }

    private void requestMediaProjection() {
        // Dialog "Izinkan merekam layar?" — muncul sekali, tidak ada notifikasi ongoing di Android 10.
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PROJECTION && resultCode == RESULT_OK && data != null) {
            // Simpan token ke Service — berlaku selama proses hidup.
            ScreenBridgeService.setProjectionToken(resultCode, data);
            Toast.makeText(this, "Izin layar diberikan", Toast.LENGTH_SHORT).show();
        }
    }

    // Cek apakah ScreenBridgeService sudah diaktifkan user di Accessibility Settings
    private boolean isServiceEnabled() {
        String flat = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        String target = getPackageName() + "/" + ScreenBridgeService.class.getName();
        return flat != null && flat.contains(target);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void setupSettings() {
        preview = findViewById(R.id.bubblePreview);

        int[] ids = {R.id.shape0, R.id.shape1, R.id.shape2, R.id.shape3};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            shapeBtns[i] = findViewById(ids[i]);
            shapeBtns[i].setOnClickListener(v -> {
                BubblePrefs.sp(this).edit().putInt("shape", idx).apply();
                refreshUi();
            });
        }

        LinearLayout row = findViewById(R.id.colorRow);
        for (int i = 0; i < swatches.length; i++) {
            final int c = BubblePrefs.COLORS[i];
            View sw = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(30), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            sw.setLayoutParams(lp);
            sw.setOnClickListener(x -> {
                BubblePrefs.sp(this).edit().putInt("color", c).apply();
                refreshUi();
            });
            row.addView(sw);
            swatches[i] = sw;
        }
        findViewById(R.id.colorReset).setOnClickListener(v -> {
            BubblePrefs.sp(this).edit().putInt("color", BubblePrefs.DEFAULT_COLOR).apply();
            refreshUi();
        });

        alphaVal = findViewById(R.id.alphaVal);
        sizeVal  = findViewById(R.id.sizeVal);
        SeekBar seekAlpha = findViewById(R.id.seekAlpha);
        SeekBar seekSize  = findViewById(R.id.seekSize);
        seekAlpha.setMax(80);
        seekAlpha.setProgress(BubblePrefs.alpha(this) - 20);
        seekSize.setMax(40);
        seekSize.setProgress(BubblePrefs.size(this) - 32);

        seekAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) { BubblePrefs.sp(MainActivity.this).edit().putInt("alpha", p + 20).apply(); refreshUi(); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        seekSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) { BubblePrefs.sp(MainActivity.this).edit().putInt("size", p + 32).apply(); refreshUi(); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        refreshUi();
    }

    private void refreshUi() {
        int shape = BubblePrefs.shape(this);
        int color = BubblePrefs.color(this);
        int alpha = BubblePrefs.alpha(this);
        int size  = BubblePrefs.size(this);

        for (int i = 0; i < shapeBtns.length; i++) {
            boolean sel = i == shape;
            shapeBtns[i].setBackgroundResource(sel ? R.drawable.bg_chip_sel : R.drawable.bg_chip);
            shapeBtns[i].setTextColor(sel ? 0xFF00E5FF : 0xFFFFFFFF);
        }
        for (int i = 0; i < swatches.length; i++) {
            boolean sel = BubblePrefs.COLORS[i] == color;
            GradientDrawable g = new GradientDrawable();
            g.setColor(BubblePrefs.COLORS[i]);
            g.setCornerRadius(dp(8));
            g.setStroke(dp(sel ? 3 : 1), sel ? 0xFFFFFFFF : 0x55FFFFFF);
            swatches[i].setBackground(g);
        }
        preview.setStyle(shape, color);
        preview.setAlpha(alpha / 100f);
        ViewGroup.LayoutParams lp = preview.getLayoutParams();
        lp.width  = dp(size);
        lp.height = dp(size);
        preview.setLayoutParams(lp);
        alphaVal.setText(alpha + "%");
        sizeVal.setText(size + " dp");
    }

    @Override
    protected void onDestroy() {
        if (glowAnim != null) glowAnim.cancel();
        super.onDestroy();
    }
}
