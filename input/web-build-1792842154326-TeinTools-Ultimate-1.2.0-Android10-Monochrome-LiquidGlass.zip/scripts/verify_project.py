#!/usr/bin/env python3
"""Lightweight pre-build contract checks for TeinTools. No third-party packages required."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
checks = []

def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append(name)
    if not condition:
        errors.append(f"FAIL: {name}" + (f" — {detail}" if detail else ""))
    else:
        print(f"PASS: {name}")

main = ROOT / "app/src/main/java/com/teinzz/teintools/MainActivity.java"
gradle = ROOT / "app/build.gradle"
manifest = ROOT / "app/src/main/AndroidManifest.xml"
workflow = ROOT / ".github/workflows/build.yml"
art = ROOT / "app/src/main/res/drawable-nodpi/hero_liquid.webp"

check("required project files exist", all(p.is_file() for p in [main, gradle, manifest, workflow, art]))

if gradle.exists():
    g = gradle.read_text(encoding="utf-8")
    check("Android 10 minimum SDK", bool(re.search(r"minSdk\s+29\b", g)))
    check("Android 10 compatibility target", bool(re.search(r"targetSdk\s+29\b", g)))
    check("compile SDK 34", bool(re.search(r"compileSdk\s+34\b", g)))
    check("AGP 8.7.3", "com.android.application' version '8.7.3'" in (ROOT / "build.gradle").read_text(encoding="utf-8"))
    check("version 1.2.0 / code 3", "versionName '1.2.0'" in g and "versionCode 3" in g)

if manifest.exists():
    try:
        tree = ET.parse(manifest)
        root = tree.getroot()
        ns = "{http://schemas.android.com/apk/res/android}"
        app = root.find("application")
        launcher = None
        if app is not None:
            for activity in app.findall("activity"):
                actions = [x.get(ns + "name") for filt in activity.findall("intent-filter") for x in filt.findall("action")]
                categories = [x.get(ns + "name") for filt in activity.findall("intent-filter") for x in filt.findall("category")]
                if "android.intent.action.MAIN" in actions and "android.intent.category.LAUNCHER" in categories:
                    launcher = activity
                    break
        check("manifest XML parses", True)
        check("launcher activity is exported", launcher is not None and launcher.get(ns + "exported") == "true")
        check("hardware acceleration enabled", app is not None and app.get(ns + "hardwareAccelerated") == "true")
    except ET.ParseError as e:
        check("manifest XML parses", False, str(e))

if main.exists():
    java = main.read_text(encoding="utf-8")
    required = [
        "showSplashScreen()", "liquidBackground()", "buildCleanerPage", "clearDirectoryContents",
        "buildSensorPage", "buildPermissionsPage", "shareDiagnostics", "buildNetworkPage",
        "buildQrPage", "buildFlashPage", "buildNotesPage", "buildTimerPage",
    ]
    check("feature entry points included", all(token in java for token in required), ", ".join(t for t in required if t not in java))
    check("cache cleanup is scoped to this app", "getCacheDir()" in java and "getExternalCacheDir()" in java and "TeinTools cache" in java and "clearDirectoryContents(getCacheDir())" in java)
    check("no hidden global-cache API", "ACTION_CLEAR_APP_CACHE" not in java)
    check("balanced Java braces", java.count("{") == java.count("}"), f"{java.count('{')} opening / {java.count('}')} closing")
    method_names = re.findall(r'^\s*(?:private|public|protected)\s+(?:static\s+)?[\w<>\[\], ?]+\s+(\w+)\s*\(', java, re.M)
    from collections import Counter
    duplicate_methods = {name: count for name, count in Counter(method_names).items() if count > 1 and name != "label"}
    check("no accidental duplicate methods", not duplicate_methods, str(duplicate_methods))

if workflow.exists():
    w = workflow.read_text(encoding="utf-8")
    check("CI pins Gradle 8.9", "gradle-version: '8.9'" in w)
    check("CI uploads the APK", "actions/upload-artifact@v4" in w and "app/build/outputs/apk/debug/app-debug.apk" in w)
    check("CI runs source contract checks", "python3 scripts/verify_project.py" in w)

if art.exists():
    check("hero artwork is bundled", art.stat().st_size > 5000 and art.stat().st_size < 500_000, f"size {art.stat().st_size} bytes")

# Android permissions are contextual and minimal: camera is the only dangerous runtime permission.
if manifest.exists() and main.exists():
    manifest_text = manifest.read_text(encoding="utf-8")
    java_text = main.read_text(encoding="utf-8")
    check("camera permission declared for QR and torch", "android.permission.CAMERA" in manifest_text and "requestCameraPermissionWithRationale" in java_text)
    check("QR scan explicitly gates camera permission", "startQrScan()" in java_text and "launchQrScanner()" in java_text)
    check("permission inspector explains normal permissions", "Automatic Android permissions" in java_text)
    check("black/white themes offered", "Black Glass" in java_text and "White Glass" in java_text)
    check("monochrome vector feature icons are used", "class LineIconView" in java_text and "new LineIconView" in java_text)
    check("no broad storage permission requested", "MANAGE_EXTERNAL_STORAGE" not in manifest_text and "WRITE_EXTERNAL_STORAGE" not in manifest_text)
    check("camera manifest conflict override retained", 'tools:replace="android:screenOrientation,android:theme"' in manifest_text)
    check("runtime camera rationale and denial path exist", "shouldShowRequestPermissionRationale" in java_text and "Other tools remain available" in java_text)
    check("empty cleaner cache is reported honestly", "Already clean" in java_text)
    check("permission and cleaner status refresh after returning from settings", "onResume()" in java_text and "permissions" in java_text and "cleaner" in java_text)
    check("system storage manager API is used with fallbacks", "StorageManager.ACTION_MANAGE_STORAGE" in java_text and "ACTION_INTERNAL_STORAGE_SETTINGS" in java_text)
    check("layout helper avoids double density scaling", "new LinearLayout.LayoutParams(width, height)" in java_text and "Do not density-scale sizes a second time" in java_text)

if errors:
    print("\n".join(errors), file=sys.stderr)
    print(f"\n{len(errors)} failure(s), {len(checks)} checks.", file=sys.stderr)
    sys.exit(1)
print(f"\nAll {len(checks)} project contract checks passed.")
