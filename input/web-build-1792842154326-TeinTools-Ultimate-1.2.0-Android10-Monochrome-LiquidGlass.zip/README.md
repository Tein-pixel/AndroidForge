# TeinTools Ultimate 1.1.0 — Android 10-first

TeinTools is a lightweight, non-root Android toolbox built in Java with native Android Views. The app targets Android 10 (API 29) and uses a liquid-glass visual language: translucent gradient surfaces, thin specular borders, an original abstract glass artwork used on the splash and home hero only, and short motion transitions.

## Included tools

- **Device Monitor:** hardware/OS details, available RAM/storage, battery details and thermal information where the device exposes it.
- **Network Lab:** HTTPS reachability, DNS resolution, TCP connection latency, a small download-throughput estimate and Wi-Fi details available through Android.
- **One-tap Cache Cleaner:** measures and clears TeinTools' own internal and external cache directories. A separate action opens Android storage settings for user-controlled cleanup elsewhere.
- **Sensor Lab:** lists sensor metadata returned by Android; it does not continuously collect sensor measurements in the background.
- **Permission Inspector:** shows camera-permission status and links to the app's native settings.
- **QR Studio:** scan, generate and save QR codes.
- **Flashlight, Calculator, Stopwatch, Countdown Timer, Unit Converter, Quick Notes, File Hub, Installed Apps, System Shortcuts** and a **Share Device Diagnostics** action.
- Persistent Black Glass / White Glass theme selection, animated splash loading, staggered page-entry transitions, action press feedback, and progress indicators for asynchronous work.

## Important Android 10 limitation: cache cleanup

A regular, non-root app cannot silently delete other apps' private cache directories. Android's scoped-storage model isolates app-specific directories. `StorageManager.ACTION_CLEAR_APP_CACHE` was added in Android 11 (API 30), requires `MANAGE_EXTERNAL_STORAGE`, and concerns external app-cache directories; it is not available on Android 10 (API 29) and does not grant access to other apps' private internal data. TeinTools therefore cleans its own cache in one tap and opens Android's user-controlled storage manager for the rest. It does not delete user photos, downloads, notes, or preferences.

## Liquid glass on Android 10

This app uses a compatibility implementation: layered gradients, translucent card fills, highlight strokes and a small number of artwork placements. Native system/window blur APIs are Android 12+ APIs, so the UI does not depend on them. This avoids an API mismatch on Android 10 and keeps rendering relatively light.

## Build

- JDK: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (pinned in `.github/workflows/build.yml`)
- compileSdk: 34
- minSdk: 29 (Android 10)
- targetSdk: 29

The GitHub Actions workflow builds a debug APK, verifies it exists, and uploads it as an artifact retained for 14 days. This source ZIP has not been device-tested. Verify the Actions build and install/test the APK on a physical Android 10 device before treating it as release-ready.

## Package

`com.teinzz.teintools`


## Version 1.2.0 — monochrome liquid glass

- Reworked home screen as an artwork billboard with transparent, non-square-filling artwork.
- Replaced text glyph/emoji-like tool symbols with custom drawn line icons.
- Added Black Glass and White Glass themes with neutral silver highlights.
- Increased card spacing and bottom navigation clearance; staggered page-enter transitions and revised splash loading.
- QR scanner now explicitly requests CAMERA at the point of use, with a rationale when Android says one is appropriate. The flashlight uses the same contextual permission.
- Permission Inspector explains normal install-time permissions, contextual camera access, and features that do not require permissions.
- Cache Cleaner remains scoped to TeinTools' own cache. Android 10 does not expose a normal third-party permission for clearing all apps' private caches; the system storage screen is the safe route for the rest.

No AccessibilityService, overlay, background-location, or broad-storage permission is requested. This avoids presenting Accessibility as a universal cleaner permission.


## Platform and design references

- Android runtime permission guidance: https://developer.android.com/training/permissions/requesting
- Android 10 scoped storage/privacy behavior: https://developer.android.com/about/versions/10/privacy/changes
- StorageManager cache-clearing API (added in API 30, so not usable on Android 10 / API 29): https://developer.android.com/reference/android/os/storage/StorageManager#ACTION_CLEAR_APP_CACHE
- Google Play AccessibilityService policy and user disclosure requirements: https://support.google.com/googleplay/android-developer/answer/10964491
- Android layout basics and consistent spacing: https://developer.android.com/design/ui/mobile/guides/layout-and-content/layout-basics

The interface borrows high-level liquid-glass visual principles (restrained translucency, thin highlights, monochrome surfaces, and a featured hero illustration) rather than copying a third-party screen.
