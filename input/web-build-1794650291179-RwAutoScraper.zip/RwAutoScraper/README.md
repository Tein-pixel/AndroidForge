# RW Free Auto-Scraper

Room Wangi (RW) VPN auto-scraper for Mobile Legends low-population matchmaking.  
Platform: Android 10+ (API 29+) · Kotlin 1.9.0 · Jetpack Compose · Material3

---

## Build Instructions

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34

### Steps

1. **Open project**  
   File → Open → select the `RwAutoScraper/` folder.

2. **Sync Gradle**  
   Android Studio will auto-download all dependencies including:
   - WireGuard tunnel library (`com.wireguard.android:tunnel:1.0.20230706`)
   - Room 2.6.1, OkHttp 4.12.0, Jetpack Compose BOM 2024.01.00

3. **Generate Gradle wrapper** (first time only, if wrapper JAR is missing)  
   Open Terminal in Android Studio and run:
   ```
   gradle wrapper --gradle-version 8.0
   ```
   Or let Android Studio download it automatically via Gradle → Sync.

4. **Build**  
   Build → Make Project   (Ctrl+F9 / Cmd+F9)

5. **Run on device / emulator**  
   - Physical device strongly recommended for VPN testing  
   - Enable Developer Options + USB Debugging  
   - Run → Run 'app'   (Shift+F10 / Ctrl+R)

---

## First-time App Usage

1. **Tap "Auto-Scrape Free Servers"** — fetches VPN Gate CSV + GitHub WireGuard configs,  
   filters to 9 low-population ML countries (QA, BY, KZ, PE, NO, MM, KH, LV, EE).

2. **Tap the ▶ FAB** → go to Sequence Builder.

3. **Select Step 1 and Step 2** from the scraped server list.

4. **Tap "Save Sequence"** — persists to Room DB.

5. **Tap "Start RW Bubble"** — grants SYSTEM_ALERT_WINDOW permission if needed,  
   then launches the floating 72dp circle.

6. **Tap the bubble** to cycle:  
   `▶ Step 1` → connects Step 1 → shows `▶ Step 2` → tap → connects Step 2 → shows `▶ Step 1` → …

---

## Architecture Notes

| File | Role |
|------|------|
| `MultiSourceScraper.kt` | Fetches VPN Gate CSV (Source 1) + GitHub WG configs (Source 3) + ip-api.com geo-tag (Source 2) |
| `AppDatabase.kt` | Room singleton, `servers` table |
| `TunnelManager.kt` | Routes to `GoBackend` (WireGuard) or `RwVpnService` (OpenVPN) |
| `RwVpnService.kt` | Custom `VpnService` — TUN relay for OpenVPN UDP/TCP. Extends transport layer; add ics-openvpn AIDL for full TLS. |
| `RotationEngine.kt` | 2-step switcher — calls `TunnelManager.disconnect()` then `connect()` |
| `FloatingBubbleService.kt` | `TYPE_APPLICATION_OVERLAY` foreground service, draggable bubble |
| `MainActivity.kt` | Compose NavHost, Dashboard, Sequence Builder, `MainViewModel` |

---

## Permissions Required

| Permission | Reason |
|-----------|--------|
| `INTERNET` | Scraping + VPN traffic |
| `SYSTEM_ALERT_WINDOW` | Floating bubble overlay |
| `FOREGROUND_SERVICE` | Bubble + VPN services |
| `BIND_VPN_SERVICE` | RwVpnService + GoBackend VpnService |

---

## Target Countries (confirmed low ML player count)

| Code | Country    |
|------|-----------|
| QA   | Qatar     |
| BY   | Belarus   |
| KZ   | Kazakhstan|
| PE   | Peru      |
| NO   | Norway    |
| MM   | Myanmar   |
| KH   | Cambodia  |
| LV   | Latvia    |
| EE   | Estonia   |
