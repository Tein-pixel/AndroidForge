package com.rw.autoscraper.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.BubbleChart
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rw.autoscraper.database.AppDatabase
import com.rw.autoscraper.database.ServerConfig
import com.rw.autoscraper.overlay.FloatingBubbleService
import com.rw.autoscraper.scraper.MultiSourceScraper
import com.rw.autoscraper.scripts.RotationEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// ══════════════════════════════════════════════════════════════════════════════
// MainActivity
// ══════════════════════════════════════════════════════════════════════════════

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val navController = rememberNavController()
                val vm: MainViewModel = viewModel()
                NavHost(navController = navController, startDestination = "dashboard") {
                    composable("dashboard") { DashboardScreen(navController, vm) }
                    composable("sequence")  { SequenceScreen(navController, vm) }
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Dashboard Screen
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun DashboardScreen(navController: NavController, viewModel: MainViewModel) {
    val servers     by viewModel.servers.collectAsState()
    val logText     by viewModel.logText.collectAsState()
    val progress    by viewModel.progress.collectAsState()
    val isScraping  = viewModel.isScraping

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0D1A))
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // ── Header ──────────────────────────────────────────────────────
            Text(
                text       = "RW Free Scraper",
                fontSize   = 22.sp,
                fontWeight = FontWeight.Bold,
                color      = Color.White
            )
            Text(
                text     = "Room Wangi Auto-Config",
                fontSize = 13.sp,
                color    = Color(0xFF9E9E9E)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Scrape button ────────────────────────────────────────────────
            Button(
                onClick  = { viewModel.startScrape() },
                enabled  = !isScraping,
                shape    = RoundedCornerShape(16.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C4DFF)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(Icons.Filled.Download, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text     = if (isScraping) "Scraping…" else "Auto-Scrape Free Servers",
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ── Progress + log panel ─────────────────────────────────────────
            if (isScraping) {
                @Suppress("DEPRECATION")
                LinearProgressIndicator(
                    progress  = progress,
                    modifier  = Modifier.fillMaxWidth(),
                    color     = Color(0xFF7C4DFF),
                    trackColor = Color(0xFF2A2A3E)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text       = logText,
                    fontSize   = 12.sp,
                    color      = Color(0xFF80CBC4),
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ── Server list header ───────────────────────────────────────────
            Text(
                text     = "Servers Found: ${servers.size}",
                fontSize = 13.sp,
                color    = Color(0xFF9E9E9E)
            )
            Spacer(modifier = Modifier.height(8.dp))

            // ── Server list ──────────────────────────────────────────────────
            LazyColumn(
                modifier            = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(servers, key = { it.id }) { server ->
                    ServerCard(server = server)
                }
            }
        }

        // ── FAB → Sequence Builder ───────────────────────────────────────────
        FloatingActionButton(
            onClick          = { navController.navigate("sequence") },
            shape            = RoundedCornerShape(16.dp),
            containerColor   = Color(0xFF7C4DFF),
            modifier         = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 8.dp, end = 8.dp)
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = "Build Sequence", tint = Color.White)
        }
    }
}

// ── Server card ───────────────────────────────────────────────────────────────

@Composable
fun ServerCard(server: ServerConfig) {
    Card(
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(
            containerColor = if (server.isLowPop) Color(0xFF1B3A1F) else Color(0xFF1A1A2E)
        ),
        border   = BorderStroke(
            0.5.dp,
            if (server.isLowPop) Color(0xFF4CAF50) else Color(0xFF2A2A3E)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier          = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Country code badge
            Box(
                modifier        = Modifier
                    .size(40.dp)
                    .background(Color(0x267C4DFF), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text       = server.countryShort,
                    fontSize   = 11.sp,
                    color      = Color(0xFF7C4DFF),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text       = server.countryLong,
                    fontSize   = 14.sp,
                    color      = Color.White,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text     = "${server.ip}:${server.port} · ${server.proto}",
                    fontSize = 11.sp,
                    color    = Color(0xFF9E9E9E)
                )
            }

            if (server.isLowPop) {
                Text(text = "RW ✓", fontSize = 11.sp, color = Color(0xFF4CAF50))
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Sequence Screen
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun SequenceScreen(navController: NavController, viewModel: MainViewModel) {
    val context = LocalContext.current
    val servers by viewModel.servers.collectAsState()
    val step1   = viewModel.step1
    val step2   = viewModel.step2

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0D1A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Text(
                text       = "2-Step Sequence",
                fontSize   = 22.sp,
                color      = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text     = "Configure BEFORE starting overlay",
                fontSize = 12.sp,
                color    = Color(0xFFFF9800)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // ── Step 1 card ──────────────────────────────────────────────────
            SequenceStepCard(
                stepNumber       = 1,
                selectedServer   = step1,
                allServers       = servers,
                onServerSelected = { viewModel.setStep(0, it) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Connector arrow ──────────────────────────────────────────────
            Icon(
                imageVector  = Icons.Filled.ArrowDownward,
                contentDescription = null,
                tint         = Color(0xFF7C4DFF),
                modifier     = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Step 2 card ──────────────────────────────────────────────────
            SequenceStepCard(
                stepNumber       = 2,
                selectedServer   = step2,
                allServers       = servers,
                onServerSelected = { viewModel.setStep(1, it) }
            )

            Spacer(modifier = Modifier.height(32.dp))

            // ── Save button ──────────────────────────────────────────────────
            Button(
                onClick  = { viewModel.saveSequence() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape    = RoundedCornerShape(16.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C4DFF))
            ) {
                Text(text = "Save Sequence")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ── Start bubble button ──────────────────────────────────────────
            Button(
                onClick  = {
                    if (!Settings.canDrawOverlays(context)) {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                        )
                    } else {
                        context.startService(
                            Intent(context, FloatingBubbleService::class.java)
                        )
                    }
                },
                enabled  = step1 != null && step2 != null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape    = RoundedCornerShape(16.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor         = Color(0xFF4CAF50),
                    disabledContainerColor = Color(0xFF2A3D2A)
                )
            ) {
                Icon(Icons.Filled.BubbleChart, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Start RW Bubble")
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// SequenceStepCard
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun SequenceStepCard(
    stepNumber: Int,
    selectedServer: ServerConfig?,
    allServers: List<ServerConfig>,
    onServerSelected: (ServerConfig) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape    = RoundedCornerShape(16.dp),
        border   = BorderStroke(1.dp, Color(0xFF7C4DFF)),
        colors   = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text     = "Step $stepNumber",
                fontSize = 12.sp,
                color    = Color(0xFF7C4DFF)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = true }
                    .background(Color(0xFF0D0D1A), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text     = selectedServer
                        ?.let { "${it.countryLong} · ${it.ip}" }
                        ?: "Tap to select server…",
                    color    = if (selectedServer != null) Color.White else Color(0xFF666666),
                    fontSize = 14.sp
                )
            }

            DropdownMenu(
                expanded          = expanded,
                onDismissRequest  = { expanded = false },
                modifier          = Modifier
                    .background(Color(0xFF1A1A2E))
                    .heightIn(max = 300.dp)
            ) {
                if (allServers.isEmpty()) {
                    DropdownMenuItem(
                        text    = { Text("No servers — scrape first", color = Color(0xFF9E9E9E)) },
                        onClick = { expanded = false }
                    )
                } else {
                    allServers.forEach { server ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text     = server.countryLong,
                                        color    = Color.White,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text     = "${server.ip} · ${server.proto}",
                                        color    = Color(0xFF9E9E9E),
                                        fontSize = 11.sp
                                    )
                                }
                            },
                            onClick = {
                                onServerSelected(server)
                                expanded = false
                            },
                            leadingIcon = {
                                if (server.isLowPop) {
                                    Text("●", color = Color(0xFF4CAF50))
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// MainViewModel
// ══════════════════════════════════════════════════════════════════════════════

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val db      = AppDatabase.getInstance(app)
    private val dao     = db.serverConfigDao()
    private val scraper = MultiSourceScraper(dao)

    val servers = dao.getAllServers().stateIn(
        scope     = viewModelScope,
        started   = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val logText  = scraper.logFlow
    val progress = scraper.progressFlow

    var isScraping by mutableStateOf(false)
        private set

    var step1: ServerConfig? by mutableStateOf(null)
    var step2: ServerConfig? by mutableStateOf(null)

    fun startScrape() {
        viewModelScope.launch {
            isScraping = true
            scraper.scrapeAll()
            isScraping = false
        }
    }

    fun setStep(index: Int, server: ServerConfig) {
        if (index == 0) step1 = server else step2 = server
    }

    fun saveSequence() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearSequence()
            step1?.let { dao.updateSequenceStep(it.id, 0) }
            step2?.let { dao.updateSequenceStep(it.id, 1) }
            RotationEngine.getInstance(getApplication()).loadSequence()
        }
    }
}
