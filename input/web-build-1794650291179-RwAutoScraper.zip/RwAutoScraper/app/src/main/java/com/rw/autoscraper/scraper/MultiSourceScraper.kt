package com.rw.autoscraper.scraper

import android.util.Base64
import com.rw.autoscraper.database.ServerConfig
import com.rw.autoscraper.database.ServerConfigDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class MultiSourceScraper(private val dao: ServerConfigDao) {

    // ── Target countries: confirmed low ML-player-count populations ──────────
    private val TARGET_COUNTRIES = setOf("QA", "BY", "KZ", "PE", "NO", "MM", "KH", "LV", "EE")
    private val TARGET_NAMES = setOf(
        "Qatar", "Belarus", "Kazakhstan", "Peru", "Norway",
        "Myanmar", "Cambodia", "Latvia", "Estonia"
    )

    val logFlow      = MutableStateFlow("")
    val progressFlow = MutableStateFlow(0f)

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // ── Entry point ───────────────────────────────────────────────────────────

    suspend fun scrapeAll(): Int = withContext(Dispatchers.IO) {
        var total = 0

        log("▶ Starting scrape from all sources…")
        progressFlow.value = 0f

        // Source 1: VPN Gate CSV (always reliable)
        log("📡 Source 1 — VPN Gate CSV…")
        progressFlow.value = 0.05f
        val vg = scrapeVpnGate()
        total += vg
        log("  ✓ VPN Gate: $vg servers")
        progressFlow.value = 0.55f

        // Source 3: GitHub WireGuard config aggregators
        log("📡 Source 3 — GitHub WireGuard configs…")
        val wg = scrapeGithubWireGuard()
        total += wg
        log("  ✓ GitHub WG: $wg servers")
        progressFlow.value = 0.95f

        log("✅ Done. Total saved: $total servers.")
        progressFlow.value = 1f
        total
    }

    // ── Source 1: VPN Gate CSV ────────────────────────────────────────────────

    private suspend fun scrapeVpnGate(): Int {
        var count = 0
        try {
            val request = Request.Builder()
                // IMPORTANT: http — VPN Gate redirects HTTPS to their portal page
                .url("http://www.vpngate.net/api/iphone/")
                .header("User-Agent", "OpenVPN")
                .build()

            val body = client.newCall(request).execute().use { it.body?.string() } ?: return 0

            val lines = body.split("\n")
            // Line 0: comment starting with *
            // Line 1: CSV header
            // Line 2+: data
            for (i in 2 until lines.size) {
                val line = lines[i].trim()
                if (line.isEmpty() || line.startsWith("*")) continue

                val parts = line.split(",")
                if (parts.size < 15) continue

                val countryShort = parts[6].trim()
                val countryLong  = parts[5].trim()
                if (countryShort !in TARGET_COUNTRIES) continue

                val b64Config = parts[14].trim()
                if (b64Config.length < 10) continue

                try {
                    val ovpnRaw = String(Base64.decode(b64Config, Base64.DEFAULT))

                    var serverIp   = parts[1].trim()
                    var serverPort = 1194
                    var proto      = "udp"

                    for (cfgLine in ovpnRaw.lines()) {
                        when {
                            cfgLine.startsWith("remote ") -> {
                                val rem = cfgLine.trim().split("\\s+".toRegex())
                                if (rem.size >= 3) {
                                    serverIp   = rem[1]
                                    serverPort = rem[2].toIntOrNull() ?: 1194
                                }
                            }
                            cfgLine.startsWith("proto ") -> {
                                proto = cfgLine.trim().split("\\s+".toRegex())
                                    .getOrElse(1) { "udp" }
                                    .lowercase()
                            }
                        }
                    }

                    dao.insert(
                        ServerConfig(
                            hostname     = parts[0].trim(),
                            ip           = serverIp,
                            port         = serverPort,
                            countryLong  = countryLong,
                            countryShort = countryShort,
                            configRaw    = ovpnRaw,
                            proto        = "openvpn",
                            ping         = parts[3].trim(),
                            speed        = parts[4].toLongOrNull() ?: 0L,
                            isLowPop     = true
                        )
                    )
                    count++
                    if (count % 5 == 0) log("  VPN Gate: $count servers so far ($countryLong)")
                } catch (_: Exception) {
                    // skip malformed Base64 or bad rows
                }
            }
        } catch (e: Exception) {
            log("  ⚠ VPN Gate error: ${e.message}")
        }
        return count
    }

    // ── Source 3: GitHub WireGuard config aggregators ─────────────────────────

    private val GITHUB_URLS = listOf(
        "https://raw.githubusercontent.com/hiddify/hiddify-manager/main/other/configs.txt",
        "https://raw.githubusercontent.com/barry-far/V2ray-Configs/main/Sub1.txt",
        "https://raw.githubusercontent.com/mahdibland/V2RayAgg/master/Eternity.txt"
    )

    private suspend fun scrapeGithubWireGuard(): Int {
        var count = 0
        for (url in GITHUB_URLS) {
            try {
                val req  = Request.Builder().url(url).build()
                val body = client.newCall(req).execute().use { it.body?.string() } ?: continue

                for (line in body.lines()) {
                    if (!line.startsWith("wireguard://")) continue
                    val (ip, port, conf) = parseWireGuardUri(line) ?: continue

                    // Source 2: ip-api.com geo-tag — 45 req/min free
                    delay(1400)   // stay well under rate limit
                    val (cLong, cShort) = getCountryForIp(ip) ?: continue
                    if (cShort !in TARGET_COUNTRIES) continue

                    dao.insert(
                        ServerConfig(
                            hostname     = ip,
                            ip           = ip,
                            port         = port,
                            countryLong  = cLong,
                            countryShort = cShort,
                            configRaw    = conf,
                            proto        = "wireguard",
                            ping         = "0",
                            speed        = 0L,
                            isLowPop     = true
                        )
                    )
                    count++
                    log("  GitHub WG: $count — $cLong ($ip)")
                }
            } catch (e: Exception) {
                log("  ⚠ GitHub error: ${e.message}")
            }
        }
        return count
    }

    /**
     * Parse a wireguard:// URI into (IP, port, wg-quick config string).
     *
     * URI format:
     *   wireguard://PRIVKEY@ENDPOINT:PORT?publickey=PUBKEY&address=ADDR&dns=DNS
     */
    private fun parseWireGuardUri(uri: String): Triple<String, Int, String>? {
        return try {
            val stripped  = uri.removePrefix("wireguard://")
            val atIdx     = stripped.indexOf('@')
            val privKey   = stripped.substring(0, atIdx)
            val rest      = stripped.substring(atIdx + 1)       // "IP:PORT?..."
            val qIdx      = rest.indexOf('?')
            val endpoint  = if (qIdx >= 0) rest.substring(0, qIdx) else rest
            val query     = if (qIdx >= 0) rest.substring(qIdx + 1) else ""

            val lastColon = endpoint.lastIndexOf(':')
            val ip   = endpoint.substring(0, lastColon)
            val port = endpoint.substring(lastColon + 1).toIntOrNull() ?: 51820

            val params = query.split("&").associate {
                val eq = it.indexOf('=')
                if (eq < 0) it to "" else it.substring(0, eq) to it.substring(eq + 1)
            }
            val pubKey  = params["publickey"] ?: return null
            val address = params["address"]   ?: "10.0.0.2/32"
            val dns     = params["dns"]       ?: "1.1.1.1"

            val conf = buildString {
                appendLine("[Interface]")
                appendLine("PrivateKey = $privKey")
                appendLine("Address = $address")
                appendLine("DNS = $dns")
                appendLine()
                appendLine("[Peer]")
                appendLine("PublicKey = $pubKey")
                appendLine("Endpoint = $ip:$port")
                appendLine("AllowedIPs = 0.0.0.0/0")
            }
            Triple(ip, port, conf)
        } catch (_: Exception) {
            null
        }
    }

    // ── Source 2: ip-api.com — geo-tag any IP (45 req/min, no key needed) ───

    private fun getCountryForIp(ip: String): Pair<String, String>? {
        return try {
            val req  = Request.Builder()
                .url("http://ip-api.com/json/$ip?fields=country,countryCode,status")
                .build()
            val body = client.newCall(req).execute().use { it.body?.string() } ?: return null

            if (!body.contains("\"success\"")) return null
            val country = Regex(""""country"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1)
            val code    = Regex(""""countryCode"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1)
            if (country == null || code == null) null else Pair(country, code)
        } catch (_: Exception) {
            null
        }
    }

    // ─────────────────────────────────────────────────────────────────────────

    private fun log(msg: String) {
        logFlow.value = msg
    }
}
