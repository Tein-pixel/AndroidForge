package com.rw.autoscraper.database

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

// ─── Entity ───────────────────────────────────────────────────────────────────

@Entity(tableName = "servers")
data class ServerConfig(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hostname: String,
    val ip: String,
    val port: Int,
    val countryLong: String,
    val countryShort: String,
    /** Full .ovpn or wg-quick .conf string — stored as plain text */
    val configRaw: String,
    /** "openvpn" | "wireguard" */
    val proto: String,
    val ping: String,
    val speed: Long,
    /** true when countryShort is in confirmed low-ML-population list */
    val isLowPop: Boolean,
    /** -1 = not in sequence | 0 = step 1 | 1 = step 2 */
    val sequenceStep: Int = -1
)

// ─── DAO ──────────────────────────────────────────────────────────────────────

@Dao
interface ServerConfigDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(config: ServerConfig): Long

    @Query("SELECT * FROM servers ORDER BY countryLong ASC")
    fun getAllServers(): Flow<List<ServerConfig>>

    @Query("SELECT * FROM servers WHERE countryShort = :code ORDER BY speed DESC")
    suspend fun getServersByCountry(code: String): List<ServerConfig>

    /**
     * Returns exactly the 2 servers that make up the configured sequence,
     * ordered by sequenceStep (0 → step1, 1 → step2).
     */
    @Query("SELECT * FROM servers WHERE sequenceStep >= 0 ORDER BY sequenceStep ASC LIMIT 2")
    suspend fun getSequenceServers(): List<ServerConfig>

    @Query("UPDATE servers SET sequenceStep = :step WHERE id = :id")
    suspend fun updateSequenceStep(id: Int, step: Int)

    /** Clears ALL sequence assignments — call before saving a new sequence. */
    @Query("UPDATE servers SET sequenceStep = -1")
    suspend fun clearSequence()

    @Query("DELETE FROM servers")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM servers")
    suspend fun getServerCount(): Int
}
