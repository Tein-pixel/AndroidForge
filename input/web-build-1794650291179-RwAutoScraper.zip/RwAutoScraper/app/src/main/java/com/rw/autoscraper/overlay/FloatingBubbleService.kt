package com.rw.autoscraper.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.rw.autoscraper.scripts.RotationEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * FloatingBubbleService
 *
 * Displays a 72dp translucent circle on top of all windows.
 * The user MUST have already configured Step 1 and Step 2 in
 * the Sequence Builder before starting the bubble.
 *
 * Tap flow:
 *   Shows "▶ Step 1"  →  tap  →  connects Step 1 server, shows "▶ Step 2"
 *   Shows "▶ Step 2"  →  tap  →  connects Step 2 server, shows "▶ Step 1"
 *   (loops forever)
 *
 * Drag: smooth repositioning anywhere on screen.
 */
class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var bubbleView: TextView
    private lateinit var params: WindowManager.LayoutParams

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var currentStep = 0   // 0 → next tap will execute step 0, then flip to 1

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        showBubble()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        if (::bubbleView.isInitialized) {
            try { windowManager.removeView(bubbleView) } catch (_: Exception) {}
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Bubble construction ───────────────────────────────────────────────────

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val density = resources.displayMetrics.density
        val sizePx  = (72 * density).toInt()

        bubbleView = TextView(this).apply {
            text      = "▶ Step 1"
            textSize  = 11f
            setTextColor(Color.WHITE)
            gravity   = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(220, 20, 10, 50))
                setStroke(2, Color.argb(180, 124, 77, 255))
            }
        }

        params = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100; y = 300
        }

        var downX     = 0f; var downY     = 0f
        var startX    = 0;  var startY    = 0
        var isDragging = false

        bubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!isDragging && (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        windowManager.updateViewLayout(bubbleView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) executeTap()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubbleView, params)
    }

    // ── Tap execution ─────────────────────────────────────────────────────────

    private fun executeTap() {
        scope.launch {
            val engine = RotationEngine.getInstance(applicationContext)

            // Execute current step (nextStep() internally uses currentStep in engine,
            // which is independent — engine and service step counters both advance together)
            val server = withContext(Dispatchers.IO) { engine.nextStep() }

            // Flip display to show NEXT step (the one the NEXT tap will execute)
            currentStep = if (currentStep == 0) 1 else 0
            val nextLabel = "▶ Step ${if (currentStep == 0) 1 else 2}"
            bubbleView.text = nextLabel

            val country = server?.countryLong ?: "None configured"
            Toast.makeText(applicationContext, "Connected: $country", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "RW Bubble", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(ch)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RW Active")
            .setContentText("Tap bubble to switch server")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val NOTIF_ID   = 1337
        const val CHANNEL_ID = "rw_bubble"
    }
}
