package com.rw.autoscraper.tunnel

import android.content.Context
import android.content.Intent
import android.util.Log
import com.rw.autoscraper.database.ServerConfig
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File

private const val TAG = "TunnelManager"

class TunnelManager private constructor(private val context: Context) {

    private var backend: Backend?   = null
    private var activeTunnel: WgTunnel? = null

    // ── Lazy-init GoBackend (heavy — only create when first WG connection) ───
    private fun wgBackend(): Backend {
        return backend ?: GoBackend(context).also { backend = it }
    }

    // ── Public API ───────────────────────────────────────────────────────────

    suspend fun connect(server: ServerConfig) = withContext(Dispatchers.IO) {
        disconnect()
        when (server.proto.lowercase()) {
            "wireguard" -> connectWireGuard(server)
            else        -> connectOpenVpn(server)   // "openvpn", "udp", "tcp"
        }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        // 1. Tear down any active WireGuard tunnel
        activeTunnel?.let { tun ->
            try {
                wgBackend().setState(tun, Tunnel.State.DOWN, null)
                Log.d(TAG, "WireGuard tunnel down: ${tun.getName()}")
            } catch (e: Exception) {
                Log.w(TAG, "WG disconnect error: ${e.message}")
            }
        }
        activeTunnel = null

        // 2. Signal RwVpnService to stop (safe even if service isn't running)
        try {
            val intent = Intent(context, RwVpnService::class.java).apply {
                action = RwVpnService.ACTION_DISCONNECT
            }
            context.startService(intent)
        } catch (_: Exception) {}
    }

    // ── WireGuard via com.wireguard.android:tunnel GoBackend ─────────────────

    private fun connectWireGuard(server: ServerConfig) {
        try {
            val config = Config.parse(ByteArrayInputStream(server.configRaw.toByteArray()))
            val tunnel = WgTunnel("rw_${server.id}")
            activeTunnel = tunnel
            wgBackend().setState(tunnel, Tunnel.State.UP, config)
            Log.d(TAG, "WireGuard UP → ${server.ip}")
        } catch (e: Exception) {
            Log.e(TAG, "WireGuard connect failed: ${e.message}")
        }
    }

    // ── OpenVPN via RwVpnService ──────────────────────────────────────────────
    //   Writes .ovpn to cacheDir — does NOT shell out.

    private fun connectOpenVpn(server: ServerConfig) {
        try {
            val ovpnFile = File(context.cacheDir, "rw_active.ovpn")
            ovpnFile.writeText(server.configRaw)

            val intent = Intent(context, RwVpnService::class.java).apply {
                putExtra(RwVpnService.EXTRA_OVPN_PATH, ovpnFile.absolutePath)
                putExtra(RwVpnService.EXTRA_SERVER_IP, server.ip)
                putExtra(RwVpnService.EXTRA_SERVER_PORT, server.port)
                putExtra(RwVpnService.EXTRA_PROTO, server.proto)
            }
            context.startService(intent)
            Log.d(TAG, "OpenVPN service started → ${server.ip}:${server.port}")
        } catch (e: Exception) {
            Log.e(TAG, "OpenVPN connect failed: ${e.message}")
        }
    }

    // ── Singleton ─────────────────────────────────────────────────────────────

    companion object {
        @Volatile private var INSTANCE: TunnelManager? = null

        fun getInstance(context: Context): TunnelManager =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: TunnelManager(context.applicationContext).also { INSTANCE = it }
            }
    }
}

// ── Minimal Tunnel wrapper required by GoBackend ─────────────────────────────

class WgTunnel(private val name: String) : Tunnel {
    override fun getName(): String = name
    override fun onStateChange(newState: Tunnel.State) {
        Log.d("WgTunnel", "$name → $newState")
    }
}
