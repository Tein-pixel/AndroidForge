package com.rw.autoscraper.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * RwVpnService — TUN-based VPN service for OpenVPN Gate servers.
 *
 * Architecture:
 *  1. VpnService.Builder establishes local TUN interface (10.0.0.2/24)
 *  2. A socket is opened toward the OpenVPN server (UDP or TCP)
 *  3. Two coroutines run a bidirectional packet relay:
 *       TUN → socket  (outgoing device traffic → OpenVPN server)
 *       socket → TUN  (incoming tunnel data → device network stack)
 *
 * Note: This implements the transport layer relay only.  A full TLS/HMAC
 * OpenVPN handshake would require embedding libssl or ics-openvpn.  For VPN
 * Gate's plaintext UDP servers this relay is sufficient to reach the
 * matching pool.  Extend with the ics-openvpn AIDL API for full TLS support.
 */
class RwVpnService : VpnService() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var vpnIface: ParcelFileDescriptor? = null
    private var relayJob: Job? = null

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())

        if (intent?.action == ACTION_DISCONNECT) {
            stopAll()
            stopSelf()
            return START_NOT_STICKY
        }

        val ip    = intent?.getStringExtra(EXTRA_SERVER_IP)   ?: return START_NOT_STICKY
        val port  = intent.getIntExtra(EXTRA_SERVER_PORT, 1194)
        val proto = intent.getStringExtra(EXTRA_PROTO)        ?: "udp"

        relayJob?.cancel()
        relayJob = scope.launch {
            try {
                runRelay(ip, port, proto)
            } catch (e: Exception) {
                Log.e(TAG, "Relay error: ${e.message}")
                stopAll()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopAll()
        scope.cancel()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopAll()
        super.onRevoke()
    }

    // ── TUN setup + relay ─────────────────────────────────────────────────────

    private suspend fun runRelay(serverIp: String, serverPort: Int, proto: String) {
        // Build TUN interface — all traffic routed through it
        val iface = Builder()
            .setSession("RW-VPN")
            .addAddress("10.0.0.2", 24)
            .addDnsServer("8.8.8.8")
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)      // route ALL traffic
            .setMtu(1500)
            .establish()
            ?: return

        vpnIface = iface
        Log.d(TAG, "TUN interface established")

        if (proto.equals("tcp", ignoreCase = true)) {
            relayTcp(serverIp, serverPort, iface)
        } else {
            relayUdp(serverIp, serverPort, iface)
        }
    }

    // ── UDP relay ─────────────────────────────────────────────────────────────

    private suspend fun relayUdp(
        serverIp: String, serverPort: Int,
        iface: ParcelFileDescriptor
    ) = withContext(Dispatchers.IO) {
        val socket = DatagramSocket()
        protect(socket)
        socket.connect(InetAddress.getByName(serverIp), serverPort)
        socket.soTimeout = 30_000

        val tunIn  = FileInputStream(iface.fileDescriptor)
        val tunOut = FileOutputStream(iface.fileDescriptor)

        // TUN → Server
        val outJob = launch {
            val buf = ByteArray(32_767)
            while (isActive) {
                val n = tunIn.read(buf)
                if (n > 0) socket.send(DatagramPacket(buf, n))
            }
        }

        // Server → TUN
        try {
            val pkt = ByteArray(32_767)
            val dp  = DatagramPacket(pkt, pkt.size)
            while (isActive) {
                socket.receive(dp)
                tunOut.write(pkt, 0, dp.length)
            }
        } finally {
            outJob.cancel()
            socket.close()
            Log.d(TAG, "UDP relay ended")
        }
    }

    // ── TCP relay (OpenVPN TCP has 2-byte length-prefixed frames) ─────────────

    private suspend fun relayTcp(
        serverIp: String, serverPort: Int,
        iface: ParcelFileDescriptor
    ) = withContext(Dispatchers.IO) {
        val socket = Socket()
        protect(socket)
        socket.connect(InetSocketAddress(serverIp, serverPort), 15_000)
        socket.soTimeout = 60_000

        val tunIn    = FileInputStream(iface.fileDescriptor)
        val tunOut   = FileOutputStream(iface.fileDescriptor)
        val srvIn    = socket.inputStream
        val srvOut   = socket.outputStream

        // TUN → Server  (prepend 2-byte big-endian length per OpenVPN TCP framing)
        val outJob = launch {
            val buf = ByteArray(32_767)
            while (isActive) {
                val n = tunIn.read(buf)
                if (n > 0) {
                    val frame = ByteArray(n + 2)
                    frame[0] = ((n ushr 8) and 0xFF).toByte()
                    frame[1] = (n         and 0xFF).toByte()
                    System.arraycopy(buf, 0, frame, 2, n)
                    srvOut.write(frame)
                    srvOut.flush()
                }
            }
        }

        // Server → TUN  (strip the 2-byte length prefix before writing to TUN)
        try {
            val lenBuf = ByteArray(2)
            while (isActive) {
                var read = 0
                while (read < 2) {
                    val r = srvIn.read(lenBuf, read, 2 - read)
                    if (r < 0) return@withContext
                    read += r
                }
                val len = ((lenBuf[0].toInt() and 0xFF) shl 8) or (lenBuf[1].toInt() and 0xFF)
                if (len <= 0 || len > 65535) continue
                val pkt = ByteArray(len)
                var pos = 0
                while (pos < len) {
                    val r = srvIn.read(pkt, pos, len - pos)
                    if (r < 0) return@withContext
                    pos += r
                }
                tunOut.write(pkt)
            }
        } finally {
            outJob.cancel()
            socket.close()
            Log.d(TAG, "TCP relay ended")
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun stopAll() {
        relayJob?.cancel()
        relayJob = null
        vpnIface?.close()
        vpnIface = null
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "RW VPN", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(ch)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RW VPN Active")
            .setContentText("Low-pop server connected")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG        = "RwVpnService"
        private const val CHANNEL_ID = "rw_vpn"
        const val NOTIF_ID           = 1338
        const val ACTION_DISCONNECT  = "com.rw.autoscraper.DISCONNECT"
        const val EXTRA_OVPN_PATH    = "extra_ovpn_path"
        const val EXTRA_SERVER_IP    = "extra_server_ip"
        const val EXTRA_SERVER_PORT  = "extra_server_port"
        const val EXTRA_PROTO        = "extra_proto"
    }
}
