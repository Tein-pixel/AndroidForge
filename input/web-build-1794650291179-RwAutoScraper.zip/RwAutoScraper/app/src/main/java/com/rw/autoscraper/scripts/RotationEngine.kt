package com.rw.autoscraper.scripts

import android.content.Context
import com.rw.autoscraper.database.AppDatabase
import com.rw.autoscraper.database.ServerConfig
import com.rw.autoscraper.tunnel.TunnelManager
import kotlinx.coroutines.delay

/**
 * RotationEngine — drives the 2-step pre-configured server switcher.
 *
 * Rules:
 *  - sequence MUST have exactly 2 entries (step 0 and step 1)
 *  - Bubble tap → executeTap → nextStep() → disconnect current → connect next
 *  - Loops forever: 0 → 1 → 0 → 1 …
 *  - Load sequence from DB via loadSequence() after saving in MainViewModel
 */
class RotationEngine private constructor(private val context: Context) {

    private val db  = AppDatabase.getInstance(context)
    private val dao = db.serverConfigDao()

    private var sequence: List<ServerConfig> = emptyList()
    private var currentIndex = 0

    // ── Sequence management ───────────────────────────────────────────────────

    suspend fun loadSequence() {
        sequence = dao.getSequenceServers()
    }

    fun isReady(): Boolean = sequence.size == 2

    fun getCurrentStepLabel(): String {
        if (sequence.isEmpty()) return "Not configured"
        val idx = currentIndex % 2
        return "Step ${idx + 1}: ${sequence[idx].countryLong}"
    }

    // ── Step execution ────────────────────────────────────────────────────────

    /**
     * Disconnect the current tunnel, connect to the next step server.
     * Returns the server we just connected to, or null if sequence is empty.
     */
    suspend fun nextStep(): ServerConfig? {
        if (sequence.isEmpty()) loadSequence()
        if (sequence.size < 2) return null

        val target = sequence[currentIndex % 2]

        // Disconnect whatever is active
        TunnelManager.getInstance(context).disconnect()
        delay(1_200)   // small pause — lets the OS finish tearing down the old tunnel

        // Connect to the target step server
        TunnelManager.getInstance(context).connect(target)

        currentIndex++
        return target
    }

    // ── Singleton ─────────────────────────────────────────────────────────────

    companion object {
        @Volatile private var INSTANCE: RotationEngine? = null

        fun getInstance(context: Context): RotationEngine =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: RotationEngine(context.applicationContext).also { INSTANCE = it }
            }
    }
}
