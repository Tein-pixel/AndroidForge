package com.manhwa.aggregator

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/** Direct JSON integration for MangaDex. Android HTTP requests do not require a CORS proxy. */
internal object MangaDexApiSource {
    private const val API_HOST = "api.mangadex.org"
    private const val DEVELOPMENT_API_HOST = "api.mangadex.dev"

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .callTimeout(24, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // Keep a secondary-host attempt bounded so a dead primary route does not
    // make the initial catalog wait another full production timeout window.
    private val fallbackClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(12, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val tagMutex = Mutex()

    @Volatile
    private var tagIdsByName: Map<String, String>? = null

    internal fun apiUrl(vararg pathSegments: String): HttpUrl.Builder {
        val builder = HttpUrl.Builder().scheme("https").host(API_HOST)
        pathSegments.forEach { segment -> builder.addPathSegment(segment) }
        return builder
    }

    /**
     * Returns the newest safe titles, or title-search results when query is supplied.
     * By default, prefer titles with Indonesian chapter availability; the caller
     * may broaden title discovery when that narrower result set is empty.
     * Every request remains restricted to the Safe content rating.
     */
    suspend fun fetchLatest(
        query: String = "",
        genre: String = "",
        requireIndonesianAvailability: Boolean = true
    ): List<Manhwa> {
        val builder = apiUrl("manga")
            .addQueryParameter("limit", "30")
            .addQueryParameter("includes[]", "cover_art")
            .addQueryParameter("contentRating[]", "safe")

        if (requireIndonesianAvailability) {
            builder.addQueryParameter("availableTranslatedLanguage[]", "id")
        }

        if (query.isNotBlank()) {
            builder.addQueryParameter("title", query.trim())
                .addQueryParameter("order[relevance]", "desc")
        } else {
            builder.addQueryParameter("order[latestUploadedChapter]", "desc")
        }

        if (genre.isNotBlank() && !genre.equals("Semua", ignoreCase = true)) {
            val tagId = resolveTagId(genre)
                ?: throw IllegalArgumentException("Genre $genre belum tersedia di katalog.")
            builder.addQueryParameter("includedTags[]", tagId)
        }

        val response = getJson(builder.build())
        val data = response.optJSONArray("data") ?: return emptyList()
        val results = ArrayList<Manhwa>(data.length())

        for (index in 0 until data.length()) {
            val manga = data.optJSONObject(index) ?: continue
            val id = manga.optString("id").takeIf { it.isNotBlank() } ?: continue
            val attributes = manga.optJSONObject("attributes") ?: continue
            val title = preferredLocalizedValue(attributes.optJSONObject("title"))
            if (title.isBlank()) continue

            var coverFile = ""
            val relationships = manga.optJSONArray("relationships")
            if (relationships != null) {
                for (relIndex in 0 until relationships.length()) {
                    val relation = relationships.optJSONObject(relIndex) ?: continue
                    if (relation.optString("type") == "cover_art") {
                        coverFile = relation.optJSONObject("attributes")
                            ?.optString("fileName")
                            .orEmpty()
                        if (coverFile.isNotBlank()) break
                    }
                }
            }

            val coverUrl = if (coverFile.isNotBlank()) {
                "https://uploads.mangadex.org/covers/$id/$coverFile.256.jpg"
            } else {
                ""
            }

            val latestChapterId = attributes.optString("latestUploadedChapter")
            val hasLatestChapter = latestChapterId.isNotBlank() && latestChapterId != "null"

            results.add(
                Manhwa(
                    title = title,
                    link = "https://mangadex.org/title/$id",
                    imageUrl = coverUrl,
                    latestChapter = if (hasLatestChapter) "Update tersedia" else "Belum ada chapter",
                    source = "MangaDex"
                )
            )
        }

        return results
    }

    /** Load MangaDex tag names once per process, then resolve the requested chip locally. */
    private suspend fun resolveTagId(name: String): String? {
        val key = name.trim().lowercase()
        if (key.isBlank()) return null

        tagIdsByName?.let { cached -> return cached[key] }

        return tagMutex.withLock {
            tagIdsByName?.let { cached -> return@withLock cached[key] }

            val response = getJson(apiUrl("manga", "tag").build())
            val data = response.optJSONArray("data")
            val map = LinkedHashMap<String, String>()

            if (data != null) {
                for (index in 0 until data.length()) {
                    val tag = data.optJSONObject(index) ?: continue
                    val id = tag.optString("id").takeIf { it.isNotBlank() } ?: continue
                    val attributes = tag.optJSONObject("attributes") ?: continue
                    val localizedName = preferredLocalizedValue(attributes.optJSONObject("name"))
                    if (localizedName.isNotBlank()) {
                        map[localizedName.trim().lowercase()] = id
                    }
                }
            }

            tagIdsByName = map
            map[key]
        }
    }

    /**
     * Tries the production API first. The official public development host is
     * used only for network failures, HTTP 403, or HTTP 5xx. Other client
     * errors and rate limits are not retried against another host.
     */
    internal suspend fun getJson(url: HttpUrl): JSONObject {
        return try {
            executeJson(url)
        } catch (primaryError: Exception) {
            if (url.host != API_HOST || !isFallbackEligible(primaryError)) {
                throw primaryError
            }

            val fallbackUrl = url.newBuilder().host(DEVELOPMENT_API_HOST).build()
            try {
                executeJson(fallbackUrl, useFallbackClient = true)
            } catch (fallbackError: Exception) {
                throw IOException(
                    "MangaDex production dan development API tidak dapat dijangkau. " +
                        "Primary: ${primaryError.message ?: primaryError.javaClass.simpleName}; " +
                        "fallback: ${fallbackError.message ?: fallbackError.javaClass.simpleName}",
                    fallbackError
                )
            }
        }
    }

    private fun isFallbackEligible(error: Exception): Boolean = when (error) {
        is MangaDexHttpException -> error.statusCode == 403 || error.statusCode in 500..599
        is IOException -> true
        else -> false
    }

    private class MangaDexHttpException(val statusCode: Int) :
        Exception("MangaDex HTTP $statusCode")

    private suspend fun executeJson(
        url: HttpUrl,
        useFallbackClient: Boolean = false
    ): JSONObject = suspendCancellableCoroutine { continuation ->
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "ManhwaHub-Android/2.1.0 (Android)")
                .header("Accept", "application/json")
                .build()
            val call = (if (useFallbackClient) fallbackClient else client).newCall(request)
            continuation.invokeOnCancellation { call.cancel() }

            call.enqueue(object : Callback {
                override fun onFailure(call: Call, error: IOException) {
                    if (continuation.isActive) continuation.resumeWithException(error)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        if (!continuation.isActive) return
                        if (!response.isSuccessful) {
                            continuation.resumeWithException(MangaDexHttpException(response.code))
                            return
                        }

                        try {
                            val body = response.body?.string().orEmpty()
                            if (body.isBlank()) {
                                throw IOException("Respons MangaDex kosong")
                            }
                            val json = JSONObject(body)
                            if (json.optString("result") == "error") {
                                continuation.resumeWithException(
                                    IllegalStateException("MangaDex API mengembalikan error")
                                )
                            } else {
                                continuation.resume(json)
                            }
                        } catch (error: Exception) {
                            if (continuation.isActive) continuation.resumeWithException(error)
                        }
                    }
                }
            })
        }

    internal fun preferredLocalizedValue(values: JSONObject?): String {
        if (values == null) return ""
        val preferred = listOf("id", "en", "ja-ro", "ja")
        for (key in preferred) {
            val value = values.optString(key).trim()
            if (value.isNotBlank() && value != "null") return value
        }
        val keys = values.keys()
        while (keys.hasNext()) {
            val value = values.optString(keys.next()).trim()
            if (value.isNotBlank() && value != "null") return value
        }
        return ""
    }
}
