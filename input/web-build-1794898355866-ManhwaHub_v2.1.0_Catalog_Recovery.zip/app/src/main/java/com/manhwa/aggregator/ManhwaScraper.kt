package com.manhwa.aggregator

import android.content.Context
import kotlinx.coroutines.CancellationException

/**
 * Catalog orchestration for the Android app.
 * Indonesian chapter availability is preferred, but the catalog can widen to
 * other safe MangaDex titles when that narrow filter returns no results.
 * Successful results are cached locally so a temporary API outage does not
 * immediately turn Home into a blank screen.
 */
class ManhwaScraper(context: Context) {
    private val cache = CatalogCache(context.applicationContext)

    data class CatalogResult(
        val items: List<Manhwa>,
        val fromCache: Boolean = false,
        val broadenedLanguageFilter: Boolean = false
    )

    suspend fun fetchLatestResult(
        query: String = "",
        genre: String = ""
    ): CatalogResult {
        try {
            val indonesianFirst = MangaDexApiSource.fetchLatest(
                query = query,
                genre = genre,
                requireIndonesianAvailability = true
            )

            if (indonesianFirst.isNotEmpty()) {
                cache.save(query, genre, indonesianFirst)
                return CatalogResult(indonesianFirst)
            }

            // The title itself can still be useful even if MangaDex has not
            // indexed an Indonesian translation for it yet. Reader remains ID-only.
            val broaderSafeCatalog = MangaDexApiSource.fetchLatest(
                query = query,
                genre = genre,
                requireIndonesianAvailability = false
            )
            if (broaderSafeCatalog.isNotEmpty()) {
                cache.save(query, genre, broaderSafeCatalog)
                return CatalogResult(
                    items = broaderSafeCatalog,
                    broadenedLanguageFilter = true
                )
            }

            val cached = cache.read(query, genre)
            return if (cached.isNotEmpty()) {
                CatalogResult(cached, fromCache = true)
            } else {
                CatalogResult(emptyList())
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            val cached = cache.read(query, genre)
            if (cached.isNotEmpty()) {
                return CatalogResult(cached, fromCache = true)
            }
            throw error
        }
    }

    /** Backward-compatible list API for any existing call sites. */
    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> =
        fetchLatestResult(query, genre).items
}
