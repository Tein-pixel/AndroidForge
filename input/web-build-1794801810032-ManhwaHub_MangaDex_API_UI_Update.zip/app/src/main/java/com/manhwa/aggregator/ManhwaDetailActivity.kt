package com.manhwa.aggregator

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.button.MaterialButton
import com.manhwa.aggregator.databinding.ActivityManhwaDetailBinding
import kotlinx.coroutines.launch

class ManhwaDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityManhwaDetailBinding
    private lateinit var item: Manhwa
    private val library by lazy { LibraryStore(this) }
    private var chapters: List<ManhwaPageRepository.Chapter> = emptyList()

    companion object {
        const val EXTRA_TITLE = "manhwa_title"
        const val EXTRA_LINK = "manhwa_link"
        const val EXTRA_IMAGE = "manhwa_image"
        const val EXTRA_CHAPTER = "manhwa_latest_chapter"
        const val EXTRA_SOURCE = "manhwa_source"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManhwaDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        item = ManhwaUrlResolver.resolveItem(Manhwa(
            intent.getStringExtra(EXTRA_TITLE).orEmpty(),
            intent.getStringExtra(EXTRA_LINK).orEmpty(),
            intent.getStringExtra(EXTRA_IMAGE).orEmpty(),
            intent.getStringExtra(EXTRA_CHAPTER).orEmpty(),
            intent.getStringExtra(EXTRA_SOURCE).orEmpty()
        ))
        library.addToHistory(item)
        bindItem()
        loadDetails()
    }

    private fun bindItem() {
        binding.btnBack.setOnClickListener { finish() }
        binding.imgCover.load(item.imageUrl, ManhwaImageLoader.get(this, item.link)) {
            crossfade(250)
            placeholder(R.drawable.cover_placeholder)
            error(R.drawable.cover_placeholder)
        }
        binding.tvTitle.text = item.title
        binding.tvSource.text = item.source
        binding.tvLatest.text = item.latestChapter.ifBlank { "Update terbaru" }
        updateFavoriteButton()
        updateReadingStatusButton()
        binding.btnFavorite.setOnClickListener {
            library.toggleFavorite(item)
            updateFavoriteButton()
        }
        binding.btnReadingStatus.setOnClickListener { showReadingStatusPicker() }
        binding.btnOpenSource.setOnClickListener { openSource(item.link, item.title) }
        binding.btnStartReading.setOnClickListener {
            val saved = library.getProgress(item.link)
            val chapter = saved?.let { ManhwaPageRepository.Chapter(it.chapterTitle, it.chapterUrl) }
                ?: chapters.firstOrNull()
            if (chapter != null) openReader(chapter) else openSource(item.link, item.title)
        }
        binding.rvChapters.layoutManager = LinearLayoutManager(this)
        binding.rvChapters.isNestedScrollingEnabled = false
    }

    private fun updateFavoriteButton() {
        val saved = library.isFavorite(item)
        binding.btnFavorite.text = if (saved) "Tersimpan ✓" else "Simpan"
        binding.btnFavorite.icon = getDrawable(if (saved) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)
    }

    private fun updateReadingStatusButton() {
        val status = library.readingStatus(item)
        binding.btnReadingStatus.text = status?.let { "Daftar bacaan  ·  $it" } ?: "Tambah ke daftar bacaan"
        val progress = library.getProgress(item.link)
        binding.btnStartReading.text = if (progress != null) "Lanjutkan membaca" else "Mulai baca"
    }

    private fun showReadingStatusPicker() {
        val options = arrayOf(
            "Sedang dibaca", "Rencana baca", "Selesai", "Ditunda", "Dihentikan", "Hapus dari daftar"
        )
        AlertDialog.Builder(this)
            .setTitle("Status bacaan")
            .setItems(options) { _, which ->
                val selected = if (which == options.lastIndex) null else options[which]
                library.setReadingStatus(item, selected)
                updateReadingStatusButton()
                Toast.makeText(this, if (selected == null) "Dihapus dari daftar bacaan" else "Status: $selected", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun loadDetails() {
        binding.progressDetails.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val details = ManhwaPageRepository.fetchDetails(item.link)
                binding.tvDescription.text = details.description.ifBlank {
                    "Deskripsi belum tersedia dari sumber ini. Kamu tetap bisa membuka halaman sumber untuk melihat informasi lengkap."
                }
                binding.tvStatus.text = details.status.ifBlank { "Status tidak tersedia" }
                binding.tvGenres.text = details.genres.joinToString("  ·  ").ifBlank { "Genre tidak tersedia" }
                chapters = details.chapters
                updateReadingStatusButton()
                binding.tvChapterCount.text = if (chapters.isEmpty()) "Chapter belum terdeteksi" else "${chapters.size} chapter"
                binding.rvChapters.adapter = ChapterAdapter(chapters) { openReader(it) }
                binding.tvNoChapters.visibility = if (chapters.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                binding.tvDescription.text = "Detail belum dapat dimuat. Koneksi atau proxy sumber mungkin sedang bermasalah."
                binding.tvChapterCount.text = "Daftar chapter tidak tersedia"
                binding.tvNoChapters.visibility = View.VISIBLE
            } finally {
                binding.progressDetails.visibility = View.GONE
            }
        }
    }

    private fun openReader(chapter: ManhwaPageRepository.Chapter) {
        startActivity(Intent(this, ReaderActivity::class.java).apply {
            putExtra(ReaderActivity.EXTRA_CHAPTER_URL, chapter.url)
            putExtra(ReaderActivity.EXTRA_CHAPTER_TITLE, chapter.title)
            putExtra(ReaderActivity.EXTRA_MANGA_TITLE, item.title)
            putExtra(ReaderActivity.EXTRA_ITEM_LINK, item.link)
            putExtra(ReaderActivity.EXTRA_ITEM_IMAGE, item.imageUrl)
            putExtra(ReaderActivity.EXTRA_ITEM_SOURCE, item.source)
        })
    }

    private fun openSource(url: String, title: String) {
        startActivity(Intent(this, SourceWebActivity::class.java).apply {
            putExtra(SourceWebActivity.EXTRA_URL, url)
            putExtra(SourceWebActivity.EXTRA_TITLE, title)
        })
    }
}

private class ChapterAdapter(
    private val chapters: List<ManhwaPageRepository.Chapter>,
    private val onClick: (ManhwaPageRepository.Chapter) -> Unit
) : RecyclerView.Adapter<ChapterAdapter.ChapterHolder>() {
    class ChapterHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(android.R.id.text1)
        val subtitle: TextView = view.findViewById(android.R.id.text2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChapterHolder {
        val context = parent.context
        val row = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false)
        row.setPadding((16 * context.resources.displayMetrics.density).toInt(),
            (13 * context.resources.displayMetrics.density).toInt(),
            (16 * context.resources.displayMetrics.density).toInt(),
            (13 * context.resources.displayMetrics.density).toInt())
        row.background = context.getDrawable(R.drawable.chapter_row_bg)
        return ChapterHolder(row)
    }

    override fun onBindViewHolder(holder: ChapterHolder, position: Int) {
        val chapter = chapters[position]
        holder.title.text = chapter.title
        holder.title.setTextColor(android.graphics.Color.WHITE)
        holder.title.textSize = 13f
        holder.title.setTypeface(holder.title.typeface, android.graphics.Typeface.BOLD)
        holder.subtitle.text = "Baca chapter  ›"
        holder.subtitle.setTextColor(android.graphics.Color.rgb(126, 151, 170))
        holder.subtitle.textSize = 10f
        holder.itemView.setOnClickListener { onClick(chapter) }
    }

    override fun getItemCount(): Int = chapters.size
}
