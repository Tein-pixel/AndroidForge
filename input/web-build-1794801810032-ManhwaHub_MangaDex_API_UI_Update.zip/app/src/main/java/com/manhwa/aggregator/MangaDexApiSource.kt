package com.manhwa.aggregator

import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Direct JSON integration for MangaDex. Native Android HTTP requests do not need a CORS proxy.
 * The default catalog is deliberately limited to MangaDex's safe content rating.
 */
internal object MangaDexApiSource {
    private const val API_HOST = "api.mangadex.org"
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .callTimeout(24, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    internal fun apiUrl(vararg pathSegments: String): HttpUrl.Builder {
        val builder = HttpUrl.Builder().scheme("https").host(API_HOST)
        pathSegments.forEach { segment -> builder.addPathSegment(segment) }
        return builder
    }

    suspend fun fetchLatest(query: String = ""): List<Manhwa> {
        val builder = apiUrl("manga")
            .addQueryParameter("limit", "30")
            .addQueryParameter("includes[]", "cover_art")
            .addQueryParameter("contentRating[]", "safe")
            .addQueryParameter("availableTranslatedLanguage[]", "id")
            .addQueryParameter("availableTranslatedLanguage[]", "en")

        if (query.isNotBlank()) {
            builder.addQueryParameter("title", query.trim())
                .addQueryParameter("order[relevance]", "desc")
        } else {
            builder.addQueryParameter("order[latestUploadedChapter]", "desc")
        }

        val response = getJson(builder.build())
        val data = response.optJSONArray("data") ?: return emptyList()
        val results = ArrayList<Manhwa>(data.length())
        for (index in 0 until data.length()) {
            val manga = data.optJSONObject(index) ?: continue
            val id = manga.optString("id").takeIf { it.isNotBlank() } ?: continue
            val attributes = manga.optJSONObject("attributes") ?: continue
            val title = preferredLocalizedValue(attributes.optJSONObject("title"))
            if (title.isBlank()) continue

            var coverFile = ""
            val relationships = manga.optJSONArray("relationships")
            if (relationships != null) {
                for (relIndex in 0 until relationships.length()) {
                    val relation = relationships.optJSONObject(relIndex) ?: continue
                    if (relation.optString("type") == "cover_art") {
                        coverFile = relation.optJSONObject("attributes")?.optString("fileName").orEmpty()
                        if (coverFile.isNotBlank()) break
                    }
                }
            }
            val coverUrl = if (coverFile.isNotBlank()) {
                "https://uploads.mangadex.org/covers/$id/$coverFile.256.jpg"
            } else ""
            val latestId = attributes.optString("latestUploadedChapter")
            val hasLatest = latestId.isNotBlank() && latestId != "null"
            results.add(
                Manhwa(
                    title = title,
                    link = "https://mangadex.org/title/$id",
                    imageUrl = coverUrl,
                    latestChapter = if (hasLatest) "Update tersedia" else "Chapter belum tersedia",
                    source = "MangaDex"
                )
            )
        }
        return results
    }

    internal suspend fun getJson(url: HttpUrl): JSONObject = suspendCancellableCoroutine { continuation ->
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "ManhwaHub-Android/1.1")
            .header("Accept", "application/json")
            .build()
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) {
                if (continuation.isActive) continuation.resumeWithException(error)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!continuation.isActive) return
                    if (!response.isSuccessful) {
                        continuation.resumeWithException(IllegalStateException("MangaDex HTTP ${response.code}"))
                        return
                    }
                    try {
                        val body = response.body?.string().orEmpty()
                        val json = JSONObject(body)
                        if (json.optString("result") == "error") {
                            continuation.resumeWithException(IllegalStateException("MangaDex API mengembalikan error"))
                        } else {
                            continuation.resume(json)
                        }
                    } catch (error: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(error)
                    }
                }
            }
        })
    }

    internal fun preferredLocalizedValue(values: JSONObject?): String {
        if (values == null) return ""
        val preferred = listOf("id", "en", "ja-ro", "ja")
        for (key in preferred) {
            val value = values.optString(key).trim()
            if (value.isNotBlank() && value != "null") return value
        }
        val keys = values.keys()
        while (keys.hasNext()) {
            val value = values.optString(keys.next()).trim()
            if (value.isNotBlank() && value != "null") return value
        }
        return ""
    }
}
