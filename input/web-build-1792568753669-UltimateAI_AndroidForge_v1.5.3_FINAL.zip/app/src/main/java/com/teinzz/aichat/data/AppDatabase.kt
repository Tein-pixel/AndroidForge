package com.teinzz.aichat.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC") fun observeConversations(): Flow<List<ConversationEntity>>
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC LIMIT 1") suspend fun latest(): ConversationEntity?
    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1") suspend fun conversation(id: Long): ConversationEntity?
    @Query("SELECT * FROM messages WHERE conversationId = :id ORDER BY id ASC") suspend fun messages(id: Long): List<MessageEntity>
    @Query("SELECT * FROM messages WHERE conversationId = :id ORDER BY id ASC") fun observeMessages(id: Long): Flow<List<MessageEntity>>
    @Insert suspend fun insertConversation(item: ConversationEntity): Long
    @Insert suspend fun insertMessage(item: MessageEntity): Long
    @Query("UPDATE conversations SET title = :title, updatedAt = :now WHERE id = :id") suspend fun rename(id: Long, title: String, now: Long = System.currentTimeMillis())
    @Query("UPDATE conversations SET modelId = :model, updatedAt = :now WHERE id = :id") suspend fun updateModel(id: Long, model: String, now: Long = System.currentTimeMillis())
    @Query("UPDATE conversations SET updatedAt = :now WHERE id = :id") suspend fun touch(id: Long, now: Long = System.currentTimeMillis())
    @Query("UPDATE messages SET content = :content WHERE id = :id") suspend fun updateMessage(id: Long, content: String)
    @Query("DELETE FROM messages WHERE id = :id") suspend fun deleteMessage(id: Long)
    @Query("DELETE FROM conversations WHERE id = :id") suspend fun deleteConversation(id: Long)
    @Query("DELETE FROM messages WHERE conversationId = :id") suspend fun deleteMessages(id: Long)
}

@Database(entities = [ConversationEntity::class, MessageEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversations(): ConversationDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "chat-ai.db").build().also { instance = it }
        }
    }
}
