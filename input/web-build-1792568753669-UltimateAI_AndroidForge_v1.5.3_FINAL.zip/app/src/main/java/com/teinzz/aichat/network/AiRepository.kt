package com.teinzz.aichat.network

import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.teinzz.aichat.ThemeManager
import com.teinzz.aichat.data.AiModel
import com.teinzz.aichat.data.ChatMode
import com.teinzz.aichat.data.MessageEntity
import com.teinzz.aichat.data.Provider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.ResponseBody
import java.net.SocketTimeoutException
import retrofit2.Response
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class ProviderException(val httpCode: Int, message: String) : Exception(message)

/**
 * Provider-specific request adapter. THINK_HARDER adds native reasoning controls where supported.
 * DEEP_RESEARCH enables actual provider-hosted web tools; it is never simulated with prompt text alone.
 */
class AiRepository(private val keys: ThemeManager) {
    private val api = AiApi.create()
    // Gemini 4 Argon can spend several minutes reasoning before the first SSE chunk.
    private val longGenerationApi = AiApi.create(readTimeoutSeconds = 900)
    private val probeApi = AiApi.createProbe()
    private val discovery = ModelDiscovery(keys)
    private val gson = Gson()

    suspend fun discoverModels(): ModelDiscoveryResult = discovery.discover()

    fun stream(
        model: AiModel,
        conversation: List<MessageEntity>,
        userText: String,
        imagePath: String?,
        mode: ChatMode = ChatMode.NORMAL
    ): Flow<String> = flow {
        val key = keys.getApiKey(model.provider)
        if (!model.provider.active) throw ProviderException(0, "Provider ${model.provider.title} sudah dipensiunkan; pilih provider aktif dari katalog.")
        if (key.isBlank() && model.provider.requiresApiKey) throw ProviderException(0, "API key ${model.provider.apiKeyLabel} belum diatur. Buka Settings untuk memasukkannya.")
        val accountId = keys.getAuxiliary(model.provider)
        if (model.provider.auxiliaryLabel.isNotBlank() && accountId.isBlank()) throw ProviderException(0, "${model.provider.auxiliaryLabel} belum diatur. Buka Settings.")
        if (imagePath != null && !model.vision) throw ProviderException(0, "Model ini tidak mendukung gambar pada konfigurasi aplikasi. Pilih model berlabel GAMBAR, misalnya Gemini atau Nemotron 3.5 Super VL.")
        if (mode == ChatMode.DEEP_RESEARCH && model.provider !in setOf(Provider.GEMINI, Provider.OPENROUTER)) {
            throw ProviderException(0, "Riset Mendalam dengan pencarian web nyata saat ini hanya didukung oleh adapter Google Gemini dan OpenRouter. Pilih salah satunya; mode ini tidak akan disimulasikan dengan prompt saja.")
        }

        val payload = if (model.provider == Provider.GEMINI) {
            geminiPayload(model, conversation, userText, imagePath, mode)
        } else {
            openAiPayload(model, conversation, userText, imagePath, mode)
        }
        val url = if (model.provider == Provider.GEMINI) GeminiService.streamUrl(model.id) else model.provider.resolvedChatUrl(accountId)
        val requestBody = gson.toJson(payload).toRequestBody("application/json; charset=utf-8".toMediaType())
        val streamingApi = if (model.provider == Provider.GEMINI && model.id == "gemini-4-argon") longGenerationApi else api
        val authorization = if (model.provider == Provider.GEMINI || key.isBlank()) null else "Bearer $key"
        val googleApiKey = if (model.provider == Provider.GEMINI) key else null
        val referer = if (model.provider == Provider.OPENROUTER) OpenRouterService.REFERER else null
        val appTitle = if (model.provider == Provider.OPENROUTER) OpenRouterService.APP_TITLE else null
        var response = streamWithInitialTimeoutRetry(streamingApi, url, authorization, googleApiKey, referer, appTitle, requestBody)
        var attemptedFreeRouterFallback = false
        // Free provider routes can be temporarily overloaded. Retry the same model once, with a bounded delay.
        if (model.provider == Provider.OPENROUTER && response.code() in setOf(502, 503, 504)) {
            response.errorBody()?.close()
            response.body()?.close()
            delay(650)
            currentCoroutineContext().ensureActive()
            response = streamingApi.stream(
                url, authorization, null, referer, appTitle, requestBody
            )
            // If a selected :free text route still fails, transparently try the official free router once.
            // Do not silently change the model for image input or non-normal modes where behavior may differ.
            if (response.code() in setOf(502, 503, 504) && model.id.endsWith(":free") &&
                model.id != "openrouter/free" && imagePath == null && mode == ChatMode.NORMAL) {
                response.errorBody()?.close()
                response.body()?.close()
                delay(350)
                currentCoroutineContext().ensureActive()
                val fallbackBody = payload.deepCopy().apply { addProperty("model", "openrouter/free") }
                    .let { gson.toJson(it).toRequestBody("application/json; charset=utf-8".toMediaType()) }
                response = streamingApi.stream(
                    url, authorization, null, referer, appTitle, fallbackBody
                )
                attemptedFreeRouterFallback = true
            }
        }
        val body = response.body()
        if (!response.isSuccessful || body == null) {
            val details = runCatching { response.errorBody()?.string()?.take(800) }.getOrNull().orEmpty().let(::redactProviderDetails)
            val friendly = when (response.code()) {
                401, 403 -> "API key salah atau akses ke model ditolak. Periksa key, izin, dan saldo provider."
                429 -> "Batas penggunaan tercapai (429). Tunggu, periksa kuota, atau pilih provider lain."
                400 -> when (mode) {
                    ChatMode.DEEP_RESEARCH -> "Provider menolak alat Riset Mendalam pada model atau tier ini. Google Search grounding tidak tersedia pada Free Tier Gemini 3.6/3.8. Gunakan akun Gemini API dengan grounding berbayar aktif, atau model OpenRouter yang mendukung web tools; periksa billing sebelum melanjutkan. Detail: ${details.take(220)}"
                    ChatMode.THINK_HARDER -> "Provider/model menolak parameter reasoning tinggi. Coba model reasoning lain atau mode Normal. Detail: ${details.take(220)}"
                    else -> "Permintaan tidak diterima oleh provider. Periksa model ID dan dukungan parameternya. Detail: ${details.take(220)}"
                }
                502, 503, 504 -> if (model.provider == Provider.OPENROUTER) {
                    if (attemptedFreeRouterFallback) {
                        "Rute model gratis pilihan dan OpenRouter Free Router sama-sama gagal (HTTP ${response.code()}). Kemungkinan gangguan sementara provider. Coba lagi nanti. Detail: ${details.take(180)}"
                    } else {
                        "Rute/provider model sedang bermasalah (HTTP ${response.code()}). Aplikasi sudah mencoba ulang sekali. Ini biasanya gangguan sementara server, bukan bukti API key salah. Coba lagi atau pilih model GRATIS lain. Detail: ${details.take(220)}"
                    }
                } else {
                    "Server provider sedang mengalami gangguan (HTTP ${response.code()}). Coba lagi sebentar. ${details.take(220)}"
                }
                else -> "Provider mengembalikan HTTP ${response.code()}. ${details.take(350)}"
            }
            throw ProviderException(response.code(), friendly)
        }

        val sources = linkedMapOf<String, String>()
        var fallbackNoteEmitted = false
        val closeOnCancel = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) body.close()
        }
        try {
            body.charStream().buffered().use { reader ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.removePrefix("data:").trim()
                    if (data.isBlank() || data == "[DONE]") continue
                    val root = runCatching { JsonParser.parseString(data).asJsonObject }.getOrNull() ?: continue
                    val streamError = root.get("error")?.takeIf { it.isJsonObject }?.asJsonObject
                    if (streamError != null) {
                        val message = redactProviderDetails(streamError.get("message")?.takeIf { it.isJsonPrimitive }?.asString.orEmpty()).take(180)
                        val details = redactProviderDetails(streamError.toString()).take(260)
                        throw ProviderException(0, "Provider gagal saat streaming${if (message.isBlank()) "" else ": ${message.take(180)}"}. $details")
                    }
                    collectSources(root, model.provider, sources)
                    val chunk = runCatching { responseText(root, model.provider) }.getOrDefault("")
                    if (chunk.isNotEmpty()) {
                        if (attemptedFreeRouterFallback && !fallbackNoteEmitted) {
                            emit("**Catatan:** rute model gratis pilihan sedang gagal, jadi jawaban ini memakai OpenRouter Free Router.\n\n")
                            fallbackNoteEmitted = true
                        }
                        emit(chunk)
                    }
                }
            }
        } finally {
            closeOnCancel?.dispose()
            body.close()
        }
        // Gemini returns grounding metadata separately from the streamed answer. Preserve those citations.
        // OpenRouter may also return structured URL annotations; model-provided citation links are retained too.
        if (sources.isNotEmpty()) {
            val sourceBlock = sources.entries.take(10).joinToString("\n") { (url, title) ->
                "- [${title.replace("[", "(").replace("]", ")").take(140)}]($url)"
            }
            emit("\n\n**Sumber web**\n$sourceBlock")
        }
    }.flowOn(Dispatchers.IO)

    /** Sends one tiny real completion so the user can verify the selected model route, not just the key. */
    suspend fun testResponse(model: AiModel): String {
        val output = StringBuilder()
        stream(model, emptyList(), "Reply with exactly OK.", null, ChatMode.NORMAL).collect { output.append(it) }
        val result = output.toString().trim()
        if (result.isBlank()) throw ProviderException(0, "Model tidak mengembalikan teks.")
        return result.take(100)
    }

    suspend fun test(model: AiModel): String {
        val provider = model.provider
        if (!provider.active) throw ProviderException(0, "Provider ${provider.title} sudah dipensiunkan.")
        val key = keys.getApiKey(provider)
        val accountId = keys.getAuxiliary(provider)
        if (key.isBlank() && provider.requiresApiKey) throw ProviderException(0, "API key belum diatur.")
        if (provider.auxiliaryLabel.isNotBlank() && accountId.isBlank()) throw ProviderException(0, "${provider.auxiliaryLabel} belum diatur.")
        val url = if (provider == Provider.GEMINI) GeminiService.KEY_CHECK_URL else provider.resolvedModelsUrl(accountId)
        val response = probeApi.probe(
            url,
            if (provider == Provider.GEMINI || key.isBlank()) null else "Bearer $key",
            if (provider == Provider.GEMINI) key else null,
            if (provider == Provider.OPENROUTER) OpenRouterService.REFERER else null,
            if (provider == Provider.OPENROUTER) OpenRouterService.APP_TITLE else null
        )
        if (!response.isSuccessful) {
            val message = when (response.code()) {
                401, 403 -> "API key salah atau akses ditolak (HTTP ${response.code()})."
                402 -> "Provider menyatakan saldo/kredit tidak cukup (HTTP 402). Model ini tidak gratis untuk akun saat ini."
                429 -> "Rate limit provider tercapai (HTTP 429)."
                else -> "Provider mengembalikan HTTP ${response.code()}."
            }
            response.errorBody()?.close()
            throw ProviderException(response.code(), message)
        }
        response.body()?.close()
        return "Koneksi katalog berhasil (HTTP ${response.code()}). Ini belum membuktikan model terpilih dapat generate atau gratis; gunakan Tes model terpilih untuk uji respons nyata."
    }

    private fun geminiPayload(model: AiModel, history: List<MessageEntity>, text: String, imagePath: String?, mode: ChatMode): JsonObject {
        val contents = JsonArray()
        history.filter { it.role == "user" || it.role == "assistant" }.takeLast(18).forEach { msg ->
            val content = JsonObject()
            content.addProperty("role", if (msg.role == "assistant") "model" else "user")
            val parts = JsonArray()
            parts.add(JsonObject().apply { addProperty("text", msg.content) })
            content.add("parts", parts)
            contents.add(content)
        }
        val currentContent = JsonObject().apply { addProperty("role", "user") }
        val parts = JsonArray()
        parts.add(JsonObject().apply { addProperty("text", text.ifBlank { "Tolong analisis gambar yang aku kirim." }) })
        imagePath?.let { path ->
            val part = imagePart(path) ?: throw ProviderException(0, "Gambar tidak dapat dibaca atau terlalu besar. Pilih ulang gambar agar dikompresi sebelum dikirim.")
            parts.add(part)
        }
        currentContent.add("parts", parts)
        contents.add(currentContent)

        val generationConfig = JsonObject().apply {
            // A smaller normal-mode output budget and LOW thinking level reduce time-to-first-token
            // on Gemini 3.x Flash. Users can still enable higher reasoning from the attachment menu.
            addProperty("maxOutputTokens", when (mode) { ChatMode.NORMAL -> 2048; ChatMode.THINK_HARDER -> 4096; ChatMode.DEEP_RESEARCH -> 8192 })
            if (model.id.startsWith("gemini-3.")) {
                add("thinkingConfig", JsonObject().apply {
                    addProperty("thinkingLevel", if (mode == ChatMode.NORMAL) "LOW" else "HIGH")
                })
            } else if (mode == ChatMode.THINK_HARDER || mode == ChatMode.DEEP_RESEARCH) {
                add("thinkingConfig", JsonObject().apply { addProperty("thinkingLevel", "HIGH") })
            }
        }
        val request = JsonObject().apply {
            add("contents", contents)
            add("generationConfig", generationConfig)
            add("systemInstruction", JsonObject().apply {
                add("parts", JsonArray().apply {
                    add(JsonObject().apply { addProperty("text", systemInstructions(mode)) })
                })
            })
        }
        if (mode == ChatMode.DEEP_RESEARCH) {
            request.add("tools", JsonArray().apply {
                add(JsonObject().apply { add("google_search", JsonObject()) })
            })
        }
        return request
    }

    private fun openAiPayload(model: AiModel, history: List<MessageEntity>, text: String, imagePath: String?, mode: ChatMode): JsonObject {
        val messages = JsonArray()
        messages.add(JsonObject().apply {
            addProperty("role", "system")
            addProperty("content", systemInstructions(mode))
        })
        history.filter { it.role == "user" || it.role == "assistant" }.takeLast(18).forEach { msg ->
            messages.add(JsonObject().apply { addProperty("role", msg.role); addProperty("content", msg.content) })
        }
        val user = JsonObject().apply { addProperty("role", "user") }
        if (imagePath != null) {
            val blocks = JsonArray()
            blocks.add(JsonObject().apply { addProperty("type", "text"); addProperty("text", text.ifBlank { "Please analyze the image I attached." }) })
            val dataUrl = imageDataUrl(imagePath)
                ?: throw ProviderException(0, "Gambar tidak bisa dibaca atau terlalu besar. Pilih ulang gambar agar dikompresi sebelum dikirim.")
            blocks.add(JsonObject().apply {
                addProperty("type", "image_url")
                add("image_url", JsonObject().apply { addProperty("url", dataUrl) })
            })
            user.add("content", blocks)
        } else {
            user.addProperty("content", text)
        }
        messages.add(user)

        val request = JsonObject().apply {
            addProperty("model", model.id)
            addProperty("stream", true)
            add("messages", messages)
        }
        // OpenRouter exposes each model's accepted parameters. Avoid sending legacy knobs to
        // models that explicitly reject them; static fallback entries use conservative defaults.
        val params = model.supportedParameters
        val hasParameterMetadata = model.provider == Provider.OPENROUTER && params.isNotEmpty()
        // Omit optional sampling parameters unless the live model metadata explicitly declares support.
        // This prevents a model-specific 400 caused by temperature/max-token aliases it rejects.
        if ("temperature" in params) request.addProperty("temperature", 0.7)
        val tokenParam = when {
            model.provider == Provider.GROQ || model.provider == Provider.CEREBRAS -> "max_completion_tokens"
            "max_completion_tokens" in params -> "max_completion_tokens"
            else -> "max_tokens"
        }
        if (!hasParameterMetadata || tokenParam in params || model.provider == Provider.GROQ || model.provider == Provider.CEREBRAS) {
            request.addProperty(tokenParam, if (mode == ChatMode.DEEP_RESEARCH) 8192 else 6144)
        }
        if (mode == ChatMode.THINK_HARDER || mode == ChatMode.DEEP_RESEARCH) {
            // OpenRouter exposes a standardized reasoning effort only when the selected route supports it.
            if (model.provider == Provider.OPENROUTER && "reasoning" in params) {
                request.add("reasoning", JsonObject().apply { addProperty("effort", "high"); addProperty("summary", "concise") })
            } else if (model.provider == Provider.COHERE || "reasoning_effort" in params) {
                // Cohere's compatibility API documents only `none` and `high`; other providers need model metadata.
                request.addProperty("reasoning_effort", "high")
            }
        }
        if (model.provider == Provider.OPENROUTER) {
            // Let OpenRouter fail over between healthy hosts for the selected model when available.
            request.add("provider", JsonObject().apply { addProperty("allow_fallbacks", true) })
        }
        if (mode == ChatMode.DEEP_RESEARCH && model.provider == Provider.OPENROUTER) {
            request.add("tools", JsonArray().apply {
                add(JsonObject().apply { addProperty("type", "openrouter:web_search") })
                add(JsonObject().apply { addProperty("type", "openrouter:web_fetch") })
            })
        }
        return request
    }

    /** Retry only if the request times out before an HTTP response exists; never replay a partially emitted answer. */
    private suspend fun streamWithInitialTimeoutRetry(
        client: AiApi,
        url: String,
        authorization: String?,
        googleApiKey: String?,
        referer: String?,
        title: String?,
        body: okhttp3.RequestBody
    ): Response<ResponseBody> {
        return try {
            client.stream(url, authorization, googleApiKey, referer, title, body)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (timeout: SocketTimeoutException) {
            delay(700)
            currentCoroutineContext().ensureActive()
            try {
                client.stream(url, authorization, googleApiKey, referer, title, body)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (secondTimeout: SocketTimeoutException) {
                throw ProviderException(0, "Provider tidak mulai merespons setelah dua percobaan. Periksa koneksi, kuota, atau pilih model/rute lain. (Timeout)")
            }
        }
    }

    private fun redactProviderDetails(raw: String): String {
        var safe = raw.replace(Regex("""(?i)(\"user_id\"\s*:\s*\")[^\"]*(\")""")) {
            "${it.groupValues[1]}[redacted]${it.groupValues[2]}"
        }
        safe = safe.replace(Regex("""(?i)(\"(?:api[_-]?key|authorization|token)\"\s*:\s*\")[^\"]*(\")""")) {
            "${it.groupValues[1]}[redacted]${it.groupValues[2]}"
        }
        return safe
    }

    private fun systemInstructions(mode: ChatMode): String {
        val base = "Kamu adalah asisten AI yang akurat, langsung, dan membantu. Gunakan bahasa pengguna. Jangan mengaku sebagai ChatGPT, Gemini, atau Claude. Jangan tampilkan rantai pemikiran privat; berikan ringkasan metode, asumsi, perhitungan, dan pemeriksaan yang relevan bila membantu."
        val personal = keys.getCustomInstructions().trim().take(2000)
        val personalizedBase = if (personal.isBlank()) base else "$base\n\nINSTRUKSI KHUSUS PENGGUNA (berlaku lintas chat selama tidak bertentangan dengan keselamatan atau instruksi sistem):\n$personal"
        return when (mode) {
            ChatMode.NORMAL -> personalizedBase
            ChatMode.THINK_HARDER -> "$personalizedBase\n\nMODE BERPIKIR LEBIH KERAS: alokasikan upaya penalaran tinggi yang didukung provider. Periksa asumsi, alternatif, edge case, konsistensi angka, dan kemungkinan kesalahan sebelum menjawab. Untuk tugas kompleks, berikan kesimpulan, ringkasan metode/validasi yang dapat diperiksa, risiko, dan tingkat kepastian. Jangan mengungkapkan chain-of-thought privat."
            ChatMode.DEEP_RESEARCH -> "$personalizedBase\n\nMODE RISET WEB MENDALAM: alat web provider harus aktif pada request ini; jangan hanya menjawab dari ingatan model. Pecah topik menjadi subpertanyaan, cari sumber yang beragam dan terbaru, utamakan dokumentasi primer, situs resmi, jurnal atau sumber institusional. Bandingkan setidaknya beberapa temuan yang relevan jika alat menyediakan hasil yang cukup; bedakan fakta terverifikasi, interpretasi, dan ketidakpastian. Cantumkan sitasi/URL yang benar-benar dikembalikan alat, serta tanggal bila tersedia. Jangan mengarang jumlah sumber atau menyatakan telah membuka halaman yang tidak dikembalikan alat. Jika alat pencarian gagal atau model/provider tidak mendukungnya, jelaskan bahwa riset web tidak berhasil dan jangan menyamarkannya sebagai riset selesai."
        }
    }

    private fun responseText(root: JsonObject, provider: Provider): String {
        if (provider == Provider.GEMINI) {
            val candidates = root.get("candidates")?.takeIf { it.isJsonArray }?.asJsonArray ?: return ""
            val candidate = candidates.firstOrNull()?.takeIf { it.isJsonObject }?.asJsonObject ?: return ""
            val parts = candidate.getAsJsonObject("content")?.get("parts")?.takeIf { it.isJsonArray }?.asJsonArray ?: return ""
            return parts.mapNotNull { part ->
                if (!part.isJsonObject) return@mapNotNull null
                val obj = part.asJsonObject
                // Never surface provider-marked private thought parts as visible assistant text.
                if (obj.get("thought")?.takeIf { it.isJsonPrimitive }?.asBoolean == true) return@mapNotNull null
                obj.get("text")?.takeIf { it.isJsonPrimitive }?.asString
            }.joinToString("")
        }
        val choices = root.get("choices")?.takeIf { it.isJsonArray }?.asJsonArray ?: return ""
        val delta = choices.firstOrNull()?.takeIf { it.isJsonObject }?.asJsonObject?.getAsJsonObject("delta") ?: return ""
        val content = delta.get("content") ?: return ""
        if (content.isJsonNull || !content.isJsonPrimitive) return ""
        return runCatching { content.asString }.getOrDefault("")
    }

    private fun collectSources(root: JsonObject, provider: Provider, target: LinkedHashMap<String, String>) {
        fun add(urlElement: JsonElement?, titleElement: JsonElement?) {
            val url = urlElement?.takeIf { it.isJsonPrimitive }?.asString?.trim().orEmpty()
            if (!url.startsWith("https://") && !url.startsWith("http://")) return
            val title = titleElement?.takeIf { it.isJsonPrimitive }?.asString?.trim().orEmpty().ifBlank { url }
            target.putIfAbsent(url, title)
        }
        if (provider == Provider.GEMINI) {
            val candidates = root.get("candidates")?.takeIf { it.isJsonArray }?.asJsonArray ?: return
            candidates.filter { it.isJsonObject }.forEach { element ->
                val metadata = element.asJsonObject.getAsJsonObject("groundingMetadata") ?: return@forEach
                val chunks = metadata.get("groundingChunks")?.takeIf { it.isJsonArray }?.asJsonArray ?: return@forEach
                chunks.filter { it.isJsonObject }.forEach { chunk ->
                    val web = chunk.asJsonObject.getAsJsonObject("web") ?: return@forEach
                    add(web.get("uri"), web.get("title"))
                }
            }
        } else if (provider == Provider.OPENROUTER) {
            // OpenRouter's server tools may emit URL annotations on the streamed message or final payload.
            root.get("citations")?.takeIf { it.isJsonArray }?.asJsonArray?.forEach { citation ->
                if (citation.isJsonPrimitive) add(citation, null)
                else if (citation.isJsonObject) add(citation.asJsonObject.get("url"), citation.asJsonObject.get("title"))
            }
            root.get("choices")?.takeIf { it.isJsonArray }?.asJsonArray?.filter { it.isJsonObject }?.forEach { choice ->
                val choiceObject = choice.asJsonObject
                val message = choiceObject.getAsJsonObject("message") ?: choiceObject.getAsJsonObject("delta") ?: return@forEach
                message.get("annotations")?.takeIf { it.isJsonArray }?.asJsonArray?.filter { it.isJsonObject }?.forEach { annotation ->
                    val obj = annotation.asJsonObject
                    val nested = obj.getAsJsonObject("url_citation")
                    add(nested?.get("url") ?: obj.get("url"), nested?.get("title") ?: obj.get("title"))
                }
            }
        }
    }

    private fun imagePart(path: String): JsonObject? = runCatching {
        val file = File(path)
        if (!file.exists() || file.length() > 12L * 1024 * 1024) return null
        val data = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        JsonObject().apply { add("inline_data", JsonObject().apply { addProperty("mime_type", "image/jpeg"); addProperty("data", data) }) }
    }.getOrNull()

    private fun imageDataUrl(path: String): String? = runCatching {
        val file = File(path)
        if (!file.exists() || file.length() > 12L * 1024 * 1024) return null
        "data:image/jpeg;base64," + Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
    }.getOrNull()
}
