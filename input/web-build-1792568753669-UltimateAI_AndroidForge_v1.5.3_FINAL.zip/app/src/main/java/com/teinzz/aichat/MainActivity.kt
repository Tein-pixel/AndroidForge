package com.teinzz.aichat

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Force Android 10+ to resize the app window around the IME instead of panning the chat
        // behind the keyboard. The Compose imePadding modifier handles the animated inset.
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContent {
            val vm: ChatViewModel = viewModel()
            val storedTheme by vm.themeManager.theme.collectAsState(initial = vm.themeManager.getInitialTheme())
            val systemDark = isSystemInDarkTheme()
            val effectiveTheme = when (storedTheme) {
                ThemeMode.SYSTEM -> if (systemDark) ThemeMode.DARK else ThemeMode.LIGHT
                else -> storedTheme
            }
            val accent = Color(vm.themeManager.accentColor.value)
            val dark = effectiveTheme != ThemeMode.LIGHT
            val view = LocalView.current

            val lightColors = lightColorScheme(
                primary = Color(vm.themeManager.accentColor.value), onPrimary = Color.White,
                background = Color(0xFFFFFFFF), onBackground = Color(0xFF171717),
                surface = Color(0xFFFFFFFF), onSurface = Color(0xFF171717),
                surfaceVariant = Color(0xFFF1F2F4), onSurfaceVariant = Color(0xFF60646C),
                outlineVariant = Color(0xFFE1E3E6), secondaryContainer = Color(0xFFE9ECF2),
                surfaceContainerLow = Color(0xFFF8F9FA)
            )
            val blackColors = darkColorScheme(
                primary = accent, onPrimary = Color(0xFF101014), background = Color(0xFF0D0D0F), onBackground = Color(0xFFECECF0),
                surface = Color(0xFF0D0D0F), onSurface = Color(0xFFECECF0), surfaceVariant = Color(0xFF1B1B1F),
                onSurfaceVariant = Color(0xFFB4B4BC), outlineVariant = Color(0xFF2C2C32),
                secondaryContainer = Color(0xFF25252C), surfaceContainerLow = Color(0xFF141418)
            )
            val grayColors = darkColorScheme(
                primary = accent, onPrimary = Color(0xFF15171B), background = Color(0xFF17191D), onBackground = Color(0xFFEDEFF2),
                surface = Color(0xFF1B1E23), onSurface = Color(0xFFEDEFF2), surfaceVariant = Color(0xFF25292F),
                onSurfaceVariant = Color(0xFFBEC3CB), outlineVariant = Color(0xFF373D45),
                secondaryContainer = Color(0xFF303640), surfaceContainerLow = Color(0xFF202329)
            )
            val customColors = darkColorScheme(
                primary = accent, onPrimary = Color(0xFF101426), background = Color(0xFF0D1120), onBackground = Color(0xFFEAF0FF),
                surface = Color(0xFF11172A), onSurface = Color(0xFFEAF0FF), surfaceVariant = Color(0xFF1B2540),
                onSurfaceVariant = Color(0xFFB8C4E2), outlineVariant = Color(0xFF303D61),
                secondaryContainer = Color(0xFF24304E), surfaceContainerLow = Color(0xFF151D34)
            )
            val selectedColors = when (effectiveTheme) {
                ThemeMode.LIGHT -> lightColors
                ThemeMode.GRAY -> grayColors
                ThemeMode.CUSTOM -> customColors
                else -> blackColors
            }
            val windowColor = when (effectiveTheme) {
                ThemeMode.LIGHT -> android.graphics.Color.WHITE
                ThemeMode.GRAY -> android.graphics.Color.rgb(23, 25, 29)
                ThemeMode.CUSTOM -> android.graphics.Color.rgb(13, 17, 32)
                else -> android.graphics.Color.rgb(13, 13, 15)
            }
            SideEffect {
                window.statusBarColor = windowColor
                window.navigationBarColor = windowColor
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !dark
            }
            MaterialTheme(colorScheme = selectedColors, typography = Typography(bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 26.sp))) {
                var screen by remember { mutableStateOf("chat") }
                BackHandler(enabled = screen != "chat") { screen = "chat" }
                when (screen) {
                    "settings" -> SettingsScreen(vm, onBack = { screen = "chat" })
                    "artifacts" -> ArtifactsScreen(vm, onBack = { screen = "chat" })
                    "camera" -> CameraScreen(onBack = { screen = "chat" }, onUsePhoto = { path -> vm.send("", ImageCompressor.cameraFile(this@MainActivity, path), "Camera.jpg"); screen = "chat" })
                    else -> ChatScreen(vm, onSettings = { screen = "settings" }, onCamera = { screen = "camera" }, onArtifacts = { screen = "artifacts" })
                }
            }
        }
    }
}
