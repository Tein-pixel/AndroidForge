# LumaBoost

Aplikasi utilitas Android ringan dengan dashboard minimalis untuk Android 10+ (API 29+). Proyek Java tanpa SDK pihak ketiga, root, Shizuku, layanan latar belakang, iklan, akun, atau koneksi jaringan.

## Fitur yang benar-benar ada

- **Optimasi aman 1 tap:** membersihkan direktori cache milik LumaBoost sendiri, menjalankan garbage collection aplikasi sendiri, lalu memperbarui angka RAM/penyimpanan/baterai. Aplikasi menjelaskan batas tindakan ini dan menyediakan tombol menuju pengaturan penyimpanan Android.
- **Monitor RAM:** menampilkan estimasi RAM terpakai dan tersedia dari `ActivityManager.MemoryInfo`. RAM Android juga mencakup cache yang dapat direklamasi; angka ini bukan jumlah RAM yang bisa dibebaskan dengan tombol.
- **Penyimpanan:** total dan ruang kosong partisi data, plus pintasan ke pengaturan penyimpanan sistem.
- **Baterai & termal:** persentase dan temperatur baterai dari broadcast sistem, status termal melalui `PowerManager` (API 29+ jika perangkat melaporkan nilainya).
- **Pemindaian folder yang dipilih pengguna:** menggunakan Storage Access Framework. Memindai nama file umum sementara/backup (`.tmp`, `.temp`, `.bak`, `thumbs.db`, `.DS_Store`), menampilkan kandidat dan meminta konfirmasi sebelum mencoba menghapusnya. Pemindaian dibatasi kedalaman 8 dan maksimal 500 kandidat.
- **Pengelola aplikasi:** daftar aplikasi yang dapat dicari, dengan pintasan membuka aplikasi dan halaman Info Aplikasi Android.
- **Tiga tema:** AMOLED Black, Midnight Purple, dan Light; tema tersimpan setelah aplikasi ditutup.
- **UI ringan:** View Android bawaan, tanpa animasi berat atau framework UI eksternal.

## Batasan Android (bukan bug yang bisa disiasati oleh UI)

Android membatasi aplikasi biasa dari menghapus cache/data milik aplikasi lain secara langsung, membaca semua file privat, memaksa membersihkan RAM sistem, atau menghentikan proses aplikasi lain di Android 14+. Karena itu LumaBoost **tidak** membuat klaim palsu seolah-olah semua RAM/cache seluruh aplikasi sudah dibersihkan. Pengaturan Android tetap menjadi tempat yang tepat untuk meninjau dan menghapus data/cache aplikasi lain.

Pemindaian folder hanya menyentuh folder yang dipilih pengguna lewat pemilih file sistem. Nama file yang terlihat sementara belum tentu tidak penting; baca daftar kandidat sebelum menyetujui penghapusan. Android 11+ membatasi folder tertentu yang dapat dipilih melalui SAF.

`QUERY_ALL_PACKAGES` dipakai agar pengelola aplikasi bisa menampilkan seluruh paket terpasang pada APK sideload. Ini bukan izin runtime. Jika aplikasi akan diterbitkan di Google Play, tinjau kebijakan Google Play untuk izin visibilitas paket.

## Build dengan AndroidForge

1. Unggah `LumaBoost-Android10Plus-v1.0.0.zip` ke AndroidForge.
2. Pilih build Gradle / proyek Java.
3. Jalankan build APK.
4. Uji pada perangkat Android 10 dan perangkat Android yang lebih baru.

Build memakai Gradle 8.7, Android Gradle Plugin 8.5.2, compile SDK 34, target SDK 34, minimum SDK 29, Java 8. Release build menggunakan debug signing untuk memudahkan pemasangan APK hasil build pribadi. Untuk distribusi publik, gunakan kunci rilis milik sendiri.

## Izin

- `QUERY_ALL_PACKAGES`: diperlukan untuk fitur daftar aplikasi terpasang.
- Tidak meminta akses semua file, kontak, lokasi, mikrofon, kamera, notifikasi, aksesibilitas, Device Admin, root, atau Shizuku.
- Pemindaian folder menggunakan pemilih file Android, jadi izin penyimpanan luas tidak diminta.

## Identitas visual

Nama: LumaBoost. Logo berupa vector drawable kilat putih dengan aksen cyan di atas gradien ungu. Semua elemen utama menggunakan kartu ber-radius besar, ruang antarbagian konsisten, aksen ungu, dan hierarki teks pendek.
