# Matriks fitur LumaBoost

| Fitur | Android 10+ | Cara kerja / batasan |
|---|---:|---|
| Optimasi aman 1 tap | Ya | Bersihkan cache milik LumaBoost, GC proses sendiri, refresh data perangkat. |
| Monitor RAM | Ya | Estimasi dari ActivityManager; bukan alat untuk mengosongkan RAM seluruh sistem. |
| Informasi penyimpanan | Ya | StatFs untuk partisi data; pengelolaan cache aplikasi lain lewat Settings. |
| Status baterai | Ya | Level dan temperatur dari sistem; sensor tidak selalu tersedia. |
| Status termal | Ya | PowerManager pada API 29+, status bergantung vendor/perangkat. |
| Scan file sementara | Ya | Hanya folder yang dipilih pengguna melalui SAF dan konfirmasi sebelum hapus. |
| Pengelola aplikasi | Ya | Pencarian aplikasi terpasang, buka aplikasi, halaman Info Aplikasi. |
| Tema AMOLED / Midnight / Light | Ya | Tersimpan melalui SharedPreferences. |
| Auto-kill semua aplikasi | Tidak | Aplikasi biasa tidak memiliki kontrol paksa yang stabil/diizinkan. |
| Hapus cache/data semua aplikasi | Tidak langsung | Gunakan halaman penyimpanan Android per aplikasi / system UI. |
| Boost CPU/GPU atau mematikan thermal throttling | Tidak | Memerlukan akses sistem/perangkat khusus dan bukan kemampuan aplikasi biasa. |
| Root / Shizuku / VPN / service terus-menerus | Tidak digunakan | Tidak diperlukan untuk fitur aplikasi ini. |
