package com.teinzz.lumaboost;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class AppManagerActivity extends Activity {
    private int bg, card, text, muted, accent, accentSoft, stroke;
    private PackageManager pm;
    private final ArrayList<ApplicationInfo> allApps = new ArrayList<>();
    private final ArrayList<ApplicationInfo> shownApps = new ArrayList<>();
    private AppAdapter adapter;
    private EditText search;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        String mode = getSharedPreferences("lumaboost_settings", MODE_PRIVATE).getString("theme", "amoled");
        setPalette(mode);
        pm = getPackageManager();
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (Build.VERSION.SDK_INT >= 26) getWindow().getDecorView().setSystemUiVisibility("light".equals(mode) ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0);
        buildUi();
        loadApps();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(16), dp(10), dp(16), dp(8));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 30, text, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(shape(card, stroke, 14));
        top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(42)));
        back.setOnClickListener(v -> finish());
        LinearLayout titlebox = new LinearLayout(this);
        titlebox.setOrientation(LinearLayout.VERTICAL);
        titlebox.setPadding(dp(12), 0, 0, 0);
        titlebox.addView(text("Kelola aplikasi", 19, text, true));
        TextView subtitle = text("Aplikasi yang terpasang di perangkat", 11, muted, false);
        subtitle.setPadding(0, dp(2), 0, 0);
        titlebox.addView(subtitle);
        top.addView(titlebox, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(top, marginBottom(13));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setTextColor(text);
        search.setHintTextColor(muted);
        search.setHint("Cari nama atau paket aplikasi…");
        search.setPadding(dp(15), dp(3), dp(12), dp(3));
        search.setBackground(shape(card, stroke, 16));
        root.addView(search, marginBottom(9));

        TextView note = text("Pilih Info untuk membuka halaman aplikasi di Android. LumaBoost tidak menghapus data atau cache aplikasi lain secara paksa.", 11, muted, false);
        note.setLineSpacing(dp(2), 1f);
        root.addView(note, marginBottom(11));

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setCacheColorHint(bg);
        list.setBackgroundColor(bg);
        list.setPadding(0, dp(1), 0, dp(1));
        adapter = new AppAdapter(this);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterApps(s == null ? "" : s.toString()); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void loadApps() {
        try {
            allApps.clear();
            allApps.addAll(pm.getInstalledApplications(PackageManager.GET_META_DATA));
            Collections.sort(allApps, new Comparator<ApplicationInfo>() {
                final Collator collator = Collator.getInstance();
                @Override public int compare(ApplicationInfo a, ApplicationInfo b) {
                    return collator.compare(label(a), label(b));
                }
            });
            filterApps("");
        } catch (Exception e) {
            Toast.makeText(this, "Daftar aplikasi tidak dapat dibaca di perangkat ini.", Toast.LENGTH_LONG).show();
        }
    }

    private void filterApps(String q) {
        String query = q.trim().toLowerCase(Locale.ROOT);
        shownApps.clear();
        for (ApplicationInfo app : allApps) {
            if (app.packageName.equals(getPackageName())) continue;
            String name = label(app).toLowerCase(Locale.ROOT);
            if (query.isEmpty() || name.contains(query) || app.packageName.toLowerCase(Locale.ROOT).contains(query)) shownApps.add(app);
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private String label(ApplicationInfo info) {
        try { return pm.getApplicationLabel(info).toString(); }
        catch (Exception e) { return info.packageName; }
    }

    private void launchOrMessage(ApplicationInfo info) {
        Intent launch = pm.getLaunchIntentForPackage(info.packageName);
        if (launch == null) {
            Toast.makeText(this, "Aplikasi sistem ini tidak menyediakan ikon peluncur.", Toast.LENGTH_SHORT).show();
            return;
        }
        try { startActivity(launch); } catch (Exception e) { Toast.makeText(this, "Aplikasi tidak dapat dibuka.", Toast.LENGTH_SHORT).show(); }
    }
    private void appInfo(ApplicationInfo info) {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + info.packageName))); }
        catch (Exception e) { Toast.makeText(this, "Halaman info aplikasi tidak tersedia.", Toast.LENGTH_SHORT).show(); }
    }

    private class AppAdapter extends BaseAdapter {
        private final Context context;
        AppAdapter(Context c) { context = c; }
        @Override public int getCount() { return shownApps.size(); }
        @Override public Object getItem(int position) { return shownApps.get(position); }
        @Override public long getItemId(int position) { return shownApps.get(position).packageName.hashCode(); }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            final ApplicationInfo app = shownApps.get(position);
            LinearLayout row;
            if (convertView instanceof LinearLayout) row = (LinearLayout) convertView;
            else {
                row = new LinearLayout(context);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(11), dp(10), dp(8), dp(10));
                row.setBackground(shape(card, stroke, 17));
                ImageView icon = new ImageView(context); icon.setTag("icon");
                row.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
                LinearLayout copy = new LinearLayout(context); copy.setTag("copy"); copy.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1); cp.leftMargin=dp(10); cp.rightMargin=dp(6);
                row.addView(copy, cp);
                LinearLayout actions = new LinearLayout(context); actions.setOrientation(LinearLayout.VERTICAL); actions.setGravity(Gravity.CENTER);
                actions.setTag("actions");
                row.addView(actions, new LinearLayout.LayoutParams(dp(62), -2));
            }
            ImageView icon = row.findViewWithTag("icon");
            try { icon.setImageDrawable(pm.getApplicationIcon(app)); } catch (Exception e) { icon.setImageDrawable(null); }
            LinearLayout copy = row.findViewWithTag("copy"); copy.removeAllViews();
            TextView name = text(label(app), 13, text, true); name.setMaxLines(1); name.setEllipsize(android.text.TextUtils.TruncateAt.END); copy.addView(name);
            TextView pkg = text(app.packageName, 9, muted, false); pkg.setMaxLines(1); pkg.setEllipsize(android.text.TextUtils.TruncateAt.END); pkg.setPadding(0, dp(3), 0, dp(3)); copy.addView(pkg);
            boolean system = (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            TextView kind = text(system ? "APLIKASI SISTEM" : "APLIKASI TERPASANG", 8, accent, true); copy.addView(kind);
            LinearLayout actions = row.findViewWithTag("actions"); actions.removeAllViews();
            TextView open = actionText("Buka"); actions.addView(open, new LinearLayout.LayoutParams(-1, dp(29)));
            TextView info = actionText("Info"); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(29)); ip.topMargin=dp(4); actions.addView(info, ip);
            open.setOnClickListener(v -> launchOrMessage(app)); info.setOnClickListener(v -> appInfo(app));
            View.OnClickListener openInfo = v -> appInfo(app); row.setOnClickListener(openInfo);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=dp(7); row.setLayoutParams(lp);
            return row;
        }
        private TextView actionText(String s) {
            TextView t = text(s, 10, accent, true); t.setGravity(Gravity.CENTER); t.setBackground(shape(accentSoft, stroke, 10)); t.setClickable(true); return t;
        }
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams marginBottom(int value) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin=dp(value); return p; }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int fill, int line, int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radius)); if (line != 0) d.setStroke(dp(1),line); return d; }
    private void setPalette(String mode) {
        if ("light".equals(mode)) { bg=0xFFF3F4F9; card=0xFFFFFFFF; text=0xFF171925; muted=0xFF777C90; accent=0xFF7554E8; accentSoft=0xFFEDE7FF; stroke=0xFFE1DDF0; }
        else if ("midnight".equals(mode)) { bg=0xFF10101A; card=0xFF191827; text=0xFFF6F4FF; muted=0xFF9C9AAF; accent=0xFF9C78FF; accentSoft=0xFF282040; stroke=0xFF39304F; }
        else { bg=0xFF080910; card=0xFF141520; text=0xFFF8F7FF; muted=0xFF9394A7; accent=0xFF9A76FF; accentSoft=0xFF251B40; stroke=0xFF302843; }
    }
}
