# Tein Booster

Aplikasi Android berbasis Java yang berjalan tanpa root dan berisi kumpulan booster + **1-Tap Cache Cleaner**, yang mengarahkan proses pembersihan cache melalui Layanan Aksesibilitas. Integrasi Shizuku opsional memakai API resmi; fitur normal tetap dapat dipakai tanpa Shizuku.
Minimum Android 10 (API 29), target API 34.

## Cara membuat APK

**A. Android Studio (paling mudah)**
1. `File > Open` pilih folder `TeinBooster` (hasil ekstrak ZIP), tunggu Gradle sync selesai (butuh internet sekali).
2. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
3. APK ada di `app/build/outputs/apk/debug/app-debug.apk` (sudah bertanda tangan debug, langsung bisa di-install).

**B. Command line** (JDK 17 + Android SDK, `ANDROID_HOME` terisi)
```
./gradlew assembleDebug
```
`gradle/wrapper/gradle-wrapper.jar` di proyek ini adalah bootstrap sederhana buatan sendiri (bukan jar resmi Gradle):
ia mengunduh Gradle 8.7 sesuai `gradle-wrapper.properties`. Jika ingin jar resmi: `gradle wrapper --gradle-version 8.7`.

**C. GitHub Actions**: unggah proyek ke repo GitHub. Workflow `.github/workflows/build-apk.yml` berjalan saat push ke `main`/`master`, tag `v*`, atau lewat *Actions > Build APK and publish release > Run workflow*. File `app-sign.apk` muncul sebagai Artifact dan sebagai aset pada GitHub Releases. APK release ini ditandatangani dengan debug key dan ditujukan untuk uji/pemakaian pribadi, bukan rilis Google Play.

## Izin yang harus diaktifkan (menu **Pusat Izin** di aplikasi)
| Izin | Dipakai untuk |
|---|---|
| Aksesibilitas | 1-Tap Cache Cleaner (menekan "Hapus cache" di Pengaturan) |
| Akses Penggunaan | ukuran cache per aplikasi, daftar pemakaian |
| Akses semua file | Junk Cleaner, file besar, duplikat |
| Ubah pengaturan sistem | Hemat Baterai / kecerahan & timeout layar |
| Tampil di atas aplikasi lain (opsional) | HUD mengambang saat bermain |
| Rekam layar (dialog sistem) | Perekam gameplay setelah persetujuan setiap sesi |
| Mikrofon (opsional, hanya ketika dimulai) | Meter level suara, berhenti otomatis saat halaman ditinggalkan |
| Notifikasi (Android 13+, opsional) | Kontrol berhenti untuk perekam/overlay lebih mudah dilihat |
| Jangan Ganggu | Game Booster |
| Abaikan optimasi baterai | Auto Boost terjadwal |
| WRITE_SECURE_SETTINGS (opsional, 1x via ADB) | Turbo UI (animasi) & Private DNS sekali tekan |

Android 13+ (APK dipasang manual): jika tombol Aksesibilitas abu-abu / "Setelan dibatasi", buka *Info aplikasi Tein Booster >
menu ⋮ > Izinkan setelan terbatas*, lalu aktifkan lagi.

## Isi booster (semua nyata, tanpa root)
- **1-Tap Cache Cleaner** – per aplikasi: Info aplikasi → Penyimpanan → *Hapus cache*; layar progres menutupi proses; tidak pernah
  menyentuh "Hapus data". Didahului pemangkasan cache via API resmi `StorageManager`. Ada tombol *Lihat log* dan *mode debug*.
- **RAM Booster** – menutup proses latar (`killBackgroundProcesses`), RAM sebelum/sesudah diukur nyata; ada daftar putih.
- **Junk Cleaner** – pindai file .tmp/.log/thumbnail/unduhan gagal/APK sisa/folder kosong/cache eksternal, hapus sungguhan.
- **Penyimpanan** – kategori, file besar, duplikat (hash MD5).
- **Hemat Baterai** – profil Hemat/Ultra (kecerahan, timeout layar, sinkronisasi) + pulihkan; aplikasi terlama dipakai.
- **Pendingin** – pantau suhu baterai live, tutup aplikasi latar, ukur suhu sebelum/sesudah.
- **Game Booster** – tutup aplikasi latar + Jangan Ganggu lalu luncurkan game; DND dipulihkan saat kembali.
- **Pusat Gaming** – hub untuk GFX Guide, Game HUD, monitor performa, alat uji sentuhan/layar/kontroler, latihan refleks offline, Game Coach lokal, perpustakaan game, Panel Game, perekam layar, dan meter suara.
- **GFX Guide** – rekomendasi manual kualitas grafis, FPS, resolusi render, serta efek berdasarkan RAM dan refresh rate. Tidak mengubah setelan game secara diam-diam.
- **Game HUD** – widget mengambang yang dapat dipindahkan, menampilkan RAM, baterai, dan suhu baterai. Membutuhkan izin Android “Tampil di atas aplikasi lain” dan menampilkan notifikasi layanan saat aktif.
- **Monitor Performa** – RAM, penyimpanan, baterai, suhu baterai, refresh rate, lalu lintas jaringan perangkat, estimasi aktivitas CPU seluruh sistem dari penghitung kernel bila dapat dibaca, grafik riwayat 60 sampel CPU/RAM, dan tes latensi TCP. GPU/FPS game lain tidak dibuat-buat karena Android tidak menyediakannya untuk aplikasi biasa.
- **Alat Uji** – sapuan multi-touch, pemeriksaan warna layar, dan deteksi input gamepad/joystick yang terhubung.
- **Latihan Gamer** – mini-game reaksi 10 ronde yang berjalan offline dengan arena yang dibuka lewat progres bintang.
- **Game Coach** – rekomendasi lokal sesuai jenis game, prioritas, RAM, suhu, dan refresh rate; tidak mengaku sebagai layanan AI daring.
- **Perpustakaan Game** – cari aplikasi yang bisa dibuka, favoritkan, luncurkan, dan tetapkan game utama. Game utama otomatis ditambahkan ke daftar Game Booster lama.
- **Panel Game** – kontrol volume media perangkat, kecerahan panel aplikasi, menjaga layar tetap aktif, tes getar, dan pintasan ke pengaturan rotasi/Wi-Fi/DND Android. Slider kecerahan tidak mengubah game lain; kontrol sistem yang dilindungi membuka halaman pengaturan resmi.
- **Perekam Layar** – rekam video MP4 tanpa audio mikrofon memakai MediaProjection, dengan persetujuan Android setiap sesi dan notifikasi berhenti. Kualitas encoder tergantung perangkat; konten yang dilindungi aplikasi bisa tampil hitam.
- **Visualisasi Suara** – meter level mikrofon selama halaman aktif. File sementara berada di cache dan dihapus ketika pengukuran dihentikan; angka bukan pengukuran dB terkalibrasi.
- **Manajer Aplikasi** – ukuran, buka, info, bersihkan cache, cadangkan APK, hapus instalan.
- **Network Booster** – tes unduh, latensi DNS (UDP), ping TCP, atur Private DNS.
- **Turbo UI** – skala animasi sistem. **Info Perangkat**. **Auto Boost** (terjadwal), ubin Quick Settings, pintasan ikon.

Tidak ada: overclock CPU/GPU, RAM tambahan/swap, "pendingin CPU" palsu, dll. — itu butuh root atau hanya tampilan kosong.

## Jika Cache Cleaner gagal di HP tertentu
Tampilan Pengaturan tiap merek berbeda. Buka *1-Tap Cache Cleaner > Lihat log* (berisi alasan gagal + teks layar yang terbaca),
salin, dan kirim agar kamus label bisa disesuaikan. Aktifkan *mode debug* untuk melihat proses langsung.

## Struktur
`app/src/main/java/com/tein/booster/` — `CleanerAccessibilityService` (inti cleaner), `Optimizer`, `FileScan`, `Net`,
`Apps`, `Sys`, `CpuStats`, `ScreenRecorderService`, layar-layar `*Activity`, view kustom (`GaugeView`, `LogoView`, `BarView`).

## Batasan pengujian
Build penuh harus dilakukan di Android Studio atau GitHub Actions dengan Android SDK dan akses dependensi Gradle. Jika lingkungan lokal tidak memiliki SDK/internet, pemeriksaan struktur/sintaks saja bukan bukti bahwa aplikasi sudah teruji di perangkat. Uji recorder, overlay, aksesibilitas, dan pengaturan OEM di HP target sebelum dipakai lama.


## UI dashboard glossy + dukungan Android 10+

- Dashboard memiliki kartu skor/Boost, statistik RAM/penyimpanan/baterai, tiga pintasan cepat, kategori yang dapat dilipat, dan navigasi bawah Home/Device/Command.
- Semua kartu memakai latar glass/gradient, garis aksen lembut, dan animasi tap. Pilihan tema disimpan: AMOLED Black, Navy, Terang, Purple Glass, Electric Blue, dan Emerald.
- **Minimum Android 10 (API 29)**. Fitur lanjutan tidak boleh dianggap tersedia hanya karena nama/ikon ditampilkan; status dukungan tiap modul mengikuti izin Android, versi OS, OEM, dan API yang dipakai.
- Status build: pemeriksaan statis tidak menggantikan kompilasi Android. Build belum berhasil diverifikasi di lingkungan ini karena Android SDK/unduhan Gradle tidak tersedia.

## Game Space edge overlay

- Layanan Game Space menampilkan pegangan kecil di tepi kiri. Ketuk atau geser pegangan ke kanan untuk membuka panel melayang di atas aplikasi lain.
- Panel berisi slider volume media, kecerahan global (hanya aktif sesudah pengguna memberi izin `Modify system settings`), DND (memerlukan Notification Policy access), toggle layar tetap menyala, mode Fokus (keep-screen-on + DND bila izin diberikan), pintasan HUD, perekam layar, Game Saya, Game Coach, Game Panel, dan Mini Browser.
- Mini Browser dapat dimasukkan ke PiP dari tombol dalam browser pada perangkat yang mendukung. PiP hanya menjadikan **aktivitas Mini Browser milik TeinBooster** mengambang; aplikasi lain harus mendukung PiP sendiri.
- Izin `Display over other apps` wajib; beberapa perangkat Android Go membatasi overlay. Layanan foreground menampilkan notifikasi saat panel aktif. Untuk menghentikan, tekan pintasan Game Space lagi dari aplikasi.
- PiP tidak bisa dipaksakan ke semua aplikasi: aplikasi yang dibuka harus mendukung PiP. Edge overlay bukan fitur sistem bawaan OEM dan bisa tidak cocok dengan kebijakan overlay/gesture pada sebagian ponsel.


## Integrasi non-root: Shizuku dan Brevent

- **Shizuku** memakai library resmi `dev.rikka.shizuku:api:13.1.5` dan `provider:13.1.5`. Pengguna harus menjalankan server dan memberikan izin eksplisit pada TeinBooster.
- Panel *Integrasi ADB* hanya menerima sesi Shizuku dengan UID **2000 (shell/ADB)**. Jika server berjalan dengan UID root (0), perintah di panel ini sengaja ditolak.
- **Refresh rate manual** hanya menulis preferensi `min_refresh_rate` / `peak_refresh_rate`, dan hanya menampilkan pilihan berdasarkan mode layar yang dilaporkan perangkat. OEM dapat mengabaikan nilai ini; fitur tidak menjanjikan FPS atau refresh aktual berubah. Nilai awal disimpan sebelum perubahan pertama dan bisa dipulihkan melalui tombol pemulihan.
- **Brevent** bisa dideteksi dan dibuka dari panel. Brevent memiliki layanan ADB sendiri; TeinBooster tidak mengirim perintah tersembunyi atau mengendalikan daftar aplikasi Brevent dari jarak jauh karena tidak memakai API publik stabil untuk fungsi tersebut. Kelola daftar aplikasi langsung di Brevent.
- **Android 11+:** Shizuku non-root dapat dimulai melalui Wireless debugging di perangkat. Setelah reboot, server biasanya perlu dimulai lagi. Panduan resmi: https://shizuku.rikka.app/guide/setup/ dan https://brevent.sh.
- **Retikel visual** adalah overlay non-interaktif berbasis izin sistem; overlay dapat diblokir Android Go atau aturan game/anti-cheat, sehingga harus dimatikan jika game melarangnya. **Timer/Cooldown** adalah timer foreground; halaman perlu tetap terbuka untuk alarm visual. **Playtime** hanya menghitung sesi ketika game diluncurkan lewat Game Saya lalu pengguna kembali ke TeinBooster, bukan analitik pemakaian OS secara penuh.
- Fitur baru tetap tanpa root: tidak ada CPU/GPU overclock, thermal-throttling disabler, bypass charging, injector, atau manipulasi game.


## Persyaratan versi 1.3.0

- Android 10 (API 29) atau lebih baru. Fitur dasar tidak memerlukan Shizuku atau Brevent.
- Fitur sistem lanjutan yang ditandai ADB memerlukan Shizuku berjalan sebagai shell/ADB (UID 2000) dan izin aplikasi. Di daftar audit, controller refresh rate dan DNS disembunyikan sampai sesi Shizuku ADB berizin terdeteksi.
- Brevent adalah layanan terpisah untuk mengelola aplikasi latar; mengaktifkan Brevent tidak memberikan akses ADB kepada TeinBooster.
- Tidak ada fitur root/overclock. DNS Pribadi dan refresh rate opsional, dapat ditolak OEM, dan memiliki pemulihan nilai sebelumnya.
- Build harus diuji di perangkat target; perubahan DNS/refresh rate tidak dijamin berlaku pada semua OEM.

## Audit fitur gaming (59 item)

Dashboard memiliki satu pintasan **Audit Fitur Gaming**. Daftar di dalamnya mengelompokkan fitur gaming, menandai statusnya (tersedia, sebagian/bergantung perangkat, atau tidak didukung), dan membuka modul yang sudah ada tanpa membuat tombol fitur duplikat di dashboard. Entri yang benar-benar memerlukan akses Shizuku disembunyikan sampai server dengan UID 2000 dan izin aplikasi tersedia. Mode DND memiliki kontrol aktif/nonaktif melalui izin Notification Policy Android. Status “sebagian” tidak berarti semua kemampuan tersedia di setiap OEM/game.

Batasan teknis penting: aplikasi non-root tidak dapat secara universal melakukan overclock/locked clocks, menonaktifkan thermal throttling, memaksa renderer/tekstur/resolusi internal game lain, menaikkan touch sampling rate, mengendalikan bypass charging, menyuntikkan skin/mod, atau membentuk ulang routing paket game. Fitur tersebut tidak dibuat seolah-olah bekerja. Shizuku memberikan akses setara ADB/shell yang tetap terbatas, bukan root; Brevent adalah layanan terpisah untuk mengelola aplikasi latar.

Referensi teknis: [Shizuku](https://github.com/RikkaApps/Shizuku), [Shizuku API](https://github.com/RikkaApps/Shizuku-API), [Android Vulkan overview](https://developer.android.com/games/develop/vulkan/overview), [Android audio latency](https://developer.android.com/ndk/guides/audio/audio-latency).
