package com.tein.booster;

import android.app.NotificationManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import rikka.shizuku.Shizuku;

/** Single compact index for the requested feature set. Statuses intentionally distinguish real controls from unsupported system/game hooks. */
public class FeatureAuditActivity extends BaseActivity {
    private static final int YES = 0, PARTIAL = 1, NO = 2;
    private TextView dndStatus;
    private NotificationManager nm;
    private boolean shizukuAtCreate;

    private static final class Feature {
        String name, note; int status; Class<?> target;
        Feature(String n, String d, int s, Class<?> t) { name=n; note=d; status=s; target=t; }
    }
    private static Feature f(String n, String d, int s, Class<?> c) { return new Feature(n,d,s,c); }

    @Override protected String title() { return "Audit Fitur Gaming"; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        shizukuAtCreate = hasShizukuAdb();
        LinearLayout col = scrollBody();
        col.addView(Ui.tv(this, "Satu daftar ringkas untuk fitur gaming. Status membedakan kontrol nyata, dukungan terbatas, dan hal yang memang tidak bisa diubah aplikasi non-root. Fitur yang butuh Shizuku ADB berizin disembunyikan sampai layanannya aktif.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));

        LinearLayout dnd = Ui.card(this);
        dnd.addView(Ui.tvb(this, "Mode Gaming: Jangan Ganggu", 15, Ui.TEXT));
        dnd.addView(Ui.tv(this, "Mengubah mode Jangan Ganggu Android jika akses kebijakan notifikasi diberikan. Pengaturan ini berlaku sistem; pengecualian kontak VIP tetap mengikuti setelan Android.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        dndStatus = Ui.tvb(this, "Status: memeriksa izin…", 12, Ui.CYAN);
        dnd.addView(dndStatus, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        dnd.addView(Ui.button(this, "Aktifkan / matikan DND", v -> toggleDnd()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        dnd.addView(Ui.ghost(this, "Atur izin DND", v -> openDndSettings()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(dnd, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        addGroup(col, "Performa & grafis", new Feature[]{
            f("Hardware Overclocking & Locked Clocks", "Tidak tersedia non-root; butuh dukungan kernel/OEM khusus.", NO, null),
            f("Thermal Throttling Disabler", "Sengaja tidak disediakan: mematikan proteksi suhu berisiko merusak perangkat.", NO, null),
            f("RAM Purge & Memory Whitelist", "Pembersihan proses terbatas; Android mengatur memori dan whitelist sistem tidak bisa dijamin.", PARTIAL, RamBoosterActivity.class),
            f("Vulkan & OpenGL API Switcher", "Tidak bisa mengganti API renderer game terpasang dari aplikasi umum.", NO, GfxGuideActivity.class),
            f("PreTransform Configuration", "Parameter engine/game tidak dapat diubah universal dari aplikasi luar.", NO, GfxGuideActivity.class),
            f("Texture Filtering Tuning", "Butuh dukungan game/driver; panduan grafis tersedia, bukan pengaturan universal.", PARTIAL, GfxGuideActivity.class),
            f("GFX Tool Custom Resolution", "Tidak dapat memaksa resolusi internal game secara universal; beberapa perubahan display bergantung OEM.", PARTIAL, GfxGuideActivity.class),
            f("Manual Refresh Rate Controller", "Kontrol ADB opsional; perlu Shizuku aktif, izin, dan dukungan perangkat.", PARTIAL, CompanionAccessActivity.class),
            f("Anti-Aliasing Toggle", "Tidak ada toggle global yang aman untuk semua game.", NO, GfxGuideActivity.class),
            f("Dynamic Resolution Scaling", "Game harus mendukungnya sendiri; tidak bisa disuntikkan ke game lain.", NO, GfxGuideActivity.class),
            f("CPU Core Parking Disabler", "Tidak tersedia lewat API publik/non-root umum.", NO, null),
            f("Shader Cache Builder", "Cache shader dibangun oleh game/driver; tidak dapat dibuat universal dari luar.", NO, GfxGuideActivity.class),
            f("Auto Graphics Downscaler on Overheat", "Tidak dapat mengubah kualitas grafis game lain; pantau suhu tersedia.", PARTIAL, CoolerActivity.class),
            f("Hardware Temperature Limiter", "Pemantauan suhu tersedia; batas termal perangkat tetap dikelola sistem.", PARTIAL, CoolerActivity.class),
            f("AI Performance Predictor", "Tren/performa dasar tersedia; prediksi AI tervalidasi belum ada.", PARTIAL, PerformanceMonitorActivity.class)
        });

        addGroup(col, "Memori, otomatisasi & aplikasi", new Feature[]{
            f("Auto RAM Flush on Launch", "Boost/pembersihan manual tersedia; flush otomatis universal tidak dijamin.", PARTIAL, RamBoosterActivity.class),
            f("Auto Cache Wiper", "Cache aplikasi lain tidak bisa dihapus diam-diam; gunakan alur pembersihan dengan izin.", PARTIAL, CacheCleanerActivity.class),
            f("Background Data Restricted", "Manajer aplikasi tersedia; pembatasan data harus diatur pada setelan Android/OEM untuk tiap aplikasi.", PARTIAL, AppManagerActivity.class),
            f("Instant Game Launch / Quick Resume Cache", "Shortcut/pustaka game tersedia; Android tidak menjamin quick-resume cache.", PARTIAL, GameLibraryActivity.class),
            f("Game Library Organizer / Auto-Categorization", "Pustaka game dan pengelompokan tersedia dengan batas deteksi aplikasi.", PARTIAL, GameLibraryActivity.class),
            f("Total Playtime Tracker / Analytics Dashboard", "Pelacakan sesi terbatas pada alur peluncuran dari TeinBooster.", PARTIAL, GameLibraryActivity.class),
            f("Game Plugin Support / Mod Loader Interface", "Antarmuka mod universal tidak tersedia; mod dapat melanggar aturan/anti-cheat.", NO, null),
            f("Skin / Texture Injector Compatibility", "Tidak menyuntikkan file ke game; kompatibilitas tergantung fitur resmi game.", NO, null),
            f("Manual Game Classification Bar", "Daftar game dan panel game tersedia; klasifikasi otomatis universal tidak dijamin.", PARTIAL, GamePanelActivity.class)
        });

        addGroup(col, "Layar, sentuhan & overlay", new Feature[]{
            f("Display Color Enhancement / Night Vision Filter", "Tidak ada filter warna global yang dijamin pada semua OEM.", NO, null),
            f("Touch Sampling Rate Overdrive", "Sampling rate ditentukan panel/firmware; aplikasi tidak dapat menaikkannya.", NO, TouchTestActivity.class),
            f("Edge Suppression Zone", "Butuh fitur bawaan OEM; tidak bisa menimpa penanganan sentuh sistem universal.", NO, TouchTestActivity.class),
            f("Save Power During Touch Protection", "Tidak ada API publik untuk memodifikasi driver touch seperti ini.", NO, null),
            f("FPS, CPU, GPU, & RAM Floating Monitor", "Monitor statistik tersedia; FPS/GPU tidak selalu bisa dibaca di game lain.", PARTIAL, GameHudActivity.class),
            f("Picture-in-Picture Floating App Multitasking", "Mini Browser TeinBooster dapat diminimalkan ke PiP di perangkat yang mendukung; aplikasi lain harus mendukung PiP sendiri.", PARTIAL, MiniBrowserActivity.class),
            f("Virtual On-Screen Reticle / Custom Crosshair Overlay", "Retikel visual tersedia; dapat dilarang oleh game/anti-cheat.", YES, GameUtilitiesActivity.class),
            f("Key Remapping & Macro Scripting", "Tidak ada remap input global atau macro universal tanpa akses khusus.", NO, null),
            f("Automatic Game Screen Capture Resolution Tuning", "Perekam layar tersedia; resolusi capture otomatis mengikuti game tidak didukung.", PARTIAL, ScreenRecorderActivity.class),
            f("Navigation Lock / Anti-Mistouch", "Tidak bisa mengunci navigasi sistem secara universal; gunakan fitur game/OEM.", NO, null),
            f("Brightness Lock", "Kecerahan bisa diatur lewat Android/OEM; penguncian global saat game tidak tersedia universal.", PARTIAL, TurboActivity.class),
            f("Floating Chat Bubble Support", "Bubble bergantung aplikasi chat dan izin sistem; tidak dapat membuat bubble bagi semua aplikasi.", PARTIAL, GamePanelActivity.class),
            f("Floating Browser Shortcut", "Mini Browser internal tersedia dan dapat diminimalkan ke PiP; bukan browser universal yang memaksa semua aplikasi jadi jendela.", PARTIAL, MiniBrowserActivity.class)
        });

        addGroup(col, "Jaringan & koneksi", new Feature[]{
            f("GPN (Gamers Private Network) Routing", "Perlu layanan VPN/routing khusus; tidak disediakan dan tidak menjamin ping lebih rendah.", NO, NetworkActivity.class),
            f("Dual-Channel Network Acceleration", "Android tidak memberi aplikasi umum kendali universal untuk menggabungkan Wi-Fi dan seluler.", NO, NetworkActivity.class),
            f("Network Priority / Traffic Shaper", "QoS global membutuhkan dukungan router/firmware; bukan kontrol aplikasi biasa.", NO, NetworkActivity.class),
            f("Wi-Fi Channel Optimizer", "Bisa memeriksa koneksi dasar; pemilihan channel router harus dilakukan di router.", PARTIAL, NetworkActivity.class),
            f("Bluetooth Coexistence Optimization", "Pengaturan radio coexistence dikendalikan firmware/OEM.", NO, null),
            f("DNS Changer / Low Latency DNS", "DNS Pribadi Cloudflare/Google tersedia melalui Shizuku ADB; DNS tidak menjamin ping game turun.", PARTIAL, CompanionAccessActivity.class),
            f("Packet Loss Compensator", "Perbaikan packet loss harus ditangani game/jaringan; aplikasi tidak bisa mengoreksi paket game terenkripsi.", NO, NetworkActivity.class)
        });

        addGroup(col, "Audio, daya & suhu", new Feature[]{
            f("Voice Changer / Sound Modifier", "Efek suara hanya bisa memproses audio yang masuk ke aplikasi; tidak bisa mengubah mic game lain universal.", NO, SoundVisualizerActivity.class),
            f("Bluetooth Stereo Audio Enhancer", "Profil codec dan kualitas dikendalikan perangkat/earphone; tidak ada booster universal.", PARTIAL, SoundVisualizerActivity.class),
            f("Voice Isolation / Noise Cancellation Boost", "Memerlukan dukungan mikrofon, OEM, atau aplikasi komunikasi yang digunakan.", PARTIAL, SoundVisualizerActivity.class),
            f("Bypass Charging / Charge Separation / Passthrough Power", "Butuh dukungan hardware/firmware; tidak bisa dipaksa aplikasi non-root.", NO, BatteryActivity.class),
            f("Smart Fan Control / Active Cooler Sync", "Tidak ada protokol cooler universal; pantau suhu tersedia.", PARTIAL, CoolerActivity.class),
            f("Haptic Feedback Boost / Touch Vibration Tuning", "Intensitas global dibatasi Android/OEM; buka setelan sistem.", PARTIAL, TurboActivity.class),
            f("Audio Delay Reducer / Gaming Audio Mode", "Latensi audio bergantung game, driver, codec, dan headset; tidak dapat dipaksa universal.", PARTIAL, SoundVisualizerActivity.class),
            f("Battery Health Monitor / Thermal Alert", "Status baterai dan suhu dasar tersedia; health cycle/kapasitas akurat tergantung OEM.", PARTIAL, BatteryActivity.class),
            f("Battery Limiter Max Charge Percentage", "Android umum tidak menyediakan kontrol batas isi daya; perlu fitur bawaan OEM.", NO, BatteryActivity.class)
        });

        addGroup(col, "Utilitas & rekam", new Feature[]{
            f("Do Not Disturb (DND) Gaming Mode", "Kontrol DND nyata tersedia di kartu atas setelah izin kebijakan notifikasi.", YES, null),
            f("Do Not Disturb Exceptions for VIP Contacts", "Pengecualian VIP harus diatur pada setelan DND Android.", PARTIAL, null),
            f("Screen Recorder & GIF Creator", "Perekam layar MP4 tersedia; pembuat GIF belum ada.", PARTIAL, ScreenRecorderActivity.class),
            f("Game Clock / Alarm", "Timer/cooldown tersedia; alarm latar yang andal perlu izin/notifikasi dan optimasi baterai OEM.", PARTIAL, GameUtilitiesActivity.class),
            f("In-Game Guide Overlay / Walkthrough Viewer", "Panduan game tersedia di aplikasi; overlay walkthrough universal belum ada.", PARTIAL, GameCoachActivity.class),
            f("Screenshot Gallery Quick Access", "Akses pemilih gambar/screenshot tersedia.", YES, GameUtilitiesActivity.class),
        });

        LinearLayout note = Ui.card(this);
        note.addView(Ui.tvb(this, "Penting", 14, Ui.TEXT));
        note.addView(Ui.tv(this, "Minimum Android 10 (API 29). Shizuku bukan root; akses ADB tetap terbatas. Wireless debugging untuk mulai Shizuku langsung di HP tersedia di Android 11+, sedangkan Android 10 biasanya perlu bantuan komputer/ADB untuk memulai sesi. Brevent adalah layanan terpisah dan tidak menggantikan izin Shizuku.", 11, Ui.SUB));
        if (!shizukuAtCreate) note.addView(Ui.button(this, "Aktifkan fitur ADB (Shizuku)", v -> startActivity(new Intent(this, CompanionAccessActivity.class))), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(note, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        updateDndStatus();
    }

    private void addGroup(LinearLayout parent, String title, Feature[] features) {
        List<Feature> visible = new ArrayList<>();
        boolean adbReady = hasShizukuAdb();
        for (Feature feature : features) {
            boolean adbOnly = feature.name.equals("Manual Refresh Rate Controller") || feature.name.equals("DNS Changer / Low Latency DNS");
            if (adbOnly && !adbReady) continue;
            visible.add(feature);
        }
        if (visible.isEmpty()) return;
        LinearLayout card = Ui.card(this);
        LinearLayout header = Ui.row(this);
        TextView name = Ui.tvb(this, title, 14, Ui.TEXT);
        header.addView(name, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView count = Ui.chip(this, visible.size() + " fitur  +", Ui.CYAN);
        header.addView(count);
        card.addView(header);
        LinearLayout rows = Ui.col(this);
        rows.setVisibility(View.GONE);
        for (Feature feature : visible) {
            LinearLayout row = Ui.col(this);
            row.setPadding(Ui.dp(this, 0), Ui.dp(this, 8), Ui.dp(this, 0), Ui.dp(this, 8));
            row.addView(Ui.tvb(this, feature.name, 12, Ui.TEXT));
            row.addView(Ui.tv(this, feature.note, 10, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
            LinearLayout action = Ui.row(this);
            String status = feature.status == YES ? "TERSEDIA" : feature.status == PARTIAL ? "SEBAGIAN" : "TIDAK DIDUKUNG";
            int color = feature.status == YES ? Ui.MINT : feature.status == PARTIAL ? Ui.EMBER : Ui.SUB;
            action.addView(Ui.chip(this, status, color), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            if (feature.target != null) action.addView(Ui.ghost(this, "Buka", v -> startActivity(new Intent(this, feature.target))));
            else if (feature.name.contains("VIP Contacts")) action.addView(Ui.ghost(this, "Atur DND", v -> openDndSettings()));
            row.addView(action, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
            rows.addView(row);
            rows.addView(Ui.divider(this));
        }
        card.addView(rows, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        header.setOnClickListener(v -> {
            boolean show = rows.getVisibility() != View.VISIBLE;
            rows.setVisibility(show ? View.VISIBLE : View.GONE);
            count.setText(visible.size() + (show ? " fitur  −" : " fitur  +"));
        });
        parent.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
    }

    private void updateDndStatus() {
        if (dndStatus == null || nm == null) return;
        if (!nm.isNotificationPolicyAccessGranted()) dndStatus.setText("Izin belum diberikan. DND belum diubah.");
        else dndStatus.setText("Status: " + (nm.getCurrentInterruptionFilter() == NotificationManager.INTERRUPTION_FILTER_ALL ? "DND mati" : "filter DND aktif"));
    }

    private void toggleDnd() {
        if (!nm.isNotificationPolicyAccessGranted()) { openDndSettings(); Toast.makeText(this, "Izinkan akses Jangan Ganggu, lalu kembali dan tekan tombol lagi.", Toast.LENGTH_LONG).show(); return; }
        try {
            int current = nm.getCurrentInterruptionFilter();
            int next = current == NotificationManager.INTERRUPTION_FILTER_ALL ? NotificationManager.INTERRUPTION_FILTER_PRIORITY : NotificationManager.INTERRUPTION_FILTER_ALL;
            nm.setInterruptionFilter(next);
            Toast.makeText(this, next == NotificationManager.INTERRUPTION_FILTER_ALL ? "DND dimatikan" : "DND diaktifkan", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "Android/OEM menolak perubahan DND. Atur dari Pengaturan.", Toast.LENGTH_LONG).show(); }
        updateDndStatus();
    }

    private void openDndSettings() {
        try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); }
        catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
    }

    private boolean hasShizukuAdb() {
        try {
            return Shizuku.pingBinder() && Shizuku.getUid() == 2000
                    && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable e) { return false; }
    }

    @Override protected void onResume() {
        super.onResume();
        boolean ready = hasShizukuAdb();
        if (ready != shizukuAtCreate) { recreate(); return; }
        updateDndStatus();
    }
}
