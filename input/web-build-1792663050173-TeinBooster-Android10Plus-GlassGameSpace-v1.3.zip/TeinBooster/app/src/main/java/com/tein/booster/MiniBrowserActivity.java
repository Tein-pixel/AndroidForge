package com.tein.booster;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.URLEncoder;

/** Small built-in browser that can be minimized into PiP on devices that support it. */
public class MiniBrowserActivity extends Activity {
    private LinearLayout root, top, addressRow, actions;
    private EditText address;
    private WebView web;
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        int savedTheme = Prefs.getInt(this, Prefs.UI_THEME, 3);
        setTheme(savedTheme == 2 ? R.style.AppThemeLight : (savedTheme == 1 ? R.style.AppTheme : R.style.AppThemeBlack));
        super.onCreate(savedInstanceState);
        Ui.applyTheme(this); Ui.applyWindowTheme(this);

        root = Ui.col(this); root.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8)); root.setBackgroundColor(Ui.BG);
        top = Ui.row(this);
        LinearLayout titleBox = Ui.col(this);
        titleBox.addView(Ui.tvb(this, "Mini Browser", 17, Ui.TEXT));
        titleBox.addView(Ui.tv(this, "Browser mengambang melalui PiP", 10, Ui.SUB));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView exit = Ui.tvb(this, "×", 24, Ui.TEXT); exit.setGravity(Gravity.CENTER); exit.setBackground(Ui.ripple(this, Ui.glassDrawable(this, 13), 13));
        top.addView(exit, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        exit.setOnClickListener(v -> finish());
        root.addView(top);

        addressRow = Ui.row(this);
        address = new EditText(this);
        address.setSingleLine(true); address.setTextSize(14); address.setTextColor(Ui.TEXT); address.setHintTextColor(Ui.SUB);
        address.setHint("URL atau cari di web"); address.setImeOptions(EditorInfo.IME_ACTION_GO); address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8)); address.setBackground(Ui.glassDrawable(this, 14));
        addressRow.addView(address, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f));
        TextView go = Ui.tvb(this, "Buka", 12, Ui.TEXT); go.setGravity(Gravity.CENTER); go.setBackground(Ui.grad(this, Ui.VIOLET, Ui.BLUE, 13));
        LinearLayout.LayoutParams goLp = new LinearLayout.LayoutParams(Ui.dp(this, 62), Ui.dp(this, 48)); goLp.setMargins(Ui.dp(this, 7), 0, 0, 0); addressRow.addView(go, goLp);
        go.setOnClickListener(v -> navigate());
        address.setOnEditorActionListener((v, actionId, event) -> { if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) { navigate(); return true; } return false; });
        root.addView(addressRow, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));

        actions = Ui.row(this);
        TextView pip = Ui.button(this, "Minimalkan ke PiP", v -> enterPip());
        actions.addView(pip, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView home = Ui.ghost(this, "Beranda", v -> loadHome());
        actions.addView(home, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        actions.getChildAt(1).setLayoutParams(new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        root.addView(actions, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 7));

        status = Ui.tv(this, "Buka halaman web lalu minimalkan. Konten web diakses langsung melalui WebView.", 10, Ui.SUB);
        root.addView(status, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 6));

        web = new WebView(this);
        web.setBackgroundColor(Ui.BG);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (address != null) address.setText(url);
                if (status != null) status.setText("Halaman dimuat • PiP bisa berbeda menurut perangkat");
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));
        setContentView(root);
        loadHome();
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            pip.setEnabled(false); pip.setAlpha(0.45f);
            status.setText("Perangkat ini tidak melaporkan dukungan PiP. Browser tetap dapat dipakai di layar penuh.");
        }
    }

    private void navigate() {
        String raw = address.getText() == null ? "" : address.getText().toString().trim();
        if (raw.isEmpty()) return;
        String url;
        if (raw.matches("(?i)^https?://.*")) url = raw;
        else if (raw.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$")) url = "https://" + raw;
        else {
            try { url = "https://duckduckgo.com/?q=" + URLEncoder.encode(raw, "UTF-8"); }
            catch (Exception e) { url = "https://duckduckgo.com/"; }
        }
        try {
            Uri uri = Uri.parse(url);
            if (!("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme()))) {
                status.setText("Hanya alamat HTTP/HTTPS yang didukung."); return;
            }
            web.loadUrl(url);
        } catch (Exception e) { status.setText("Alamat tidak dapat dibuka."); }
    }

    private void loadHome() { if (web != null) web.loadUrl("https://duckduckgo.com"); }

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            status.setText("PiP tidak didukung perangkat ini; gunakan browser layar penuh."); return;
        }
        try {
            PictureInPictureParams params = new PictureInPictureParams.Builder().setAspectRatio(new Rational(9, 16)).build();
            enterPictureInPictureMode(params);
        } catch (Exception e) { status.setText("Android/OEM menolak mode PiP untuk sesi ini."); }
    }

    @Override public void onPictureInPictureModeChanged(boolean inPipMode, android.content.res.Configuration newConfig) {
        super.onPictureInPictureModeChanged(inPipMode, newConfig);
        if (top != null) top.setVisibility(inPipMode ? View.GONE : View.VISIBLE);
        if (addressRow != null) addressRow.setVisibility(inPipMode ? View.GONE : View.VISIBLE);
        if (actions != null) actions.setVisibility(inPipMode ? View.GONE : View.VISIBLE);
        if (status != null) status.setVisibility(inPipMode ? View.GONE : View.VISIBLE);
        if (root != null) root.setPadding(0, 0, 0, 0);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) { web.stopLoading(); web.setWebChromeClient(null); web.setWebViewClient(null); web.destroy(); web = null; }
        super.onDestroy();
    }
}
