package com.tein.booster;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Kumpulan helper UI (semua tampilan dibangun lewat kode agar ringan & minim bug XML). */
public final class Ui {
    // Mutable so a user's saved theme applies consistently across all code-built screens.
    public static int BG = 0xFF000000;
    public static int PANEL = 0xFF0C0C0E;
    public static int PANEL2 = 0xFF17171B;
    public static int LINE = 0xFF28282E;
    public static int TEXT = 0xFFF2F3F5;
    public static int SUB = 0xFF9B9DA8;
    public static int CYAN = 0xFF2EE6FF;
    public static int BLUE = 0xFF3D8BFF;
    public static int VIOLET = 0xFF8B5CFF;
    public static int MINT = 0xFF35E0A1;
    public static int EMBER = 0xFFFFB020;
    public static int CORAL = 0xFFFF5C7A;
    public static int PINK = 0xFFFF5FA8;
    public static int INK = 0xFF06101F;

    /** Tema pilihan: 0 AMOLED, 1 navy, 2 light, 3 purple glass, 4 electric blue, 5 emerald glass. */
    public static void applyTheme(Context c) {
        int mode = Prefs.getInt(c, Prefs.UI_THEME, 3);
        if (mode < 0 || mode > 5) mode = 3;
        if (mode == 1) {
            BG = 0xFF080B18; PANEL = 0xEF11182B; PANEL2 = 0xDD192544; LINE = 0xFF28385D;
            TEXT = 0xFFF0F4FF; SUB = 0xFF9AA9CB; CYAN = 0xFF54DDF4; BLUE = 0xFF4C8DFF;
            VIOLET = 0xFF8776FF; MINT = 0xFF48E0B2; EMBER = 0xFFFFC56A; CORAL = 0xFFFF7089;
            PINK = 0xFFFF70CB; INK = 0xFF071020;
        } else if (mode == 2) {
            BG = 0xFFF3F4FA; PANEL = 0xF7FFFFFF; PANEL2 = 0xFFF0F1FA; LINE = 0xFFE0DFF0;
            TEXT = 0xFF201C2B; SUB = 0xFF716B80; CYAN = 0xFF6550C8; BLUE = 0xFF4F69D9;
            VIOLET = 0xFF7851CD; MINT = 0xFF118B70; EMBER = 0xFF9A5B00; CORAL = 0xFFC43150;
            PINK = 0xFFC2439A; INK = 0xFF171326;
        } else if (mode == 3) {
            // Purple glass inspired by modern gaming hubs; translucent surfaces with violet rims.
            BG = 0xFF090510; PANEL = 0xEB22133D; PANEL2 = 0xDE301858; LINE = 0xFF623AA1;
            TEXT = 0xFFF9F5FF; SUB = 0xFFC0AECF; CYAN = 0xFFDC9BFF; BLUE = 0xFF9E4DFF;
            VIOLET = 0xFFB16CFF; MINT = 0xFF62E6BE; EMBER = 0xFFFFC16B; CORAL = 0xFFFF7395;
            PINK = 0xFFFF78D7; INK = 0xFF1B0A2B;
        } else if (mode == 4) {
            BG = 0xFF050A13; PANEL = 0xE9142037; PANEL2 = 0xDA1B3152; LINE = 0xFF315985;
            TEXT = 0xFFF1F8FF; SUB = 0xFF9CB5CF; CYAN = 0xFF73E7FF; BLUE = 0xFF368DFF;
            VIOLET = 0xFF7C7EFF; MINT = 0xFF52E9C6; EMBER = 0xFFFFCE6A; CORAL = 0xFFFF7688;
            PINK = 0xFF73BFFF; INK = 0xFF051020;
        } else if (mode == 5) {
            BG = 0xFF05100E; PANEL = 0xE9183027; PANEL2 = 0xD8234237; LINE = 0xFF356E58;
            TEXT = 0xFFF0FFF8; SUB = 0xFF9FBDB0; CYAN = 0xFF78F5CD; BLUE = 0xFF38BFA0;
            VIOLET = 0xFF82D8B2; MINT = 0xFF6DE9A8; EMBER = 0xFFFFD179; CORAL = 0xFFFF7F83;
            PINK = 0xFF93E8DF; INK = 0xFF051B16;
        } else {
            BG = 0xFF000000; PANEL = 0xE80C0C11; PANEL2 = 0xD8171722; LINE = 0xFF343044;
            TEXT = 0xFFF2F3F8; SUB = 0xFFA2A2B3; CYAN = 0xFFBCA0FF; BLUE = 0xFF8051FF;
            VIOLET = 0xFFA978FF; MINT = 0xFF5BE2BB; EMBER = 0xFFFFC270; CORAL = 0xFFFF668A;
            PINK = 0xFFFF75D3; INK = 0xFF080510;
        }
    }

    public static int theme(Context c) {
        int t = Prefs.getInt(c, Prefs.UI_THEME, 3);
        return t < 0 || t > 5 ? 3 : t;
    }

    public static void applyWindowTheme(Activity a) {
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(BG);
        if (theme(a) == 2) {
            a.getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        } else {
            a.getWindow().getDecorView().setSystemUiVisibility(0);
        }
    }
    public static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    public static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    public static GradientDrawable rect(Context c, int color, float rDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, rDp));
        return g;
    }

    public static GradientDrawable grad(Context c, int c1, int c2, float rDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(c, rDp));
        return g;
    }

    public static GradientDrawable outline(Context c, int fill, int stroke, float rDp) {
        GradientDrawable g = rect(c, fill, rDp);
        g.setStroke(Math.max(1, dp(c, 1)), stroke);
        return g;
    }

    public static Drawable ripple(Context c, Drawable content, float rDp) {
        return new RippleDrawable(ColorStateList.valueOf(theme(c) == 2 ? 0x18000000 : 0x33FFFFFF), content, rect(c, 0xFFFFFFFF, rDp));
    }

    public static TextView tv(Context c, CharSequence t, float sp, int color) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        return v;
    }

    public static TextView tvb(Context c, CharSequence t, float sp, int color) {
        TextView v = tv(c, t, sp, color);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return v;
    }

    public static TextView num(Context c, CharSequence t, float sp, int color) {
        TextView v = tv(c, t, sp, color);
        v.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        return v;
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** LayoutParams dengan margin dalam dp. */
    public static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    /** Lebar 0 + bobot (untuk baris), margin dalam dp. */
    public static LinearLayout.LayoutParams lpw(Context c, float weight, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, weight);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    /** Glass-like card with a soft top sheen, subtle tint and accent rim. */
    public static GradientDrawable glassDrawable(Context c, float radiusDp) {
        int mode = theme(c);
        int top = mode == 2 ? 0xF9FFFFFF : alpha(VIOLET, mode == 3 ? 0x36 : 0x22);
        int middle = PANEL;
        int bottom = mode == 2 ? 0xF5F1F2FC : alpha(BLUE, mode == 3 ? 0x1F : 0x12);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{top, middle, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1)), alpha(VIOLET, mode == 2 ? 0x60 : 0x78));
        return g;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(glassDrawable(c, 18));
        if (Build.VERSION.SDK_INT >= 21) l.setElevation(dp(c, 2));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static TextView button2(Context c, String text, int c1, int c2, View.OnClickListener click) {
        TextView b = tvb(c, text, 16, INK);
        b.setGravity(Gravity.CENTER);
        b.setBackground(ripple(c, grad(c, c1, c2, 16), 16));
        b.setPadding(dp(c, 20), dp(c, 15), dp(c, 20), dp(c, 15));
        b.setClickable(true);
        b.setOnClickListener(click);
        pressable(b);
        return b;
    }

    public static TextView button(Context c, String text, View.OnClickListener click) {
        return button2(c, text, CYAN, BLUE, click);
    }

    public static TextView ghost(Context c, String text, View.OnClickListener click) {
        TextView b = tvb(c, text, 15, TEXT);
        b.setGravity(Gravity.CENTER);
        b.setBackground(ripple(c, outline(c, 0x00000000, LINE, 16), 16));
        b.setPadding(dp(c, 18), dp(c, 13), dp(c, 18), dp(c, 13));
        b.setClickable(true);
        b.setOnClickListener(click);
        pressable(b);
        return b;
    }

    public static TextView chip(Context c, String text, int color) {
        TextView v = tvb(c, text, 12, color);
        v.setBackground(rect(c, alpha(color, 0x2A), 10));
        v.setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5));
        return v;
    }

    public static TextView badge(Context c, String emoji, int color, float sizeDp) {
        TextView t = new TextView(c);
        t.setText(emoji);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeDp * 0.44f);
        t.setGravity(Gravity.CENTER);
        t.setBackground(grad(c, alpha(color, 0x55), alpha(color, 0x1F), sizeDp * 0.32f));
        int s = dp(c, sizeDp);
        t.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return t;
    }

    public static TextView sectionTitle(Context c, String text) {
        TextView t = tvb(c, text, 15, TEXT);
        t.setPadding(dp(c, 4), dp(c, 20), 0, dp(c, 8));
        return t;
    }

    public static View space(Context c, float hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, hDp)));
        return v;
    }

    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(c, 1))));
        return v;
    }

    public static LinearLayout kv(Context c, String k, String v) {
        LinearLayout r = row(c);
        TextView a = tv(c, k, 13, SUB);
        TextView b = tvb(c, v, 13, TEXT);
        b.setGravity(Gravity.END);
        r.addView(a, new LinearLayout.LayoutParams(0, WRAP, 0.85f));
        r.addView(b, new LinearLayout.LayoutParams(0, WRAP, 1.15f));
        r.setPadding(0, dp(c, 7), 0, dp(c, 7));
        return r;
    }

    public static void pressable(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                }
                return false;
            }
        });
    }

    /** Animasi masuk berurutan (sekali, saat layar dibuka). */
    public static void reveal(View... views) {
        int i = 0;
        for (View v : views) {
            v.setAlpha(0f);
            v.setTranslationY(v.getResources().getDisplayMetrics().density * 14f);
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 55L).setDuration(380)
                    .setInterpolator(new DecelerateInterpolator()).start();
            i++;
        }
    }

    public static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    public static void copy(Context c, String label, String text) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
        } catch (Exception ignored) {
        }
    }

    public static void confirm(Activity a, String title, String msg, String ok, final Runnable onOk) {
        new AlertDialog.Builder(a)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(ok, (d, w) -> onOk.run())
                .setNegativeButton("Batal", null)
                .show();
    }

    public interface Pick {
        void onPick(int index);
    }

    /** Kontrol segmen (tab pilihan tunggal) dengan pil gradasi pada yang terpilih. */
    public static LinearLayout segment(final Context c, String[] labels, int selected, final Pick pick) {
        final LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackground(outline(c, PANEL2, LINE, 14));
        int pad = dp(c, 3);
        row.setPadding(pad, pad, pad, pad);
        final TextView[] tabs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = tvb(c, labels[i], 13, TEXT);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(c, 6), dp(c, 10), dp(c, 6), dp(c, 10));
            t.setClickable(true);
            t.setOnClickListener(v -> {
                paintSegment(c, tabs, idx);
                pick.onPick(idx);
            });
            tabs[i] = t;
            row.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        paintSegment(c, tabs, selected);
        return row;
    }

    private static void paintSegment(Context c, TextView[] tabs, int sel) {
        for (int i = 0; i < tabs.length; i++) {
            boolean on = i == sel;
            tabs[i].setTextColor(on ? INK : SUB);
            tabs[i].setBackground(on ? grad(c, CYAN, BLUE, 11) : rect(c, 0x00000000, 11));
        }
    }
}
