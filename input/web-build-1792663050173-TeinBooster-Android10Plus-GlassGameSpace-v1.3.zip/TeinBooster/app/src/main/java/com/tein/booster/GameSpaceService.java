package com.tein.booster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import android.app.NotificationManager.Policy;

/** Edge-trigger Game Space. Uses only Android APIs available to ordinary apps; no game injection. */
public class GameSpaceService extends Service {
    public static final String ACTION_START = "com.tein.booster.gamespace.START";
    public static final String ACTION_STOP = "com.tein.booster.gamespace.STOP";
    private static final String CHANNEL = "tein_game_space";
    private static final int NOTIFICATION_ID = 7302;
    public static volatile boolean running = false;

    private WindowManager wm;
    private View handle;
    private View panel;
    private WindowManager.LayoutParams handleParams;
    private WindowManager.LayoutParams panelParams;
    private float downX, downY;
    private boolean openedBySwipe;
    private boolean keepScreen;

    @Override public void onCreate() {
        super.onCreate();
        Ui.applyTheme(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        keepScreen = Prefs.getBool(this, Prefs.GAME_SPACE_KEEP_SCREEN, false);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopSpace(); return START_NOT_STICKY; }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIFICATION_ID, n);
            }
            running = true;
            Prefs.putBool(this, Prefs.GAME_SPACE_ENABLED, true);
            createHandle();
        } catch (Throwable e) {
            stopSpace();
        }
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Game Space", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Panel gaming tepi yang diaktifkan pengguna");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("TeinBooster • Game Space aktif")
                .setContentText("Geser pegangan di tepi layar ke kanan untuk membuka panel")
                .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private int commonFlags() {
        int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (keepScreen) f |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        return f;
    }

    private void createHandle() {
        removeHandle();
        TextView pill = Ui.tvb(this, "›", 26, Ui.TEXT);
        pill.setGravity(Gravity.CENTER);
        pill.setBackground(Ui.glassDrawable(this, 16));
        pill.setElevation(Ui.dp(this, 8));
        handle = pill;
        handleParams = new WindowManager.LayoutParams(Ui.dp(this, 24), Ui.dp(this, 100), overlayType(), commonFlags(), PixelFormat.TRANSLUCENT);
        handleParams.gravity = Gravity.START | Gravity.CENTER_VERTICAL;
        handleParams.x = 0;
        // Keep the touch handle in the upper third, similar to OEM gaming sidebars.
        handleParams.y = -getResources().getDisplayMetrics().heightPixels / 4;
        pill.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY(); openedBySwipe = false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - downX;
                    if (dx > Ui.dp(this, 36) && !openedBySwipe) { openedBySwipe = true; showPanel(); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!openedBySwipe) showPanel();
                    return true;
                case MotionEvent.ACTION_CANCEL: return true;
            }
            return true;
        });
        try { wm.addView(handle, handleParams); } catch (Exception e) { handle = null; stopSpace(); }
    }

    private void showPanel() {
        if (!running || wm == null) return;
        if (panel != null) { hidePanel(); return; }
        LinearLayout shell = Ui.col(this);
        shell.setPadding(Ui.dp(this, 15), Ui.dp(this, 14), Ui.dp(this, 15), Ui.dp(this, 14));
        shell.setBackground(Ui.glassDrawable(this, 26));
        shell.setElevation(Ui.dp(this, 16));

        LinearLayout top = Ui.row(this);
        LinearLayout titleBox = Ui.col(this);
        titleBox.addView(Ui.tvb(this, "GAME SPACE", 16, Ui.TEXT));
        titleBox.addView(Ui.tv(this, "Quick controls • Android 10+", 10, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView close = Ui.tvb(this, "×", 26, Ui.TEXT);
        close.setGravity(Gravity.CENTER); close.setBackground(Ui.ripple(this, Ui.rect(this, 0x22FFFFFF, 14), 14));
        top.addView(close, new LinearLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 38)));
        close.setOnClickListener(v -> hidePanel());
        shell.addView(top);

        ScrollView bodyScroll = new ScrollView(this);
        bodyScroll.setVerticalScrollBarEnabled(false);
        LinearLayout body = Ui.col(this);
        body.addView(Ui.tv(this, "Geser dari pegangan tepi untuk membuka kapan saja. Izin tambahan hanya diminta untuk kontrol yang memang membutuhkannya.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 9));

        addDividerLabel(body, "TAMPILAN");
        TextView brightLabel = Ui.tvb(this, "Kecerahan layar", 12, Ui.TEXT);
        body.addView(brightLabel, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        SeekBar bright = new SeekBar(this); bright.setMax(255);
        int old = 128;
        try { old = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128); } catch (Exception ignored) {}
        bright.setProgress(old);
        boolean canWrite = Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(this);
        bright.setEnabled(canWrite);
        bright.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.VIOLET));
        bright.setThumbTintList(android.content.res.ColorStateList.valueOf(Ui.CYAN));
        bright.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int val, boolean fromUser) {
                if (!fromUser) return;
                if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(GameSpaceService.this)) return;
                int safe = Math.max(8, val);
                try {
                    Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                    Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, safe);
                } catch (Exception ignored) {}
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        body.addView(bright, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 1, 0, 1));
        if (!canWrite) body.addView(Ui.ghost(this, "Izinkan kontrol kecerahan", v -> openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, "package:" + getPackageName())), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 3));

        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        body.addView(Ui.tvb(this, "Volume media", 12, Ui.TEXT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        SeekBar volume = new SeekBar(this);
        int max = audio == null ? 15 : audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int level = audio == null ? 7 : audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        volume.setMax(Math.max(1, max)); volume.setProgress(level);
        volume.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.VIOLET));
        volume.setThumbTintList(android.content.res.ColorStateList.valueOf(Ui.CYAN));
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int val, boolean fromUser) {
                if (fromUser && audio != null) try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, val, 0); } catch (Exception ignored) {}
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        body.addView(volume, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 1, 0, 5));

        LinearLayout keepRow = Ui.row(this);
        LinearLayout keepText = Ui.col(this);
        keepText.addView(Ui.tvb(this, "Layar tetap menyala", 12, Ui.TEXT));
        keepText.addView(Ui.tv(this, "Selama Game Space aktif", 10, Ui.SUB));
        keepRow.addView(keepText, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView keepButton = Ui.chip(this, keepScreen ? "AKTIF" : "MATI", keepScreen ? Ui.MINT : Ui.SUB);
        keepRow.addView(keepButton);
        keepRow.setPadding(Ui.dp(this, 10), Ui.dp(this, 9), Ui.dp(this, 10), Ui.dp(this, 9));
        keepRow.setBackground(Ui.ripple(this, Ui.rect(this, 0x20FFFFFF, 13), 13));
        keepRow.setOnClickListener(v -> {
            keepScreen = !keepScreen; Prefs.putBool(GameSpaceService.this, Prefs.GAME_SPACE_KEEP_SCREEN, keepScreen);
            keepButton.setText(keepScreen ? "AKTIF" : "MATI"); keepButton.setTextColor(keepScreen ? Ui.MINT : Ui.SUB);
            updateKeepScreenFlags();
        });
        body.addView(keepRow, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 2));

        addDividerLabel(body, "GAMING");
        LinearLayout actionRow1 = Ui.row(this);
        actionRow1.addView(actionTile("◈", "Jangan Ganggu", "DND", () -> toggleDnd()), equalWeight());
        actionRow1.addView(actionTile("◉", "Game HUD", "Monitor melayang", () -> startFeature(GameHudService.class, GameHudService.ACTION_START)), spacedWeight());
        body.addView(actionRow1, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));

        LinearLayout actionRow2 = Ui.row(this);
        actionRow2.addView(actionTile("●", "Rekam layar", "Izin diperlukan", () -> openActivity(ScreenRecorderActivity.class)), equalWeight());
        actionRow2.addView(actionTile("▣", "Game Saya", "Pustaka", () -> openActivity(GameLibraryActivity.class)), spacedWeight());
        body.addView(actionRow2, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));

        LinearLayout actionRow3 = Ui.row(this);
        actionRow3.addView(actionTile("⌘", "Game Coach", "Panduan", () -> openActivity(GameCoachActivity.class)), equalWeight());
        actionRow3.addView(actionTile("⚙", "Game Panel", "Pengaturan", () -> openActivity(GamePanelActivity.class)), spacedWeight());
        body.addView(actionRow3, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));

        LinearLayout actionRow4 = Ui.row(this);
        actionRow4.addView(actionTile("▣", "Mini Browser", "Buka sebagai PiP", () -> openActivity(MiniBrowserActivity.class)), equalWeight());
        actionRow4.addView(actionTile("◎", Prefs.getBool(this, Prefs.GAME_SPACE_FOCUS, false) ? "Fokus aktif" : "Mode Fokus", "DND + layar", () -> toggleFocusMode()), spacedWeight());
        body.addView(actionRow4, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        body.addView(Ui.tv(this, "Mini Browser dapat memakai PiP jika perangkat mendukung. Aplikasi lain hanya bisa melayang jika aplikasi tersebut mendukung PiP; TeinBooster tidak bisa memaksa semua aplikasi menjadi jendela atau mengubah FPS internal game.", 10, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        bodyScroll.addView(body);
        shell.addView(bodyScroll, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));

        panel = shell;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int width = Math.min(Ui.dp(this, 350), (int)(screenWidth * 0.86f));
        int height = Math.min(Ui.dp(this, 590), (int)(screenHeight * 0.82f));
        panelParams = new WindowManager.LayoutParams(width, height, overlayType(), commonFlags() | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.START | Gravity.CENTER_VERTICAL;
        panelParams.x = Ui.dp(this, 8); panelParams.y = 0;
        try {
            wm.addView(panel, panelParams);
            panel.setAlpha(0f); panel.setTranslationX(-Ui.dp(this, 16));
            panel.animate().alpha(1f).translationX(0f).setDuration(180).start();
        } catch (Exception e) { panel = null; }
    }

    private LinearLayout.LayoutParams equalWeight() { return new LinearLayout.LayoutParams(0, Ui.dp(this, 67), 1f); }
    private LinearLayout.LayoutParams spacedWeight() { LinearLayout.LayoutParams lp = equalWeight(); lp.setMargins(Ui.dp(this, 7), 0, 0, 0); return lp; }

    private View actionTile(String icon, String title, String sub, Runnable click) {
        LinearLayout tile = Ui.col(this); tile.setGravity(Gravity.CENTER); tile.setPadding(Ui.dp(this, 5), Ui.dp(this, 8), Ui.dp(this, 5), Ui.dp(this, 8));
        tile.setBackground(Ui.ripple(this, Ui.glassDrawable(this, 15), 15));
        tile.addView(Ui.tvb(this, icon, 18, Ui.VIOLET));
        TextView t = Ui.tvb(this, title, 10, Ui.TEXT); t.setGravity(Gravity.CENTER); t.setMaxLines(1); tile.addView(t, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
        TextView s = Ui.tv(this, sub, 9, Ui.SUB); s.setGravity(Gravity.CENTER); tile.addView(s, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 1, 0, 0));
        tile.setOnClickListener(v -> click.run()); Ui.pressable(tile); return tile;
    }

    private void addDividerLabel(LinearLayout parent, String label) {
        TextView t = Ui.tvb(this, label, 10, Ui.VIOLET);
        t.setLetterSpacing(0.12f);
        parent.addView(t, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 1));
        parent.addView(Ui.divider(this));
    }

    private void toggleDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 23 && !nm.isNotificationPolicyAccessGranted()) {
            openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null);
            Toast.makeText(this, "Beri akses Jangan Ganggu, lalu buka panel lagi.", Toast.LENGTH_LONG).show(); return;
        }
        try {
            if (Prefs.getBool(this, Prefs.DND_ACTIVE, false)) {
                GameBoosterActivity.restoreDnd(this);
                Toast.makeText(this, "Mode Jangan Ganggu sebelumnya dipulihkan", Toast.LENGTH_SHORT).show();
            } else {
                GameBoosterActivity.enableDnd(this);
                Toast.makeText(this, "Mode Jangan Ganggu prioritas diaktifkan", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) { Toast.makeText(this, "DND ditolak sistem. Periksa izin atau pengaturan OEM.", Toast.LENGTH_LONG).show(); }
    }

    private void updateKeepScreenFlags() {
        if (handleParams != null && handle != null) {
            handleParams.flags = commonFlags(); try { wm.updateViewLayout(handle, handleParams); } catch (Exception ignored) {}
        }
        if (panelParams != null && panel != null) {
            panelParams.flags = commonFlags() | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL; try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) {}
        }
    }

    private void toggleFocusMode() {
        boolean focus = !Prefs.getBool(this, Prefs.GAME_SPACE_FOCUS, false);
        Prefs.putBool(this, Prefs.GAME_SPACE_FOCUS, focus);
        if (focus) {
            Prefs.putBool(this, Prefs.GAME_SPACE_KEEP_PREV, keepScreen);
            keepScreen = true; Prefs.putBool(this, Prefs.GAME_SPACE_KEEP_SCREEN, true); updateKeepScreenFlags();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && (Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted())) {
                GameBoosterActivity.enableDnd(this);
            } else {
                openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null);
                Toast.makeText(this, "Fokus aktif dengan layar tetap menyala. Beri izin DND untuk membisukan notifikasi.", Toast.LENGTH_LONG).show();
            }
            Toast.makeText(this, "Mode Fokus aktif.", Toast.LENGTH_SHORT).show();
        } else {
            keepScreen = Prefs.getBool(this, Prefs.GAME_SPACE_KEEP_PREV, false);
            Prefs.putBool(this, Prefs.GAME_SPACE_KEEP_SCREEN, keepScreen); updateKeepScreenFlags();
            if (Prefs.getBool(this, Prefs.DND_ACTIVE, false)) GameBoosterActivity.restoreDnd(this);
            Toast.makeText(this, "Mode Fokus dimatikan.", Toast.LENGTH_SHORT).show();
        }
        hidePanel(); showPanel();
    }

    private void openSettings(String action, String data) {
        try {
            Intent i = new Intent(action); if (data != null) i.setData(Uri.parse(data));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        } catch (Exception ignored) { Toast.makeText(this, "Pengaturan tidak tersedia di perangkat ini.", Toast.LENGTH_SHORT).show(); }
    }

    private void openActivity(Class<?> activity) {
        try { Intent i = new Intent(this, activity); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); hidePanel(); }
        catch (Exception e) { Toast.makeText(this, "Fitur tidak dapat dibuka saat ini.", Toast.LENGTH_SHORT).show(); }
    }

    private void startFeature(Class<?> service, String action) {
        try {
            Intent i = new Intent(this, service); i.setAction(action);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Game HUD diminta aktif. Jika gagal, periksa izin overlay.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "HUD tidak dapat dijalankan.", Toast.LENGTH_SHORT).show(); }
    }

    private void hidePanel() {
        if (panel != null && wm != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
        panel = null; panelParams = null;
    }

    private void removeHandle() {
        if (handle != null && wm != null) { try { wm.removeView(handle); } catch (Exception ignored) {} }
        handle = null; handleParams = null;
    }

    private void stopSpace() {
        running = false; Prefs.putBool(this, Prefs.GAME_SPACE_ENABLED, false); hidePanel(); removeHandle();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        running = false; Prefs.putBool(this, Prefs.GAME_SPACE_ENABLED, false); hidePanel(); removeHandle(); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
