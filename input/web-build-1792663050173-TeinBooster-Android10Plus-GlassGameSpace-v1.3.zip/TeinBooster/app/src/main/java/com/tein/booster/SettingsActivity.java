package com.tein.booster;

import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Pengaturan: Auto Boost terjadwal, daftar putih, tips ubin Quick Settings, tentang. */
public class SettingsActivity extends BaseActivity {
    private static final int[] HOURS = {0, 1, 3, 6, 12};
    private TextView wlInfo;
    private LinearLayout batteryHint;

    @Override
    protected String title() { return "Pengaturan"; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout col = scrollBody();

        LinearLayout appearance = Ui.card(this);
        appearance.addView(Ui.tvb(this, "Tampilan aplikasi", 16, Ui.TEXT));
        appearance.addView(Ui.tv(this, "Pilih gaya antarmuka. Pilih AMOLED, glass ungu/biru/hijau, navy atau tema terang.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        int selectedTheme = Math.max(0, Math.min(5, Prefs.getInt(this, Prefs.UI_THEME, 3)));
        appearance.addView(themeChoiceRow(new String[]{"AMOLED", "Navy", "Terang"}, new int[]{0, 1, 2}, selectedTheme), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        appearance.addView(themeChoiceRow(new String[]{"Purple Glass", "Electric Blue", "Emerald"}, new int[]{3, 4, 5}, selectedTheme), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(appearance, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout gameSpace = Ui.card(this);
        gameSpace.addView(Ui.tvb(this, "Game Space melayang", 16, Ui.TEXT));
        gameSpace.addView(Ui.tv(this, "Panel tepi yang bisa dibuka dengan menggeser pegangan kiri ke kanan saat bermain. Berisi slider kecerahan/volume, DND, layar tetap menyala, HUD, perekam dan pintasan game. Membutuhkan izin tampil di atas aplikasi lain; brightness global juga memerlukan izin ubah pengaturan.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        gameSpace.addView(Ui.button(this, GameSpaceService.running ? "Matikan Game Space" : "Aktifkan Game Space", v -> toggleGameSpace()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        gameSpace.addView(Ui.ghost(this, "Buka pengaturan izin overlay", v -> openOverlaySettings()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        col.addView(gameSpace, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout tutorial = Ui.card(this);
        tutorial.addView(Ui.tvb(this, "Tutorial", 16, Ui.TEXT));
        tutorial.addView(Ui.tv(this, "Panduan ringkas fitur booster dan izin yang dibutuhkan.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        tutorial.addView(Ui.button(this, "Buka tutorial", v -> showTutorial()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(tutorial, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout adb = Ui.card(this);
        adb.addView(Ui.tvb(this, "Integrasi non-root", 16, Ui.TEXT));
        adb.addView(Ui.tv(this, "Status Shizuku ADB, kontrol refresh rate opsional, akses Brevent, timer game dan galeri screenshot.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        adb.addView(Ui.button(this, "Buka integrasi ADB", v -> startActivity(new Intent(this, CompanionAccessActivity.class))), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(adb, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout auto = Ui.card(this);
        auto.addView(Ui.tvb(this, "Auto Boost", 16, Ui.TEXT));
        auto.addView(Ui.tv(this, "Menutup proses latar & menghapus cache Tein Booster secara berkala di latar belakang.", 13, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        int cur = Prefs.getInt(this, Prefs.AUTO_HOURS, 0);
        int sel = 0;
        for (int i = 0; i < HOURS.length; i++) if (HOURS[i] == cur) sel = i;
        auto.addView(Ui.segment(this, new String[]{"Mati", "1 jam", "3 jam", "6 jam", "12 jam"}, sel, i -> {
            Prefs.putInt(this, Prefs.AUTO_HOURS, HOURS[i]);
            AutoBoostService.schedule(getApplicationContext(), HOURS[i]);
            Ui.toast(this, HOURS[i] == 0 ? "Auto Boost dimatikan" : "Auto Boost tiap " + HOURS[i] + " jam");
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        batteryHint = Ui.col(this);
        batteryHint.addView(Ui.tv(this, "Agar tidak dimatikan sistem, izinkan abaikan optimasi baterai.", 12, Ui.EMBER),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        batteryHint.addView(Ui.ghost(this, "Izinkan", v -> Perm.openBattery(this)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        auto.addView(batteryHint);
        col.addView(auto);

        LinearLayout wl = Ui.card(this);
        wl.addView(Ui.tvb(this, "Daftar putih", 16, Ui.TEXT));
        wlInfo = Ui.tv(this, "", 13, Ui.SUB);
        wl.addView(wlInfo, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        wl.addView(Ui.ghost(this, "Pilih aplikasi yang dilindungi", v -> {
            Intent i = new Intent(this, AppPickerActivity.class);
            i.putExtra(AppPickerActivity.EXTRA_MODE, "whitelist");
            startActivity(i);
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(wl, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout tile = Ui.card(this);
        tile.addView(Ui.tvb(this, "Akses cepat", 16, Ui.TEXT));
        tile.addView(Ui.tv(this, "\u2022 Ubin Quick Settings \"Boost\": tarik panel notifikasi \u2192 ikon pensil \u2192 seret ubin Boost.\n"
                + "\u2022 Tekan lama ikon Tein Booster di layar utama untuk pintasan Boost RAM, Cache Cleaner, dan Junk Cleaner.", 13, Ui.SUB),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(tile, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout about = Ui.card(this);
        about.addView(Ui.tvb(this, "Tentang Tein Booster", 16, Ui.TEXT));
        about.addView(Ui.tv(this, "Versi " + appVersion() + "\nBooster memakai API Android yang tersedia tanpa root. Beberapa fitur dibatasi oleh kebijakan sistem/OEM.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        about.addView(Ui.ghost(this, "Pusat Izin", v -> startActivity(new Intent(this, PermissionsActivity.class))), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(about, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));

        LinearLayout help = Ui.card(this);
        help.addView(Ui.tvb(this, "Bantuan & legal", 16, Ui.TEXT));
        help.addView(Ui.button(this, "Laporkan masalah / minta fitur", v -> reportProblem()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        help.addView(Ui.ghost(this, "Kebijakan privasi", v -> showPrivacy()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(help, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
    }

    private View themeChoiceRow(String[] labels, int[] indices, int selected) {
        LinearLayout row = Ui.row(this);
        for (int i = 0; i < labels.length; i++) {
            final int theme = indices[i];
            TextView option = Ui.tvb(this, labels[i], 10, theme == selected ? Ui.TEXT : Ui.SUB);
            option.setGravity(android.view.Gravity.CENTER);
            option.setMaxLines(2);
            option.setPadding(Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 12));
            option.setBackground(Ui.ripple(this, theme == selected ? Ui.grad(this, Ui.alpha(Ui.VIOLET, 0xC8), Ui.alpha(Ui.BLUE, 0x99), 13) : Ui.glassDrawable(this, 13), 13));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
            if (i > 0) lp.setMargins(Ui.dp(this, 6), 0, 0, 0);
            row.addView(option, lp);
            option.setOnClickListener(v -> {
                Prefs.putInt(this, Prefs.UI_THEME, theme);
                Ui.applyTheme(this);
                Ui.toast(this, "Tema " + labels[indexOf(indices, theme)] + " dipilih");
                recreate();
            });
        }
        return row;
    }

    private int indexOf(int[] values, int target) {
        for (int i = 0; i < values.length; i++) if (values[i] == target) return i;
        return 0;
    }

    private void openOverlaySettings() {
        try { startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + getPackageName()))); }
        catch (Exception e) { Ui.toast(this, "Pengaturan overlay tidak tersedia."); }
    }

    private void toggleGameSpace() {
        Intent i = new Intent(this, GameSpaceService.class);
        if (GameSpaceService.running) {
            i.setAction(GameSpaceService.ACTION_STOP); startService(i); Ui.toast(this, "Game Space dimatikan.");
        } else if (android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            Prefs.putBool(this, Prefs.GAME_SPACE_PENDING, true); openOverlaySettings();
            Ui.toast(this, "Izinkan overlay, lalu kembali untuk mengaktifkan panel.");
            return;
        } else {
            i.setAction(GameSpaceService.ACTION_START);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Ui.toast(this, "Game Space diaktifkan. Geser pegangan kiri ke kanan.");
        }
        recreate();
    }

    private String appVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "tidak diketahui"; }
    }

    private void showTutorial() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Tutorial Tein Booster")
                .setMessage("1. Buka Pusat Gaming untuk GFX Guide, HUD, monitor, tes sentuhan/kontroler, latihan gamer, Game Coach, perpustakaan game, panel, perekam layar, dan meter suara.\n\n"
                        + "2. Game Saya hanya menampilkan aplikasi yang terpasang dan dapat dibuka. Jadikan game utama untuk menambahkannya ke daftar Game Booster.\n\n"
                        + "3. Rekam layar membutuhkan persetujuan Android setiap kali dimulai. HUD membutuhkan izin overlay. Meter suara meminta izin mikrofon ketika kamu menekan Mulai dan berhenti saat halaman ditinggalkan.\n\n"
                        + "4. GFX Guide adalah saran manual. Atur grafis dari menu di dalam game; aplikasi ini tidak bisa memaksa FPS/GPU game.")
                .setPositiveButton("Mengerti", null).show();
    }

    private void showPrivacy() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Kebijakan privasi ringkas")
                .setMessage("Fitur utama memproses data perangkat secara lokal. Daftar aplikasi, favorit, dan pilihan grafis disimpan di preferensi aplikasi.\n\n"
                        + "Tes jaringan hanya berjalan saat kamu memulainya dan akan menghubungkan perangkat ke layanan tes yang ditampilkan di fitur itu. Perekam layar memakai dialog persetujuan Android setiap sesi. Meter suara mengakses mikrofon hanya saat aktif; file temporer dihapus ketika pengukuran dihentikan.\n\n"
                        + "Kode proyek ini tidak memasang analitik atau pelacak iklan. Hati-hati saat membagikan rekaman/screenshot karena isinya dapat memuat informasi pribadi.")
                .setPositiveButton("Tutup", null).show();
    }

    private void reportProblem() {
        String body = "Tein Booster version: " + appVersion() + "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nPerangkat: " + Build.MANUFACTURER + " " + Build.MODEL
                + "\n\nMasalah / fitur yang diminta:\n\nLangkah untuk mengulangi masalah (jika ada): ";
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Laporan Tein Booster");
        send.putExtra(Intent.EXTRA_TEXT, body);
        try { startActivity(Intent.createChooser(send, "Kirim laporan melalui aplikasi pilihanmu")); }
        catch (Exception e) { Ui.copy(this, "Laporan Tein Booster", body); Ui.toast(this, "Tidak ada aplikasi berbagi. Laporan disalin ke clipboard."); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Prefs.getBool(this, Prefs.GAME_SPACE_PENDING, false)) {
            Prefs.putBool(this, Prefs.GAME_SPACE_PENDING, false);
            if (android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)) {
                Intent i = new Intent(this, GameSpaceService.class); i.setAction(GameSpaceService.ACTION_START);
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
                Ui.toast(this, "Game Space aktif. Geser pegangan kiri ke kanan.");
                recreate();
                return;
            } else Ui.toast(this, "Izin overlay belum diberikan. Game Space belum aktif.");
        }
        wlInfo.setText(Prefs.getSet(this, Prefs.WHITELIST).size() + " aplikasi tidak akan ditutup atau dibersihkan.");
        batteryHint.setVisibility(Perm.batteryWhitelist(this) ? View.GONE : View.VISIBLE);
    }
}
