package app.yomikaze.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashOverlay(onFinished: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.88f) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.coroutineScope {
            launch { alpha.animateTo(1f, tween(420, easing = FastOutSlowInEasing)) }
            launch { scale.animateTo(1f, tween(520, easing = FastOutSlowInEasing)) }
        }
        delay(650)
        alpha.animateTo(0f, tween(260))
        onFinished()
    }
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(
        listOf(Color(0xFF0F0F13), Color(0xFF17152A), Color(0xFF0F0F13)))),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(13.dp), modifier = Modifier.alpha(alpha).scale(scale)) {
            Box(Modifier.size(76.dp).background(
                Brush.linearGradient(listOf(Color(0xFF7867F2), Color(0xFF353078))), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.AutoStories, contentDescription = null, tint = Color.White,
                    modifier = Modifier.size(40.dp))
            }
            Text("YOMIKAZE", color = Color.White, fontSize = 25.sp, letterSpacing = 3.sp,
                style = MaterialTheme.typography.titleLarge)
            Text("Ruang baca cerita favoritmu", color = Color(0xFFB9B6C7),
                style = MaterialTheme.typography.labelMedium)
        }
    }
}
