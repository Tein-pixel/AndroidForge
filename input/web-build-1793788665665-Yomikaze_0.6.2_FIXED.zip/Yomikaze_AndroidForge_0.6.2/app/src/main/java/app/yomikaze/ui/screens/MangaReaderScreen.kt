package app.yomikaze.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.app.Activity
import android.content.ContextWrapper
import androidx.compose.runtime.DisposableEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.core.ChapterContent
import app.yomikaze.core.ReadingMode
import app.yomikaze.ui.ReaderViewModel
import coil3.compose.AsyncImage
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.collect

@Composable
fun MangaReaderScreen(
    onBack: () -> Unit,
    viewModel: ReaderViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val content = state.content
    val view = LocalView.current
    DisposableEffect(view) {
        val activity = generateSequence(view.context) { context ->
            if (context is ContextWrapper) context.baseContext else null
        }.filterIsInstance<Activity>().firstOrNull()
        val window = activity?.window
        val controller = window?.let { WindowInsetsControllerCompat(it, view) }
        if (window != null && controller != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            if (window != null) WindowCompat.setDecorFitsSystemWindows(window, false)
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        ReaderTopBar(
            title = state.chapter?.let { chapter ->
                "Bab ${chapter.number}" + chapter.title?.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()
            } ?: "Pembaca Yomikaze",
            onBack = onBack,
            current = state.page + 1,
            total = (content as? ChapterContent.Images)?.pages?.size ?: 0,
        )
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when {
                state.loading -> CircularProgressIndicator(color = Color(0xFF86AFFF))
                state.error != null -> Text(
                    state.error ?: "Gagal memuat bab.",
                    color = Color.White,
                    modifier = Modifier.padding(24.dp),
                )
                content is ChapterContent.Images -> {
                    val pages = content.pages
                    when {
                        pages.isEmpty() -> Text("Tidak ada halaman.", color = Color.White)
                        state.readingMode == ReadingMode.WEBTOON -> {
                            key(state.chapter?.id) {
                                VerticalImageReader(
                                    pages = pages,
                                    initialPage = state.page,
                                    onPageChanged = viewModel::onPageChanged,
                                )
                            }
                        }
                        else -> {
                            key(state.chapter?.id) {
                                PagedImageReader(
                                    pages = pages,
                                    initialPage = state.page,
                                    onPageChanged = viewModel::onPageChanged,
                                )
                            }
                        }
                    }
                }
                content is ChapterContent.Text -> Text(
                    "Bab ini berisi teks. Buka melalui pembaca novel.",
                    color = Color.White,
                    modifier = Modifier.padding(24.dp),
                )
                else -> Text("Konten tidak tersedia.", color = Color.White)
            }
        }
        ReaderBottomBar(
            previousEnabled = viewModel.previousChapter() != null,
            nextEnabled = viewModel.nextChapter() != null,
            onPrevious = { viewModel.previousChapter()?.let { viewModel.load(it.id) } },
            onNext = { viewModel.nextChapter()?.let { viewModel.load(it.id) } },
        )
    }
}

@Composable
private fun ReaderTopBar(title: String, onBack: () -> Unit, current: Int, total: Int) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF090C11)).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Kembali", tint = Color.White)
        }
        Text(title, modifier = Modifier.weight(1f), color = Color.White,
            style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (total > 0) {
            Text("$current/$total", color = Color(0xFFB8C3D3),
                style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp))
        }
    }
}

@Composable
private fun ReaderBottomBar(
    previousEnabled: Boolean,
    nextEnabled: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF090C11)).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("YOMIKAZE", color = Color(0xFF9BB9F7), style = MaterialTheme.typography.labelLarge)
        Row {
            IconButton(onClick = onPrevious, enabled = previousEnabled) {
                Icon(Icons.Default.NavigateBefore, contentDescription = "Bab sebelumnya",
                    tint = if (previousEnabled) Color.White else Color.DarkGray)
            }
            IconButton(onClick = onNext, enabled = nextEnabled) {
                Icon(Icons.Default.NavigateNext, contentDescription = "Bab berikutnya",
                    tint = if (nextEnabled) Color.White else Color.DarkGray)
            }
        }
    }
}

@Composable
private fun VerticalImageReader(
    pages: List<app.yomikaze.core.Page>,
    initialPage: Int,
    onPageChanged: (Int, Int) -> Unit,
) {
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = initialPage.coerceIn(0, (pages.size - 1).coerceAtLeast(0)),
    )
    LaunchedEffect(listState, pages.size) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collect { onPageChanged(it, pages.size) }
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        itemsIndexed(pages, key = { _, page -> page.index }) { _, page ->
            AsyncImage(
                model = page.url,
                contentDescription = "Halaman ${page.index + 1}",
                modifier = Modifier.fillMaxWidth(),
                contentScale = ContentScale.FillWidth,
            )
        }
    }
}

@Composable
private fun PagedImageReader(
    pages: List<app.yomikaze.core.Page>,
    initialPage: Int,
    onPageChanged: (Int, Int) -> Unit,
) {
    val pagerState = rememberPagerState(
        initialPage = initialPage.coerceIn(0, (pages.size - 1).coerceAtLeast(0)),
        pageCount = { pages.size },
    )
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }
            .distinctUntilChanged()
            .collect { onPageChanged(it, pages.size) }
    }
    HorizontalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize(),
        key = { pages[it].index },
    ) { index ->
        AsyncImage(
            model = pages[index].url,
            contentDescription = "Halaman ${index + 1}",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit,
        )
    }
}
