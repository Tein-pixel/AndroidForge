package app.yomikaze.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.yomikaze.core.ContentSummary
import app.yomikaze.ui.BrowseViewModel
import app.yomikaze.ui.components.ContentCard
import app.yomikaze.ui.components.EmptyState
import coil3.compose.SubcomposeAsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    onOpen: (String, String) -> Unit,
    onSearch: () -> Unit,
    viewModel: BrowseViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val selectedGenre by viewModel.selectedGenre.collectAsStateWithLifecycle()
    val filteredPopular = remember(state.items, selectedGenre) {
        if (selectedGenre == "Semua Genre") state.items
        else {
            val aliases = when (selectedGenre) {
                "Aksi" -> listOf("action", "aksi")
                "Romansa" -> listOf("romance", "romansa")
                "Fantasi" -> listOf("fantasy", "fantasi")
                "Komedi" -> listOf("comedy", "komedi")
                "Horor" -> listOf("horror", "horor")
                "Misteri" -> listOf("mystery", "misteri")
                else -> listOf(selectedGenre)
            }
            state.items.filter { item -> item.tags.any { tag -> aliases.any { tag.contains(it, ignoreCase = true) } } }
        }
    }
    val featured = filteredPopular.firstOrNull()
    val latest = state.latestItems

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                        Text("Yomikaze", style = MaterialTheme.typography.titleLarge, letterSpacing = 0.4.sp)
                        Text("Baca cerita, temukan dunia baru", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.load(state.category) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Muat ulang")
                    }
                    IconButton(onClick = onSearch) {
                        Icon(Icons.Default.Search, contentDescription = "Cari komik")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(viewModel.categories) { category ->
                    FilterChip(
                        selected = state.category == category,
                        onClick = { viewModel.load(category) },
                        label = { Text(category.label, maxLines = 1) },
                        shape = RoundedCornerShape(50),
                    )
                }
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                items(viewModel.genres) { genre ->
                    FilterChip(
                        selected = selectedGenre == genre,
                        onClick = { viewModel.setGenre(genre) },
                        label = { Text(genre, maxLines = 1) },
                        shape = RoundedCornerShape(50),
                    )
                }
            }

            when {
                state.loading && state.items.isEmpty() && latest.isEmpty() -> BrowseShimmer()
                state.items.isEmpty() && latest.isEmpty() -> {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                        EmptyState(state.error ?: "Katalog belum tersedia. Periksa koneksi, lalu coba lagi.")
                        OutlinedButton(onClick = { viewModel.load(state.category) }) { Text("Coba lagi") }
                    }
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (featured != null) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                SectionHeading("Pilihan untukmu", "Sorotan")
                                FeaturedCard(featured) { onOpen(featured.sourceId, featured.id) }
                            }
                        }
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            SectionHeading("Paling banyak dibaca", "Populer")
                            if (filteredPopular.isEmpty()) {
                                Text("Belum ada judul untuk pilihan ini.", color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.bodySmall)
                            } else {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    items(filteredPopular, key = { "${it.sourceId}:${it.id}" }) { item ->
                                        ContentCard(item, { onOpen(item.sourceId, item.id) }, Modifier.width(138.dp))
                                    }
                                }
                            }
                        }
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        SectionHeading("Bab baru dari sumber aktif", "Update terbaru")
                    }
                    if (latest.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text("Belum ada pembaruan yang tersedia.", color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall)
                        }
                    } else {
                        gridItems(latest, key = { "latest:${it.sourceId}:${it.id}" }) { item ->
                            ContentCard(item, { onOpen(item.sourceId, item.id) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeading(kicker: String, title: String) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Text(kicker, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun FeaturedCard(item: ContentSummary, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(174.dp).clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surface).clickable(onClick = onClick),
    ) {
        SubcomposeAsyncImage(
            model = item.coverUrl,
            contentDescription = item.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            loading = { ShimmerBlock(Modifier.fillMaxSize()) },
            error = { Box(Modifier.fillMaxSize().background(Color(0xFF242333))) },
        )
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(
            listOf(Color(0xF00B0B12), Color(0xB50B0B12), Color(0x160B0B12)))))
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(0.84f).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Surface(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.88f), shape = RoundedCornerShape(50)) {
                Text("PILIHAN EDITOR", Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                    color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
            Text(item.title, color = Color.White, style = MaterialTheme.typography.titleLarge,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${mediaTypeLabel(item.mediaType)}  ·  ${statusLabel(item.status.name)}",
                color = Color(0xFFD8D6E5), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun BrowseShimmer() {
    Column(Modifier.fillMaxSize().padding(top = 18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        ShimmerBlock(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(174.dp))
        ShimmerBlock(Modifier.padding(horizontal = 16.dp).width(116.dp).height(24.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(4) { ShimmerBlock(Modifier.width(138.dp).aspectRatio(0.64f)) }
        }
        ShimmerBlock(Modifier.padding(horizontal = 16.dp).width(150.dp).height(24.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(2) { ShimmerBlock(Modifier.weight(1f).aspectRatio(0.68f)) }
        }
    }
}

@Composable
private fun ShimmerBlock(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "kilau")
    val shift by transition.animateFloat(
        initialValue = -0.7f, targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Restart), label = "pergeseranKilau",
    )
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(
        Brush.linearGradient(
            colors = listOf(Color(0xFF191923), Color(0xFF303044), Color(0xFF191923)),
            start = androidx.compose.ui.geometry.Offset(shift * 500f, 0f),
            end = androidx.compose.ui.geometry.Offset((shift + 0.8f) * 500f, 500f),
        ),
    ))
}

private fun mediaTypeLabel(type: app.yomikaze.core.MediaType): String = when (type) {
    app.yomikaze.core.MediaType.MANGA -> "Manga"
    app.yomikaze.core.MediaType.MANHWA -> "Manhwa"
    app.yomikaze.core.MediaType.MANHUA -> "Manhua"
    app.yomikaze.core.MediaType.COMIC -> "Komik"
    app.yomikaze.core.MediaType.NOVEL -> "Novel"
}

private fun statusLabel(value: String): String = when (value) {
    "ONGOING" -> "Berjalan"
    "COMPLETED" -> "Tamat"
    "HIATUS" -> "Hiatus"
    "CANCELLED" -> "Dihentikan"
    else -> "Belum diketahui"
}
