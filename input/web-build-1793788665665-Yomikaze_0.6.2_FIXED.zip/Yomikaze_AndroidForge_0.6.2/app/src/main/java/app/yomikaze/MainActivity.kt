package app.yomikaze

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import app.yomikaze.ui.YomikazeNavHost
import app.yomikaze.ui.theme.YomikazeTheme
import app.yomikaze.ui.components.SplashOverlay
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YomikazeTheme {
                var showSplash by remember { mutableStateOf(true) }
                Box(Modifier.fillMaxSize()) {
                    Surface(modifier = Modifier.fillMaxSize()) { YomikazeNavHost() }
                    if (showSplash) SplashOverlay(onFinished = { showSplash = false })
                }
            }
        }
    }
}
