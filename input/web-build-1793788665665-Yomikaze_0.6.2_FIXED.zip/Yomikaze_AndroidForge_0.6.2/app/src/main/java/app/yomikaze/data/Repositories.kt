package app.yomikaze.data

import app.yomikaze.core.*
import app.yomikaze.sources.SourceRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CatalogRepository @Inject constructor(
    private val registry: SourceRegistry,
    private val settings: SettingsRepository
) {
    private suspend fun isRestricted() = settings.isRestrictedModeEnabled.first()

    /** Each adapter is isolated: timeout, parser error or adapter cancellation becomes an empty result. */
    private suspend fun <T> safeSourceCall(
        fallback: T,
        block: suspend () -> T,
    ): T = withTimeoutOrNull(SOURCE_TIMEOUT_MS) {
        try {
            block()
        } catch (cancelled: CancellationException) {
            // Preserve cancellation of the caller, but isolate a source that cancels itself.
            if (!currentCoroutineContext().isActive) throw cancelled
            fallback
        } catch (_: Exception) {
            fallback
        }
    } ?: fallback

    suspend fun search(query: String, sourceId: String?, page: Int = 1, limit: Int = 24): List<ContentSummary> = supervisorScope {
        val restricted = isRestricted()
        val sources = if (sourceId != null) {
            listOfNotNull(runCatching { registry.get(sourceId) }.getOrNull())
        } else {
            registry.getActiveSources(restricted)
        }
        sources.map { source ->
            async { safeSourceCall(emptyList()) { source.search(query, page, limit) } }
        }.awaitAll().flatten().let(::prioritizeIndonesian)
    }

    suspend fun popular(category: MediaCategory, page: Int = 1, limit: Int = 24): List<ContentSummary> {
        val restricted = isRestricted()
        if (category == MediaCategory.ALL) return browseAll(restricted, page, 10)
        return supervisorScope {
            registry.forCategory(category, restricted).map { source ->
                async { safeSourceCall(emptyList()) { source.popular(category, page, limit) } }
            }.awaitAll().flatten().let(::prioritizeIndonesian)
        }
    }

    suspend fun latest(page: Int = 1, limit: Int = 18): List<ContentSummary> {
        val restricted = isRestricted()
        return supervisorScope {
            registry.getActiveSources(restricted).map { source ->
                async { safeSourceCall(emptyList()) { source.latest(page, limit) } }
            }.awaitAll().flatten().let(::prioritizeIndonesian).take(limit.coerceAtLeast(1))
        }
    }

    suspend fun browseAll(isRestricted: Boolean, page: Int = 1, perSource: Int = 10): List<ContentSummary> = supervisorScope {
        registry.getActiveSources(isRestricted).map { source ->
            async { safeSourceCall(emptyList()) { source.popular(null, page, perSource) } }
        }.awaitAll().flatten().let(::prioritizeIndonesian)
    }

    /** Indonesian-language catalogs appear first while preserving source-specific entries. */
    private fun prioritizeIndonesian(items: List<ContentSummary>): List<ContentSummary> =
        items.distinctBy { "${it.sourceId}:${it.id}" }
            .sortedBy { item ->
                val sourceIsIndonesian = item.sourceId in setOf("komiku", "sankaapi", "kiryuu")
                if (item.originalLanguage.equals("id", ignoreCase = true) || sourceIsIndonesian) 0 else 1
            }

    suspend fun details(sourceId: String, contentId: String): ContentDetails =
        registry.get(sourceId).details(contentId)

    suspend fun chapterContent(sourceId: String, chapterId: String): ChapterContent =
        registry.get(sourceId).loadChapter(chapterId)

    private companion object {
        const val SOURCE_TIMEOUT_MS = 18_000L
    }
}

@Singleton
class LibraryRepository @Inject constructor(
    private val libraryDao: LibraryDao,
    private val progressDao: ProgressDao,
) {
    fun observeLibrary(): Flow<List<LibraryEntity>> = libraryDao.observeAll()
    fun observeProgress(contentId: String): Flow<ProgressEntity?> = progressDao.observe(contentId)
    suspend fun find(contentId: String): LibraryEntity? = libraryDao.find(contentId)
    suspend fun add(summary: ContentSummary) {
        libraryDao.upsert(
            LibraryEntity(summary.id, summary.sourceId, summary.title, summary.coverUrl, summary.mediaType.name, summary.readingMode.name, System.currentTimeMillis(), null)
        )
    }
    suspend fun remove(contentId: String) = libraryDao.delete(contentId)
    suspend fun saveProgress(contentId: String, chapterId: String, page: Int, totalPages: Int) {
        val now = System.currentTimeMillis()
        progressDao.upsert(ProgressEntity(contentId, chapterId, page, totalPages, now))
        libraryDao.touch(contentId, now)
    }
}

@Singleton
class DownloadRepository @Inject constructor(
    private val downloadDao: DownloadDao,
) {
    fun observeAll(): Flow<List<DownloadEntity>> = downloadDao.observeAll()
    fun observeForContent(contentId: String): Flow<List<DownloadEntity>> = downloadDao.observeForContent(contentId)
    suspend fun find(chapterId: String): DownloadEntity? = downloadDao.find(chapterId)
    suspend fun update(entity: DownloadEntity) = downloadDao.upsert(entity)
    suspend fun remove(chapterId: String) = downloadDao.delete(chapterId)
}