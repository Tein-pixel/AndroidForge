package app.yomikaze.sources

import app.yomikaze.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Indo18hSource @Inject constructor(
    private val http: HttpClient,
) : ContentSource {

    override val id = "indo18h"
    override val name = "Indo18h"
    override val mediaTypes = setOf(MediaType.MANGA, MediaType.MANHWA, MediaType.MANHUA)
    override val isRestricted = true

    private val base = "https://indo18h.com"

    override suspend fun search(query: String, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/?s=${URLEncoder.encode(query, "UTF-8")}")
        return doc.select("div.bs, div.listupd > div").mapNotNull { parseCard(it) }.take(limit)
    }

    override suspend fun popular(category: MediaCategory?, page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/manga/?page=$page&order=popular")
        return doc.select("div.bs, div.listupd > div").mapNotNull { parseCard(it) }.take(limit)
    }

    override suspend fun latest(page: Int, limit: Int): List<ContentSummary> {
        val doc = parse("$base/manga/?page=$page&order=update")
        return doc.select("div.bs, div.listupd > div").mapNotNull { parseCard(it) }.take(limit)
    }

    override suspend fun details(contentId: String): ContentDetails {
        val slug = contentId.trim('/')
        val doc = parse("$base/manga/$slug/")
        val title = doc.selectFirst("h1.entry-title")?.text()?.trim().orEmpty()
        val cover = doc.selectFirst("div.thumb img")?.absUrl("src")
        val description = doc.selectFirst("div.entry-content")?.text()?.trim().orEmpty()
        val chapters = doc.select("div.eplister li a").mapNotNull { a ->
            val href = a.absUrl("href")
            Chapter(
                id = href,
                contentId = slug,
                sourceId = id,
                number = Regex("Chapter\\s*([\\d.]+)").find(a.text())?.groupValues?.get(1) ?: "?",
                title = a.text().trim(),
                url = href,
            )
        }.reversed()
        return ContentDetails(
            ContentSummary(id = slug, sourceId = id, title = title, coverUrl = cover, description = description, mediaType = MediaType.MANHWA),
            chapters = chapters
        )
    }

    override suspend fun chapters(contentId: String, language: String?): List<Chapter> = details(contentId).chapters

    override suspend fun loadChapter(chapterId: String): ChapterContent {
        val doc = parse(chapterId)
        val pages = doc.select("div#readerarea img").mapNotNull { it.absUrl("src").takeIf { u -> u.startsWith("http") } }
        return ChapterContent.Images(pages.mapIndexed { i, url -> Page(i, url) })
    }

    private suspend fun parse(url: String): Document = withContext(Dispatchers.IO) {
        Jsoup.parse(http.get(url), url)
    }

    private fun parseCard(item: Element): ContentSummary? {
        val a = item.selectFirst("a[href*=/manga/]") ?: return null
        val href = a.absUrl("href")
        val slug = href.substringAfter("/manga/").trimEnd('/')
        return ContentSummary(
            id = slug,
            sourceId = id,
            title = item.selectFirst("h4, .tt")?.text()?.trim() ?: a.text().trim(),
            coverUrl = item.selectFirst("img")?.absUrl("src"),
            mediaType = MediaType.MANHWA,
            contentRating = ContentRating.RESTRICTED
        )
    }
}