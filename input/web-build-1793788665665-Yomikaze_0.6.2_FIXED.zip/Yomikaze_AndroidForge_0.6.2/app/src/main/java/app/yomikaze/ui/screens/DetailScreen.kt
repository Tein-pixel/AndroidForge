package app.yomikaze.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import app.yomikaze.core.Chapter
import app.yomikaze.ui.DetailViewModel
import app.yomikaze.ui.components.EmptyState
import app.yomikaze.ui.components.LoadingState
import app.yomikaze.work.ChapterDownloadWorker
import coil3.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    onBack: () -> Unit,
    onRead: (String, String, String, Boolean) -> Unit,
    viewModel: DetailViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val details = state.details
    val context = LocalContext.current
    var synopsisExpanded by remember(details?.summary?.id) { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(details?.summary?.title ?: "Detail komik", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Kembali") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        when {
            state.loading -> LoadingState()
            state.error != null && details == null -> EmptyState(state.error ?: "Detail tidak dapat dimuat.")
            details != null -> {
                val summary = details.summary
                val resumeChapter = details.chapters.firstOrNull { it.id == state.progress?.chapterId }
                    ?: details.chapters.lastOrNull()
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(bottom = 30.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    item {
                        Box(Modifier.fillMaxWidth().height(242.dp)) {
                            AsyncImage(model = summary.coverUrl, contentDescription = null,
                                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                                listOf(Color(0x330A0A10), Color(0xF20A0A10)))))
                            Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(18.dp),
                                horizontalArrangement = Arrangement.spacedBy(15.dp), verticalAlignment = Alignment.Bottom) {
                                AsyncImage(model = summary.coverUrl, contentDescription = summary.title,
                                    modifier = Modifier.width(112.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(15.dp)),
                                    contentScale = ContentScale.Crop)
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text(summary.title, style = MaterialTheme.typography.titleLarge, color = Color.White,
                                        maxLines = 3, overflow = TextOverflow.Ellipsis)
                                    Text("${mediaTypeLabel(summary.mediaType)}  ·  ${statusLabel(summary.status.name)}",
                                        style = MaterialTheme.typography.bodySmall, color = Color(0xFFD8D7E3))
                                    Text("${details.chapters.size} bab tersedia", style = MaterialTheme.typography.labelMedium,
                                        color = Color(0xFFC5B9FF))
                                }
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            InfoChip(statusLabel(summary.status.name))
                            InfoChip(mediaTypeLabel(summary.mediaType))
                            summary.year?.let { InfoChip(it.toString()) }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    resumeChapter?.let { chapter ->
                                        if (!chapter.externalUrl.isNullOrBlank()) openExternal(context, chapter.externalUrl)
                                        else onRead(chapter.sourceId, chapter.contentId, chapter.id, viewModel.isNovel())
                                    }
                                }, enabled = resumeChapter != null, modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                            ) { Text(if (state.progress != null) "Lanjut baca" else "Mulai baca") }
                            OutlinedButton(onClick = viewModel::toggleLibrary, shape = RoundedCornerShape(14.dp)) {
                                Icon(if (state.inLibrary) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (state.inLibrary) "Tersimpan" else "Simpan")
                            }
                        }
                    }
                    if (details.authors.isNotEmpty() || details.artists.isNotEmpty()) {
                        item {
                            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                if (details.authors.isNotEmpty()) Text("Penulis: ${details.authors.joinToString()}",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (details.artists.isNotEmpty()) Text("Ilustrator: ${details.artists.joinToString()}",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (summary.tags.isNotEmpty()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Genre", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleMedium)
                                LazyRowChips(summary.tags)
                            }
                        }
                    }
                    if (summary.description.isNotBlank()) {
                        item {
                            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Sinopsis", style = MaterialTheme.typography.titleMedium)
                                Text(summary.description, maxLines = if (synopsisExpanded) Int.MAX_VALUE else 4,
                                    overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(if (synopsisExpanded) "Tampilkan lebih sedikit" else "Baca selengkapnya",
                                    color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.clickable { synopsisExpanded = !synopsisExpanded })
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("Daftar bab", style = MaterialTheme.typography.titleLarge)
                            Text("Terbaru di atas", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    items(details.chapters.asReversed(), key = { it.id }) { chapter ->
                        ChapterRow(
                            chapter = chapter,
                            onOpen = {
                                if (!chapter.externalUrl.isNullOrBlank()) openExternal(context, chapter.externalUrl)
                                else onRead(chapter.sourceId, chapter.contentId, chapter.id, viewModel.isNovel())
                            },
                            onDownload = { enqueueDownload(context, chapter.sourceId, chapter.contentId, chapter.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoChip(text: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.78f), shape = RoundedCornerShape(50)) {
        Text(text, Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LazyRowChips(tags: List<String>) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        items(tags.take(12)) { InfoChip(it) }
    }
}

@Composable
private fun ChapterRow(chapter: Chapter, onOpen: () -> Unit, onDownload: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).clickable(onClick = onOpen),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
        shape = RoundedCornerShape(14.dp),
    ) {
        Row(Modifier.padding(start = 14.dp, end = 5.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(chapter.number, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(chapter.title?.takeIf { it.isNotBlank() } ?: "Bab ${chapter.number}",
                    maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                val info = buildList {
                    add(chapter.language.uppercase())
                    if (chapter.pageCount > 0) add("${chapter.pageCount} halaman")
                    chapter.scanlationGroups.firstOrNull()?.let(::add)
                    if (!chapter.externalUrl.isNullOrBlank()) add("Tautan luar")
                }
                Text(info.joinToString(" · "), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!chapter.externalUrl.isNullOrBlank()) {
                Icon(Icons.Default.OpenInNew, contentDescription = "Buka sumber luar",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDownload, enabled = chapter.externalUrl.isNullOrBlank()) {
                Icon(Icons.Default.Download, contentDescription = "Unduh bab", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

private fun mediaTypeLabel(type: app.yomikaze.core.MediaType): String = when (type) {
    app.yomikaze.core.MediaType.MANGA -> "Manga"
    app.yomikaze.core.MediaType.MANHWA -> "Manhwa"
    app.yomikaze.core.MediaType.MANHUA -> "Manhua"
    app.yomikaze.core.MediaType.COMIC -> "Komik"
    app.yomikaze.core.MediaType.NOVEL -> "Novel"
}

private fun statusLabel(value: String): String = when (value) {
    "ONGOING" -> "Berjalan"
    "COMPLETED" -> "Tamat"
    "HIATUS" -> "Hiatus"
    "CANCELLED" -> "Dihentikan"
    else -> "Belum diketahui"
}

private fun openExternal(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun enqueueDownload(context: Context, sourceId: String, contentId: String, chapterId: String) {
    val request = OneTimeWorkRequestBuilder<ChapterDownloadWorker>()
        .setInputData(Data.Builder()
            .putString(ChapterDownloadWorker.KEY_SOURCE, sourceId)
            .putString(ChapterDownloadWorker.KEY_CONTENT, contentId)
            .putString(ChapterDownloadWorker.KEY_CHAPTER, chapterId).build())
        .build()
    WorkManager.getInstance(context).enqueue(request)
}
