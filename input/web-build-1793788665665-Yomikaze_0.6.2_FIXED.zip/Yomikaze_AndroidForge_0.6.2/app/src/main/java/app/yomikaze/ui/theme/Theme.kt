package app.yomikaze.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF30266D),
    onPrimaryContainer = Color(0xFFE7E2FF),
    secondary = Color(0xFF72C9F2),
    onSecondary = Color(0xFF061B26),
    background = Color(0xFF0F0F13),
    onBackground = Color(0xFFF4F2FA),
    surface = Color(0xFF1A1A22),
    onSurface = Color(0xFFF4F2FA),
    surfaceVariant = Color(0xFF252530),
    onSurfaceVariant = Color(0xFFB9B6C7),
    outline = Color(0xFF393744),
)

private val AppTypography = Typography(
    headlineLarge = TextStyle(fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 33.sp),
    headlineMedium = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 26.sp),
    titleMedium = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 10.sp, lineHeight = 14.sp),
)

@Composable
fun YomikazeTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = AppTypography, content = content)
}
