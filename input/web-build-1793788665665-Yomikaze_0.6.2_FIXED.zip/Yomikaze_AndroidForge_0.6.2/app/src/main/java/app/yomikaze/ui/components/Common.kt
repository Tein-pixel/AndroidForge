package app.yomikaze.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.yomikaze.core.ContentSummary
import coil3.compose.SubcomposeAsyncImage

@Composable
fun ContentCard(
    item: ContentSummary,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.38f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)) {
            SubcomposeAsyncImage(
                model = item.coverUrl,
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                loading = { CoverFallback(item.title) },
                error = { CoverFallback(item.title) },
            )
            Box(
                Modifier.fillMaxWidth().height(118.dp).align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF5000000)))),
            )
            Column(
                modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    buildString {
                        append(mediaTypeLabel(item.mediaType))
                        if (item.year != null) append("  ·  ${item.year}")
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFD4DAE4),
                    maxLines = 1,
                )
            }
            Surface(
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                color = Color(0xD9000000),
                shape = RoundedCornerShape(7.dp),
            ) {
                Text(
                    mediaTypeLabel(item.mediaType),
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                color = Color(0xB91A2940),
                shape = RoundedCornerShape(7.dp),
            ) {
                Text(
                    sourceLabel(item.sourceId),
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                    color = Color(0xFFE3EDFF),
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun CoverFallback(title: String) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF182333), Color(0xFF090D14), Color(0xFF25395B))),
        ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(Icons.Outlined.AutoStories, contentDescription = null, tint = Color(0xFF9DBBFF),
                modifier = Modifier.size(30.dp))
            Text(title.take(42), color = Color(0xFFDCE7FA), style = MaterialTheme.typography.labelMedium,
                maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun mediaTypeLabel(type: app.yomikaze.core.MediaType): String = when (type) {
    app.yomikaze.core.MediaType.MANGA -> "Manga"
    app.yomikaze.core.MediaType.MANHWA -> "Manhwa"
    app.yomikaze.core.MediaType.MANHUA -> "Manhua"
    app.yomikaze.core.MediaType.COMIC -> "Komik"
    app.yomikaze.core.MediaType.NOVEL -> "Novel"
}

private fun sourceLabel(sourceId: String): String = when (sourceId.lowercase()) {
    "mangadex" -> "MangaDex"
    "mangahub" -> "MangaHub"
    "weebcentral" -> "WeebCentral"
    "kiryuu" -> "Kiryuu"
    "novelfire" -> "NovelFire"
    "sankaapi" -> "Sanka"
    "anikuro" -> "Anikuro"
    "komiku" -> "Komiku"
    else -> sourceId.replaceFirstChar { it.uppercase() }
}

@Composable
fun EmptyState(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun LoadingState() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
    }
}
