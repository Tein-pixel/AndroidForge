package com.manhwa.aggregator

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.annotation.SuppressLint
import coil.load

class ManhwaAdapter(
    private val manhwaList: List<Manhwa>,
    private val onItemClick: (Manhwa) -> Unit
) : RecyclerView.Adapter<ManhwaAdapter.ViewHolder>() {

    private val animatedPositions = mutableSetOf<Int>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgCover: ImageView = view.findViewById(R.id.imgCover)
        val tvTitle:  TextView  = view.findViewById(R.id.tvTitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_manhwa, parent, false)
        return ViewHolder(view)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = manhwaList[position]
        holder.tvTitle.text = item.title

        // Comick CDN (meo.comick.pictures) — load with referer from item.link
        holder.imgCover.load(
            item.imageUrl,
            ManhwaImageLoader.get(holder.itemView.context, item.link)
        ) {
            crossfade(240)
            placeholder(R.drawable.cover_placeholder)
            error(R.drawable.cover_placeholder)
        }

        holder.itemView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> view.animate()
                    .scaleX(0.975f).scaleY(0.975f)
                    .setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(220).setInterpolator(OvershootInterpolator(1.15f)).start()
            }
            false
        }
        holder.itemView.setOnClickListener { onItemClick(item) }

        if (animatedPositions.add(position)) {
            holder.itemView.alpha = 0f
            holder.itemView.translationY = 32f
            holder.itemView.animate()
                .alpha(1f).translationY(0f).setDuration(300)
                .setStartDelay((position % 6 * 35).toLong())
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    override fun getItemCount(): Int = manhwaList.size
}
