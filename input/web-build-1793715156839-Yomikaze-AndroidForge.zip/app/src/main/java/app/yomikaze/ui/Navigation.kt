package app.yomikaze.ui

import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import app.yomikaze.ui.screens.*

private object Routes {
    const val BROWSE = "browse"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val SETTINGS = "settings"
    const val DETAIL = "detail/{sourceId}/{contentId}"
    const val MANGA_READER = "read/manga/{sourceId}/{contentId}/{chapterId}"
    const val NOVEL_READER = "read/novel/{sourceId}/{contentId}/{chapterId}"

    fun detail(sourceId: String, contentId: String) =
        "detail/${Uri.encode(sourceId)}/${Uri.encode(contentId)}"

    fun mangaReader(sourceId: String, contentId: String, chapterId: String) =
        "read/manga/${Uri.encode(sourceId)}/${Uri.encode(contentId)}/${Uri.encode(chapterId)}"

    fun novelReader(sourceId: String, contentId: String, chapterId: String) =
        "read/novel/${Uri.encode(sourceId)}/${Uri.encode(contentId)}/${Uri.encode(chapterId)}"
}

@Composable
fun YomikazeNavHost() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute !in setOf(Routes.MANGA_READER, Routes.NOVEL_READER)

    Scaffold(
        bottomBar = { if (showBottomBar) BottomBar(navController) },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.BROWSE,
            modifier = Modifier.padding(padding),
        ) {
            composable(Routes.BROWSE) {
                BrowseScreen(
                    onOpen = { sourceId, contentId -> navController.navigate(Routes.detail(sourceId, contentId)) },
                    onSearch = { navController.navigate(Routes.SEARCH) },
                )
            }
            composable(Routes.SEARCH) {
                SearchScreen(
                    onOpen = { sourceId, contentId -> navController.navigate(Routes.detail(sourceId, contentId)) },
                )
            }
            composable(Routes.LIBRARY) {
                LibraryScreen(
                    onOpen = { sourceId, contentId -> navController.navigate(Routes.detail(sourceId, contentId)) },
                )
            }
            composable(Routes.SETTINGS) { SettingsScreen() }
            composable(
                route = Routes.DETAIL,
                arguments = listOf(
                    androidx.navigation.navArgument("sourceId") { type = androidx.navigation.NavType.StringType },
                    androidx.navigation.navArgument("contentId") { type = androidx.navigation.NavType.StringType },
                ),
            ) {
                DetailScreen(
                    onBack = { navController.popBackStack() },
                    onRead = { sourceId, contentId, chapterId, isNovel ->
                        navController.navigate(
                            if (isNovel) Routes.novelReader(sourceId, contentId, chapterId)
                            else Routes.mangaReader(sourceId, contentId, chapterId)
                        )
                    },
                )
            }
            composable(
                route = Routes.MANGA_READER,
                arguments = listOf(
                    androidx.navigation.navArgument("sourceId") { type = androidx.navigation.NavType.StringType },
                    androidx.navigation.navArgument("contentId") { type = androidx.navigation.NavType.StringType },
                    androidx.navigation.navArgument("chapterId") { type = androidx.navigation.NavType.StringType },
                ),
            ) {
                MangaReaderScreen(onBack = { navController.popBackStack() })
            }
            composable(
                route = Routes.NOVEL_READER,
                arguments = listOf(
                    androidx.navigation.navArgument("sourceId") { type = androidx.navigation.NavType.StringType },
                    androidx.navigation.navArgument("contentId") { type = androidx.navigation.NavType.StringType },
                    androidx.navigation.navArgument("chapterId") { type = androidx.navigation.NavType.StringType },
                ),
            ) {
                NovelReaderScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun BottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    NavigationBar {
        listOf(
            Triple(Routes.BROWSE, "Jelajah", Icons.Default.Explore),
            Triple(Routes.SEARCH, "Cari", Icons.Default.Search),
            Triple(Routes.LIBRARY, "Koleksi", Icons.Default.Bookmarks),
            Triple(Routes.SETTINGS, "Pengaturan", Icons.Default.Settings),
        ).forEach { (route, label, icon) ->
            NavigationBarItem(
                selected = currentDestination?.hierarchy?.any { it.route == route } == true,
                onClick = {
                    navController.navigate(route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) },
            )
        }
    }
}
