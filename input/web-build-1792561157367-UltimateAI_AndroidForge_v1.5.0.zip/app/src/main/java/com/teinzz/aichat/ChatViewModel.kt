package com.teinzz.aichat

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teinzz.aichat.data.*
import com.teinzz.aichat.network.AiRepository
import com.teinzz.aichat.network.ProviderException
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).conversations()
    val themeManager = ThemeManager(app)
    private val repository = AiRepository(themeManager)
    val modelCatalog = mutableStateOf(ModelCatalog.all)
    var isRefreshingModelCatalog = mutableStateOf(false); private set
    var modelCatalogStatus = mutableStateOf(""); private set
    var isTestingModel = mutableStateOf(false); private set
    var modelTestStatus = mutableStateOf(""); private set
    val conversations = dao.observeConversations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val messages = mutableStateListOf<MessageEntity>()
    var currentConversationId = mutableStateOf<Long?>(null); private set
    var currentModel = mutableStateOf(ModelCatalog.byStorageKey(themeManager.getLastModel()) ?: ModelCatalog.byId(themeManager.getLastModel())); private set
    var chatMode = mutableStateOf(themeManager.getLastChatMode()); private set
    var isGenerating = mutableStateOf(false); private set
    var errorMessage = mutableStateOf<String?>(null); private set
    var showPaidModels = mutableStateOf(false); private set
    private var activeSendJob: Job? = null
    private var artifactGenerationJob: Job? = null
    var isGeneratingArtifact = mutableStateOf(false); private set
    var generatedArtifactHtml = mutableStateOf<String?>(null); private set
    var artifactGenerationError = mutableStateOf<String?>(null); private set

    init {
        if (!currentModel.value.provider.active) {
            currentModel.value = ModelCatalog.default()
            themeManager.setLastModel(currentModel.value.storageKey)
        }
        viewModelScope.launch {
            runCatching { dao.latest() }.getOrNull()?.let { latest ->
                currentConversationId.value = latest.id
                val conversation = runCatching { dao.conversation(latest.id) }.getOrNull()
                if (conversation != null) {
                    currentModel.value = modelCatalog.value.firstOrNull { it.storageKey == conversation.modelId }
                        ?: modelCatalog.value.firstOrNull { it.id == conversation.modelId }
                        ?: ModelCatalog.byId(conversation.modelId)
                    messages.addAll(runCatching { dao.messages(latest.id) }.getOrDefault(emptyList()))
                }
            }
            refreshModelCatalog(silent = true)
        }
    }

    fun refreshModelCatalog(silent: Boolean = false) {
        if (isRefreshingModelCatalog.value) return
        viewModelScope.launch {
            isRefreshingModelCatalog.value = true
            if (!silent) modelCatalogStatus.value = "Memuat katalog langsung dari provider…"
            try {
                val result = repository.discoverModels()
                if (result.refreshedProviders.isNotEmpty()) {
                    val refreshed = result.refreshedProviders
                    val liveModels = result.modelsByProvider.values.flatten()
                    val preserved = modelCatalog.value.filter { model ->
                        model.provider !in refreshed ||
                            (model.provider == Provider.OPENROUTER && model.id == "openrouter/free" && liveModels.none { it.storageKey == model.storageKey })
                    }
                    val merged = (preserved + liveModels).distinctBy { it.storageKey }
                        .sortedWith(compareBy<AiModel> { Provider.values().indexOf(it.provider) }.thenByDescending { it.freeTier }.thenBy { it.name.lowercase() })
                    modelCatalog.value = merged
                    val activeConversation = currentConversationId.value?.let { dao.conversation(it) }
                    val desiredKey = activeConversation?.modelId ?: themeManager.getLastModel()
                    val selected = merged.firstOrNull { it.storageKey == desiredKey } ?: merged.firstOrNull { it.id == desiredKey }
                    if (selected != null) {
                        currentModel.value = selected
                    } else {
                        val storedProvider = desiredKey.substringBefore("::", "").let { raw -> runCatching { Provider.valueOf(raw) }.getOrNull() }
                        val fallbackProvider = storedProvider ?: currentModel.value.provider
                        if (fallbackProvider in refreshed) {
                            val replacement = merged.firstOrNull { it.provider == fallbackProvider && it.freeTier }
                                ?: merged.firstOrNull { it.provider == fallbackProvider }
                                ?: ModelCatalog.default()
                            currentModel.value = replacement
                            themeManager.setLastModel(replacement.storageKey)
                            activeConversation?.let { dao.updateModel(it.id, replacement.storageKey) }
                        }
                    }
                }
                modelCatalogStatus.value = result.messages.joinToString(" · ").ifBlank { "Katalog siap." }
            } catch (t: Throwable) {
                modelCatalogStatus.value = "Katalog belum dapat diperbarui. Model cadangan tetap tersedia. ${t.message.orEmpty()}"
            } finally {
                isRefreshingModelCatalog.value = false
            }
        }
    }
    fun newChat() { activeSendJob?.cancel(); activeSendJob = null; isGenerating.value = false; currentConversationId.value = null; messages.clear(); errorMessage.value = null }
    fun setPaidVisible(value: Boolean) { showPaidModels.value = value }
    fun testSelectedModel() {
        if (isTestingModel.value || isGenerating.value || isGeneratingArtifact.value) return
        val model = currentModel.value
        viewModelScope.launch {
            isTestingModel.value = true
            modelTestStatus.value = "Mengirim satu request percobaan ke ${model.name}…"
            try {
                val response = repository.testResponse(model)
                modelTestStatus.value = "BERHASIL · ${model.name} menjawab: ${response.take(75)}"
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                modelTestStatus.value = "GAGAL · ${model.name}: ${(t.message ?: t.javaClass.simpleName).take(150)}"
            } finally {
                isTestingModel.value = false
            }
        }
    }
    fun selectModel(model: AiModel) {
        currentModel.value = model; modelTestStatus.value = ""; themeManager.setLastModel(model.storageKey)
        if (chatMode.value == ChatMode.DEEP_RESEARCH && model.provider !in setOf(Provider.GEMINI, Provider.OPENROUTER)) {
            chatMode.value = ChatMode.NORMAL
            themeManager.setLastChatMode(ChatMode.NORMAL)
            errorMessage.value = "Riset Mendalam dimatikan karena provider terpilih tidak mendukung tool web pada adapter ini. Pilih Gemini atau OpenRouter untuk riset web nyata."
        }
        viewModelScope.launch { currentConversationId.value?.let { dao.updateModel(it, model.storageKey) } }
    }
    fun setChatMode(mode: ChatMode) {
        if (mode == ChatMode.DEEP_RESEARCH && currentModel.value.provider !in setOf(Provider.GEMINI, Provider.OPENROUTER)) {
            errorMessage.value = "Riset Mendalam membutuhkan Gemini (Google Search grounding) atau OpenRouter (web search server tool). Mode tidak diaktifkan agar aplikasi tidak berpura-pura melakukan riset."
            return
        }
        chatMode.value = mode
        themeManager.setLastChatMode(mode)
    }
    fun selectConversation(id: Long) {
        activeSendJob?.cancel(); isGenerating.value = false
        viewModelScope.launch {
            val conv = dao.conversation(id)
            currentConversationId.value = id
            if (conv != null) currentModel.value = modelCatalog.value.firstOrNull { it.storageKey == conv.modelId } ?: modelCatalog.value.firstOrNull { it.id == conv.modelId } ?: ModelCatalog.byId(conv.modelId)
            messages.clear(); messages.addAll(dao.messages(id)); errorMessage.value = null
        }
    }
    fun renameConversation(id: Long, title: String) { viewModelScope.launch { dao.rename(id, title.trim().ifBlank { "New chat" }.take(80)) } }
    fun deleteConversation(id: Long) { viewModelScope.launch { dao.deleteMessages(id); dao.deleteConversation(id); if (currentConversationId.value == id) newChat() } }

    fun send(text: String, imagePath: String? = null, attachmentName: String? = null) {
        if (isGenerating.value || (text.isBlank() && imagePath == null)) return
        errorMessage.value = null
        activeSendJob = viewModelScope.launch {
            var assistantId = 0L
            try {
                val previous = messages.toList()
                var conversationId = currentConversationId.value
                if (conversationId == null) {
                    val title = text.trim().ifBlank { if (imagePath != null) "Image analysis" else attachmentName ?: "New chat" }.take(40)
                    conversationId = dao.insertConversation(ConversationEntity(title = title, modelId = currentModel.value.storageKey))
                    currentConversationId.value = conversationId
                }
                val userMessage = MessageEntity(conversationId = conversationId!!, role = "user", content = text, imagePath = imagePath, fileName = attachmentName)
                val userId = dao.insertMessage(userMessage)
                messages.add(userMessage.copy(id = userId))
                dao.touch(conversationId)
                val assistant = MessageEntity(conversationId = conversationId, role = "assistant", content = "")
                assistantId = dao.insertMessage(assistant)
                messages.add(assistant.copy(id = assistantId))
                isGenerating.value = true
                val buffer = StringBuilder()
                var lastPersist = 0L
                repository.stream(currentModel.value, previous, text, imagePath, chatMode.value).collect { chunk ->
                    buffer.append(chunk)
                    val index = messages.indexOfLast { it.id == assistantId }
                    if (index >= 0) messages[index] = messages[index].copy(content = buffer.toString())
                    val now = System.currentTimeMillis()
                    if (now - lastPersist > 250) { dao.updateMessage(assistantId, buffer.toString()); lastPersist = now }
                }
                if (buffer.isEmpty()) buffer.append("Model menyelesaikan permintaan tanpa teks. Coba lagi atau pilih model lain.")
                dao.updateMessage(assistantId, buffer.toString())
                val finalIndex = messages.indexOfLast { it.id == assistantId }
                if (finalIndex >= 0) messages[finalIndex] = messages[finalIndex].copy(content = buffer.toString())
                dao.touch(conversationId)
            } catch (t: Throwable) {
                if (t is CancellationException) {
                    if (assistantId != 0L) messages.lastOrNull { it.id == assistantId }?.let { msg -> runCatching { dao.updateMessage(assistantId, msg.content) } }
                    throw t
                }
                val friendly = when (t) {
                    is ProviderException -> t.message ?: "Permintaan gagal."
                    is SocketTimeoutException -> "Server terlalu lama merespons. Sambungan streaming kini diberi batas lebih longgar; coba lagi atau gunakan model/rute lain. (Timeout)"
                    is UnknownHostException -> "Alamat provider tidak dapat dijangkau. Periksa koneksi internet atau DNS, lalu coba lagi."
                    else -> "Permintaan gagal: ${t.message?.take(180) ?: t.javaClass.simpleName}. Periksa internet, API key, dan model."
                }
                errorMessage.value = friendly
                val last = messages.lastOrNull()
                if (last?.role == "assistant" && last.content.isBlank()) {
                    val idx = messages.lastIndex; messages[idx] = last.copy(content = friendly)
                    runCatching { dao.updateMessage(last.id, friendly) }
                }
            } finally { if (activeSendJob == coroutineContext[kotlinx.coroutines.Job]) { isGenerating.value = false; activeSendJob = null } }
        }
    }

    fun stopGenerating() { activeSendJob?.cancel(); isGenerating.value = false }
    suspend fun testConnection(model: AiModel): String = repository.test(model)

    /** Generate a runnable HTML artifact through the currently selected provider/model. */
    fun generateArtifact(prompt: String, existingHtml: String? = null) {
        if (isGeneratingArtifact.value) return
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isBlank()) {
            artifactGenerationError.value = "Tulis instruksi artifact terlebih dahulu."
            return
        }
        artifactGenerationJob?.cancel()
        artifactGenerationError.value = null
        generatedArtifactHtml.value = null
        isGeneratingArtifact.value = true
        val job = viewModelScope.launch(start = CoroutineStart.LAZY) {
            try {
                val task = buildString {
                    append("You are generating a runnable AI Artifact for an Android app HTML preview. ")
                    append("Return ONLY one complete, self-contained HTML document. No Markdown fences, no explanations outside HTML. ")
                    append("Include <!doctype html>, html/head/body, UTF-8 meta, responsive viewport, and embedded CSS/JavaScript. ")
                    append("Make the UI polished, mobile-first, accessible, and functional; implement the requested interactions, not decorative dead buttons. ")
                    append("Prefer vanilla HTML/CSS/JS and avoid build tools, server APIs, external dependencies, and secrets. ")
                    append("Do not use file:// links, request local files, or attempt to access the host app. ")
                    append("Task from user: ").append(cleanPrompt).append("\n")
                    if (!existingHtml.isNullOrBlank()) {
                        append("\nRevise the following existing artifact, preserving working features unless the user specifically requests a change. Return the full updated HTML document, not a patch.\n")
                        append("<existing_artifact_html>\n")
                        append(existingHtml.take(90000))
                        append("\n</existing_artifact_html>")
                    }
                }
                val output = StringBuilder()
                repository.stream(currentModel.value, emptyList(), task, null, ChatMode.NORMAL).collect { chunk ->
                    output.append(chunk)
                }
                val result = output.toString().trim()
                if (result.isBlank()) throw IllegalStateException("Model tidak mengembalikan kode. Coba ulangi atau pilih model lain.")
                generatedArtifactHtml.value = result
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                artifactGenerationError.value = when (t) {
                    is ProviderException -> t.message ?: "Gagal membuat artifact."
                    else -> "Gagal membuat artifact: ${t.message ?: t.javaClass.simpleName}"
                }
            } finally {
                if (artifactGenerationJob == kotlin.coroutines.coroutineContext[kotlinx.coroutines.Job]) {
                    isGeneratingArtifact.value = false
                    artifactGenerationJob = null
                }
            }
        }
        artifactGenerationJob = job
        job.start()
    }

    fun stopArtifactGeneration() {
        artifactGenerationJob?.cancel()
        artifactGenerationJob = null
        isGeneratingArtifact.value = false
    }

    fun clearGeneratedArtifact() {
        generatedArtifactHtml.value = null
        artifactGenerationError.value = null
    }

    override fun onCleared() {
        artifactGenerationJob?.cancel()
        activeSendJob?.cancel()
        super.onCleared()
    }
}
