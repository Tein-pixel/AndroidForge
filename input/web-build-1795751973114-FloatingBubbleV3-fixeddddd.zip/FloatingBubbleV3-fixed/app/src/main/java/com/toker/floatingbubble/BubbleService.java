// BubbleService.java : java, Android 29+, com.toker.floatingbubble
// v3 — major rewrite:
//   • FLAG_SECURE removed from pill panel → tembus semua apk & web
//   • Bubble shape: circle / square / rounded / triangle via BubbleView
//   • Pill menu 7 items: Search | Sparkle (AI crop) | Gemini | Translate | Gallery | Camera | Scan Setting
//   • Gallery / Camera → CameraProxyActivity → routes by SharedPrefHelper.getImageDest()
//   • Settings change broadcast applies shape + color + alpha + size live
//   • Text OCR routes by SharedPrefHelper.getTextDest() (Search / AI / Translate)
//   • Scan Setting dialog (ScanSettingDialog) toggle via pill item 7
package com.toker.floatingbubble;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.graphics.Outline;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

public class BubbleService extends Service {

    public static final String ACTION_SETTINGS_CHANGED = "com.toker.floatingbubble.SETTINGS_CHANGED";

    private static final String CHANNEL_ID = "bubble_channel";
    private static final int    NOTIF_ID   = 42;

    private WindowManager windowManager;
    private BubbleView    bubbleView;
    private View          panelView;
    private WindowManager.LayoutParams bubbleParams;
    private boolean       panelShown = false;

    private View          cropOverlayView;

    // ── scan setting dialog ───────────────────────────────────────────────────
    private ScanSettingDialog scanSettingDialog;

    private int screenWidth, screenHeight;

    private BroadcastReceiver textExtractedRx;
    private BroadcastReceiver settingsRx;

    // ── lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIF_ID, buildNotification());
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth  = dm.widthPixels;
        screenHeight = dm.heightPixels;
        scanSettingDialog = new ScanSettingDialog(this, windowManager);
        registerReceivers();
        addBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        scanSettingDialog.dismiss();
        safeRemove(bubbleView);
        if (panelShown) safeRemove(panelView);
        safeRemove(cropOverlayView);
        try { unregisterReceiver(textExtractedRx); } catch (Exception ignored) {}
        try { unregisterReceiver(settingsRx);       } catch (Exception ignored) {}
    }

    // ── receivers ─────────────────────────────────────────────────────────────

    private void registerReceivers() {
        textExtractedRx = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                String text = intent.getStringExtra(TextExtractorService.EXTRA_TEXT);
                removeCropOverlay();
                // route based on user's scan setting for OCR text
                routeText(text != null ? text : "");
            }
        };
        register(textExtractedRx, TextExtractorService.ACTION_TEXT_EXTRACTED);

        settingsRx = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                applySettings();
            }
        };
        register(settingsRx, ACTION_SETTINGS_CHANGED);
    }

    private void register(BroadcastReceiver rx, String action) {
        IntentFilter f = new IntentFilter(action);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(rx, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(rx, f);
        }
    }

    // ── bubble ────────────────────────────────────────────────────────────────

    private void addBubble() {
        int sz = dp(SharedPrefHelper.getBubbleSizeDp(this));
        bubbleView = new BubbleView(this);

        bubbleParams = new WindowManager.LayoutParams(
                sz, sz,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = screenWidth - sz - dp(8);
        bubbleParams.y = dp(200);

        attachTouch(bubbleView, bubbleParams);
        windowManager.addView(bubbleView, bubbleParams);
        applySettings();
    }

    private void applySettings() {
        if (bubbleView == null) return;
        int alpha   = SharedPrefHelper.getBubbleAlpha(this);
        int color   = SharedPrefHelper.getBubbleColor(this);
        int shape   = SharedPrefHelper.getBubbleShape(this);
        int sizePx  = dp(SharedPrefHelper.getBubbleSizeDp(this));

        bubbleView.setAlpha(alpha / 255f);
        bubbleView.setFillColor(color);
        bubbleView.setShape(shape);

        if (bubbleParams.width != sizePx) {
            bubbleParams.width  = sizePx;
            bubbleParams.height = sizePx;
            bubbleParams.x = Math.max(0, Math.min(bubbleParams.x, screenWidth - sizePx));
            try { windowManager.updateViewLayout(bubbleView, bubbleParams); } catch (Exception ignored) {}
        }
    }

    // ── drag + tap ────────────────────────────────────────────────────────────

    private void attachTouch(View v, WindowManager.LayoutParams params) {
        final int[]   initPos   = new int[2];
        final float[] initTouch = new float[2];
        final long[]  t0        = new long[1];

        v.setOnTouchListener((view, ev) -> {
            switch (ev.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initPos[0]   = params.x;
                    initPos[1]   = params.y;
                    initTouch[0] = ev.getRawX();
                    initTouch[1] = ev.getRawY();
                    t0[0]        = System.currentTimeMillis();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    params.x = initPos[0] + (int)(ev.getRawX() - initTouch[0]);
                    params.y = initPos[1] + (int)(ev.getRawY() - initTouch[1]);
                    windowManager.updateViewLayout(view, params);
                    return true;

                case MotionEvent.ACTION_UP:
                    float dx = Math.abs(ev.getRawX() - initTouch[0]);
                    float dy = Math.abs(ev.getRawY() - initTouch[1]);
                    if (System.currentTimeMillis() - t0[0] < 220 && dx < 12 && dy < 12) {
                        togglePanel();
                    } else {
                        snapToEdge(params, view);
                    }
                    return true;
            }
            return false;
        });
    }

    private void snapToEdge(WindowManager.LayoutParams p, View v) {
        int center = p.x + v.getWidth() / 2;
        int target = (center < screenWidth / 2) ? dp(8) : screenWidth - v.getWidth() - dp(8);
        animX(p, v, target);
    }

    private void animX(WindowManager.LayoutParams p, View v, int targetX) {
        final int  start = p.x;
        final int  dist  = targetX - start;
        final long t0    = System.currentTimeMillis();
        final long dur   = 180L;
        v.post(new Runnable() {
            @Override public void run() {
                float t = Math.min(1f, (System.currentTimeMillis() - t0) / (float) dur);
                t = 1f - (1f - t) * (1f - t);
                p.x = start + (int)(dist * t);
                try { windowManager.updateViewLayout(v, p); } catch (Exception ignored) {}
                if (t < 1f) v.postDelayed(this, 8);
            }
        });
    }

    // ── pill menu ─────────────────────────────────────────────────────────────

    private void togglePanel() {
        if (panelShown) {
            safeRemove(panelView);
            panelShown = false;
        } else {
            panelView = buildPillMenu();
            int menuSizePx = dp(SharedPrefHelper.getMenuSizeDp(this));
            int itemCount = 7;   // 6 action + 1 scan setting
            int panelW = menuSizePx + dp(20);
            int panelH = itemCount * (menuSizePx + dp(12)) + dp(24);

            // ── FLAG_SECURE REMOVED — tembus semua apk & web ──────────────────
            WindowManager.LayoutParams pp = new WindowManager.LayoutParams(
                    panelW, panelH,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            pp.gravity = Gravity.TOP | Gravity.START;
            boolean onRight = bubbleParams.x > screenWidth / 2;
            pp.x = onRight ? bubbleParams.x - panelW - dp(4) : bubbleParams.x + bubbleParams.width + dp(4);
            pp.y = bubbleParams.y;
            windowManager.addView(panelView, pp);
            panelShown = true;
        }
    }

    private View buildPillMenu() {
        int menuSizePx = dp(SharedPrefHelper.getMenuSizeDp(this));

        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.VERTICAL);
        pill.setGravity(Gravity.CENTER_HORIZONTAL);
        pill.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        pill.setBackground(getDrawable(R.drawable.panel_glass));
        pill.setClipToOutline(true);
        pill.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(28));
            }
        });
        pill.setPadding(0, dp(10), 0, dp(10));

        // 1. Google Search
        pill.addView(pillItem(R.drawable.ic_search, menuSizePx, v -> {
            closePanel();
            launchWeb(WebActivity.MODE_SEARCH, "");
        }));

        // 2. Sparkle — AI crop text → routes by textDest pref
        pill.addView(pillItem(R.drawable.ic_sparkle, menuSizePx, v -> {
            closePanel();
            onSparkle();
        }));

        // 3. Gemini direct
        pill.addView(pillItem(R.drawable.ic_globe, menuSizePx, v -> {
            closePanel();
            launchGemini("", null);
        }));

        // 4. Google Translate
        pill.addView(pillItem(R.drawable.ic_translate, menuSizePx, v -> {
            closePanel();
            launchWeb(WebActivity.MODE_TRANSLATE, "");
        }));

        // 5. Gallery → routes by imageDest pref
        pill.addView(pillItem(R.drawable.ic_gallery, menuSizePx, v -> {
            closePanel();
            launchCamera(CameraProxyActivity.MODE_GALLERY);
        }));

        // 6. Camera → routes by imageDest pref
        pill.addView(pillItem(R.drawable.ic_camera, menuSizePx, v -> {
            closePanel();
            launchCamera(CameraProxyActivity.MODE_CAMERA);
        }));

        // 7. Scan Setting — toggle floating dialog
        pill.addView(pillItem(R.drawable.ic_scan_setting, menuSizePx, v -> {
            closePanel();
            toggleScanSetting();
        }));

        return pill;
    }

    private View pillItem(int iconRes, int sizePx, View.OnClickListener listener) {
        ImageButton btn = new ImageButton(this);
        btn.setImageDrawable(getDrawable(iconRes));
        btn.setScaleType(ImageButton.ScaleType.CENTER_INSIDE);
        btn.setBackground(getDrawable(R.drawable.pill_button_bg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sizePx, sizePx);
        lp.setMargins(0, dp(5), 0, dp(5));
        btn.setLayoutParams(lp);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void closePanel() {
        if (panelShown) { safeRemove(panelView); panelShown = false; }
    }

    // ── scan setting ──────────────────────────────────────────────────────────

    private void toggleScanSetting() {
        if (scanSettingDialog.isVisible()) {
            scanSettingDialog.dismiss();
        } else {
            // anchor near the bubble position
            int dialogX = Math.max(dp(16), bubbleParams.x - dp(310));
            int dialogY = Math.max(dp(60), bubbleParams.y);
            scanSettingDialog.show(dialogX, dialogY);
        }
    }

    // ── sparkle / crop flow ───────────────────────────────────────────────────

    private void onSparkle() {
        if (!TextExtractorService.isEnabled(this)) {
            Toast.makeText(this,
                    "Aktifkan aksesibilitas:\nPengaturan → Aksesibilitas → Floating Bubble",
                    Toast.LENGTH_LONG).show();
            Intent acc = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            acc.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(acc);
            return;
        }
        showCropOverlay();
    }

    private void showCropOverlay() {
        if (cropOverlayView != null) return;
        float lineThick = SharedPrefHelper.getLineThicknessDp(this);
        int   lineColor = SharedPrefHelper.getLineColor(this);

        CropOverlayView ov = new CropOverlayView(this, lineThick, lineColor);
        ov.setListener(new CropOverlayView.OnCropListener() {
            @Override public void onConfirm(Rect cropRect) {
                Intent intent = new Intent(TextExtractorService.ACTION_CROP_CONFIRM);
                intent.putExtra(TextExtractorService.EXTRA_RECT_LEFT,   cropRect.left);
                intent.putExtra(TextExtractorService.EXTRA_RECT_TOP,    cropRect.top);
                intent.putExtra(TextExtractorService.EXTRA_RECT_RIGHT,  cropRect.right);
                intent.putExtra(TextExtractorService.EXTRA_RECT_BOTTOM, cropRect.bottom);
                sendBroadcast(intent);
            }
            @Override public void onCancel() { removeCropOverlay(); }
        });

        WindowManager.LayoutParams op = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT);
        op.gravity = Gravity.TOP | Gravity.START;
        cropOverlayView = ov;
        windowManager.addView(cropOverlayView, op);
    }

    private void removeCropOverlay() {
        if (cropOverlayView != null) { safeRemove(cropOverlayView); cropOverlayView = null; }
    }

    // ── routing ───────────────────────────────────────────────────────────────

    /**
     * Routes OCR-extracted text to the destination set in Scan Setting.
     * Default (combo saran): DEST_SEARCH → Google Search.
     */
    private void routeText(String text) {
        int dest = SharedPrefHelper.getTextDest(this);
        switch (dest) {
            case SharedPrefHelper.DEST_AI:
                launchGemini(text, null);
                break;
            case SharedPrefHelper.DEST_TRANSLATE:
                launchWeb(WebActivity.MODE_TRANSLATE, text);
                break;
            case SharedPrefHelper.DEST_SEARCH:
            default:
                launchWeb(WebActivity.MODE_SEARCH, text);
                break;
        }
    }

    // ── launches ──────────────────────────────────────────────────────────────

    /** Open Gemini WebView with optional text query and optional image path. */
    private void launchGemini(String text, String imagePath) {
        Intent intent = new Intent(this, GeminiWebViewActivity.class);
        intent.putExtra(GeminiWebViewActivity.EXTRA_QUERY, text);
        if (imagePath != null && !imagePath.isEmpty()) {
            intent.putExtra(GeminiWebViewActivity.EXTRA_IMAGE_PATH, imagePath);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    /** Open generic WebActivity for search / translate. */
    private void launchWeb(int mode, String query) {
        Intent intent = new Intent(this, WebActivity.class);
        intent.putExtra(WebActivity.EXTRA_MODE, mode);
        intent.putExtra(WebActivity.EXTRA_QUERY, query);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    /** Open CameraProxyActivity to handle gallery pick or camera capture. */
    private void launchCamera(int mode) {
        Intent intent = new Intent(this, CameraProxyActivity.class);
        intent.putExtra(CameraProxyActivity.EXTRA_MODE, mode);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    // ── notification ──────────────────────────────────────────────────────────

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Bubble Service", NotificationManager.IMPORTANCE_MIN);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Float Bubble aktif")
                .setSmallIcon(android.R.drawable.presence_online)
                .build();
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private void safeRemove(View v) {
        if (v == null) return;
        try { windowManager.removeView(v); } catch (Exception ignored) {}
    }

    private int dp(int v)   { return (int)(v * getResources().getDisplayMetrics().density); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
}
