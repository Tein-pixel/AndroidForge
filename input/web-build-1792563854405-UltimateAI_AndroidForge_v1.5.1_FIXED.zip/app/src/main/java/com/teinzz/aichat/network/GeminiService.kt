package com.teinzz.aichat.network

/** Gemini REST/SSE endpoints. Stream responses are parsed by AiRepository. */
object GeminiService {
    const val KEY_CHECK_URL = "https://generativelanguage.googleapis.com/v1beta/models"
    fun streamUrl(modelId: String): String = "https://generativelanguage.googleapis.com/v1beta/models/$modelId:streamGenerateContent?alt=sse"
}
