package com.teinzz.aichat

import android.content.Context
import android.net.Uri
import java.io.File

/** JPEG compression shared by gallery and CameraX images. */
object ImageCompressor {
    fun fromGallery(context: Context, uri: Uri): File = AttachmentTools.copyImage(context, uri)
    fun cameraFile(context: Context, path: String): String = AttachmentTools.compressPath(context, path)
}
