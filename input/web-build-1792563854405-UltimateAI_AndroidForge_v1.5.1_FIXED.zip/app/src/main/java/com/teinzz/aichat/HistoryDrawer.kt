package com.teinzz.aichat

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.teinzz.aichat.data.ConversationEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryDrawerContent(
    conversations: List<ConversationEntity>, onNewChat: () -> Unit,
    onSelect: (Long) -> Unit, onRename: (Long, String) -> Unit, onDelete: (Long) -> Unit,
    onSettings: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    var actionFor by remember { mutableStateOf<ConversationEntity?>(null) }
    var renameFor by remember { mutableStateOf<ConversationEntity?>(null) }
    var renameText by remember { mutableStateOf("") }
    val filtered = conversations.filter { it.title.contains(search, true) }
    val now = System.currentTimeMillis()
    val groups = listOf(
        "Today" to filtered.filter { now - it.updatedAt < 24L * 60 * 60 * 1000 },
        "Yesterday" to filtered.filter { now - it.updatedAt >= 24L * 60 * 60 * 1000 && now - it.updatedAt < 48L * 60 * 60 * 1000 },
        "Previous 7 days" to filtered.filter { now - it.updatedAt >= 48L * 60 * 60 * 1000 && now - it.updatedAt < 7L * 24 * 60 * 60 * 1000 },
        "Previous 30 days" to filtered.filter { now - it.updatedAt >= 7L * 24 * 60 * 60 * 1000 && now - it.updatedAt < 30L * 24 * 60 * 60 * 1000 },
        "Older" to filtered.filter { now - it.updatedAt >= 30L * 24 * 60 * 60 * 1000 }
    )
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerLow).padding(horizontal = 12.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
            Text("ChatAI", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, contentDescription = "Settings") }
        }
        Button(onClick = onNewChat, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface)) {
            Icon(Icons.Outlined.Add, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("New chat"); Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp), placeholder = { Text("Search chats…") }, leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) })
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            groups.forEach { (label, groupItems) ->
                if (groupItems.isNotEmpty()) {
                    item { Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 14.dp, bottom = 5.dp)) }
                    items(groupItems, key = { it.id }) { conv ->
                        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp)).clickable { onSelect(conv.id) }.padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(conv.title, maxLines = 2, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            Box {
                                IconButton(onClick = { actionFor = conv }, modifier = Modifier.size(34.dp)) { Icon(Icons.Outlined.MoreHoriz, contentDescription = "Conversation actions", modifier = Modifier.size(19.dp)) }
                                DropdownMenu(expanded = actionFor?.id == conv.id, onDismissRequest = { actionFor = null }) {
                                    DropdownMenuItem(text = { Text("Rename") }, leadingIcon = { Icon(Icons.Outlined.Edit, null) }, onClick = { renameText = conv.title; renameFor = conv; actionFor = null })
                                    DropdownMenuItem(text = { Text("Delete") }, leadingIcon = { Icon(Icons.Outlined.DeleteOutline, null) }, onClick = { onDelete(conv.id); actionFor = null })
                                }
                            }
                        }
                    }
                }
            }
            if (filtered.isEmpty()) item { Text(if (search.isBlank()) "Your conversations will appear here." else "No matching chats.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(12.dp)) }
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Row(Modifier.fillMaxWidth().clickable(onClick = onSettings).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Settings, contentDescription = null); Spacer(Modifier.width(12.dp)); Text("Settings", modifier = Modifier.weight(1f)); Icon(Icons.Outlined.ChevronRight, contentDescription = null)
        }
    }
    renameFor?.let { conv ->
        AlertDialog(onDismissRequest = { renameFor = null }, title = { Text("Rename chat") }, text = {
            OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true, label = { Text("Chat title") })
        }, confirmButton = { TextButton(onClick = { onRename(conv.id, renameText); renameFor = null }) { Text("Save") } }, dismissButton = { TextButton(onClick = { renameFor = null }) { Text("Cancel") } })
    }
}
