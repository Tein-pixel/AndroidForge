package com.teinzz.aichat

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.teinzz.aichat.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onSettings: () -> Unit, onCamera: () -> Unit, onArtifacts: () -> Unit) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val conversations by vm.conversations.collectAsState()
    var showModels by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var attachedPath by remember { mutableStateOf<String?>(null) }
    var attachmentName by remember { mutableStateOf<String?>(null) }
    var fileContext by remember { mutableStateOf<String?>(null) }
    var isImage by remember { mutableStateOf(false) }
    var busyAttachment by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val messages = vm.messages
    val listState = rememberLazyListState()
    val snack = remember { SnackbarHostState() }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busyAttachment = true
            runCatching { withContext(Dispatchers.IO) { ImageCompressor.fromGallery(context, uri) } }
                .onSuccess { attachedPath = it.absolutePath; attachmentName = "Image.jpg"; isImage = true; fileContext = null }
                .onFailure { snack.showSnackbar("Gambar gagal dibuka: ${it.message ?: "format tidak didukung"}") }
            busyAttachment = false
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busyAttachment = true
            val name = withContext(Dispatchers.IO) {
                context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else "attachment" } ?: "attachment"
            }
            runCatching { withContext(Dispatchers.IO) { AttachmentTools.copyAndExtract(context, uri, name) } }
                .onSuccess { (file, extracted) -> attachedPath = file.absolutePath; attachmentName = name; fileContext = extracted; isImage = false }
                .onFailure { snack.showSnackbar("File gagal dibaca: ${it.message ?: "error"}") }
            busyAttachment = false
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.content) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
    LaunchedEffect(vm.errorMessage.value) { vm.errorMessage.value?.let { snack.showSnackbar(it) } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth(0.86f)) {
                HistoryDrawerContent(conversations, onNewChat = { vm.newChat(); draft = ""; scope.launch { drawerState.close() } },
                    onSelect = { vm.selectConversation(it); draft = ""; scope.launch { drawerState.close() } },
                    onRename = vm::renameConversation, onDelete = vm::deleteConversation,
                    onSettings = { scope.launch { drawerState.close() }; onSettings() })
            }
        }
    ) {
        Scaffold(
            // Combined with windowSoftInputMode=adjustResize, this keeps the composer above the IME
            // on Android 10 and newer instead of allowing the keyboard to cover the text field.
            modifier = Modifier.fillMaxSize().imePadding(),
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Outlined.Menu, contentDescription = "Open history") }
                        TextButton(onClick = { showModels = true }, modifier = Modifier.weight(1f)) {
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (vm.isModelReady()) vm.currentModel.value.name else "Pilih model AI", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Icon(Icons.Outlined.ExpandMore, contentDescription = "Choose model")
                        }
                        IconButton(onClick = { vm.newChat(); draft = ""; attachedPath = null; fileContext = null }) { Icon(Icons.Outlined.Edit, contentDescription = "New chat") }
                        IconButton(onClick = onArtifacts) { Icon(Icons.Outlined.Code, contentDescription = "Open Artifacts") }
                        IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, contentDescription = "Settings") }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (messages.isEmpty()) {
                        WelcomePanel(onSuggestion = { draft = it })
                    }
                    if (messages.isNotEmpty()) {
                        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                            items(messages, key = { if (it.id == 0L) "${it.role}-${it.createdAt}" else it.id }) { msg ->
                                MessageRow(msg, streaming = vm.isGenerating.value && msg.id == messages.lastOrNull()?.id)
                            }
                            if (vm.isGenerating.value && (messages.lastOrNull()?.content.isNullOrBlank())) item { TypingIndicator() }
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    if (isImage && attachedPath != null && !vm.currentModel.value.vision) {
                        Text("Model ini tidak mendukung gambar. Pilih model berlabel GAMBAR dari pemilih model.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
                    }
                    if (attachedPath != null || busyAttachment) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (isImage && attachedPath != null) AsyncImage(model = File(attachedPath!!), contentDescription = "Image preview", modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
                            else Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) { Icon(Icons.Outlined.AttachFile, null, Modifier.padding(13.dp)) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (busyAttachment) "Reading attachment…" else attachmentName ?: "Attachment", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                                Text(if (isImage) "Image will be sent to a vision model" else if (fileContext != null) "Text extracted and ready" else "File attached", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { attachedPath = null; attachmentName = null; fileContext = null; isImage = false }) { Icon(Icons.Outlined.Close, contentDescription = "Remove attachment") }
                        }
                    }
                    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                            BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), minLines = 1, maxLines = 4,
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface, lineHeight = 24.sp),
                                decorationBox = { inner -> Box { if (draft.isEmpty()) Text("Tanyakan apa saja…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge); inner() } })
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                var showAttachMenu by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(onClick = { showAttachMenu = true }, enabled = !busyAttachment) {
                                        Icon(Icons.Outlined.Add, contentDescription = "Lampiran dan mode", modifier = Modifier.size(26.dp))
                                    }
                                    DropdownMenu(expanded = showAttachMenu, onDismissRequest = { showAttachMenu = false }) {
                                        DropdownMenuItem(
                                            text = { Text("File atau dokumen") },
                                            leadingIcon = { Icon(Icons.Outlined.AttachFile, contentDescription = null) },
                                            onClick = { showAttachMenu = false; filePicker.launch(arrayOf("application/pdf", "text/plain", "text/csv", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Ambil foto dengan kamera") },
                                            leadingIcon = { Icon(Icons.Outlined.PhotoCamera, contentDescription = null) },
                                            onClick = { showAttachMenu = false; onCamera() }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Pilih foto dari galeri") },
                                            leadingIcon = { Icon(Icons.Outlined.Image, contentDescription = null) },
                                            onClick = { showAttachMenu = false; gallery.launch("image/*") }
                                        )
                                        HorizontalDivider()
                                        DropdownMenuItem(
                                            text = { Text(if (vm.chatMode.value == ChatMode.THINK_HARDER) "Matikan berpikir lebih keras" else "Berpikir lebih keras") },
                                            leadingIcon = { Icon(Icons.Outlined.Psychology, contentDescription = null) },
                                            trailingIcon = { if (vm.chatMode.value == ChatMode.THINK_HARDER) Icon(Icons.Outlined.Check, contentDescription = "Aktif") },
                                            onClick = { showAttachMenu = false; vm.setChatMode(if (vm.chatMode.value == ChatMode.THINK_HARDER) ChatMode.NORMAL else ChatMode.THINK_HARDER) }
                                        )
                                        DropdownMenuItem(
                                            enabled = vm.currentModel.value.provider in setOf(Provider.GEMINI, Provider.OPENROUTER),
                                            text = { Text(if (vm.chatMode.value == ChatMode.DEEP_RESEARCH) "Matikan riset mendalam" else "Riset mendalam") },
                                            leadingIcon = { Icon(Icons.Outlined.TravelExplore, contentDescription = null) },
                                            trailingIcon = { if (vm.chatMode.value == ChatMode.DEEP_RESEARCH) Icon(Icons.Outlined.Check, contentDescription = "Aktif") },
                                            onClick = { showAttachMenu = false; vm.setChatMode(if (vm.chatMode.value == ChatMode.DEEP_RESEARCH) ChatMode.NORMAL else ChatMode.DEEP_RESEARCH) }
                                        )
                                    }
                                }
                                Spacer(Modifier.weight(1f))
                                if (vm.isGenerating.value) {
                                    IconButton(onClick = vm::stopGenerating) { Icon(Icons.Outlined.StopCircle, contentDescription = "Stop generating") }
                                } else {
                                    IconButton(onClick = {
                                        val finalText = if (!isImage && fileContext != null) buildString { append(draft); append("\n\n[Attached file: ${attachmentName ?: "file"}]\n"); append(fileContext) } else draft
                                        val modelReady = vm.isModelReady()
                                        vm.send(finalText, if (isImage) attachedPath else null, attachmentName)
                                        // Keep the user's draft if no authenticated live model is ready yet.
                                        if (modelReady) {
                                            draft = ""; attachedPath = null; attachmentName = null; fileContext = null; isImage = false
                                        }
                                    }, enabled = (draft.isNotBlank() || attachedPath != null) && !busyAttachment && (!isImage || vm.currentModel.value.vision), modifier = Modifier.size(42.dp).background(if ((draft.isNotBlank() || attachedPath != null) && !busyAttachment) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant, CircleShape)) {
                                        Icon(Icons.Outlined.ArrowUpward, contentDescription = "Send", tint = MaterialTheme.colorScheme.surface, modifier = Modifier.size(22.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showModels) {
            ModalBottomSheet(onDismissRequest = { showModels = false }, containerColor = MaterialTheme.colorScheme.surface) {
                ModelChooser(vm = vm, onSelect = { vm.selectModel(it); showModels = false })
            }
        }
    }
}

@Composable
private fun WelcomePanel(onSuggestion: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(62.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.AutoAwesome, contentDescription = null, modifier = Modifier.size(32.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        Text("Ada yang bisa saya bantu?", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(24.dp))
        val suggestions = listOf("Buat gambar" to Icons.Outlined.Image, "Analisis foto" to Icons.Outlined.Visibility, "Bantu coding" to Icons.Outlined.Code, "Rangkum file" to Icons.Outlined.Description)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            suggestions.chunked(2).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { (label, icon) ->
                        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), modifier = Modifier.weight(1f).clickable { onSuggestion(when (label) { "Buat gambar" -> "Bantu aku merancang prompt untuk gambar: "; "Analisis foto" -> "Analisis foto ini dan jelaskan detail pentingnya."; "Bantu coding" -> "Bantu aku menulis dan memperbaiki kode. Jelaskan solusinya."; else -> "Rangkum isi file yang aku lampirkan." }) }.padding(horizontal = 12.dp, vertical = 15.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)); Text(label, style = MaterialTheme.typography.bodyMedium, maxLines = 2) }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ModelChooser(vm: ChatViewModel, onSelect: (AiModel) -> Unit) {
    var search by remember { mutableStateOf("") }
    val allModels = vm.modelCatalog.value
    val readyProviders = vm.availableModelProviders.value
    val models = allModels.filter { it.provider.active && it.provider in readyProviders &&
        vm.themeManager.getApiKey(it.provider).isNotBlank() && (vm.showPaidModels.value || it.freeTier) && (
        search.isBlank() || it.name.contains(search, ignoreCase = true) || it.id.contains(search, ignoreCase = true) || it.provider.title.contains(search, ignoreCase = true)
    ) }
    Column(
        Modifier.fillMaxWidth().heightIn(max = 680.dp).padding(horizontal = 18.dp).padding(bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Pilih model", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${models.size} model ditampilkan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${models.count { it.freeTier }} gratis/kuota terbatas dari ${models.size} model aktif", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { vm.refreshModelCatalog() }, enabled = !vm.isRefreshingModelCatalog.value) {
                if (vm.isRefreshingModelCatalog.value) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                else Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text("Perbarui")
            }
        }
        OutlinedTextField(
            value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, placeholder = { Text("Cari nama atau ID model…") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            trailingIcon = { if (search.isNotBlank()) IconButton(onClick = { search = "" }) { Icon(Icons.Outlined.Close, contentDescription = "Hapus pencarian") } }
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Tampilkan model berbayar", style = MaterialTheme.typography.bodyMedium)
                Text("Nonaktif = hanya model bertanda gratis/kuota terbatas", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = vm.showPaidModels.value, onCheckedChange = vm::setPaidVisible)
        }
        if (vm.modelCatalogStatus.value.isNotBlank()) {
            Text(vm.modelCatalogStatus.value, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = vm::testSelectedModel, enabled = vm.isModelReady() && !vm.isTestingModel.value && !vm.isGenerating.value && !vm.isGeneratingArtifact.value) {
                if (vm.isTestingModel.value) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp)
                else Icon(Icons.Outlined.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text("Tes model terpilih")
            }
            Text("Mengirim satu request API", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (vm.modelTestStatus.value.isNotBlank()) {
            Text(vm.modelTestStatus.value, style = MaterialTheme.typography.labelSmall,
                color = if (vm.modelTestStatus.value.startsWith("BERHASIL")) MaterialTheme.colorScheme.primary else if (vm.modelTestStatus.value.startsWith("GAGAL")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        if (models.isEmpty()) {
            if (vm.isRefreshingModelCatalog.value) {
                Row(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Memuat katalog model…", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                Text("Belum ada model siap. Buka Pengaturan, simpan API key yang valid, lalu tekan Perbarui. Provider tanpa key atau dengan katalog gagal tidak ditampilkan.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 18.dp))
            }
        } else {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 320.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Provider.values().filter { provider -> models.any { it.provider == provider } }.forEach { provider ->
                    val providerModels = models.filter { it.provider == provider }
                    item(key = "provider_${provider.name}") {
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(provider.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.width(8.dp))
                            Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant) {
                                Text("${providerModels.size}", modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    items(providerModels, key = { it.storageKey }) { model ->
                        val selected = vm.currentModel.value.storageKey == model.storageKey
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                                .then(if (selected) Modifier.border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), RoundedCornerShape(14.dp)) else Modifier)
                                .clickable { onSelect(model) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(model.name, style = MaterialTheme.typography.bodyLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(model.id, style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 2.dp))
                                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    ModelMetaBadge(model.badge)
                                    if (model.vision) ModelMetaBadge("GAMBAR")
                                }
                                if (model.description.isNotBlank()) Text(model.description, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 3.dp))
                            }
                            if (selected) {
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Outlined.CheckCircle, contentDescription = "Model dipilih", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
        Text("Daftar hanya berisi model chat yang dikembalikan katalog live setelah key provider tersimpan. Model berbayar dapat menimbulkan biaya; label gratis/kuota bukan jaminan akses atau uptime.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ModelMetaBadge(label: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun MessageRow(message: MessageEntity, streaming: Boolean) {
    val isUser = message.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Top) {
        if (!isUser) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(top = 1.dp).size(28.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.AutoAwesome, contentDescription = "AI response", modifier = Modifier.size(16.dp)) } }
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.widthIn(max = if (isUser) 310.dp else 560.dp).fillMaxWidth(if (isUser) 0.85f else 1f).clip(if (isUser) RoundedCornerShape(24.dp) else RoundedCornerShape(4.dp)).background(if (isUser) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent).padding(if (isUser) 14.dp else 0.dp)) {
            if (message.imagePath != null) {
                AsyncImage(model = File(message.imagePath), contentDescription = "Sent image", modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(16.dp)))
                if (message.content.isNotBlank()) Spacer(Modifier.height(8.dp))
            }
            if (message.content.isNotBlank()) {
                if (isUser) Text(message.content, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                else RichMarkdown(message.content + if (streaming) "▍" else "")
            }
            if (!isUser && !streaming && message.content.isNotBlank()) {
                val clipboard = LocalClipboardManager.current
                TextButton(
                    onClick = { clipboard.setText(AnnotatedString(message.content)) },
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                ) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy full answer", modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Salin jawaban", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (isUser && message.fileName != null && message.imagePath == null) Text("Attached: ${message.fileName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 5.dp))
        }
    }
}

@Composable
private fun RichMarkdown(markdown: String) {
    val clipboard = LocalClipboardManager.current
    val uriHandler = LocalUriHandler.current
    val blocks = remember(markdown) {
        val result = mutableListOf<Pair<Boolean, String>>()
        val regex = Regex("```([^\\n]*)\\n([\\s\\S]*?)```")
        var cursor = 0
        regex.findAll(markdown).forEach { match ->
            if (match.range.first > cursor) result.add(false to markdown.substring(cursor, match.range.first))
            result.add(true to (match.groupValues[1].trim() + "\n" + match.groupValues[2].trimEnd()))
            cursor = match.range.last + 1
        }
        if (cursor < markdown.length) result.add(false to markdown.substring(cursor))
        result
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        blocks.forEach { (code, content) ->
            if (code) {
                val codeText = content.substringAfter('\n', "")
                Surface(color = Color(0xFF0D1117), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(Modifier.fillMaxWidth().background(Color(0xFF171B22)).padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(content.substringBefore('\n').ifBlank { "code" }, style = MaterialTheme.typography.labelSmall, color = Color(0xFFB7C0CC), modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(codeText)) }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) { Icon(Icons.Outlined.ContentCopy, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("Copy", fontSize = 12.sp) }
                        }
                        Text(syntaxHighlight(codeText), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(14.dp), color = Color(0xFFE6EDF3), fontSize = 13.sp, lineHeight = 19.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    }
                }
            } else if (content.isNotBlank()) {
                val lines = content.lines()
                lines.forEach { line ->
                    val trimmed = line.trimStart()
                    val bullet = trimmed.startsWith("- ") || trimmed.startsWith("* ") || Regex("^\\d+\\. ").containsMatchIn(trimmed)
                    val annotated = styledMarkdown(if (bullet) "•  " + trimmed.removePrefix("- ").removePrefix("* ").replaceFirst(Regex("^\\d+\\. "), "") else line, MaterialTheme.colorScheme.surfaceVariant)
                    ClickableText(
                        text = annotated,
                        style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface, lineHeight = 27.sp),
                        onClick = { offset ->
                            annotated.getStringAnnotations("URL", offset, offset).firstOrNull()?.let { annotation ->
                                runCatching { uriHandler.openUri(annotation.item) }
                            }
                        }
                    )
                }
            }
        }
    }
}

private fun styledMarkdown(line: String, inlineCodeBackground: Color): AnnotatedString = buildAnnotatedString {
    val token = Regex("\\[[^\\]]+\\]\\(https?://[^)]+\\)|\\*\\*.+?\\*\\*|(?<!\\*)\\*[^*]+\\*|`[^`]+`")
    var cursor = 0
    token.findAll(line).forEach { match ->
        append(line.substring(cursor, match.range.first))
        val raw = match.value
        when {
            raw.startsWith("[") && raw.contains("](") -> {
                val split = raw.indexOf("](")
                val label = raw.substring(1, split)
                val url = raw.substring(split + 2, raw.length - 1)
                pushStringAnnotation(tag = "URL", annotation = url)
                pushStyle(SpanStyle(color = Color(0xFF2F80ED), textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline))
                append(label)
                pop(); pop()
            }
            raw.startsWith("**") -> { pushStyle(SpanStyle(fontWeight = FontWeight.Bold)); append(raw.substring(2, raw.length - 2)); pop() }
            raw.startsWith("*") -> { pushStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)); append(raw.substring(1, raw.length - 1)); pop() }
            else -> { pushStyle(SpanStyle(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, background = inlineCodeBackground)); append(raw.substring(1, raw.length - 1)); pop() }
        }
        cursor = match.range.last + 1
    }
    append(line.substring(cursor))
}

private fun syntaxHighlight(code: String): AnnotatedString = buildAnnotatedString {
    append(code)
    val keywords = Regex("\\b(fun|val|var|class|object|return|if|else|when|for|while|suspend|data|private|public|import|package|const|let|function|async|await|def|from|as|try|catch|throw|new|true|false|null)\\b")
    keywords.findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFFFF7B72), fontWeight = FontWeight.Medium), it.range.first, it.range.last + 1) }
    Regex("\"[^\"]*\"|'[^']*'").findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFFA5D6FF)), it.range.first, it.range.last + 1) }
    Regex("//[^\\n]*|#[^\\n]*").findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFF8B949E)), it.range.first, it.range.last + 1) }
}

@Composable
private fun TypingIndicator() {
    Row(Modifier.padding(start = 40.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { idx -> Surface(shape = CircleShape, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f), modifier = Modifier.padding(end = 4.dp).size(if (idx == 1) 7.dp else 5.dp)) {} }
        Text("Thinking", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 5.dp))
    }
}
