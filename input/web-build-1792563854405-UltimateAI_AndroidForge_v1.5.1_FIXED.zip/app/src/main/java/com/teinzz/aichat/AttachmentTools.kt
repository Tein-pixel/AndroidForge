package com.teinzz.aichat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.InputSource
import java.io.StringReader

object AttachmentTools {
    fun copyImage(context: Context, uri: Uri): File {
        val source = context.contentResolver.openInputStream(uri) ?: error("Tidak dapat membaca gambar")
        val bytes = source.use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: error("Format gambar tidak didukung")
        val ratio = minOf(1f, 1800f / maxOf(bitmap.width, bitmap.height))
        val scaled = if (ratio < 1f || bytes.size > 2 * 1024 * 1024) {
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true)
        } else bitmap
        val out = ByteArrayOutputStream()
        var quality = 85
        do { out.reset(); scaled.compress(Bitmap.CompressFormat.JPEG, quality, out); quality -= 8 } while (out.size() > 950 * 1024 && quality >= 37)
        if (scaled !== bitmap) scaled.recycle()
        bitmap.recycle()
        val target = File(context.filesDir, "img_${System.currentTimeMillis()}.jpg")
        target.writeBytes(out.toByteArray())
        return target
    }

    fun copyAndExtract(context: Context, uri: Uri, name: String): Pair<File, String> {
        val target = File(context.filesDir, "file_${System.currentTimeMillis()}_${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
        context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } } ?: error("File tidak dapat dibaca")
        val lower = name.lowercase()
        val extracted = when {
            lower.endsWith(".txt") || lower.endsWith(".csv") -> target.readText().take(100_000)
            lower.endsWith(".pdf") -> runCatching {
                PDFBoxResourceLoader.init(context)
                PDDocument.load(target).use { doc -> PDFTextStripper().getText(doc).take(100_000) }
            }.getOrElse { "PDF tersimpan, tetapi teks gagal diekstrak: ${it.message}" }
            lower.endsWith(".docx") -> runCatching {
                ZipInputStream(target.inputStream()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null && entry.name != "word/document.xml") entry = zip.nextEntry
                    if (entry == null) "Tidak menemukan teks DOCX" else {
                        val xml = zip.bufferedReader().readText()
                        val factory = DocumentBuilderFactory.newInstance().apply { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
                        val doc = factory.newDocumentBuilder().parse(InputSource(StringReader(xml)))
                        val nodes = doc.getElementsByTagName("w:t")
                        (0 until nodes.length).joinToString(" ") { nodes.item(it).textContent }.take(100_000)
                    }
                }
            }.getOrElse { "DOCX tersimpan, tetapi teks gagal diekstrak: ${it.message}" }
            else -> "File tersimpan (${target.length() / 1024} KB). Format ini belum diekstrak otomatis; jelaskan apa yang perlu dibaca."
        }
        return target to extracted
    }

    fun compressPath(context: Context, path: String): String {
        val source = File(path)
        if (!source.exists() || source.length() <= 950 * 1024) return path
        val bitmap = BitmapFactory.decodeFile(path) ?: return path
        val ratio = minOf(1f, 1800f / maxOf(bitmap.width, bitmap.height))
        val scaled = if (ratio < 1f) Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true) else bitmap
        val output = ByteArrayOutputStream()
        var quality = 82
        do { output.reset(); scaled.compress(Bitmap.CompressFormat.JPEG, quality, output); quality -= 8 } while (output.size() > 950 * 1024 && quality >= 42)
        if (scaled !== bitmap) scaled.recycle()
        bitmap.recycle()
        val target = File(context.filesDir, "compressed_${System.currentTimeMillis()}.jpg")
        target.writeBytes(output.toByteArray())
        return if (target.length() < source.length()) target.absolutePath else path
    }
}
