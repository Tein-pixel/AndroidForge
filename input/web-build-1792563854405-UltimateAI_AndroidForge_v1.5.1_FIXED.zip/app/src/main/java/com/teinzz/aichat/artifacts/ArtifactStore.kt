package com.teinzz.aichat.artifacts

import android.content.Context
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Local-only artifact persistence. Projects stay inside app-private storage. */
data class ArtifactProject(
    val id: String,
    val title: String,
    val prompt: String,
    val html: String,
    val updatedAt: Long
)

object ArtifactStore {
    private fun root(context: Context): File = File(context.filesDir, "artifacts").apply { mkdirs() }

    suspend fun list(context: Context): List<ArtifactProject> = withContext(Dispatchers.IO) {
        root(context).listFiles { f -> f.isFile && f.extension == "json" }
            .orEmpty()
            .mapNotNull { file -> runCatching { parse(file) }.getOrNull() }
            .sortedByDescending { it.updatedAt }
    }

    suspend fun save(context: Context, project: ArtifactProject): ArtifactProject = withContext(Dispatchers.IO) {
        val safeId = project.id.takeIf { it.matches(Regex("[A-Za-z0-9-]{1,80}")) } ?: UUID.randomUUID().toString()
        val saved = project.copy(id = safeId, title = project.title.trim().ifBlank { "Untitled artifact" }.take(100), updatedAt = System.currentTimeMillis())
        val file = File(root(context), "${saved.id}.json")
        val json = JSONObject()
            .put("id", saved.id)
            .put("title", saved.title)
            .put("prompt", saved.prompt)
            .put("html", saved.html)
            .put("updatedAt", saved.updatedAt)
        val temp = File(file.parentFile, "${file.name}.tmp")
        temp.writeText(json.toString(), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(json.toString(), Charsets.UTF_8)
            temp.delete()
        }
        saved
    }

    suspend fun delete(context: Context, id: String) = withContext(Dispatchers.IO) {
        if (!id.matches(Regex("[A-Za-z0-9-]{1,80}"))) return@withContext
        File(root(context), "$id.json").delete()
    }

    private fun parse(file: File): ArtifactProject {
        val json = JSONObject(file.readText(Charsets.UTF_8))
        return ArtifactProject(
            id = json.optString("id", file.nameWithoutExtension),
            title = json.optString("title", "Untitled artifact"),
            prompt = json.optString("prompt", ""),
            html = json.optString("html", ""),
            updatedAt = json.optLong("updatedAt", file.lastModified())
        )
    }
}
