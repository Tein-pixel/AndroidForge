package com.teinzz.aichat

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalUriHandler
import com.teinzz.aichat.data.ModelCatalog
import com.teinzz.aichat.data.Provider
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val theme by vm.themeManager.theme.collectAsState(initial = vm.themeManager.getInitialTheme())
    val showPaid = vm.showPaidModels.value
    var feedback by remember { mutableStateOf("") }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Settings") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Back") } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                ThemeMode.values().forEach { mode ->
                    val selected = theme == mode
                    Box(Modifier.weight(1f).background(if (selected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)).clickable { scope.launch { vm.themeManager.setTheme(mode) } }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }, color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            HorizontalDivider()
            Text("Provider API keys", style = MaterialTheme.typography.titleMedium)
            Text("Keys disimpan lokal menggunakan EncryptedSharedPreferences. Jangan membagikan key kepada orang lain.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Provider.values().forEach { provider ->
                ApiKeyCard(vm, provider, onTest = { result -> feedback = result })
            }
            HorizontalDivider()
            Text("Model access", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Show paid / usage-based models")
                    Text("Matikan untuk menyaring katalog ke model bertanda free. Label gratis tidak menjamin kuota selalu tersedia.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = showPaid, onCheckedChange = vm::setPaidVisible)
            }
            if (feedback.isNotBlank()) Text(feedback, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
            Text("API usage and free-tier limits are managed by each provider; this app cannot guarantee a free quota for every account.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ApiKeyCard(vm: ChatViewModel, provider: Provider, onTest: (String) -> Unit) {
    val uriHandler = LocalUriHandler.current
    val scope = rememberCoroutineScope()
    var value by remember(provider) { mutableStateOf(vm.themeManager.getApiKey(provider)) }
    var show by remember { mutableStateOf(false) }
    var expanded by remember(provider) { mutableStateOf(provider == Provider.GEMINI || vm.themeManager.getApiKey(provider).isNotBlank() || vm.themeManager.getAuxiliary(provider).isNotBlank()) }
    var extraValue by remember(provider) { mutableStateOf(vm.themeManager.getAuxiliary(provider)) }
    var testing by remember { mutableStateOf(false) }
    var localStatus by remember { mutableStateOf("") }
    val model = ModelCatalog.all.first { it.provider == provider }
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(provider.title, style = MaterialTheme.typography.titleSmall)
                    Text(when {
                        value.isNotBlank() -> "API key tersimpan"
                        !provider.requiresApiKey -> "API key opsional"
                        else -> "API key belum diatur"
                    }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { uriHandler.openUri(provider.keyUrl) }) { Text(if (!provider.active) "Status ↗" else if (provider.requiresApiKey) "Buat key ↗" else "Dokumentasi ↗") }
                Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, contentDescription = if (expanded) "Tutup" else "Buka")
            }
            if (!provider.active) {
                Text("Provider ini telah dipensiunkan dan tidak dapat dipakai. API dan katalog GitHub Models berhenti pada 30 Juli 2026.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            } else if (expanded) {
            if (provider.auxiliaryLabel.isNotBlank()) {
                OutlinedTextField(value = extraValue, onValueChange = { extraValue = it; localStatus = "" }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text(provider.auxiliaryLabel) }, placeholder = { Text(provider.auxiliaryPlaceholder) })
            }
            OutlinedTextField(value = value, onValueChange = { value = it; localStatus = "" }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text(provider.apiKeyLabel) }, placeholder = { Text("Paste API key") },
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { IconButton(onClick = { show = !show }) { Icon(if (show) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, contentDescription = if (show) "Hide key" else "Show key") } })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = {
                    vm.themeManager.setApiKey(provider, value)
                    if (provider.auxiliaryLabel.isNotBlank()) vm.themeManager.setAuxiliary(provider, extraValue)
                    localStatus = "Pengaturan tersimpan lokal."
                    vm.refreshModelCatalog(silent = true)
                }, modifier = Modifier.weight(1f)) { Text("Simpan") }
                Button(onClick = {
                    vm.themeManager.setApiKey(provider, value)
                    if (provider.auxiliaryLabel.isNotBlank()) vm.themeManager.setAuxiliary(provider, extraValue)
                    if (value.isBlank() && provider.requiresApiKey) { localStatus = "Masukkan API key dahulu."; onTest(localStatus) }
                    else if (provider.auxiliaryLabel.isNotBlank() && extraValue.isBlank()) { localStatus = "Masukkan ${provider.auxiliaryLabel}."; onTest(localStatus) }
                    else {
                        testing = true; localStatus = "Memeriksa endpoint provider…"
                        scope.launch {
                            val result = runCatching { vm.testConnection(model) }
                            localStatus = result.fold({ "Koneksi OK · ${it.take(70)}" }, { it.message ?: "Connection test failed." })
                            testing = false; onTest("${provider.title}: $localStatus")
                            vm.refreshModelCatalog(silent = true)
                        }
                    }
                }, enabled = !testing && (!provider.requiresApiKey || value.isNotBlank()) && (provider.auxiliaryLabel.isBlank() || extraValue.isNotBlank()), modifier = Modifier.weight(1f)) { if (testing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Tes koneksi") }
            }
            Text(localStatus.ifBlank { "Tes endpoint katalog. Tes respons AI dari pemilih model sebelum digunakan." }, style = MaterialTheme.typography.bodySmall, color = if (localStatus.contains("OK")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
