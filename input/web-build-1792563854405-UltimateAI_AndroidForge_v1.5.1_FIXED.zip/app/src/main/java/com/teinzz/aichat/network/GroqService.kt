package com.teinzz.aichat.network

/** Groq OpenAI-compatible API endpoints. */
object GroqService {
    const val STREAM_URL = "https://api.groq.com/openai/v1/chat/completions"
    const val KEY_CHECK_URL = "https://api.groq.com/openai/v1/models"
}
