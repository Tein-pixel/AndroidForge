package com.teinzz.aichat

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.teinzz.aichat.data.ChatMode
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "chat_ai_settings")

enum class ThemeMode { LIGHT, DARK, SYSTEM }

class ThemeManager(private val context: Context) {
    private val key = stringPreferencesKey("theme_mode")
    private val statePrefs = context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE)

    init {
        // One-time v1.3 migration: make existing installs dark by default, but keep Light/System selectable later.
        if (!statePrefs.getBoolean("theme_dark_default_migrated_v13", false)) {
            val saved = statePrefs.getString("theme_mode", null)
            if (saved == null || saved == "SYSTEM") statePrefs.edit().putString("theme_mode", "DARK").apply()
            statePrefs.edit().putBoolean("theme_dark_default_migrated_v13", true).apply()
        }
    }

    val theme = context.settingsStore.data.map { prefs ->
        val saved = statePrefs.getString("theme_mode", prefs[key] ?: "DARK") ?: "DARK"
        runCatching { ThemeMode.valueOf(saved) }.getOrDefault(ThemeMode.DARK)
    }
    suspend fun setTheme(mode: ThemeMode) {
        statePrefs.edit().putString("theme_mode", mode.name).apply()
        context.settingsStore.edit { it[key] = mode.name }
    }
    fun getInitialTheme(): ThemeMode = runCatching {
        ThemeMode.valueOf(statePrefs.getString("theme_mode", "DARK") ?: "DARK")
    }.getOrDefault(ThemeMode.DARK)
    private val prefs by lazy {
        val master = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(context, "secure_api_keys", master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    fun getApiKey(provider: com.teinzz.aichat.data.Provider): String = runCatching { prefs.getString(provider.name, "").orEmpty() }.getOrDefault("")
    fun setApiKey(provider: com.teinzz.aichat.data.Provider, value: String) { runCatching { prefs.edit().putString(provider.name, value.trim()).apply() } }
    fun getAuxiliary(provider: com.teinzz.aichat.data.Provider): String = runCatching { prefs.getString("${provider.name}_AUX", "").orEmpty() }.getOrDefault("")
    fun setAuxiliary(provider: com.teinzz.aichat.data.Provider, value: String) { runCatching { prefs.edit().putString("${provider.name}_AUX", value.trim()).apply() } }
    fun getLastModel(): String = context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).getString("last_model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
    fun setLastModel(id: String) { context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).edit().putString("last_model", id).apply() }
    fun getLastChatMode(): ChatMode = runCatching {
        ChatMode.valueOf(context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).getString("last_chat_mode", "NORMAL") ?: "NORMAL")
    }.getOrDefault(ChatMode.NORMAL)
    fun setLastChatMode(mode: ChatMode) { context.getSharedPreferences("chat_ai_state", Context.MODE_PRIVATE).edit().putString("last_chat_mode", mode.name).apply() }
}
