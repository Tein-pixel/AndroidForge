package com.teinzz.aichat.network

import okhttp3.RequestBody
import okhttp3.ResponseBody
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Streaming
import retrofit2.http.Url

interface AiApi {
    @Streaming
    @POST
    suspend fun stream(
        @Url url: String,
        @Header("Authorization") authorization: String?,
        @Header("x-goog-api-key") googleApiKey: String?,
        @Header("HTTP-Referer") referer: String?,
        @Header("X-Title") title: String?,
        @Body body: RequestBody
    ): Response<ResponseBody>

    @GET
    suspend fun probe(
        @Url url: String,
        @Header("Authorization") authorization: String?,
        @Header("x-goog-api-key") googleApiKey: String?,
        @Header("HTTP-Referer") referer: String?,
        @Header("X-Title") title: String?
    ): Response<ResponseBody>

    companion object {
        fun create(readTimeoutSeconds: Long = 120): AiApi {
            // Streaming requests may legitimately take longer than OkHttp's 10-second default read timeout.
            val streamingClient = OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .readTimeout(readTimeoutSeconds, TimeUnit.SECONDS)
                .callTimeout(0, TimeUnit.MILLISECONDS)
                .retryOnConnectionFailure(true)
                .build()
            return Retrofit.Builder()
                .baseUrl("https://api.openai.com/")
                .client(streamingClient)
                .build().create(AiApi::class.java)
        }

        fun createProbe(): AiApi {
            val probeClient = OkHttpClient.Builder()
                .connectTimeout(12, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .callTimeout(20, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build()
            return Retrofit.Builder()
                .baseUrl("https://api.openai.com/")
                .client(probeClient)
                .build().create(AiApi::class.java)
        }
    }
}
