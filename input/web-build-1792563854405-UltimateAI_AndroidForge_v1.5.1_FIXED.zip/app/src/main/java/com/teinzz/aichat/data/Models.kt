package com.teinzz.aichat.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Provider(
    val title: String,
    val apiKeyLabel: String,
    val keyUrl: String,
    val chatUrl: String,
    val modelsUrl: String,
    val requiresApiKey: Boolean = true,
    val auxiliaryLabel: String = "",
    val auxiliaryPlaceholder: String = "",
    val active: Boolean = true
) {
    GEMINI("Gemini", "GEMINI_API_KEY", "https://aistudio.google.com/apikey", "", "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000"),
    GROQ("Groq", "GROQ_API_KEY", "https://console.groq.com/keys", "https://api.groq.com/openai/v1/chat/completions", "https://api.groq.com/openai/v1/models"),
    CEREBRAS("Cerebras", "CEREBRAS_API_KEY", "https://cloud.cerebras.ai/", "https://api.cerebras.ai/v1/chat/completions", "https://api.cerebras.ai/v1/models"),
    OPENROUTER("OpenRouter", "OPENROUTER_API_KEY", "https://openrouter.ai/settings/keys", "https://openrouter.ai/api/v1/chat/completions", "https://openrouter.ai/api/v1/models?output_modalities=text"),
    CLOUDFLARE("Cloudflare", "CLOUDFLARE_API_TOKEN", "https://dash.cloudflare.com/", "https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/v1/chat/completions", "https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/models/search?task=text-generation&per_page=100&page=1", auxiliaryLabel = "Cloudflare Account ID", auxiliaryPlaceholder = "Paste Account ID from Cloudflare dashboard"),
    NVIDIA("NVIDIA", "NVIDIA_API_KEY", "https://build.nvidia.com/", "https://integrate.api.nvidia.com/v1/chat/completions", "https://integrate.api.nvidia.com/v1/models"),
    MISTRAL("Mistral", "MISTRAL_API_KEY", "https://console.mistral.ai/api-keys/", "https://api.mistral.ai/v1/chat/completions", "https://api.mistral.ai/v1/models"),
    SAMBANOVA("SambaNova", "SAMBANOVA_API_KEY", "https://cloud.sambanova.ai/", "https://api.sambanova.ai/v1/chat/completions", "https://api.sambanova.ai/v1/models"),
    HUGGINGFACE("Hugging Face", "HF_TOKEN", "https://huggingface.co/settings/tokens", "https://router.huggingface.co/v1/chat/completions", "https://router.huggingface.co/v1/models"),
    GITHUB("GitHub Models · retired", "Unavailable", "https://github.blog/changelog/2026-07-30-github-models-is-now-retired/", "", "", active = false),
    COHERE("Cohere", "COHERE_API_KEY", "https://dashboard.cohere.com/api-keys", "https://api.cohere.ai/compatibility/v1/chat/completions", "https://api.cohere.ai/v2/models"),
    ZAI("Z.ai / GLM", "ZAI_API_KEY", "https://z.ai/manage-apikey/apikey-list", "https://api.z.ai/api/paas/v4/chat/completions", "https://api.z.ai/api/paas/v4/models"),
    LLM7("LLM7.io", "LLM7 API token", "https://dash.llm7.io/", "https://api.llm7.io/v1/chat/completions", "https://api.llm7.io/v1/models"),
    POLLINATIONS("Pollinations", "POLLINATIONS_API_KEY", "https://enter.pollinations.ai/keys", "https://gen.pollinations.ai/v1/chat/completions", "https://gen.pollinations.ai/v1/models"),
    VERCEL("Vercel AI Gateway", "AI_GATEWAY_API_KEY", "https://vercel.com/ai-gateway", "https://ai-gateway.vercel.sh/v1/chat/completions", "https://ai-gateway.vercel.sh/v1/models"),
    REKA("Reka", "REKA_API_KEY", "https://platform.reka.ai/", "https://api.reka.ai/v1/chat/completions", "https://api.reka.ai/v1/models");

    fun resolvedChatUrl(auxiliaryValue: String = ""): String = chatUrl.replace("{account_id}", auxiliaryValue.trim())
    fun resolvedModelsUrl(auxiliaryValue: String = ""): String = modelsUrl.replace("{account_id}", auxiliaryValue.trim())
}

/** These modes change provider request parameters/tools; they are not animation-only UI states. */
enum class ChatMode(val title: String, val description: String) {
    NORMAL("Normal", "Respons seimbang untuk penggunaan sehari-hari."),
    THINK_HARDER("Berpikir Lebih Keras", "Meminta effort penalaran tinggi dari model yang mendukungnya."),
    DEEP_RESEARCH("Riset Mendalam", "Mengaktifkan pencarian web nyata dan sintesis sumber; biaya pencarian dapat berlaku.")
}

data class AiModel(
    val id: String,
    val name: String,
    val provider: Provider,
    /** Short, honest label shown in the model picker; never a guarantee of quota. */
    val badge: String,
    val freeTier: Boolean,
    val vision: Boolean = false,
    val description: String = "",
    /** Provider-declared compatible request parameters; empty means metadata is unavailable. */
    val supportedParameters: Set<String> = emptySet()
) {
    // Provider-qualified persistence prevents a model slug shared by Groq/OpenRouter from selecting the wrong API.
    val storageKey: String get() = "${provider.name}::$id"
}

object ModelCatalog {
    // Offline fallback catalogue. With a valid key, Settings/Model chooser can refresh live IDs from provider APIs.
    val all = listOf(
        AiModel("gemini-3.8-flash", "Gemini 3.8 Flash", Provider.GEMINI, "GRATIS*", true, true, "Model Flash aktif; kuota, akses akun, dan batas penggunaan berlaku."),
        AiModel("gemini-3.6-flash", "Gemini 3.6 Flash", Provider.GEMINI, "GRATIS*", true, true, "Alternatif Flash resmi; kuota gratis dapat berubah."),
        AiModel("gemini-3.5-flash-lite", "Gemini 3.5 Flash-Lite", Provider.GEMINI, "GRATIS*", true, true, "Model ringan untuk tugas cepat; akses akun tetap berlaku."),
        AiModel("gemini-3.1-flash-lite", "Gemini 3.1 Flash-Lite", Provider.GEMINI, "GRATIS*", true, true, "Model ringan dengan tier gratis; cek kuota akun."),
        AiModel("gemini-3-flash-preview", "Gemini 3 Flash Preview", Provider.GEMINI, "GRATIS*", true, true, "Model preview; ketersediaan dan kuota mengikuti Google API."),
        
        AiModel("gemini-2.5-pro", "Gemini 2.5 Pro", Provider.GEMINI, "GRATIS*", true, true, "Model reasoning; batas free-tier lebih ketat dan dapat berubah."),
        AiModel("gemini-2.5-flash", "Gemini 2.5 Flash", Provider.GEMINI, "GRATIS*", true, true, "Model Flash multimodal stabil dengan kuota free-tier."),
        AiModel("gemini-2.5-flash-lite", "Gemini 2.5 Flash-Lite", Provider.GEMINI, "GRATIS*", true, true, "Model ringan; kuota free-tier berlaku."),
        AiModel("gemma-4-31b-it", "Gemma 4 31B IT", Provider.GEMINI, "GRATIS*", true, true, "Model open-weight gratis via Gemini API; akses sesuai batas provider."),
        AiModel("gemma-4-26b-a4b-it", "Gemma 4 26B A4B IT", Provider.GEMINI, "GRATIS*", true, true, "Varian Gemma 4 MoE gratis via Gemini API; akses sesuai batas provider."),
        AiModel("gemma-3-27b-it", "Gemma 3 27B IT", Provider.GEMINI, "GRATIS*", true, true, "Model instruksi Gemma 3 multimodal; batas free-tier berlaku."),
        AiModel("gemma-3-12b-it", "Gemma 3 12B IT", Provider.GEMINI, "GRATIS*", true, true, "Model instruksi Gemma 3 multimodal; batas free-tier berlaku."),
        AiModel("gemma-3-4b-it", "Gemma 3 4B IT", Provider.GEMINI, "GRATIS*", true, true, "Model Gemma yang lebih ringan untuk perangkat berdaya terbatas di sisi klien API."),
        AiModel("gemma-3-1b-it", "Gemma 3 1B IT", Provider.GEMINI, "GRATIS*", true, false, "Model Gemma ringan untuk chat teks."),
        AiModel("gemma-3n-e4b-it", "Gemma 3n E4B IT", Provider.GEMINI, "GRATIS*", true, true, "Model Gemma 3n instruction; kuota provider berlaku."),
        AiModel("gemma-3n-e2b-it", "Gemma 3n E2B IT", Provider.GEMINI, "GRATIS*", true, true, "Model Gemma 3n instruction ringan; kuota provider berlaku."),
        AiModel("gemini-4-argon", "Gemini 4 Argon", Provider.GEMINI, "BERBAYAR / CEK TIER", false, true, "Model premium terbaru; cek batas harga dan tier Google sebelum dipakai."),

        AiModel("openai/gpt-oss-120b", "GPT-OSS 120B", Provider.GROQ, "GRATIS*", true, false, "Tersedia melalui model/rate limits Groq; periksa kuota dan harga akun."),
        AiModel("openai/gpt-oss-20b", "GPT-OSS 20B", Provider.GROQ, "GRATIS*", true, false, "Model teks lebih ringan; Free Plan memiliki batas penggunaan."),
        AiModel("qwen/qwen3.8-27b", "Qwen3.8 27B", Provider.GROQ, "GRATIS*", true, true, "ID pengganti resmi untuk Qwen3.6-27B; periksa kuota dan akses akun Groq."),

        AiModel("openrouter/free", "OpenRouter Free Router", Provider.OPENROUTER, "GRATIS*", true, false, "Memilih model gratis yang sesuai. Rute dan modalitas tujuan dapat berubah."),
        AiModel("minimax/minimax-m3.1-flash:free", "MiniMax M3.1 Flash (Free)", Provider.OPENROUTER, "GRATIS*", true, true, "Model multimodal gratis; rute dan kuota dapat berubah."),
        AiModel("poolside/laguna-s-2.1:free", "Poolside Laguna S 2.1", Provider.OPENROUTER, "GRATIS*", true, false, "Model coding gratis dari katalog OpenRouter; antrean bisa berubah."),
        AiModel("nvidia/nemotron-3-super-120b-a12b:free", "Nemotron 3 Super", Provider.OPENROUTER, "GRATIS*", true, false, "Model reasoning terbuka; rute gratis bisa sibuk."),
        AiModel("cohere/north-mini-code:free", "Cohere North Mini Code", Provider.OPENROUTER, "GRATIS*", true, false, "Model coding; kebijakan pemrosesan data provider tetap berlaku."),
        AiModel("poolside/laguna-xs-2.1:free", "Poolside Laguna XS 2.1", Provider.OPENROUTER, "GRATIS*", true, false, "Model coding lebih ringkas; rute gratis bisa sibuk."),
        AiModel("inclusionai/ling-3.0-tiny:free", "Ling 3.0 Tiny", Provider.OPENROUTER, "GRATIS*", true, false, "Model ringan untuk instruksi dan percakapan."),
        AiModel("nvidia/nemotron-3-nano-30b-a3b:free", "Nemotron 3 Nano 30B A3B", Provider.OPENROUTER, "GRATIS*", true, false, "Model teks hemat komputasi; rute gratis bisa berubah."),
        AiModel("nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free", "Nemotron 3 Nano Omni", Provider.OPENROUTER, "GRATIS*", true, true, "Model multimodal untuk teks dan gambar; rute dapat penuh."),
        AiModel("google/gemma-4-26b-a4b-it:free", "Gemma 4 26B A4B", Provider.OPENROUTER, "GRATIS*", true, true, "Model instruction multimodal gratis melalui OpenRouter."),
        AiModel("nvidia/nemotron-nano-9b-v2:free", "Nemotron Nano 9B V2", Provider.OPENROUTER, "GRATIS*", true, false, "Model reasoning ringan; rute gratis bisa berubah."),
        AiModel("openai/gpt-oss-20b:free", "GPT-OSS 20B", Provider.OPENROUTER, "GRATIS*", true, false, "Model teks open-weight gratis melalui OpenRouter."),
        AiModel("nvidia/nemotron-3-ultra-550b-a55b:free", "Nemotron 3 Ultra (Free)", Provider.OPENROUTER, "GRATIS*", true, false, "Model reasoning gratis; rute dapat sementara penuh atau gagal."),
        AiModel("nvidia/nemotron-3.5-super-vl:free", "Nemotron 3.5 Super VL (Free)", Provider.OPENROUTER, "GRATIS*", true, true, "Model multimodal teks/gambar. Rute gratis dapat mengalami gangguan provider."),
        AiModel("nvidia/nemotron-3.5-lightning:free", "Nemotron 3.5 Lightning (Free)", Provider.OPENROUTER, "GRATIS*", true, false, "Model teks cepat; ketersediaan rute gratis bergantung provider."),
        AiModel("anthropic/claude-sonnet-4.5", "Claude Sonnet 4.5", Provider.OPENROUTER, "BERBAYAR", false, true, "Model premium melalui OpenRouter; penggunaan dapat dikenakan biaya."),
        AiModel("openai/gpt-5-mini", "GPT-5 mini", Provider.OPENROUTER, "BERBAYAR", false, true, "Model premium melalui OpenRouter; biaya mengikuti harga aktif."),

        // Provider-specific fallback IDs. Refresh each provider's live catalog before relying on these IDs.
        AiModel("gpt-oss-120b", "GPT-OSS 120B", Provider.CEREBRAS, "FREE TIER*", true, false, "Cerebras documents a free developer tier with stricter limits; current account eligibility, any card requirement, and model availability must be confirmed in its dashboard. Promotional credits are not a permanent free quota."),
        AiModel("llama3.1-8b", "Llama 3.1 8B", Provider.CEREBRAS, "FREE TIER*", true, false, "Known Cerebras model ID; free-tier quotas and account eligibility apply."),
        AiModel("zai-glm-4.7", "GLM 4.7", Provider.CEREBRAS, "FREE TIER*", true, false, "Model ID documented by Cerebras; verify the currently enabled model and account limit in the live catalog."),
        AiModel("@cf/zai-org/glm-4.7-flash", "GLM 4.7 Flash", Provider.CLOUDFLARE, "FREE QUOTA*", true, false, "Cloudflare documents this model in the Workers Free model allowance; daily Neurons and account access apply."),
        AiModel("@cf/google/gemma-4-26b-a4b-it", "Gemma 4 26B A4B IT", Provider.CLOUDFLARE, "FREE QUOTA*", true, true, "Cloudflare documents this model in the Workers Free model allowance; daily Neurons and account access apply."),
        AiModel("@cf/nvidia/nemotron-3-120b-a12b", "Nemotron 3 120B A12B", Provider.CLOUDFLARE, "FREE QUOTA*", true, false, "Cloudflare documents this model in the Workers Free model allowance; daily Neurons and account access apply."),
        AiModel("openai/gpt-oss-20b", "GPT-OSS 20B", Provider.NVIDIA, "FREE DEV ACCESS*", true, false, "NVIDIA Developer Program offers NIM API access for prototyping/testing; account/model entitlements apply and production has separate licensing."),
        AiModel("mistral-small-latest", "Mistral Small", Provider.MISTRAL, "FREE MODE*", true, false, "Mistral Studio Free mode is rate-limited and account-dependent."),
        AiModel("ministral-8b-latest", "Ministral 8B", Provider.MISTRAL, "FREE MODE*", true, false, "Refresh the account model list for currently accessible models."),
        AiModel("Meta-Llama-3.3-70B-Instruct", "Llama 3.3 70B Instruct", Provider.SAMBANOVA, "FREE TIER*", true, false, "SambaNova access and usage limits depend on the account."),
        AiModel("DeepSeek-V3.1", "DeepSeek V3.1", Provider.SAMBANOVA, "FREE TIER*", true, false, "Fallback only; refresh the live catalog for exact model IDs and account quota."),
        AiModel("Qwen3-235B-A22B", "Qwen3 235B A22B", Provider.SAMBANOVA, "FREE TIER*", true, false, "Refresh the live catalog for exact model IDs."),
        AiModel("openai/gpt-oss-120b:fastest", "GPT-OSS 120B · fastest", Provider.HUGGINGFACE, "CREDIT-BASED", false, false, "Inference Providers has limited free credits; each model may be usage-priced."),
        AiModel("github-models-retired", "GitHub Models (retired)", Provider.GITHUB, "RETIRED", false, false, "GitHub retired its model catalog and inference API on 30 July 2026; this entry is disabled."),
        AiModel("command-r7b-12-2024", "Command R7B", Provider.COHERE, "TRIAL QUOTA*", true, false, "Trial keys have limited use and may restrict model access."),
        AiModel("glm-4.7-flash", "GLM-4.7 Flash", Provider.ZAI, "FREE TIER*", true, false, "Flash-model pricing and access should be confirmed in the Z.ai console."),
        AiModel("gpt-4o-mini", "GPT-4o mini (LLM7 route)", Provider.LLM7, "FREE QUOTA*", true, false, "LLM7 requires an API token; current free-token access is limited and may change with demand."),
        AiModel("openai/gpt-5.4-nano", "GPT-5.4 Nano · Pollinations", Provider.POLLINATIONS, "CHECK BALANCE", false, false, "Current Pollinations generation requires an API key; check model prices and account budget."),
        AiModel("openai/gpt-oss-120b", "GPT-OSS 120B · Vercel Gateway", Provider.VERCEL, "USAGE-BASED", false, false, "Gateway routing does not make underlying model usage automatically free."),
        AiModel("reka-flash-3", "Reka Flash 3", Provider.REKA, "USAGE-BASED", false, false, "Reka publishes model-specific pricing; a listed model is not necessarily free.")
    )

    fun default() = all.first()
    fun byId(id: String) = all.firstOrNull { it.id == id || it.storageKey == id } ?: default()
    fun byStorageKey(key: String) = all.firstOrNull { it.storageKey == key }
}

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val modelId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,
    val content: String,
    val imagePath: String? = null,
    val fileName: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
