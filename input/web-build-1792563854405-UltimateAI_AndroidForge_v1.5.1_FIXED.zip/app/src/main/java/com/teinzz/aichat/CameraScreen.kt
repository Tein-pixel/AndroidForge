package com.teinzz.aichat

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.PointF
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.MeteringPointFactory
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import java.io.File
import java.util.concurrent.TimeUnit
import androidx.compose.ui.graphics.Color

@Composable
fun CameraScreen(onBack: () -> Unit, onUsePhoto: (String) -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var photoPath by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var lastFocus by remember { mutableStateOf<Offset?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    val controller = remember(context) { LifecycleCameraController(context) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }

    LaunchedEffect(Unit) { if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA) }
    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            controller.cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            controller.imageCaptureFlashMode = flashMode
            controller.bindToLifecycle(owner)
        }
    }
    DisposableEffect(controller) { onDispose { controller.unbind() } }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().height(56.dp).background(Color(0xFF171717)).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.Close, contentDescription = "Close camera", tint = Color.White) }
            Text("Camera", color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                controller.cameraSelector = if (controller.cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            }) { Icon(Icons.Outlined.Cameraswitch, contentDescription = "Switch camera", tint = Color.White) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (!hasPermission) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Camera permission is required to use this screen.", color = Color.White)
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) { Text("Grant permission") }
                }
            } else if (photoPath == null) {
                AndroidView(factory = { ctx ->
                    PreviewView(ctx).also { view ->
                        previewView = view
                        view.controller = controller
                        view.scaleType = PreviewView.ScaleType.FILL_CENTER
                    }
                }, modifier = Modifier.fillMaxSize()
                    .pointerInput(controller) {
                        detectTapGestures { point ->
                            val view = previewView
                            if (view != null) {
                                val factory: MeteringPointFactory = view.meteringPointFactory
                                val meteringPoint = factory.createPoint(point.x, point.y)
                                runCatching { controller.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(meteringPoint).setAutoCancelDuration(3, TimeUnit.SECONDS).build()) }
                                lastFocus = point
                            }
                        }
                    }.pointerInput(controller) {
                        detectTransformGestures { _, _, zoomChange, _ ->
                            val state = controller.cameraInfo?.zoomState?.value
                            if (state != null) { zoom = (zoom * zoomChange).coerceIn(state.minZoomRatio, state.maxZoomRatio); controller.setZoomRatio(zoom) }
                        }
                    })
                lastFocus?.let { p -> Box(Modifier.offset(x = (p.x / context.resources.displayMetrics.density - 35).dp, y = (p.y / context.resources.displayMetrics.density - 35).dp).size(70.dp).border(2.dp, Color(0xFFFFD54F), RoundedCornerShape(10.dp))) }
            } else {
                AsyncImage(model = File(photoPath!!), contentDescription = "Captured photo preview", modifier = Modifier.fillMaxSize())
                Surface(color = Color(0xAA000000), shape = RoundedCornerShape(20.dp), modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)) { Text("Review photo", color = Color.White, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }
            }
            if (message.isNotBlank()) Text(message, color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).background(Color(0xAA000000), RoundedCornerShape(10.dp)).padding(10.dp))
        }
        if (photoPath == null) {
            Column(Modifier.fillMaxWidth().background(Color(0xFF171717)).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Off" to ImageCapture.FLASH_MODE_OFF, "On" to ImageCapture.FLASH_MODE_ON, "Auto" to ImageCapture.FLASH_MODE_AUTO).forEach { (label, mode) ->
                        val selected = flashMode == mode
                        OutlinedButton(onClick = {
                            flashMode = mode; controller.imageCaptureFlashMode = mode
                            if (mode == ImageCapture.FLASH_MODE_ON && controller.cameraInfo?.hasFlashUnit() == true) controller.enableTorch(true) else controller.enableTorch(false)
                            if (mode != ImageCapture.FLASH_MODE_ON && mode != ImageCapture.FLASH_MODE_AUTO) message = ""
                        }, border = BorderStroke(1.dp, if (selected) Color.White else Color.DarkGray), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp)) {
                            Icon(when (mode) { ImageCapture.FLASH_MODE_OFF -> Icons.Outlined.FlashOff; ImageCapture.FLASH_MODE_ON -> Icons.Outlined.FlashOn; else -> Icons.Outlined.FlashAuto }, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text(label)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Box(Modifier.size(78.dp).border(4.dp, Color.White.copy(alpha = 0.8f), CircleShape).padding(6.dp).clip(CircleShape).background(Color.White).clickable {
                    if (controller.cameraInfo?.hasFlashUnit() == false && flashMode == ImageCapture.FLASH_MODE_ON) message = "This camera has no flash unit."
                    else {
                        val file = File(context.filesDir, "camera_${System.currentTimeMillis()}.jpg")
                        val output = ImageCapture.OutputFileOptions.Builder(file).build()
                        controller.takePicture(output, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(result: ImageCapture.OutputFileResults) { photoPath = file.absolutePath; message = "" }
                            override fun onError(exception: ImageCaptureException) { message = "Capture failed: ${exception.message ?: "camera error"}" }
                        })
                    }
                })
            }
        } else {
            Row(Modifier.fillMaxWidth().background(Color(0xFF171717)).padding(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { photoPath?.let { File(it).delete() }; photoPath = null; lastFocus = null }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Icon(Icons.Outlined.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Retake") }
                Button(onClick = { photoPath?.let(onUsePhoto) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Icon(Icons.Outlined.Check, null); Spacer(Modifier.width(6.dp)); Text("Use photo") }
            }
        }
    }
}
