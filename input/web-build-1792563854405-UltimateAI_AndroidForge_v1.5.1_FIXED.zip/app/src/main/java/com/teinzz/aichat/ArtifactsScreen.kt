package com.teinzz.aichat

import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.teinzz.aichat.artifacts.ArtifactProject
import com.teinzz.aichat.artifacts.ArtifactStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private enum class ArtifactPane(val label: String) { PREVIEW("Preview"), CODE("Code"), SPLIT("Split View") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtifactsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var title by remember { mutableStateOf("My Artifact") }
    var prompt by remember { mutableStateOf("") }
    var html by remember { mutableStateOf(STARTER_HTML) }
    var previewHtml by remember { mutableStateOf(STARTER_HTML) }
    var currentId by remember { mutableStateOf<String?>(null) }
    var pane by remember { mutableStateOf(ArtifactPane.PREVIEW) }
    var savedProjects by remember { mutableStateOf<List<ArtifactProject>>(emptyList()) }
    var showSaved by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var snackbar by remember { mutableStateOf<String?>(null) }
    var previewRevision by remember { mutableIntStateOf(0) }
    val generatedHtml = vm.generatedArtifactHtml.value
    val isGenerating = vm.isGeneratingArtifact.value
    val generationError = vm.artifactGenerationError.value
    val snackHost = remember { SnackbarHostState() }

    fun reloadList() {
        scope.launch { savedProjects = ArtifactStore.list(context) }
    }
    LaunchedEffect(Unit) { reloadList() }
    LaunchedEffect(generatedHtml) {
        if (!generatedHtml.isNullOrBlank()) {
            html = normalizeArtifactHtml(generatedHtml)
            previewHtml = html
            if (prompt.isNotBlank()) title = prompt.trim().lineSequence().first().take(44).ifBlank { "AI Artifact" }
            currentId = null
            pane = ArtifactPane.PREVIEW
            previewRevision++
        }
    }
    LaunchedEffect(snackbar) { snackbar?.let { snackHost.showSnackbar(it); snackbar = null } }

    val exportHtml = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri: Uri? ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(html) } ?: error("Tidak dapat membuka file tujuan") } }
                .onSuccess { snackbar = "HTML berhasil diekspor" }
                .onFailure { snackbar = "Ekspor gagal: ${it.message ?: "kesalahan file"}" }
        }
    }
    val importHtml = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: error("File tidak dapat dibaca") } }
                .onSuccess { imported -> html = normalizeArtifactHtml(imported); previewHtml = html; title = "Imported artifact"; prompt = "Edit imported HTML"; currentId = null; pane = ArtifactPane.CODE; previewRevision++ }
                .onFailure { snackbar = "Impor gagal: ${it.message ?: "kesalahan file"}" }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackHost) },
        topBar = {
            TopAppBar(
                title = { Column { Text("Artifacts"); Text("Website · tools · mini-apps", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Kembali ke chat") } },
                actions = {
                    IconButton(onClick = { showSaved = true }) { Icon(Icons.Outlined.FolderOpen, contentDescription = "Proyek tersimpan") }
                    IconButton(onClick = { currentId = null; title = "My Artifact"; prompt = ""; html = STARTER_HTML; previewHtml = STARTER_HTML; pane = ArtifactPane.PREVIEW; vm.clearGeneratedArtifact(); vm.stopArtifactGeneration(); previewRevision++ }) { Icon(Icons.Outlined.Add, contentDescription = "Artifact baru") }
                }
            )
        }
    ) { outerPadding ->
        Column(Modifier.fillMaxSize().padding(outerPadding).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Outlined.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text("Buat atau revisi dengan AI", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.weight(1f))
                        Text(vm.currentModel.value.name, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 120.dp))
                    }
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4,
                        placeholder = { Text("Contoh: buat kalkulator bunga dengan UI minimalis. Untuk revisi, jelaskan apa yang harus diubah.") },
                        shape = RoundedCornerShape(15.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            if (prompt.isBlank()) snackbar = "Tulis dulu apa yang ingin dibuat atau direvisi"
                            else vm.generateArtifact(prompt.trim(), html.takeIf { it != STARTER_HTML && it.isNotBlank() })
                        }, enabled = !isGenerating, modifier = Modifier.weight(1f)) {
                            if (isGenerating) { CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)); Text("Membuat…") }
                            else { Icon(Icons.Outlined.AutoAwesome, contentDescription = null); Spacer(Modifier.width(6.dp)); Text(if (currentId == null && html == STARTER_HTML) "Generate artifact" else "Revisi dengan AI") }
                        }
                        if (isGenerating) IconButton(onClick = vm::stopArtifactGeneration) { Icon(Icons.Outlined.Stop, contentDescription = "Stop generation") }
                        IconButton(onClick = { importHtml.launch(arrayOf("text/html", "text/plain", "application/octet-stream")) }) { Icon(Icons.Outlined.UploadFile, contentDescription = "Impor HTML") }
                    }
                    if (!generationError.isNullOrBlank()) Text(generationError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Text("HTML, CSS, dan JavaScript dijalankan dalam WebView terisolasi dari file aplikasi.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            OutlinedTextField(value = title, onValueChange = { title = it.take(100) }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text("Nama artifact") })

            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtifactPane.values().forEach { option ->
                    FilterChip(selected = pane == option, onClick = {
                        pane = option
                        if (option == ArtifactPane.PREVIEW) { previewHtml = html; previewRevision++ }
                    }, label = { Text(option.label) })
                }
                Spacer(Modifier.width(4.dp))
                Text("${html.length} chars", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (isGenerating) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("AI sedang menyusun artifact lewat API model terpilih. Preview diperbarui setelah respons selesai.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Box(Modifier.fillMaxWidth().weight(1f)) {
                when (pane) {
                    ArtifactPane.PREVIEW -> ArtifactPreview(previewHtml, previewRevision, Modifier.fillMaxSize())
                    ArtifactPane.CODE -> ArtifactCodeEditor(html, onChange = { html = it }, modifier = Modifier.fillMaxSize())
                    ArtifactPane.SPLIT -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ArtifactCodeEditor(html, onChange = { html = it }, modifier = Modifier.weight(1f).fillMaxHeight())
                        ArtifactPreview(previewHtml, previewRevision, Modifier.weight(1f).fillMaxHeight())
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    if (html.isBlank()) snackbar = "Kode artifact masih kosong"
                    else scope.launch {
                        isSaving = true
                        runCatching {
                            ArtifactStore.save(context, ArtifactProject(currentId.orEmpty(), title, prompt, html, System.currentTimeMillis()))
                        }.onSuccess { saved -> currentId = saved.id; reloadList(); snackbar = "Artifact tersimpan di perangkat" }
                            .onFailure { snackbar = "Gagal menyimpan: ${it.message ?: "error"}" }
                        isSaving = false
                    }
                }, enabled = !isSaving, modifier = Modifier.weight(1f)) {
                    if (isSaving) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Outlined.Save, contentDescription = null)
                    Spacer(Modifier.width(6.dp)); Text("Simpan")
                }
                OutlinedButton(onClick = { clipboard.setText(AnnotatedString(html)); snackbar = "Kode disalin" }, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.ContentCopy, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Copy code") }
                IconButton(onClick = { exportHtml.launch((title.ifBlank { "artifact" }.replace(Regex("[^A-Za-z0-9_-]"), "_").take(50)) + ".html") }) { Icon(Icons.Outlined.Download, contentDescription = "Ekspor HTML") }
                IconButton(onClick = { previewHtml = html; previewRevision++ }) { Icon(Icons.Outlined.PlayArrow, contentDescription = "Jalankan kode") }
            }
        }
    }

    if (showSaved) {
        ModalBottomSheet(onDismissRequest = { showSaved = false }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Proyek tersimpan", style = MaterialTheme.typography.titleLarge)
                if (savedProjects.isEmpty()) Text("Belum ada artifact yang disimpan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(modifier = Modifier.heightIn(max = 460.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(savedProjects, key = { it.id }) { project ->
                        Surface(shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f).clickable {
                                    currentId = project.id; title = project.title; prompt = project.prompt; html = project.html; previewHtml = project.html; pane = ArtifactPane.PREVIEW; previewRevision++; showSaved = false
                                }.padding(vertical = 5.dp)) {
                                    Text(project.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(project.updatedAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { scope.launch { ArtifactStore.delete(context, project.id); reloadList() } }) { Icon(Icons.Outlined.DeleteOutline, contentDescription = "Hapus ${project.title}") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArtifactCodeEditor(code: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.fillMaxSize().padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp)); Text("index.html", style = MaterialTheme.typography.labelMedium)
            }
            HorizontalDivider(Modifier.padding(vertical = 7.dp))
            androidx.compose.foundation.text.BasicTextField(
                value = code,
                onValueChange = onChange,
                modifier = Modifier.fillMaxSize().padding(2.dp),
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface),
                decorationBox = { inner -> Box { if (code.isEmpty()) Text("Tulis atau edit HTML di sini…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant); inner() } }
            )
        }
    }
}

@Composable
private fun ArtifactPreview(html: String, revision: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.allowFileAccessFromFileURLs = false
                settings.allowUniversalAccessFromFileURLs = false
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                settings.javaScriptCanOpenWindowsAutomatically = false
                settings.setSupportMultipleWindows(false)
                settings.loadsImagesAutomatically = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val uri = request?.url ?: return true
                        val scheme = uri.scheme?.lowercase().orEmpty()
                        if (scheme == "https" || scheme == "http") {
                            val internal = uri.host == "artifact-preview.local"
                            if (internal) return false
                            return try { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (_: Exception) { true }
                        }
                        return true
                    }
                }
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            }
        },
        update = { webView ->
            val signature = 31 * html.hashCode() + revision
            if (webView.tag != signature) {
                webView.tag = signature
                webView.loadDataWithBaseURL("https://artifact-preview.local/", normalizeArtifactHtml(html), "text/html", "UTF-8", "https://artifact-preview.local/")
            }
        },
        onRelease = { webView -> webView.stopLoading(); webView.destroy() }
    )
}

private fun normalizeArtifactHtml(raw: String): String {
    var html = raw.trim()
        .removePrefix("```html").removePrefix("```HTML").removePrefix("```")
        .removeSuffix("```").trim()
    val start = html.indexOf("<html", ignoreCase = true)
    val end = html.lastIndexOf("</html>", ignoreCase = true)
    if (start >= 0 && end >= start) html = html.substring(start, end + 7)
    if (html.contains("<html", ignoreCase = true) || html.contains("<!doctype", ignoreCase = true)) return html
    return "<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta charset=\"utf-8\"><title>Artifact</title></head><body style=\"font-family: sans-serif; padding: 16px; white-space: pre-wrap; overflow-wrap: anywhere;\"><pre>${html.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")}</pre></body></html>"
}

private const val STARTER_HTML = """
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Artifact</title>
<style>
:root{color-scheme:light dark;font-family:Inter,system-ui,-apple-system,sans-serif}body{margin:0;padding:24px;display:grid;min-height:calc(100vh - 48px);place-items:center;background:Canvas;color:CanvasText}main{width:min(100%,440px);box-sizing:border-box;border:1px solid color-mix(in srgb,CanvasText 15%,transparent);border-radius:24px;padding:24px;background:color-mix(in srgb,Canvas 92%,CanvasText 8%)}h1{font-size:24px;margin-top:0}p{line-height:1.6;color:color-mix(in srgb,CanvasText 75%,transparent)}button{border:0;border-radius:12px;padding:12px 16px;font:inherit;font-weight:600;background:CanvasText;color:Canvas;cursor:pointer}
</style>
</head>
<body><main><h1>Mulai membuat artifact</h1><p>Tulis instruksi di atas untuk membuat website atau mini-app. Hasil dapat diedit, dijalankan, disimpan, dan diekspor sebagai HTML.</p><button onclick="document.querySelector('p').textContent='JavaScript berjalan. Kamu bisa mengganti contoh ini dengan artifact buatan AI.'">Tes interaksi</button></main></body>
</html>
"""
