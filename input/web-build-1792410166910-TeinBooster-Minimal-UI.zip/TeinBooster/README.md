# Tein Booster

Aplikasi Android (Java, tanpa dependensi pihak ketiga, tanpa root) berisi kumpulan booster + **1-Tap Cache Cleaner**
yang membersihkan cache semua aplikasi otomatis lewat Layanan Aksesibilitas.
Min Android 7.0 (API 24), target API 34.

## Cara membuat APK

**A. Android Studio (paling mudah)**
1. `File > Open` pilih folder `TeinBooster` (hasil ekstrak ZIP), tunggu Gradle sync selesai (butuh internet sekali).
2. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
3. APK ada di `app/build/outputs/apk/debug/app-debug.apk` (sudah bertanda tangan debug, langsung bisa di-install).

**B. Command line** (JDK 17 + Android SDK, `ANDROID_HOME` terisi)
```
./gradlew assembleDebug
```
`gradle/wrapper/gradle-wrapper.jar` di proyek ini adalah bootstrap sederhana buatan sendiri (bukan jar resmi Gradle):
ia mengunduh Gradle 8.7 sesuai `gradle-wrapper.properties`. Jika ingin jar resmi: `gradle wrapper --gradle-version 8.7`.

**C. GitHub Actions**: unggah proyek ke repo GitHub. Workflow `.github/workflows/build-apk.yml` berjalan saat push ke `main`/`master`, tag `v*`, atau lewat *Actions > Build APK and publish release > Run workflow*. File `app-sign.apk` muncul sebagai Artifact dan sebagai aset pada GitHub Releases. APK release ini ditandatangani dengan debug key dan ditujukan untuk uji/pemakaian pribadi, bukan rilis Google Play.

## Izin yang harus diaktifkan (menu **Pusat Izin** di aplikasi)
| Izin | Dipakai untuk |
|---|---|
| Aksesibilitas | 1-Tap Cache Cleaner (menekan "Hapus cache" di Pengaturan) |
| Akses Penggunaan | ukuran cache per aplikasi, daftar pemakaian |
| Akses semua file | Junk Cleaner, file besar, duplikat |
| Ubah pengaturan sistem | Hemat Baterai / kecerahan & timeout layar |
| Tampil di atas aplikasi lain (opsional) | HUD mengambang saat bermain |
| Rekam layar (dialog sistem) | Perekam gameplay setelah persetujuan setiap sesi |
| Mikrofon (opsional, hanya ketika dimulai) | Meter level suara, berhenti otomatis saat halaman ditinggalkan |
| Notifikasi (Android 13+, opsional) | Kontrol berhenti untuk perekam/overlay lebih mudah dilihat |
| Jangan Ganggu | Game Booster |
| Abaikan optimasi baterai | Auto Boost terjadwal |
| WRITE_SECURE_SETTINGS (opsional, 1x via ADB) | Turbo UI (animasi) & Private DNS sekali tekan |

Android 13+ (APK dipasang manual): jika tombol Aksesibilitas abu-abu / "Setelan dibatasi", buka *Info aplikasi Tein Booster >
menu ⋮ > Izinkan setelan terbatas*, lalu aktifkan lagi.

## Isi booster (semua nyata, tanpa root)
- **1-Tap Cache Cleaner** – per aplikasi: Info aplikasi → Penyimpanan → *Hapus cache*; layar progres menutupi proses; tidak pernah
  menyentuh "Hapus data". Didahului pemangkasan cache via API resmi `StorageManager`. Ada tombol *Lihat log* dan *mode debug*.
- **RAM Booster** – menutup proses latar (`killBackgroundProcesses`), RAM sebelum/sesudah diukur nyata; ada daftar putih.
- **Junk Cleaner** – pindai file .tmp/.log/thumbnail/unduhan gagal/APK sisa/folder kosong/cache eksternal, hapus sungguhan.
- **Penyimpanan** – kategori, file besar, duplikat (hash MD5).
- **Hemat Baterai** – profil Hemat/Ultra (kecerahan, timeout layar, sinkronisasi) + pulihkan; aplikasi terlama dipakai.
- **Pendingin** – pantau suhu baterai live, tutup aplikasi latar, ukur suhu sebelum/sesudah.
- **Game Booster** – tutup aplikasi latar + Jangan Ganggu lalu luncurkan game; DND dipulihkan saat kembali.
- **Pusat Gaming** – hub untuk GFX Guide, Game HUD, monitor performa, alat uji sentuhan/layar/kontroler, latihan refleks offline, Game Coach lokal, perpustakaan game, Panel Game, perekam layar, dan meter suara.
- **GFX Guide** – rekomendasi manual kualitas grafis, FPS, resolusi render, serta efek berdasarkan RAM dan refresh rate. Tidak mengubah setelan game secara diam-diam.
- **Game HUD** – widget mengambang yang dapat dipindahkan, menampilkan RAM, baterai, dan suhu baterai. Membutuhkan izin Android “Tampil di atas aplikasi lain” dan menampilkan notifikasi layanan saat aktif.
- **Monitor Performa** – RAM, penyimpanan, baterai, suhu baterai, refresh rate, lalu lintas jaringan perangkat, estimasi aktivitas CPU seluruh sistem dari penghitung kernel bila dapat dibaca, grafik riwayat 60 sampel CPU/RAM, dan tes latensi TCP. GPU/FPS game lain tidak dibuat-buat karena Android tidak menyediakannya untuk aplikasi biasa.
- **Alat Uji** – sapuan multi-touch, pemeriksaan warna layar, dan deteksi input gamepad/joystick yang terhubung.
- **Latihan Gamer** – mini-game reaksi 10 ronde yang berjalan offline dengan arena yang dibuka lewat progres bintang.
- **Game Coach** – rekomendasi lokal sesuai jenis game, prioritas, RAM, suhu, dan refresh rate; tidak mengaku sebagai layanan AI daring.
- **Perpustakaan Game** – cari aplikasi yang bisa dibuka, favoritkan, luncurkan, dan tetapkan game utama. Game utama otomatis ditambahkan ke daftar Game Booster lama.
- **Panel Game** – kontrol volume media perangkat, kecerahan panel aplikasi, menjaga layar tetap aktif, tes getar, dan pintasan ke pengaturan rotasi/Wi-Fi/DND Android. Slider kecerahan tidak mengubah game lain; kontrol sistem yang dilindungi membuka halaman pengaturan resmi.
- **Perekam Layar** – rekam video MP4 tanpa audio mikrofon memakai MediaProjection, dengan persetujuan Android setiap sesi dan notifikasi berhenti. Kualitas encoder tergantung perangkat; konten yang dilindungi aplikasi bisa tampil hitam.
- **Visualisasi Suara** – meter level mikrofon selama halaman aktif. File sementara berada di cache dan dihapus ketika pengukuran dihentikan; angka bukan pengukuran dB terkalibrasi.
- **Manajer Aplikasi** – ukuran, buka, info, bersihkan cache, cadangkan APK, hapus instalan.
- **Network Booster** – tes unduh, latensi DNS (UDP), ping TCP, atur Private DNS.
- **Turbo UI** – skala animasi sistem. **Info Perangkat**. **Auto Boost** (terjadwal), ubin Quick Settings, pintasan ikon.

Tidak ada: overclock CPU/GPU, RAM tambahan/swap, "pendingin CPU" palsu, dll. — itu butuh root atau hanya tampilan kosong.

## Jika Cache Cleaner gagal di HP tertentu
Tampilan Pengaturan tiap merek berbeda. Buka *1-Tap Cache Cleaner > Lihat log* (berisi alasan gagal + teks layar yang terbaca),
salin, dan kirim agar kamus label bisa disesuaikan. Aktifkan *mode debug* untuk melihat proses langsung.

## Struktur
`app/src/main/java/com/tein/booster/` — `CleanerAccessibilityService` (inti cleaner), `Optimizer`, `FileScan`, `Net`,
`Apps`, `Sys`, `CpuStats`, `ScreenRecorderService`, layar-layar `*Activity`, view kustom (`GaugeView`, `LogoView`, `BarView`).

## Batasan pengujian
Build penuh harus dilakukan di Android Studio atau GitHub Actions dengan Android SDK dan akses dependensi Gradle. Jika lingkungan lokal tidak memiliki SDK/internet, pemeriksaan struktur/sintaks saja bukan bukti bahwa aplikasi sudah teruji di perangkat. Uji recorder, overlay, aksesibilitas, dan pengaturan OEM di HP target sebelum dipakai lama.


## Pembaruan UI minimalis (AMOLED-first)

- Dashboard diringkas: skor dan Boost berada dalam satu panel, statistik RAM/penyimpanan/baterai memakai satu permukaan, dan Cache Cleaner menjadi pintasan satu baris.
- Fitur disusun ke kategori yang dapat dibuka/tutup: Gaming, Performa & baterai, Pembersihan & jaringan, serta Rekam & utilitas. Kelas Activity dan alur fitur yang ada tetap digunakan.
- Pilihan tema disimpan di preferensi aplikasi: `AMOLED Black` (default), `Gelap` (navy), dan `Terang`. Tema diterapkan sebelum layar dibuat dan diperbarui ketika kembali dari pengaturan.
- Target minimum tetap Android 7.0 (API 24); kompatibel dengan Android 10 (API 29) pada level framework yang dipakai proyek.
- Status build: pemeriksaan statis XML/struktur Java dilakukan di lingkungan kerja, tetapi build APK belum diverifikasi karena unduhan Gradle terhalang DNS dan Android SDK tidak tersedia di lingkungan tersebut.
