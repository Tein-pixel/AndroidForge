package com.tein.booster;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

/** User-started, foreground-only microphone level meter; temporary capture is deleted on stop. */
public class SoundVisualizerActivity extends BaseActivity {
    private static final int REQ_MIC = 4809;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaRecorder recorder;
    private File tempFile;
    private boolean running;
    private TextView state, levelText, startButton;
    private ProgressBar meter;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!running || recorder == null || !alive()) return;
            try {
                int amp = Math.max(0, recorder.getMaxAmplitude());
                int percent = Math.min(100, Math.round(amp * 100f / 32767f));
                double db = amp <= 0 ? -60.0 : Math.max(-60.0, 20.0 * Math.log10(amp / 32767.0));
                meter.setProgress(percent);
                levelText.setText(String.format(Locale.US, "Puncak input: %d%% • sekitar %.1f dBFS", percent, db));
            } catch (Exception e) {
                levelText.setText("Meter tidak tersedia pada perangkat ini.");
            }
            handler.postDelayed(this, 120L);
        }
    };

    @Override protected String title() { return "Visualisasi Suara"; }

    @Override protected void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        LinearLayout col = scrollBody();
        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.tvb(this, "AUDIO LEVEL METER", 15, Ui.CYAN));
        intro.addView(Ui.tv(this, "Mengukur tingkat suara melalui mikrofon ketika kamu menekan Mulai. Tidak berjalan di latar belakang dan file sementara dihapus saat berhenti. Ini bukan pengukur desibel terkalibrasi.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(intro, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));

        LinearLayout card = Ui.card(this);
        state = Ui.tvb(this, "Mikrofon tidak aktif", 16, Ui.TEXT);
        card.addView(state);
        meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        meter.setMax(100); meter.setProgress(0);
        if (Build.VERSION.SDK_INT >= 21) meter.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.MINT));
        card.addView(meter, Ui.lp(this, Ui.MATCH, Ui.dp(this, 12), 0, 16, 0, 0));
        levelText = Ui.tv(this, "Puncak input: --", 14, Ui.CYAN);
        card.addView(levelText, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        startButton = Ui.button(this, "MULAI UKUR", v -> toggle());
        card.addView(startButton, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 16, 0, 0));
        col.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout note = Ui.card(this);
        note.addView(Ui.tvb(this, "Privasi dan penggunaan", 14, Ui.EMBER));
        note.addView(Ui.tv(this, "Izin mikrofon diminta hanya saat kamu mulai. Jika kamu meninggalkan halaman ini, pengukuran berhenti otomatis. Hindari menempelkan pengeras suara ke telinga saat melakukan tes volume.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        col.addView(note);
    }

    private void toggle() {
        if (running) { stopMeter(); return; }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        startMeter();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startMeter();
            else Toast.makeText(this, "Izin mikrofon diperlukan untuk menampilkan level suara.", Toast.LENGTH_LONG).show();
        }
    }

    private void startMeter() {
        if (running) return;
        try {
            tempFile = new File(getCacheDir(), "tein_audio_meter_temp.m4a");
            if (tempFile.exists()) //noinspection ResultOfMethodCallIgnored
                tempFile.delete();
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setOutputFile(tempFile.getAbsolutePath());
            recorder.prepare(); recorder.start();
            running = true;
            state.setText("Mikrofon aktif — ukur suara sekitar"); state.setTextColor(Ui.MINT);
            startButton.setText("HENTIKAN UKUR");
            handler.removeCallbacks(ticker); handler.post(ticker);
        } catch (IOException | RuntimeException e) {
            releaseRecorder();
            if (tempFile != null && tempFile.exists()) { //noinspection ResultOfMethodCallIgnored
                tempFile.delete();
            }
            tempFile = null;
            state.setText("Tidak dapat memulai mikrofon");
            Toast.makeText(this, "Gagal mengaktifkan meter: periksa izin mikrofon atau kompatibilitas perangkat.", Toast.LENGTH_LONG).show();
        }
    }

    private void stopMeter() {
        running = false;
        handler.removeCallbacks(ticker);
        try { if (recorder != null) recorder.stop(); } catch (RuntimeException ignored) { }
        releaseRecorder();
        if (tempFile != null && tempFile.exists()) //noinspection ResultOfMethodCallIgnored
            tempFile.delete();
        tempFile = null;
        if (state != null) { state.setText("Mikrofon tidak aktif"); state.setTextColor(Ui.TEXT); }
        if (levelText != null) levelText.setText("Pengukuran selesai. File sementara tidak disimpan.");
        if (meter != null) meter.setProgress(0);
        if (startButton != null) startButton.setText("MULAI UKUR");
    }

    private void releaseRecorder() {
        try { if (recorder != null) recorder.reset(); } catch (Exception ignored) { }
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) { }
        recorder = null;
    }

    @Override protected void onPause() { super.onPause(); if (running) stopMeter(); }
    @Override protected void onDestroy() { handler.removeCallbacks(ticker); if (running) stopMeter(); else releaseRecorder(); super.onDestroy(); }
}
