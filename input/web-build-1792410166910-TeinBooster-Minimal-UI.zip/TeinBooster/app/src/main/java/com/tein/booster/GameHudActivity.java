package com.tein.booster;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Pengatur HUD overlay. Izin tampil di atas aplikasi lain diperlukan oleh Android. */
public class GameHudActivity extends BaseActivity {
    private boolean requestedPermission;
    private TextView status;

    @Override protected String title() { return "Game HUD"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = scrollBody();
        LinearLayout preview = Ui.card(this);
        preview.addView(Ui.tvb(this, "PRATINJAU HUD", 13, Ui.MINT));
        TextView mock = Ui.tvb(this, "RAM 62%   •   BAT 40%   •   33°C", 13, Ui.TEXT);
        mock.setGravity(android.view.Gravity.CENTER);
        mock.setPadding(Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14));
        mock.setBackground(Ui.outline(this, Ui.PANEL2, Ui.MINT, 14));
        preview.addView(mock, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 9, 0, 0));
        col.addView(preview, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));

        LinearLayout details = Ui.card(this);
        details.addView(Ui.tvb(this, "HUD MENGAMBANG", 15, Ui.TEXT));
        details.addView(Ui.tv(this, "Widget kecil dapat ditampilkan di atas game dan aplikasi lain. Widget menunjukkan penggunaan RAM, persentase baterai, dan suhu baterai; geser bar judul untuk memindahkan posisi dan tekan × untuk menutupnya.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        details.addView(Ui.tv(this, "Android akan meminta izin khusus ‘Tampil di atas aplikasi lain’. Izin ini dapat dicabut kapan saja di pengaturan Android.", 12, Ui.EMBER), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(details, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        status = Ui.tvb(this, "Status: " + (GameHudService.running ? "aktif" : "mati"), 14, Ui.CYAN);
        col.addView(status, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 8));
        col.addView(Ui.button(this, "Aktifkan HUD", v -> enableHud()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        col.addView(Ui.ghost(this, "Matikan HUD", v -> stopHud()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        col.addView(Ui.tv(this, "HUD berjalan sebagai layanan foreground agar tetap terlihat saat berpindah ke game. Android mungkin menampilkan notifikasi layanan aktif selama HUD digunakan.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
    }

    private void enableHud() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            requestedPermission = true;
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                requestedPermission = false;
                Toast.makeText(this, "Buka Pengaturan Android dan izinkan tampil di atas aplikasi lain.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        startHudService();
    }

    private void startHudService() {
        requestedPermission = false;
        try {
            Intent i = new Intent(this, GameHudService.class);
            i.setAction(GameHudService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("Status: perintah aktivasi dikirim");
            Toast.makeText(this, "HUD diaktifkan. Pindahkan widget lewat bar judulnya.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            status.setText("Status: gagal diaktifkan");
            Toast.makeText(this, "HUD gagal dijalankan: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private void stopHud() {
        try { Intent i = new Intent(this, GameHudService.class); i.setAction(GameHudService.ACTION_STOP); startService(i); }
        catch (Exception ignored) { stopService(new Intent(this, GameHudService.class)); }
        status.setText("Status: dihentikan");
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) status.setText("Status: " + (GameHudService.running ? "aktif" : "mati"));
        if (requestedPermission && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startHudService();
    }
}
