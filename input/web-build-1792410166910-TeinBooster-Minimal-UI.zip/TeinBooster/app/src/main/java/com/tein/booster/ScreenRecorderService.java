package com.tein.booster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Foreground screen-recording service, started only after Android's capture-consent dialog. */
public class ScreenRecorderService extends Service {
    public static final String ACTION_START = "com.tein.booster.recorder.START";
    public static final String ACTION_STOP = "com.tein.booster.recorder.STOP";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    private static final String CHANNEL = "tein_screen_recorder";
    private static final int NOTIFICATION_ID = 7401;

    public static volatile boolean isRecording = false;
    public static volatile long startedAt = 0L;
    public static volatile String lastError = "";
    public static volatile String lastOutput = "";

    private MediaProjection projection;
    private MediaRecorder recorder;
    private VirtualDisplay display;
    private ParcelFileDescriptor descriptor;
    private Uri outputUri;
    private File outputFile;
    private boolean stopping;
    private final Handler main = new Handler(Looper.getMainLooper());
    private int width, height, density;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopRecordingInternal(true);
            return START_NOT_STICKY;
        }
        if (isRecording) return START_NOT_STICKY;
        if (intent == null || !intent.hasExtra(EXTRA_RESULT_DATA)) {
            lastError = "Token izin rekam layar tidak tersedia";
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            startForegroundCompat();
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if (resultData == null) throw new IllegalStateException("Data izin kosong");
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (manager == null) throw new IllegalStateException("MediaProjection tidak tersedia");
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("Izin layar ditolak sistem");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopRecordingInternal(false); }
            }, main);
            prepareRecording();
            return START_NOT_STICKY;
        } catch (Throwable e) {
            lastError = "Gagal merekam: " + e.getClass().getSimpleName();
            stopRecordingInternal(false);
            return START_NOT_STICKY;
        }
    }

    private void startForegroundCompat() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Perekam layar Tein Booster", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Notifikasi saat sesi perekaman layar aktif");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(c);
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, ScreenRecorderService.class).setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stop = PendingIntent.getService(this, 7402, stopIntent, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Tein Booster • Rekam layar")
                .setContentText("Perekaman layar aktif. Tekan Berhenti untuk mengakhiri.")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Berhenti", stop)
                .build();
    }

    private void getDisplaySize() {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm != null) wm.getDefaultDisplay().getRealMetrics(dm);
        density = dm.densityDpi > 0 ? dm.densityDpi : 160;
        int sourceW = dm.widthPixels > 0 ? dm.widthPixels : 720;
        int sourceH = dm.heightPixels > 0 ? dm.heightPixels : 1280;
        // Limit large displays for broader hardware encoder compatibility and lower heat.
        float scale = Math.min(1f, 1280f / Math.max(sourceW, sourceH));
        width = Math.max(2, ((int) (sourceW * scale)) & ~1);
        height = Math.max(2, ((int) (sourceH * scale)) & ~1);
    }

    private void createOutput() throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String name = "TeinBooster_" + stamp + ".mp4";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TeinBooster");
            cv.put(MediaStore.Video.Media.IS_PENDING, 1);
            outputUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
            if (outputUri == null) throw new IllegalStateException("Tidak dapat membuat file video di MediaStore");
            descriptor = getContentResolver().openFileDescriptor(outputUri, "w");
            if (descriptor == null) throw new IllegalStateException("Tidak dapat membuka file video");
        } else {
            File base = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (base == null) throw new IllegalStateException("Penyimpanan video tidak tersedia");
            File folder = new File(base, "TeinBooster");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Folder video tidak dapat dibuat");
            outputFile = new File(folder, name);
        }
    }

    private void prepareRecording() throws Exception {
        getDisplaySize();
        createOutput();
        recorder = new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(width, height);
        recorder.setVideoFrameRate(30);
        recorder.setVideoEncodingBitRate(5 * 1000 * 1000);
        if (Build.VERSION.SDK_INT >= 29 && descriptor != null) recorder.setOutputFile(descriptor.getFileDescriptor());
        else if (outputFile != null) recorder.setOutputFile(outputFile.getAbsolutePath());
        recorder.prepare();
        display = projection.createVirtualDisplay("TeinBoosterScreenCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder.getSurface(), null, main);
        if (display == null) throw new IllegalStateException("Virtual display gagal dibuat");
        recorder.start();
        isRecording = true;
        startedAt = android.os.SystemClock.elapsedRealtime();
        lastError = "";
    }

    private void stopRecordingInternal(boolean userRequested) {
        if (stopping) return;
        stopping = true;
        boolean valid = false;
        try {
            if (recorder != null && isRecording) {
                try { recorder.stop(); valid = true; }
                catch (RuntimeException e) { valid = false; }
            }
        } catch (Exception ignored) { valid = false; }
        isRecording = false;
        startedAt = 0L;

        try { if (display != null) display.release(); } catch (Exception ignored) { }
        display = null;
        try { if (recorder != null) recorder.reset(); } catch (Exception ignored) { }
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) { }
        recorder = null;
        try { if (descriptor != null) descriptor.close(); } catch (Exception ignored) { }
        descriptor = null;
        try {
            if (projection != null) {
                MediaProjection p = projection;
                projection = null;
                p.stop();
            }
        } catch (Exception ignored) { }

        try {
            if (outputUri != null) {
                if (valid) {
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues(); cv.put(MediaStore.Video.Media.IS_PENDING, 0);
                        getContentResolver().update(outputUri, cv, null, null);
                    }
                    lastOutput = outputUri.toString();
                    getSharedPreferences("screen_recorder", MODE_PRIVATE).edit().putString("last_uri", lastOutput).apply();
                } else {
                    getContentResolver().delete(outputUri, null, null);
                    lastError = "Rekaman terlalu singkat atau encoder gagal; file tidak disimpan";
                }
            } else if (outputFile != null) {
                if (valid && outputFile.length() > 0) {
                    lastOutput = outputFile.getAbsolutePath();
                    getSharedPreferences("screen_recorder", MODE_PRIVATE).edit().putString("last_uri", "").putString("last_path", lastOutput).apply();
                } else {
                    // Don't leave an empty or invalid file behind.
                    //noinspection ResultOfMethodCallIgnored
                    outputFile.delete();
                    lastError = "Rekaman terlalu singkat atau encoder gagal; file tidak disimpan";
                }
            }
        } catch (Exception e) {
            lastError = "Video dibuat tetapi finalisasi penyimpanan gagal";
        }
        outputUri = null; outputFile = null;
        try { if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true); } catch (Exception ignored) { }
        // Keep the guard set: onDestroy may run immediately after stopSelf().
        stopSelf();
    }

    @Override public void onDestroy() {
        if (!stopping) stopRecordingInternal(false);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
