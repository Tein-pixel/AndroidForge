package com.tein.booster;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Compact rolling chart of actual system CPU/RAM samples (not game-specific telemetry). */
public final class PerformanceTrendView extends View {
    private static final int CAPACITY = 60;
    private final float[] cpu = new float[CAPACITY];
    private final float[] ram = new float[CAPACITY];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int next;
    private int count;

    public PerformanceTrendView(Context context) {
        super(context);
        setMinimumHeight(Ui.dp(context, 150));
        setBackground(Ui.rect(context, Ui.PANEL, 12));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
    }

    public void addSample(float cpuPercent, float ramPercent) {
        cpu[next] = valid(cpuPercent) ? clamp(cpuPercent) : -1f;
        ram[next] = valid(ramPercent) ? clamp(ramPercent) : -1f;
        next = (next + 1) % CAPACITY;
        count = Math.min(CAPACITY, count + 1);
        invalidate();
    }

    private boolean valid(float value) { return !Float.isNaN(value) && !Float.isInfinite(value) && value >= 0f; }
    private float clamp(float value) { return Math.max(0f, Math.min(100f, value)); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density = getResources().getDisplayMetrics().density;
        float left = 12f * density, right = getWidth() - 12f * density;
        float top = 14f * density, bottom = getHeight() - 26f * density;
        if (right <= left || bottom <= top) return;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, density));
        paint.setColor(Ui.alpha(Ui.LINE, 0xA0));
        for (int i = 0; i <= 4; i++) {
            float y = top + (bottom - top) * i / 4f;
            canvas.drawLine(left, y, right, y, paint);
        }
        if (count == 0) {
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(12f * density);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setColor(Ui.SUB);
            canvas.drawText("Mengumpulkan sampel CPU/RAM…", getWidth() / 2f, (top + bottom) / 2f, paint);
            drawLegend(canvas, density);
            return;
        }
        drawSeries(canvas, cpu, left, top, right, bottom, Ui.VIOLET, density);
        drawSeries(canvas, ram, left, top, right, bottom, Ui.CYAN, density);
        drawLegend(canvas, density);
    }

    private void drawSeries(Canvas canvas, float[] samples, float left, float top, float right, float bottom, int color, float density) {
        Path path = new Path();
        boolean segment = false;
        int total = count;
        int start = (next - total + CAPACITY) % CAPACITY;
        for (int i = 0; i < total; i++) {
            float value = samples[(start + i) % CAPACITY];
            if (value < 0f) { segment = false; continue; }
            float x = total <= 1 ? right : left + (right - left) * i / (total - 1f);
            float y = bottom - (bottom - top) * value / 100f;
            if (!segment) { path.moveTo(x, y); segment = true; }
            else path.lineTo(x, y);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f * density);
        paint.setColor(color);
        canvas.drawPath(path, paint);
    }

    private void drawLegend(Canvas canvas, float density) {
        float y = getHeight() - 10f * density;
        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTextSize(10f * density);
        paint.setColor(Ui.VIOLET);
        canvas.drawText("● CPU sistem", 12f * density, y, paint);
        paint.setColor(Ui.CYAN);
        canvas.drawText("● RAM terpakai", 104f * density, y, paint);
    }
}
