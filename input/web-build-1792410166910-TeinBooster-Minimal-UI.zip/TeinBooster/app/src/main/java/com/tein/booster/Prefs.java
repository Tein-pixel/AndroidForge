package com.tein.booster;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public final class Prefs {
    public static final String WHITELIST = "whitelist";
    public static final String GAMES = "games";
    public static final String AUTO_HOURS = "auto_hours";
    public static final String LAST_BOOST = "last_boost";
    public static final String LAST_FREED = "last_freed";
    public static final String ONBOARDED = "onboarded";
    public static final String DND_ACTIVE = "dnd_active";
    public static final String DND_PREV = "dnd_prev";
    public static final String GAME_DND = "game_dnd";
    public static final String GAME_KILL = "game_kill";
    public static final String BATT_SAVED = "batt_saved";
    public static final String BATT_BRIGHT = "batt_bright";
    public static final String BATT_MODE = "batt_mode";
    public static final String BATT_TIMEOUT = "batt_timeout";
    public static final String BATT_SYNC = "batt_sync";
    public static final String BATT_PROFILE = "batt_profile";
    public static final String CLEAN_SYSTEM = "clean_system";
    public static final String CLEAN_DEBUG = "clean_debug";
    public static final String UI_THEME = "ui_theme"; // 0=AMOLED black, 1=dark navy, 2=light

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("tein_prefs", Context.MODE_PRIVATE);
    }

    public static Set<String> getSet(Context c, String k) {
        Set<String> s = sp(c).getStringSet(k, null);
        return s == null ? new HashSet<String>() : new HashSet<String>(s);
    }

    public static void putSet(Context c, String k, Set<String> v) {
        sp(c).edit().putStringSet(k, new HashSet<String>(v)).apply();
    }

    public static boolean getBool(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }

    public static void putBool(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }

    public static int getInt(Context c, String k, int d) { return sp(c).getInt(k, d); }

    public static void putInt(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }

    public static long getLong(Context c, String k, long d) { return sp(c).getLong(k, d); }

    public static void putLong(Context c, String k, long v) { sp(c).edit().putLong(k, v).apply(); }
}
