package com.tein.booster;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Explicit-consent screen recorder. Video only; it does not capture microphone audio. */
public class ScreenRecorderActivity extends BaseActivity {
    private static final int REQ_CAPTURE = 4207;
    private static final int REQ_NOTIFICATIONS = 4208;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status, action, elapsed;
    private boolean waitingForCapture;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!alive()) return;
            updateStatus();
            handler.postDelayed(this, 800L);
        }
    };

    @Override protected String title() { return "Perekam Layar"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = scrollBody();
        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.tvb(this, "SCREEN RECORDER", 16, Ui.CYAN));
        intro.addView(Ui.tv(this, "Rekam layar gameplay sebagai MP4 ke folder Movies/TeinBooster. Video saja—mikrofon tidak diaktifkan. Android akan menampilkan dialog izin berbagi layar setiap kali rekaman dimulai.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        col.addView(intro, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));

        LinearLayout recordCard = Ui.card(this);
        recordCard.addView(Ui.tvb(this, "STATUS REKAMAN", 13, Ui.MINT));
        status = Ui.tvb(this, "Belum merekam", 21, Ui.TEXT);
        recordCard.addView(status, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        elapsed = Ui.tv(this, "00:00", 15, Ui.SUB);
        recordCard.addView(elapsed, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        action = Ui.button(this, "MULAI REKAM", v -> startCaptureFlow());
        recordCard.addView(action, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 14, 0, 0));
        recordCard.addView(Ui.ghost(this, "Hentikan rekaman", v -> stopRecording()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(recordCard, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout files = Ui.card(this);
        files.addView(Ui.tvb(this, "HASIL REKAMAN", 14, Ui.CYAN));
        files.addView(Ui.tv(this, "File baru pada Android 10+ disimpan ke Movies/TeinBooster dan dapat dilihat melalui Galeri/Foto. Rekaman sangat singkat mungkin dibuang jika encoder belum sempat membuat MP4 yang valid.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        files.addView(Ui.button(this, "Buka rekaman terakhir", v -> openLastRecording()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        files.addView(Ui.ghost(this, "Buka aplikasi Galeri / video", v -> openGallery()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(files, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout note = Ui.card(this);
        note.addView(Ui.tvb(this, "Catatan kompatibilitas", 14, Ui.EMBER));
        note.addView(Ui.tv(this, "Kualitas dan dukungan encoder mengikuti perangkat. Notifikasi layanan menampilkan tombol berhenti. Konten aman/terlindungi dari aplikasi lain dapat menjadi hitam karena Android melarang perekaman jenis konten tersebut.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        col.addView(note);
        updateStatus();
    }

    private void startCaptureFlow() {
        if (ScreenRecorderService.isRecording) { Toast.makeText(this, "Rekaman sedang berjalan.", Toast.LENGTH_SHORT).show(); return; }
        if (waitingForCapture) return;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            // Continue capture after the notification prompt returns; permission denial does not grant capture.
            waitingForCapture = true;
            return;
        }
        requestScreenCapturePermission();
    }

    private void requestScreenCapturePermission() {
        try {
            MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mgr == null) { Toast.makeText(this, "Layanan rekam layar tidak tersedia pada perangkat ini.", Toast.LENGTH_LONG).show(); return; }
            waitingForCapture = true;
            startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE);
        } catch (Exception e) {
            waitingForCapture = false;
            Toast.makeText(this, "Tidak dapat meminta izin rekam layar: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            waitingForCapture = false;
            requestScreenCapturePermission();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        waitingForCapture = false;
        if (resultCode != Activity.RESULT_OK || data == null) {
            Toast.makeText(this, "Izin perekaman layar dibatalkan.", Toast.LENGTH_SHORT).show();
            updateStatus();
            return;
        }
        try {
            Intent service = new Intent(this, ScreenRecorderService.class);
            service.setAction(ScreenRecorderService.ACTION_START);
            service.putExtra(ScreenRecorderService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(ScreenRecorderService.EXTRA_RESULT_DATA, data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            Toast.makeText(this, "Permintaan rekaman dikirim. Periksa status di bawah.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Layanan rekam layar gagal dimulai: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
        updateStatus();
    }

    private void stopRecording() {
        try {
            Intent i = new Intent(this, ScreenRecorderService.class).setAction(ScreenRecorderService.ACTION_STOP);
            startService(i);
        } catch (Exception e) { stopService(new Intent(this, ScreenRecorderService.class)); }
        Toast.makeText(this, "Perintah berhenti dikirim.", Toast.LENGTH_SHORT).show();
    }

    private void updateStatus() {
        if (status == null || action == null || elapsed == null) return;
        if (ScreenRecorderService.isRecording) {
            status.setText("Sedang merekam"); status.setTextColor(Ui.CORAL); action.setText("REKAMAN AKTIF"); action.setEnabled(false);
            long seconds = Math.max(0L, (android.os.SystemClock.elapsedRealtime() - ScreenRecorderService.startedAt) / 1000L);
            elapsed.setText(String.format(java.util.Locale.US, "%02d:%02d", seconds / 60L, seconds % 60L));
        } else {
            status.setText("Tidak merekam"); status.setTextColor(Ui.TEXT); action.setText("MULAI REKAM"); action.setEnabled(true);
            elapsed.setText(ScreenRecorderService.lastError == null || ScreenRecorderService.lastError.isEmpty() ? "Video terakhir: " + (ScreenRecorderService.lastOutput == null || ScreenRecorderService.lastOutput.isEmpty() ? "belum ada" : "tersimpan") : "Status terakhir: " + ScreenRecorderService.lastError);
        }
    }

    private void openLastRecording() {
        android.content.SharedPreferences sp = getSharedPreferences("screen_recorder", MODE_PRIVATE);
        String saved = sp.getString("last_uri", "");
        if (saved == null || saved.isEmpty()) saved = sp.getString("last_path", "");
        if (saved == null || saved.isEmpty()) saved = ScreenRecorderService.lastOutput == null ? "" : ScreenRecorderService.lastOutput;
        if (saved.isEmpty()) { Toast.makeText(this, "Belum ada rekaman yang berhasil disimpan.", Toast.LENGTH_SHORT).show(); return; }
        try {
            Uri uri = saved.startsWith("content://") || saved.startsWith("file://")
                    ? Uri.parse(saved) : Uri.fromFile(new java.io.File(saved));
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "video/mp4");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada pemutar video yang bisa membuka rekaman ini. Periksa folder Movies/TeinBooster.", Toast.LENGTH_LONG).show();
        }
    }

    private void openGallery() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI)); }
        catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            catch (Exception ignored) { Toast.makeText(this, "Buka Galeri dari layar utama perangkat.", Toast.LENGTH_SHORT).show(); }
        }
    }

    @Override protected void onResume() { super.onResume(); handler.removeCallbacks(ticker); handler.post(ticker); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(ticker); }
    @Override protected void onDestroy() { handler.removeCallbacks(ticker); super.onDestroy(); }
}
