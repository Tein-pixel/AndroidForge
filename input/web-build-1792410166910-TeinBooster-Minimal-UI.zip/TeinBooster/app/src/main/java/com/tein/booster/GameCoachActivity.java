package com.tein.booster;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Coach berbasis aturan lokal; tidak mengaku menggunakan AI atau mengakses data server. */
public class GameCoachActivity extends BaseActivity {
    private String gameType = "MOBA";
    private String priority = "Stabil dan minim panas";
    private TextView gameChoice, priorityChoice;
    private LinearLayout result;

    @Override protected String title() { return "Game Coach"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = scrollBody();
        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.tvb(this, "REKOMENDASI PERANGKAT", 14, Ui.MINT));
        intro.addView(Ui.tv(this, "Pilih jenis game dan tujuanmu. Rekomendasi dibuat di perangkat berdasarkan RAM, suhu baterai, dan refresh rate yang terbaca.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(intro, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));
        LinearLayout choices = Ui.card(this);
        choices.addView(Ui.tvb(this, "Jenis game", 14, Ui.TEXT));
        gameChoice = Ui.tvb(this, gameType + "  ▾", 15, Ui.CYAN);
        gameChoice.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        gameChoice.setOnClickListener(v -> pickGame());
        choices.addView(gameChoice);
        choices.addView(Ui.divider(this));
        choices.addView(Ui.tvb(this, "Prioritas", 14, Ui.TEXT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        priorityChoice = Ui.tvb(this, priority + "  ▾", 15, Ui.CYAN);
        priorityChoice.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        priorityChoice.setOnClickListener(v -> pickPriority());
        choices.addView(priorityChoice);
        choices.addView(Ui.button(this, "Buat rekomendasi", v -> makeAdvice()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(choices, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        result = Ui.col(this);
        col.addView(result);
        makeAdvice();
    }

    private void pickGame() {
        String[] items = {"MOBA", "Battle Royale", "FPS / tembak-menembak", "Balapan", "Casual"};
        new AlertDialog.Builder(this).setTitle("Pilih jenis game").setItems(items, (d, which) -> { gameType = items[which]; gameChoice.setText(gameType + "  ▾"); makeAdvice(); }).show();
    }

    private void pickPriority() {
        String[] items = {"Stabil dan minim panas", "Visual lebih bagus", "Respons sentuhan", "Hemat baterai"};
        new AlertDialog.Builder(this).setTitle("Pilih prioritas").setItems(items, (d, which) -> { priority = items[which]; priorityChoice.setText(priority + "  ▾"); makeAdvice(); }).show();
    }

    private void makeAdvice() {
        if (result == null) return;
        result.removeAllViews();
        long ram = Sys.ramTotal(this);
        float temp = Sys.battery(this).tempC;
        int hz = Math.round(getWindowManager().getDefaultDisplay().getRefreshRate());
        boolean low = ram < 3L * 1024L * 1024L * 1024L;
        boolean medium = ram < 6L * 1024L * 1024L * 1024L;
        String quality = low ? "Rendah" : "Sedang";
        String fps = low ? "30 FPS" : medium ? "30–40 FPS" : (hz >= 60 ? "45–60 FPS jika tersedia" : "30 FPS");
        String render = low ? "70–80%" : medium ? "80–90%" : "90%";
        String effects = low || temp >= 38f ? "Bayangan dan efek berat: mati / rendah" : "Bayangan: rendah; tingkatkan hanya jika tetap stabil";
        if ("Visual lebih bagus".equals(priority) && !low && temp < 38f) { quality = "Sedang, lalu uji Tinggi"; render = "90–100% jika stabil"; }
        if ("Respons sentuhan".equals(priority)) { effects = "Matikan blur, efek layar, dan gerakan kamera bila opsi tersedia"; }
        if ("Hemat baterai".equals(priority)) { fps = "30 FPS"; render = low ? "70%" : "80%"; effects = "Bayangan mati; turunkan kecerahan layar secukupnya"; }
        if ("Stabil dan minim panas".equals(priority) && temp >= 38f) { quality = "Rendah"; fps = "30 FPS"; effects = "Hentikan sementara game bila perangkat terlalu panas; jangan mendinginkan secara ekstrem"; }
        LinearLayout card = Ui.card(this);
        card.addView(Ui.tvb(this, "SARAN UNTUK " + gameType.toUpperCase(java.util.Locale.US), 15, Ui.MINT));
        adviceRow(card, "Kualitas grafis", quality);
        adviceRow(card, "Batas FPS", fps);
        adviceRow(card, "Resolusi render", render);
        adviceRow(card, "Efek", effects);
        adviceRow(card, "Kondisi perangkat", String.format(java.util.Locale.US, "RAM %.1f GB • suhu baterai %.1f°C • layar %d Hz", ram / (1024f * 1024f * 1024f), temp, hz));
        card.addView(Ui.tv(this, "Catatan jaringan: pilih server terdekat dalam game dan gunakan koneksi stabil. Alat ini tidak bisa menjamin ping rendah atau mengubah server game.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        result.addView(card);
    }

    private void adviceRow(LinearLayout parent, String label, String value) {
        LinearLayout item = Ui.col(this);
        item.addView(Ui.tv(this, label, 12, Ui.SUB));
        item.addView(Ui.tvb(this, value, 14, Ui.TEXT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        parent.addView(item, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
    }
}
