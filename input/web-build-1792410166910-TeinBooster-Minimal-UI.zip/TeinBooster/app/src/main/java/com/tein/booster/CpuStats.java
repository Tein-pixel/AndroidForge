package com.tein.booster;

import java.io.BufferedReader;
import java.io.FileReader;

/** Best-effort whole-device CPU activity from Linux aggregate counters; never represents game-only CPU usage. */
public final class CpuStats {
    private long lastTotal = -1L;
    private long lastIdle = -1L;

    /** Returns percent since the prior sample, or -1 when the kernel counters are unavailable. */
    public synchronized float samplePercent() {
        BufferedReader r = null;
        try {
            r = new BufferedReader(new FileReader("/proc/stat"));
            String line = r.readLine();
            if (line == null || !line.startsWith("cpu ")) return -1f;
            String[] parts = line.trim().split("\\s+");
            if (parts.length < 5) return -1f;
            long total = 0L;
            long[] values = new long[parts.length - 1];
            int usable = Math.min(parts.length - 1, 8); // user through steal; don't double-count guest fields
            values = new long[usable];
            for (int i = 1; i <= usable; i++) {
                long value = Long.parseLong(parts[i]);
                values[i - 1] = value;
                total += value;
            }
            long idle = values[3];
            if (values.length > 4) idle += values[4]; // iowait
            if (lastTotal < 0L || total <= lastTotal || idle < lastIdle) {
                lastTotal = total; lastIdle = idle; return -1f;
            }
            long totalDelta = total - lastTotal;
            long idleDelta = idle - lastIdle;
            lastTotal = total; lastIdle = idle;
            if (totalDelta <= 0L) return -1f;
            return Math.max(0f, Math.min(100f, (1f - (float) idleDelta / (float) totalDelta) * 100f));
        } catch (Exception ignored) {
            return -1f;
        } finally {
            try { if (r != null) r.close(); } catch (Exception ignored) { }
        }
    }
}
