package com.tein.booster;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Kumpulan helper UI (semua tampilan dibangun lewat kode agar ringan & minim bug XML). */
public final class Ui {
    // Mutable so a user's saved theme applies consistently across all code-built screens.
    public static int BG = 0xFF000000;
    public static int PANEL = 0xFF0C0C0E;
    public static int PANEL2 = 0xFF17171B;
    public static int LINE = 0xFF28282E;
    public static int TEXT = 0xFFF2F3F5;
    public static int SUB = 0xFF9B9DA8;
    public static int CYAN = 0xFF2EE6FF;
    public static int BLUE = 0xFF3D8BFF;
    public static int VIOLET = 0xFF8B5CFF;
    public static int MINT = 0xFF35E0A1;
    public static int EMBER = 0xFFFFB020;
    public static int CORAL = 0xFFFF5C7A;
    public static int PINK = 0xFFFF5FA8;
    public static int INK = 0xFF06101F;

    /** Theme 0: AMOLED black (default); 1: navy dark; 2: light. */
    public static void applyTheme(Context c) {
        int mode = Prefs.getInt(c, Prefs.UI_THEME, 0);
        if (mode < 0 || mode > 2) mode = 0;
        if (mode == 1) {
            BG = 0xFF0A0E1F; PANEL = 0xFF121A33; PANEL2 = 0xFF1A2547; LINE = 0xFF263459;
            TEXT = 0xFFEAF0FF; SUB = 0xFF8C99BE; CYAN = 0xFF2EE6FF; BLUE = 0xFF3D8BFF;
            VIOLET = 0xFF8B5CFF; MINT = 0xFF35E0A1; EMBER = 0xFFFFB020; CORAL = 0xFFFF5C7A;
            PINK = 0xFFFF5FA8; INK = 0xFF06101F;
        } else if (mode == 2) {
            BG = 0xFFF5F6F8; PANEL = 0xFFFFFFFF; PANEL2 = 0xFFEEF0F4; LINE = 0xFFE0E3E9;
            TEXT = 0xFF171A21; SUB = 0xFF687080; CYAN = 0xFF087F8C; BLUE = 0xFF3567C8;
            VIOLET = 0xFF7053B8; MINT = 0xFF087A53; EMBER = 0xFF9A5B00; CORAL = 0xFFC43150;
            PINK = 0xFFB73570; INK = 0xFF07111B;
        } else {
            BG = 0xFF000000; PANEL = 0xFF0C0C0E; PANEL2 = 0xFF17171B; LINE = 0xFF28282E;
            TEXT = 0xFFF2F3F5; SUB = 0xFF9B9DA8; CYAN = 0xFF2EE6FF; BLUE = 0xFF3D8BFF;
            VIOLET = 0xFF8B5CFF; MINT = 0xFF35E0A1; EMBER = 0xFFFFB020; CORAL = 0xFFFF5C7A;
            PINK = 0xFFFF5FA8; INK = 0xFF06101F;
        }
    }

    public static int theme(Context c) { return Prefs.getInt(c, Prefs.UI_THEME, 0); }

    public static void applyWindowTheme(Activity a) {
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(BG);
        if (theme(a) == 2) {
            a.getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        } else {
            a.getWindow().getDecorView().setSystemUiVisibility(0);
        }
    }
    public static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    public static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    public static GradientDrawable rect(Context c, int color, float rDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, rDp));
        return g;
    }

    public static GradientDrawable grad(Context c, int c1, int c2, float rDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(c, rDp));
        return g;
    }

    public static GradientDrawable outline(Context c, int fill, int stroke, float rDp) {
        GradientDrawable g = rect(c, fill, rDp);
        g.setStroke(Math.max(1, dp(c, 1)), stroke);
        return g;
    }

    public static Drawable ripple(Context c, Drawable content, float rDp) {
        return new RippleDrawable(ColorStateList.valueOf(theme(c) == 2 ? 0x18000000 : 0x33FFFFFF), content, rect(c, 0xFFFFFFFF, rDp));
    }

    public static TextView tv(Context c, CharSequence t, float sp, int color) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        return v;
    }

    public static TextView tvb(Context c, CharSequence t, float sp, int color) {
        TextView v = tv(c, t, sp, color);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return v;
    }

    public static TextView num(Context c, CharSequence t, float sp, int color) {
        TextView v = tv(c, t, sp, color);
        v.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        return v;
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** LayoutParams dengan margin dalam dp. */
    public static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    /** Lebar 0 + bobot (untuk baris), margin dalam dp. */
    public static LinearLayout.LayoutParams lpw(Context c, float weight, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, weight);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(outline(c, PANEL, LINE, 18));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static TextView button2(Context c, String text, int c1, int c2, View.OnClickListener click) {
        TextView b = tvb(c, text, 16, INK);
        b.setGravity(Gravity.CENTER);
        b.setBackground(ripple(c, grad(c, c1, c2, 16), 16));
        b.setPadding(dp(c, 20), dp(c, 15), dp(c, 20), dp(c, 15));
        b.setClickable(true);
        b.setOnClickListener(click);
        pressable(b);
        return b;
    }

    public static TextView button(Context c, String text, View.OnClickListener click) {
        return button2(c, text, CYAN, BLUE, click);
    }

    public static TextView ghost(Context c, String text, View.OnClickListener click) {
        TextView b = tvb(c, text, 15, TEXT);
        b.setGravity(Gravity.CENTER);
        b.setBackground(ripple(c, outline(c, 0x00000000, LINE, 16), 16));
        b.setPadding(dp(c, 18), dp(c, 13), dp(c, 18), dp(c, 13));
        b.setClickable(true);
        b.setOnClickListener(click);
        pressable(b);
        return b;
    }

    public static TextView chip(Context c, String text, int color) {
        TextView v = tvb(c, text, 12, color);
        v.setBackground(rect(c, alpha(color, 0x2A), 10));
        v.setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5));
        return v;
    }

    public static TextView badge(Context c, String emoji, int color, float sizeDp) {
        TextView t = new TextView(c);
        t.setText(emoji);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeDp * 0.44f);
        t.setGravity(Gravity.CENTER);
        t.setBackground(grad(c, alpha(color, 0x55), alpha(color, 0x1F), sizeDp * 0.32f));
        int s = dp(c, sizeDp);
        t.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return t;
    }

    public static TextView sectionTitle(Context c, String text) {
        TextView t = tvb(c, text, 15, TEXT);
        t.setPadding(dp(c, 4), dp(c, 20), 0, dp(c, 8));
        return t;
    }

    public static View space(Context c, float hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, hDp)));
        return v;
    }

    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(c, 1))));
        return v;
    }

    public static LinearLayout kv(Context c, String k, String v) {
        LinearLayout r = row(c);
        TextView a = tv(c, k, 13, SUB);
        TextView b = tvb(c, v, 13, TEXT);
        b.setGravity(Gravity.END);
        r.addView(a, new LinearLayout.LayoutParams(0, WRAP, 0.85f));
        r.addView(b, new LinearLayout.LayoutParams(0, WRAP, 1.15f));
        r.setPadding(0, dp(c, 7), 0, dp(c, 7));
        return r;
    }

    public static void pressable(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                }
                return false;
            }
        });
    }

    /** Animasi masuk berurutan (sekali, saat layar dibuka). */
    public static void reveal(View... views) {
        int i = 0;
        for (View v : views) {
            v.setAlpha(0f);
            v.setTranslationY(v.getResources().getDisplayMetrics().density * 14f);
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 55L).setDuration(380)
                    .setInterpolator(new DecelerateInterpolator()).start();
            i++;
        }
    }

    public static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    public static void copy(Context c, String label, String text) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
        } catch (Exception ignored) {
        }
    }

    public static void confirm(Activity a, String title, String msg, String ok, final Runnable onOk) {
        new AlertDialog.Builder(a)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(ok, (d, w) -> onOk.run())
                .setNegativeButton("Batal", null)
                .show();
    }

    public interface Pick {
        void onPick(int index);
    }

    /** Kontrol segmen (tab pilihan tunggal) dengan pil gradasi pada yang terpilih. */
    public static LinearLayout segment(final Context c, String[] labels, int selected, final Pick pick) {
        final LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackground(outline(c, PANEL2, LINE, 14));
        int pad = dp(c, 3);
        row.setPadding(pad, pad, pad, pad);
        final TextView[] tabs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = tvb(c, labels[i], 13, TEXT);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(c, 6), dp(c, 10), dp(c, 6), dp(c, 10));
            t.setClickable(true);
            t.setOnClickListener(v -> {
                paintSegment(c, tabs, idx);
                pick.onPick(idx);
            });
            tabs[i] = t;
            row.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        paintSegment(c, tabs, selected);
        return row;
    }

    private static void paintSegment(Context c, TextView[] tabs, int sel) {
        for (int i = 0; i < tabs.length; i++) {
            boolean on = i == sel;
            tabs[i].setTextColor(on ? INK : SUB);
            tabs[i].setBackground(on ? grad(c, CYAN, BLUE, 11) : rect(c, 0x00000000, 11));
        }
    }
}
