package com.tein.booster;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.input.InputManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Tes input layar lokal: sapuan, beberapa titik sentuh, warna layar, dan kontroler eksternal. */
public class TouchTestActivity extends BaseActivity {
    private LinearLayout pane;
    private int tab = 0;
    private TextView controllerEvent;
    private int screenColorIndex = 0;
    private final int[] screenColors = {0xFF000000, 0xFFFFFFFF, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF};
    private final String[] colorNames = {"Hitam", "Putih", "Merah", "Hijau", "Biru"};

    @Override protected String title() { return "Alat Uji"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = scrollBody();
        LinearLayout tabs = Ui.row(this);
        tabs.setBackground(Ui.outline(this, Ui.PANEL, Ui.LINE, 14));
        addTab(tabs, "SENTUHAN", 0);
        addTab(tabs, "LAYAR", 1);
        addTab(tabs, "KONTROLER", 2);
        root.addView(tabs, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 12));
        pane = Ui.col(this);
        root.addView(pane, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        renderTab();
    }

    private void addTab(LinearLayout parent, String label, int index) {
        TextView button = Ui.tvb(this, label, 11, tab == index ? Ui.MINT : Ui.SUB);
        button.setGravity(Gravity.CENTER);
        button.setPadding(Ui.dp(this, 5), Ui.dp(this, 14), Ui.dp(this, 5), Ui.dp(this, 14));
        button.setOnClickListener(v -> { tab = index; renderTab(); });
        parent.addView(button, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
    }

    private void renderTab() {
        pane.removeAllViews();
        if (tab == 0) renderTouch();
        else if (tab == 1) renderScreen();
        else renderController();
    }

    private void renderTouch() {
        LinearLayout info = Ui.card(this);
        info.addView(Ui.tvb(this, "Uji sentuhan dan multi-touch", 15, Ui.MINT));
        info.addView(Ui.tv(this, "Geser satu atau beberapa jari di bidang. Kotak yang terkena sentuhan akan berubah warna.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        pane.addView(info, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        TextView metrics = Ui.tvb(this, "Laju event gerak: --\nTitik bersamaan: --\nEvent terhitung: --", 14, Ui.TEXT);
        metrics.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 10));
        pane.addView(metrics);
        TouchSurface surface = new TouchSurface(this, (rate, count, maxPoints, events) -> metrics.setText(String.format(Locale.US, "Laju event gerak: %.0f event/detik\nTitik bersamaan: %d • maksimum %d\nEvent terhitung: %d", rate, count, maxPoints, events)));
        pane.addView(surface, Ui.lp(this, Ui.MATCH, Ui.dp(this, 370), 0, 0, 0, 12));
        pane.addView(Ui.tv(this, "Catatan: angka laju adalah event input yang diterima aplikasi, bukan refresh rate layar dan bukan FPS game. Tes beberapa kali karena hasil dipengaruhi gerakan jari dan sistem.", 12, Ui.SUB));
        pane.addView(Ui.button(this, "Reset hasil sentuhan", v -> { surface.reset(); metrics.setText("Laju event gerak: --\nTitik bersamaan: 0 • maksimum 0\nEvent terhitung: 0"); }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
    }

    private void renderScreen() {
        LinearLayout info = Ui.card(this);
        info.addView(Ui.tvb(this, "Pemeriksaan warna layar", 15, Ui.MINT));
        info.addView(Ui.tv(this, "Ganti warna untuk membantu melihat piksel yang macet atau area dengan warna tidak merata. Layar tidak dapat menguji semua cacat panel secara otomatis.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        pane.addView(info, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        TextView swatch = Ui.tvb(this, "KETUK UNTUK GANTI WARNA", 14, screenTextColor());
        swatch.setGravity(Gravity.CENTER);
        swatch.setBackgroundColor(screenColors[screenColorIndex]);
        pane.addView(swatch, Ui.lp(this, Ui.MATCH, Ui.dp(this, 370), 0, 0, 0, 8));
        TextView label = Ui.tvb(this, "Warna: " + colorNames[screenColorIndex], 14, Ui.TEXT);
        label.setGravity(Gravity.CENTER);
        pane.addView(label, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 10));
        View.OnClickListener next = v -> {
            screenColorIndex = (screenColorIndex + 1) % screenColors.length;
            swatch.setBackgroundColor(screenColors[screenColorIndex]);
            swatch.setTextColor(screenTextColor());
            label.setText("Warna: " + colorNames[screenColorIndex]);
        };
        swatch.setOnClickListener(next);
        pane.addView(Ui.button(this, "Warna berikutnya", next), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 0));
    }

    private int screenTextColor() { return (screenColorIndex == 1 || screenColorIndex == 3) ? 0xFF111111 : 0xFFFFFFFF; }

    private void renderController() {
        LinearLayout info = Ui.card(this);
        info.addView(Ui.tvb(this, "Kontroler yang terdeteksi", 15, Ui.MINT));
        info.addView(Ui.tv(this, "Hubungkan gamepad Bluetooth/USB lewat pengaturan Android, lalu kembali ke halaman ini.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        pane.addView(info, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        int[] ids = InputDevice.getDeviceIds();
        int found = 0;
        for (int id : ids) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null || d.isVirtual()) continue;
            int src = d.getSources();
            boolean controller = (src & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                    || (src & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
            if (!controller) continue;
            found++;
            LinearLayout c = Ui.card(this);
            c.addView(Ui.tvb(this, d.getName(), 14, Ui.TEXT));
            c.addView(Ui.tv(this, "ID " + id + " • " + d.getMotionRanges().size() + " rentang sumbu", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
            pane.addView(c, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        }
        if (found == 0) pane.addView(Ui.tv(this, "Belum ada gamepad/joystick fisik yang terdeteksi. Layar sentuh tetap dapat diuji tanpa perangkat tambahan.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 8));
        controllerEvent = Ui.tvb(this, "Input kontroler terakhir: belum ada", 13, Ui.CYAN);
        LinearLayout eventBox = Ui.card(this);
        eventBox.addView(controllerEvent);
        pane.addView(eventBox, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        pane.addView(Ui.tv(this, "Tekan tombol atau gerakkan stik ketika halaman ini aktif. Tidak ada input yang direkam di latar belakang.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (tab == 2 && controllerEvent != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            controllerEvent.setText("Tombol diterima: " + KeyEvent.keyCodeToString(event.getKeyCode()) + " (ID perangkat " + event.getDeviceId() + ")");
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean onGenericMotionEvent(MotionEvent event) {
        if (tab == 2 && controllerEvent != null) {
            controllerEvent.setText(String.format(Locale.US, "Gerakan sumbu diterima • X %.2f • Y %.2f (ID %d)", event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y), event.getDeviceId()));
            return true;
        }
        return super.onGenericMotionEvent(event);
    }

    private interface MetricsCallback { void onMetrics(float rate, int points, int maxPoints, int events); }

    private static class TouchSurface extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final MetricsCallback callback;
        private final float[] xs = new float[10];
        private final float[] ys = new float[10];
        private final boolean[] active = new boolean[10];
        private long startAt = 0L;
        private int eventCount = 0;
        private int moveEventCount = 0;
        private int maxPoints = 0;
        private float rate = 0f;

        TouchSurface(TouchTestActivity c, MetricsCallback cb) {
            super(c); callback = cb;
            setBackground(Ui.rect(c, Ui.PANEL, 12));
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cw = getWidth() / 6f, ch = getHeight() / 10f;
            paint.setStrokeWidth(Ui.dp(getContext(), 1));
            paint.setStyle(Paint.Style.STROKE); paint.setColor(Ui.LINE);
            for (int r = 0; r < 10; r++) for (int c = 0; c < 6; c++) {
                RectF cell = new RectF(c * cw + 2, r * ch + 2, (c + 1) * cw - 2, (r + 1) * ch - 2);
                canvas.drawRoundRect(cell, Ui.dp(getContext(), 4), Ui.dp(getContext(), 4), paint);
            }
            paint.setStyle(Paint.Style.FILL);
            for (int i = 0; i < active.length; i++) if (active[i]) {
                paint.setColor(Ui.alpha(Ui.MINT, 0xAA));
                canvas.drawCircle(xs[i], ys[i], Ui.dp(getContext(), 18), paint);
                paint.setColor(Ui.TEXT);
                canvas.drawCircle(xs[i], ys[i], Ui.dp(getContext(), 5), paint);
            }
            if (startAt == 0) {
                paint.setColor(Ui.SUB); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(Ui.dp(getContext(), 13));
                canvas.drawText("Geser satu atau beberapa jari", getWidth() / 2f, getHeight() / 2f, paint);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            int action = e.getActionMasked();
            if (startAt == 0) startAt = android.os.SystemClock.elapsedRealtime();
            eventCount++;
            int count = Math.min(e.getPointerCount(), xs.length);
            int activeCount = count;
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) activeCount = 0;
            else if (action == MotionEvent.ACTION_POINTER_UP) activeCount = Math.max(0, count - 1);
            if (action == MotionEvent.ACTION_MOVE) moveEventCount++;
            for (int i = 0; i < active.length; i++) active[i] = false;
            for (int i = 0; i < count; i++) {
                if (action == MotionEvent.ACTION_POINTER_UP && i == e.getActionIndex()) continue;
                int idx = e.getPointerId(i);
                if (idx >= 0 && idx < active.length) {
                    xs[idx] = e.getX(i); ys[idx] = e.getY(i); active[idx] = activeCount > 0;
                }
            }
            maxPoints = Math.max(maxPoints, activeCount);
            long elapsed = Math.max(1L, android.os.SystemClock.elapsedRealtime() - startAt);
            rate = moveEventCount * 1000f / elapsed;
            callback.onMetrics(rate, activeCount, maxPoints, eventCount);
            invalidate();
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                for (int i = 0; i < active.length; i++) active[i] = false;
                invalidate();
            }
            return true;
        }

        void reset() {
            startAt = 0L; eventCount = 0; moveEventCount = 0; maxPoints = 0; rate = 0f;
            for (int i = 0; i < active.length; i++) active[i] = false;
            invalidate();
        }
    }
}
