package com.tein.booster;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Bar horizontal bersegmen (progres tunggal atau bar bertumpuk). */
public class BarView extends View {
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint seg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private float[] fr = new float[0];
    private int[] cols = new int[0];
    private float prog = 1f;
    private ValueAnimator anim;

    public BarView(Context c) {
        super(c);
        bg.setColor(Ui.PANEL2);
    }

    public BarView(Context c, AttributeSet a) {
        super(c, a);
        bg.setColor(Ui.PANEL2);
    }

    public void setValue(float f, int color) {
        setSegments(new float[]{f}, new int[]{color});
    }

    public void setSegments(float[] f, int[] c) {
        fr = f;
        cols = c;
        if (anim != null) anim.cancel();
        prog = 0f;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(700);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            prog = (Float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    private float cur = 0f;

    /** Ubah nilai tunggal dengan transisi halus dari nilai sekarang (cocok untuk pembaruan live). */
    public void setSmooth(float target, int color) {
        final float to = Math.max(0f, Math.min(1f, target));
        cols = new int[]{color};
        prog = 1f;
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(cur, to);
        anim.setDuration(450);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            cur = (Float) a.getAnimatedValue();
            fr = new float[]{cur};
            invalidate();
        });
        anim.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rect.set(0f, 0f, w, h);
        clip.reset();
        clip.addRoundRect(rect, h / 2f, h / 2f, Path.Direction.CW);
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float h = getHeight();
        cv.drawRoundRect(rect, h / 2f, h / 2f, bg);
        cv.save();
        cv.clipPath(clip);
        float x = 0f;
        for (int i = 0; i < fr.length && i < cols.length; i++) {
            float w = Math.max(0f, fr[i]) * getWidth() * prog;
            seg.setColor(cols[i]);
            cv.drawRect(x, 0f, x + w, h, seg);
            x += w;
        }
        cv.restore();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (anim != null) anim.cancel();
    }
}
