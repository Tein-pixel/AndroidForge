package com.tein.booster;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Mini-game offline untuk latihan reaksi dan akurasi sentuhan. */
public class GamerTrainingActivity extends BaseActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final List<TextView> targets = new ArrayList<>();
    private TextView status, score, startButton;
    private LinearLayout modeRow;
    private int mode = 0;
    private int targetIndex = -1, round = 0, hits = 0, misses = 0, reactionCount = 0;
    private long totalReaction = 0L, signalAt;
    private boolean active, waitingSignal, signalReady;
    private Runnable signalRunnable, timeoutRunnable, nextRunnable;
    private final String[] modeNames = {"Lapangan latihan", "Gudang robot", "Atap gedung"};

    @Override protected String title() { return "Latihan Gamer"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = scrollBody();
        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.tvb(this, "LATIHAN REFLEKS", 15, Ui.MINT));
        intro.addView(Ui.tv(this, "Sentuh target hijau secepat dan seakurat mungkin. Satu sesi terdiri dari 10 ronde. Berjalan sepenuhnya offline.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        col.addView(intro, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));
        col.addView(Ui.sectionTitle(this, "PILIH ARENA"));
        modeRow = Ui.row(this);
        col.addView(modeRow, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        LinearLayout stats = Ui.card(this);
        status = Ui.tvb(this, "Pilih arena lalu tekan mulai.", 14, Ui.TEXT);
        stats.addView(status);
        score = Ui.tv(this, "Ronde 0/10 • Tepat 0 • Meleset 0 • Rata-rata --", 12, Ui.SUB);
        stats.addView(score, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        col.addView(stats, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));

        LinearLayout grid = Ui.col(this);
        for (int r = 0; r < 3; r++) {
            LinearLayout row = Ui.row(this);
            for (int c = 0; c < 3; c++) {
                final int idx = r * 3 + c;
                TextView t = Ui.tvb(this, "•", 26, Ui.SUB);
                t.setGravity(Gravity.CENTER);
                t.setBackground(Ui.ripple(this, Ui.outline(this, Ui.PANEL, Ui.LINE, 12), 12));
                t.setOnClickListener(v -> tapTarget(idx));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 82), 1f);
                lp.setMargins(Ui.dp(this, 3), Ui.dp(this, 3), Ui.dp(this, 3), Ui.dp(this, 3));
                row.addView(t, lp);
                targets.add(t);
            }
            grid.addView(row);
        }
        col.addView(grid, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 10));
        startButton = Ui.button(this, "Mulai latihan • 10 ronde", v -> startTraining());
        col.addView(startButton, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
        col.addView(Ui.tv(this, "Penilaian bintang berdasarkan jumlah target yang tepat dan kecepatan rata-rata. Ini melatih timing dalam aplikasi, bukan mengukur latensi sentuh perangkat secara ilmiah.", 12, Ui.SUB));
        refreshModes(); clearTargets();
    }

    private int[] bestStars() {
        int[] values = new int[3];
        for (int i = 0; i < 3; i++) values[i] = getPreferences(MODE_PRIVATE).getInt("best_stars_" + i, 0);
        return values;
    }

    private void refreshModes() {
        modeRow.removeAllViews();
        int[] stars = bestStars();
        int total = stars[0] + stars[1] + stars[2];
        for (int i = 0; i < 3; i++) {
            final int chosen = i;
            boolean unlocked = i == 0 || (i == 1 && total >= 1) || (i == 2 && total >= 3);
            String label = (unlocked ? "✓ " : "🔒 ") + modeNames[i] + (i == 0 ? "" : "\nBintang " + total + "/" + (i == 1 ? "1" : "3"));
            TextView b = Ui.tvb(this, label, 10, unlocked ? (mode == i ? Ui.MINT : Ui.TEXT) : Ui.SUB);
            b.setGravity(Gravity.CENTER);
            b.setPadding(Ui.dp(this, 5), Ui.dp(this, 10), Ui.dp(this, 5), Ui.dp(this, 10));
            b.setBackground(Ui.outline(this, mode == i ? Ui.alpha(Ui.MINT, 0x22) : Ui.PANEL, mode == i ? Ui.MINT : Ui.LINE, 12));
            b.setAlpha(unlocked ? 1f : 0.55f);
            b.setOnClickListener(v -> {
                int[] current = bestStars(); int totalNow = current[0] + current[1] + current[2];
                boolean ok = chosen == 0 || (chosen == 1 && totalNow >= 1) || (chosen == 2 && totalNow >= 3);
                if (!ok) { Toast.makeText(this, chosen == 1 ? "Dapatkan minimal 1 bintang untuk membuka arena ini." : "Dapatkan total 3 bintang untuk membuka arena ini.", Toast.LENGTH_SHORT).show(); return; }
                if (active) stopTraining("Latihan dibatalkan. Pilih arena baru.");
                mode = chosen; refreshModes(); clearTargets(); status.setText(modeNames[mode] + " dipilih.");
            });
            modeRow.addView(b, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        }
    }

    private void startTraining() {
        cancelTimers(); active = true; waitingSignal = false; signalReady = false;
        round = hits = misses = reactionCount = 0; totalReaction = 0L;
        startButton.setText("Latihan berjalan… tekan target hijau");
        startButton.setEnabled(false);
        clearTargets(); nextRound();
    }

    private void nextRound() {
        if (!active) return;
        if (round >= 10) { finishTraining(); return; }
        round++;
        targetIndex = -1; waitingSignal = true; signalReady = false;
        clearTargets(); updateScore();
        status.setText("Ronde " + round + "/10 — tunggu sampai target berubah hijau");
        int delay = mode == 0 ? 850 + random.nextInt(1400) : mode == 1 ? 650 + random.nextInt(1500) : 450 + random.nextInt(1400);
        signalRunnable = () -> {
            if (!active || !waitingSignal) return;
            waitingSignal = false; signalReady = true;
            int limit = mode == 0 ? 6 : 9;
            targetIndex = random.nextInt(limit);
            signalAt = SystemClock.elapsedRealtime();
            TextView target = targets.get(targetIndex);
            target.setText("TEKAN");
            target.setTextColor(Ui.INK);
            target.setBackground(Ui.grad(this, Ui.MINT, 0xFF6AFF9F, 12));
            status.setText("SEKARANG! Sentuh target hijau.");
            timeoutRunnable = () -> {
                if (active && signalReady) {
                    signalReady = false; misses++; status.setText("Waktu habis — lanjut ronde berikutnya.");
                    updateScore(); scheduleNext();
                }
            };
            handler.postDelayed(timeoutRunnable, 1800L);
        };
        handler.postDelayed(signalRunnable, delay);
    }

    private void tapTarget(int index) {
        if (!active) return;
        if (waitingSignal) {
            waitingSignal = false; misses++;
            if (signalRunnable != null) handler.removeCallbacks(signalRunnable);
            status.setText("Terlalu cepat. Tunggu isyarat hijau.");
            updateScore(); scheduleNext();
            return;
        }
        if (!signalReady) return;
        signalReady = false;
        if (timeoutRunnable != null) handler.removeCallbacks(timeoutRunnable);
        if (index == targetIndex) {
            long ms = SystemClock.elapsedRealtime() - signalAt;
            totalReaction += ms; reactionCount++; hits++;
            status.setText("Tepat! " + ms + " ms");
        } else {
            misses++; status.setText("Meleset. Target berada di kotak lain.");
        }
        updateScore(); scheduleNext();
    }

    private void scheduleNext() {
        if (nextRunnable != null) handler.removeCallbacks(nextRunnable);
        nextRunnable = () -> nextRound();
        handler.postDelayed(nextRunnable, 650L);
    }

    private void updateScore() {
        String avg = reactionCount > 0 ? String.format(Locale.US, "%.0f ms", totalReaction / (double) reactionCount) : "--";
        score.setText("Ronde " + round + "/10 • Tepat " + hits + " • Meleset " + misses + " • Rata-rata " + avg);
    }

    private void finishTraining() {
        active = false; waitingSignal = false; signalReady = false; cancelTimers(); clearTargets();
        double avg = reactionCount > 0 ? totalReaction / (double) reactionCount : 9999;
        int stars = hits >= 8 && avg <= 500 ? 3 : hits >= 6 && avg <= 750 ? 2 : hits >= 4 ? 1 : 0;
        int prior = getPreferences(MODE_PRIVATE).getInt("best_stars_" + mode, 0);
        if (stars > prior) getPreferences(MODE_PRIVATE).edit().putInt("best_stars_" + mode, stars).apply();
        status.setText("Selesai • " + (stars == 0 ? "belum mendapat bintang" : (stars + " bintang")) + " • rata-rata " + (reactionCount > 0 ? String.format(Locale.US, "%.0f ms", avg) : "--"));
        startButton.setEnabled(true); startButton.setText("Main lagi • 10 ronde");
        refreshModes();
    }

    private void stopTraining(String message) {
        active = false; waitingSignal = false; signalReady = false; cancelTimers(); clearTargets();
        if (startButton != null) { startButton.setEnabled(true); startButton.setText("Mulai latihan • 10 ronde"); }
        if (status != null) status.setText(message);
    }

    private void cancelTimers() {
        if (signalRunnable != null) handler.removeCallbacks(signalRunnable);
        if (timeoutRunnable != null) handler.removeCallbacks(timeoutRunnable);
        if (nextRunnable != null) handler.removeCallbacks(nextRunnable);
        signalRunnable = timeoutRunnable = nextRunnable = null;
    }

    private void clearTargets() {
        for (int i = 0; i < targets.size(); i++) {
            TextView t = targets.get(i);
            t.setText("•"); t.setTextColor(Ui.SUB);
            boolean visible = mode != 0 || i < 6;
            t.setAlpha(visible ? 1f : 0.20f);
            t.setBackground(Ui.ripple(this, Ui.outline(this, Ui.PANEL, Ui.LINE, 12), 12));
        }
    }

    @Override protected void onPause() { super.onPause(); if (active) stopTraining("Latihan dijeda saat aplikasi ditinggalkan."); }
    @Override protected void onDestroy() { cancelTimers(); super.onDestroy(); }
}
