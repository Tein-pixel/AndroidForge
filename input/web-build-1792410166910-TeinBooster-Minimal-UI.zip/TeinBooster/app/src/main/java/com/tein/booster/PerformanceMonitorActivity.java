package com.tein.booster;

import android.app.ActivityManager;
import android.net.TrafficStats;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Pemantauan statistik sistem yang tersedia untuk aplikasi biasa tanpa root. */
public class PerformanceMonitorActivity extends BaseActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout list;
    private TextView updated, pingText, pingButton;
    private PerformanceTrendView trend;
    private long oldTraffic = -1L, oldTime;
    private boolean pinging;
    private final CpuStats cpuStats = new CpuStats();
    private final Runnable ticker = new Runnable() {
        @Override public void run() { if (!alive()) return; renderStats(); handler.postDelayed(this, 2000L); }
    };

    @Override protected String title() { return "Monitor Performa"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = scrollBody();
        LinearLayout card = Ui.card(this);
        card.addView(Ui.tvb(this, "PERFORMANCE STATS", 14, Ui.CYAN));
        updated = Ui.tv(this, "Memperbarui…", 12, Ui.SUB);
        card.addView(updated, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        list = Ui.col(this);
        card.addView(list, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        card.addView(Ui.tvb(this, "RIWAYAT CPU / RAM", 13, Ui.MINT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        card.addView(Ui.tv(this, "Maksimal 60 sampel • kira-kira 2 menit • CPU sistem, bukan CPU game", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 8));
        trend = new PerformanceTrendView(this);
        card.addView(trend, Ui.lp(this, Ui.MATCH, Ui.dp(this, 150), 0, 0, 0, 0));
        col.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 12));

        LinearLayout net = Ui.card(this);
        net.addView(Ui.tvb(this, "TES LATENSI", 14, Ui.MINT));
        pingText = Ui.tvb(this, "Belum diuji", 22, Ui.TEXT);
        net.addView(pingText, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        net.addView(Ui.tv(this, "Menguji koneksi TCP ke 1.1.1.1:443 sebanyak tiga kali; ini bukan jaminan ping ke server game.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        pingButton = Ui.button(this, "Mulai tes ping", v -> runPing());
        net.addView(pingButton, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        col.addView(net, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout limitations = Ui.card(this);
        limitations.addView(Ui.tvb(this, "Yang bisa dan tidak bisa diukur", 14, Ui.CYAN));
        limitations.addView(Ui.tv(this, "RAM, kapasitas penyimpanan, baterai, suhu baterai, refresh rate layar, jenis jaringan dan lalu lintas jaringan dibaca dari sistem. CPU sistem adalah perkiraan dari penghitung kernel dan bukan CPU game per aplikasi. Android membatasi pemantauan GPU/FPS game lain pada perangkat biasa, jadi angka tersebut tidak dikarang.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(limitations);
        renderStats();
    }

    private void renderStats() {
        if (list == null) return;
        list.removeAllViews();
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (am != null) am.getMemoryInfo(mi);
        float cpuPercent = cpuStats.samplePercent();
        addMetric("CPU sistem (perkiraan)", cpuPercent < 0f ? "Tidak tersedia" : String.format(Locale.US, "%.0f%%", cpuPercent), cpuPercent < 0f ? -1f : cpuPercent / 100f, Ui.VIOLET);
        long used = Math.max(0L, mi.totalMem - mi.availMem);
        float ramPercent = mi.totalMem > 0 ? (float) used * 100f / mi.totalMem : -1f;
        addMetric("RAM terpakai", Fmt.bytes(used) + " / " + Fmt.bytes(mi.totalMem), mi.totalMem > 0 ? (float) used / mi.totalMem : 0f, Ui.CYAN);
        if (trend != null) trend.addSample(cpuPercent, ramPercent);
        long total = Sys.storageTotal(); long free = Sys.storageFree(); long stored = Math.max(0L, total - free);
        addMetric("Penyimpanan", Fmt.bytes(stored) + " / " + Fmt.bytes(total), total > 0 ? (float) stored / total : 0f, Ui.BLUE);
        Sys.Batt b = Sys.battery(this);
        addMetric("Baterai", b.level + "% • " + (b.charging ? "Mengisi" : "Tidak mengisi"), b.level / 100f, b.level < 20 ? Ui.EMBER : Ui.MINT);
        addMetric("Suhu baterai", String.format(Locale.US, "%.1f°C • %s", b.tempC, Sys.tempLabel(b.tempC)), Math.min(1f, Math.max(0f, b.tempC / 50f)), Sys.tempColor(b.tempC));
        int hz = Math.round(getWindowManager().getDefaultDisplay().getRefreshRate());
        addMetric("Refresh rate layar", hz + " Hz", Math.min(1f, hz / 120f), Ui.VIOLET);
        android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        android.net.NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
        String conn = ni != null && ni.isConnected() ? (ni.getType() == android.net.ConnectivityManager.TYPE_WIFI ? "Wi-Fi" : ni.getType() == android.net.ConnectivityManager.TYPE_MOBILE ? "Data seluler" : "Terhubung") : "Tidak terhubung";
        addMetric("Jaringan", conn, ni != null && ni.isConnected() ? 1f : 0f, Ui.CYAN);
        long now = SystemClock.elapsedRealtime(), rx = TrafficStats.getTotalRxBytes(), tx = TrafficStats.getTotalTxBytes();
        long totalTraffic = (rx < 0 || tx < 0) ? -1L : rx + tx;
        String traffic = "Tidak tersedia";
        if (totalTraffic >= 0 && oldTraffic >= 0 && now > oldTime) {
            double rate = Math.max(0L, totalTraffic - oldTraffic) / 1024.0 / ((now - oldTime) / 1000.0);
            traffic = String.format(Locale.US, "%.1f KB/detik", rate);
        } else if (totalTraffic >= 0) traffic = "Mengukur…";
        addMetric("Lalu lintas perangkat", traffic, -1f, Ui.MINT);
        addMetric("GPU / FPS game", "Tidak tersedia tanpa API khusus game", -1f, Ui.SUB);
        oldTraffic = totalTraffic; oldTime = now;
        updated.setText("Pembaruan otomatis setiap 2 detik • " + android.text.format.DateFormat.format("HH:mm:ss", System.currentTimeMillis()));
    }

    private void addMetric(String label, String value, float fraction, int color) {
        LinearLayout item = Ui.col(this);
        LinearLayout head = Ui.row(this);
        head.addView(Ui.tv(this, label, 12, Ui.SUB), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        head.addView(Ui.tvb(this, value, 13, Ui.TEXT));
        item.addView(head);
        if (fraction >= 0f) {
            BarView bar = new BarView(this);
            bar.setSmooth(fraction, color);
            item.addView(bar, Ui.lp(this, Ui.MATCH, Ui.dp(this, 4), 0, 6, 0, 0));
        }
        list.addView(item, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
    }

    private void runPing() {
        if (pinging) return;
        pinging = true; pingButton.setText("Menguji…");
        Bg.run(() -> {
            double[] r = Net.tcpPing("1.1.1.1", 443, 3);
            Bg.ui(() -> {
                pinging = false;
                if (!alive()) return;
                pingButton.setText("Tes ulang");
                pingText.setText(r[0] < 0 ? "Gagal terhubung" : String.format(Locale.US, "%.0f ms", r[0]));
                if (r[0] >= 0) pingText.append(String.format(Locale.US, "\nJitter %.0f ms • kehilangan %.0f%%", r[1], r[2]));
            });
        });
    }

    @Override protected void onResume() { super.onResume(); handler.removeCallbacks(ticker); handler.post(ticker); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(ticker); }
}
