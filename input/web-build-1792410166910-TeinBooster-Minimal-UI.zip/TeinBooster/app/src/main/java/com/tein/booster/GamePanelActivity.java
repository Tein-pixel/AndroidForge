package com.tein.booster;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** Quick controls that use public Android APIs and do not require root/Shizuku. */
public class GamePanelActivity extends BaseActivity {
    private AudioManager audio;
    private SeekBar volumeBar, brightnessBar;
    private TextView volumeValue, brightnessValue;
    private CheckBox keepScreenOn;
    private boolean applyingVolume;

    @Override protected String title() { return "Panel Game"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        LinearLayout col = scrollBody();

        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.tvb(this, "KONTROL CEPAT GAME", 15, Ui.CYAN));
        intro.addView(Ui.tv(this, "Kontrol volume media berlaku untuk perangkat. Slider kecerahan di sini hanya mengubah layar aplikasi Tein Booster; untuk game, buka pengaturan layar Android. Fitur yang tidak diizinkan Android akan membuka pengaturan resmi.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(intro, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 12));

        LinearLayout display = Ui.card(this);
        display.addView(Ui.tvb(this, "Kecerahan panel", 14, Ui.TEXT));
        brightnessValue = Ui.tv(this, "Kecerahan aplikasi", 12, Ui.SUB);
        display.addView(brightnessValue, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
        brightnessBar = new SeekBar(this);
        brightnessBar.setMax(100);
        brightnessBar.setProgress(readWindowBrightness());
        brightnessBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = Math.max(0.02f, progress / 100f);
                getWindow().setAttributes(lp);
                if (brightnessValue != null) brightnessValue.setText("Kecerahan panel aplikasi: " + progress + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        display.addView(brightnessBar, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        display.addView(Ui.button(this, "Buka pengaturan layar perangkat", v -> openDisplaySettings()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        keepScreenOn = new CheckBox(this);
        keepScreenOn.setText("Jaga layar tetap menyala saat panel terbuka");
        keepScreenOn.setTextColor(Ui.TEXT);
        keepScreenOn.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.CYAN));
        keepScreenOn.setOnCheckedChangeListener((button, checked) -> {
            if (checked) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
        display.addView(keepScreenOn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        col.addView(display, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout sound = Ui.card(this);
        sound.addView(Ui.tvb(this, "Volume media", 14, Ui.TEXT));
        volumeValue = Ui.tv(this, "", 12, Ui.SUB);
        sound.addView(volumeValue, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
        volumeBar = new SeekBar(this);
        int max = audio == null ? 15 : audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int current = audio == null ? 0 : audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        volumeBar.setMax(Math.max(1, max)); volumeBar.setProgress(current);
        volumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && audio != null) {
                    try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0); } catch (Exception ignored) { }
                }
                updateVolumeText(progress, seekBar.getMax());
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { applyingVolume = true; }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { applyingVolume = false; }
        });
        sound.addView(volumeBar, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        LinearLayout soundButtons = Ui.row(this);
        soundButtons.addView(Ui.ghost(this, "Tes getar", v -> testVibration()), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        soundButtons.addView(Ui.ghost(this, "Pengaturan suara / DND", v -> openSoundSettings()), Ui.lp(this, 0, Ui.WRAP, 8, 0, 0, 0));
        soundButtons.getChildAt(1).setLayoutParams(new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        sound.addView(soundButtons, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        col.addView(sound, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout system = Ui.card(this);
        system.addView(Ui.tvb(this, "Kontrol yang dikelola Android", 14, Ui.CYAN));
        system.addView(Ui.button(this, "Pengaturan rotasi otomatis", v -> openRotationSettings()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        system.addView(Ui.button(this, "Pengaturan jaringan Wi-Fi", v -> openSettings(Settings.ACTION_WIFI_SETTINGS)), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        system.addView(Ui.button(this, "Pengaturan notifikasi / Jangan Ganggu", v -> openSoundSettings()), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        system.addView(Ui.tv(this, "Android tidak mengizinkan aplikasi biasa mengganti semua pengaturan sistem secara diam-diam. Karena itu, Wi-Fi, rotasi global, dan Jangan Ganggu dibuka melalui layar sistem.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        col.addView(system, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        col.addView(Ui.sectionTitle(this, "ALAT GAMING"));
        addTool(col, "Game Saya", "Daftar game terpasang dan favorit", GameLibraryActivity.class);
        addTool(col, "Game HUD", "Statistik mengambang RAM, baterai, dan suhu", GameHudActivity.class);
        addTool(col, "Perekam layar", "Rekam gameplay dengan izin proyeksi Android", ScreenRecorderActivity.class);
        addTool(col, "Visualisasi suara", "Ukur suara lewat mikrofon hanya saat dimulai", SoundVisualizerActivity.class);
        addTool(col, "Monitor performa", "RAM, penyimpanan, suhu, dan tes latensi", PerformanceMonitorActivity.class);
    }

    private void addTool(LinearLayout parent, String label, String sub, Class<?> target) {
        LinearLayout item = Ui.card(this);
        item.addView(Ui.tvb(this, label, 14, Ui.TEXT));
        item.addView(Ui.tv(this, sub, 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
        item.setOnClickListener(v -> startActivity(new Intent(this, target)));
        item.setClickable(true); Ui.pressable(item);
        parent.addView(item, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
    }

    private int readWindowBrightness() {
        float b = getWindow().getAttributes().screenBrightness;
        if (b < 0f) {
            try { b = android.provider.Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS) / 255f; }
            catch (Exception ignored) { b = 0.5f; }
        }
        return Math.max(2, Math.min(100, Math.round(b * 100f)));
    }

    private void updateVolumeText(int value, int max) {
        if (volumeValue != null) volumeValue.setText("Volume media: " + value + " / " + max);
    }

    private void openDisplaySettings() { openSettings(Settings.ACTION_DISPLAY_SETTINGS); }

    private void openRotationSettings() {
        try { startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); }
        catch (Exception e) { openSettings(Settings.ACTION_SETTINGS); }
    }

    private void openSoundSettings() {
        try {
            Intent i = Build.VERSION.SDK_INT >= 23 ? new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) : new Intent(Settings.ACTION_SOUND_SETTINGS);
            startActivity(i);
        } catch (Exception e) { openSettings(Settings.ACTION_SOUND_SETTINGS); }
    }

    private void openSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { Toast.makeText(this, "Pengaturan tidak tersedia pada perangkat ini.", Toast.LENGTH_SHORT).show(); }
    }

    private void testVibration() {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) { Toast.makeText(this, "Perangkat tidak memiliki motor getar.", Toast.LENGTH_SHORT).show(); return; }
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(70);
        } catch (Exception e) { Toast.makeText(this, "Tes getar tidak tersedia.", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onResume() {
        super.onResume();
        if (volumeBar != null && audio != null && !applyingVolume) {
            int value = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
            volumeBar.setProgress(value);
            updateVolumeText(value, volumeBar.getMax());
        }
    }
}
