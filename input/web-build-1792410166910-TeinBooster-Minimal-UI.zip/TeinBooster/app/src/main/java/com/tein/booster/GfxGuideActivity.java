package com.tein.booster;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Panduan grafis berdasarkan spesifikasi; tidak mencoba mengubah pengaturan game secara diam-diam. */
public class GfxGuideActivity extends BaseActivity {
    private LinearLayout content;
    private final String[] keys = {"Kualitas grafis", "Batas frame rate", "Resolusi / skala render", "Efek dan bayangan"};
    private String[] options = new String[4];
    private String[] recs = new String[4];
    private String ramDisplay = "-";
    private int refreshHz;

    @Override protected String title() { return "GFX Guide"; }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        content = scrollBody();
        analyzeDevice();
        android.content.SharedPreferences saved = getSharedPreferences("gfx_manual", MODE_PRIVATE);
        options = recs.clone();
        for (int i = 0; i < options.length; i++) options[i] = saved.getString("option_" + i, recs[i]);
        showGuide();
    }

    private void analyzeDevice() {
        long bytes = Sys.ramTotal(this);
        ramDisplay = String.format(Locale.US, "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
        DisplayMetrics dm = getResources().getDisplayMetrics();
        refreshHz = Math.round(getWindowManager().getDefaultDisplay().getRefreshRate());
        if (refreshHz < 30) refreshHz = 60;
        boolean low = bytes < 3L * 1024L * 1024L * 1024L;
        boolean medium = bytes < 6L * 1024L * 1024L * 1024L;
        recs[0] = low ? "Rendah" : medium ? "Sedang" : "Tinggi";
        int recommendedFps = low ? 30 : medium ? 40 : Math.min(60, refreshHz);
        recs[1] = recommendedFps + " FPS";
        recs[2] = low ? "70–80%" : medium ? "80–90%" : "90% (uji stabilitas)";
        recs[3] = low ? "Mati" : "Rendah / mati";
        options = recs.clone();
    }

    private void showGuide() {
        content.removeAllViews();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        LinearLayout top = Ui.card(this);
        LinearLayout row = Ui.row(this);
        LinearLayout left = Ui.col(this);
        left.addView(Ui.tvb(this, "TINGKAT YANG DISARANKAN", 11, Ui.SUB));
        boolean low = Sys.ramTotal(this) < 3L * 1024L * 1024L * 1024L;
        left.addView(Ui.tvb(this, low ? "Halus / hemat" : "Seimbang", 23, Ui.TEXT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        left.addView(Ui.tv(this, "Panduan manual untuk mengurangi frame drop dan panas.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        row.addView(left, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView bars = Ui.tvb(this, low ? "▂▃▅" : "▃▅▇", 25, Ui.MINT);
        bars.setGravity(Gravity.CENTER);
        row.addView(bars, Ui.lp(this, Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        top.addView(row);
        top.addView(Ui.divider(this), Ui.lp(this, Ui.MATCH, Ui.dp(this, 1), 0, 12, 0, 10));
        LinearLayout specs = Ui.row(this);
        specs.addView(spec("RAM", ramDisplay), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        specs.addView(spec("CORE CPU", String.valueOf(Runtime.getRuntime().availableProcessors())), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        specs.addView(spec("LAYAR", refreshHz + " Hz"), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        top.addView(specs);
        top.addView(Ui.tv(this, "Resolusi layar: " + dm.widthPixels + " × " + dm.heightPixels + " px. RAM/CPU bukan satu-satunya penentu: GPU, optimasi game, dan suhu juga berpengaruh.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        content.addView(top, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 14));

        LinearLayout card = Ui.card(this);
        card.addView(Ui.tvb(this, "ATUR INI DI DALAM GAME", 14, Ui.MINT));
        card.addView(Ui.tv(this, "Pilih baris untuk meninjau opsi. Ini rekomendasi manual; aplikasi tidak dapat mengubah setelan internal game.", 12, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 10));
        for (int i = 0; i < keys.length; i++) {
            final int index = i;
            LinearLayout item = Ui.row(this);
            item.setGravity(Gravity.CENTER_VERTICAL);
            TextView n = Ui.chip(this, String.valueOf(i + 1), Ui.MINT);
            item.addView(n, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 10, 0));
            LinearLayout mid = Ui.col(this);
            mid.addView(Ui.tvb(this, keys[i], 14, Ui.TEXT));
            TextView selected = Ui.tvb(this, options[i], 12, Ui.MINT);
            mid.addView(selected, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
            item.addView(mid, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            TextView arrow = Ui.tvb(this, "⌄", 21, Ui.SUB);
            item.addView(arrow);
            item.setPadding(Ui.dp(this, 2), Ui.dp(this, 12), Ui.dp(this, 2), Ui.dp(this, 12));
            item.setClickable(true);
            item.setOnClickListener(v -> choose(index));
            card.addView(item);
            if (i < keys.length - 1) card.addView(Ui.divider(this));
        }
        card.addView(Ui.button(this, "Kembalikan rekomendasi perangkat", v -> {
            options = recs.clone();
            android.content.SharedPreferences.Editor editor = getSharedPreferences("gfx_manual", MODE_PRIVATE).edit();
            for (int i = 0; i < options.length; i++) editor.remove("option_" + i);
            editor.apply();
            showGuide();
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        content.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        LinearLayout note = Ui.card(this);
        note.addView(Ui.tvb(this, "Cara memilih", 14, Ui.CYAN));
        note.addView(Ui.tv(this, "Jika frame drop, turunkan kualitas grafis dan bayangan dahulu. Jika suhu meningkat, pilih 30/40 FPS dibanding memaksa FPS tinggi. Aktifkan opsi 60 FPS hanya jika game stabil dan perangkat mendukungnya.", 13, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        content.addView(note);
    }

    private View spec(String title, String value) {
        LinearLayout c = Ui.col(this);
        c.addView(Ui.tv(this, title, 10, Ui.SUB));
        c.addView(Ui.tvb(this, value, 17, Ui.TEXT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
        return c;
    }

    private void choose(int index) {
        String[] list;
        if (index == 0) list = new String[]{"Rendah", "Sedang", "Tinggi", "Sangat tinggi"};
        else if (index == 1) list = new String[]{"30 FPS", "40 FPS", "45 FPS", "60 FPS", "90 FPS"};
        else if (index == 2) list = new String[]{"60%", "70%", "80%", "90%", "100%"};
        else list = new String[]{"Mati", "Rendah", "Sedang", "Tinggi"};
        new AlertDialog.Builder(this).setTitle(keys[index] + " (panduan)")
                .setSingleChoiceItems(list, indexOf(list, options[index]), (dialog, which) -> {
                    options[index] = list[which];
                    getSharedPreferences("gfx_manual", MODE_PRIVATE).edit().putString("option_" + index, options[index]).apply();
                    dialog.dismiss(); showGuide();
                }).setNegativeButton("Batal", null).show();
    }

    private int indexOf(String[] arr, String s) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(s)) return i;
        return 0;
    }
}
