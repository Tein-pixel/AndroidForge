package com.tein.booster;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/** Minimal AMOLED-first dashboard; actions still call the original feature activities. */
public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private GaugeView gauge;
    private TextView scoreChip, boostBtn, resultTv, lastTv, bannerTv;
    private Stat ram, storage, battery;
    private LinearLayout banner;
    private boolean boosting;
    private int themeAtCreate;

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (isFinishing() || isDestroyed()) return;
            refreshStats(false);
            h.postDelayed(this, 2500L);
        }
    };

    private static final class Stat {
        LinearLayout view;
        TextView value, sub;
        BarView bar;
    }

    private static final class ToolItem {
        final String icon, title, sub; final int color; final Class<?> target;
        ToolItem(String i, String t, String s, int c, Class<?> cl) { icon=i; title=t; sub=s; color=c; target=cl; }
    }

    @Override protected void onCreate(Bundle state) {
        int savedTheme = Prefs.getInt(this, Prefs.UI_THEME, 0);
        setTheme(savedTheme == 2 ? R.style.AppThemeLight : (savedTheme == 1 ? R.style.AppTheme : R.style.AppThemeBlack));
        super.onCreate(state);
        Ui.applyTheme(this);
        Ui.applyWindowTheme(this);
        themeAtCreate = Ui.theme(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout page = Ui.col(this);
        int p = Ui.dp(this, 16);
        page.setPadding(p, Ui.dp(this, 12), p, Ui.dp(this, 26));
        scroll.addView(page, new ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP));
        setContentView(scroll);

        // Compact brand header
        LinearLayout header = Ui.row(this);
        TextView mark = Ui.tvb(this, "TB", 14, Ui.BG);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(Ui.grad(this, Ui.CYAN, Ui.BLUE, 13));
        header.addView(mark, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        LinearLayout brand = Ui.col(this);
        brand.addView(Ui.tvb(this, "TeinBooster", 20, Ui.TEXT));
        brand.addView(Ui.tv(this, "DEVICE TOOLS  ·  GAMING", 10, Ui.SUB));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        bp.setMargins(Ui.dp(this, 11), 0, 0, 0);
        header.addView(brand, bp);
        TextView settings = Ui.tvb(this, "⚙", 21, Ui.TEXT);
        settings.setGravity(Gravity.CENTER);
        settings.setBackground(Ui.ripple(this, Ui.outline(this, Ui.PANEL, Ui.LINE, 14), 14));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        header.addView(settings, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)));
        page.addView(header);

        LinearLayout labelRow = Ui.row(this);
        TextView label = Ui.tvb(this, "KONDISI PERANGKAT", 11, Ui.SUB);
        labelRow.addView(label, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        scoreChip = Ui.chip(this, "MEMERIKSA", Ui.CYAN);
        labelRow.addView(scoreChip);
        page.addView(labelRow, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 18, 0, 8));

        // Low-height hero: score gauge and the primary action share one row.
        LinearLayout hero = Ui.card(this);
        hero.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        LinearLayout heroRow = Ui.row(this);
        gauge = new GaugeView(this);
        LinearLayout.LayoutParams gLp = new LinearLayout.LayoutParams(Ui.dp(this, 126), Ui.dp(this, 126));
        gLp.setMargins(0, 0, Ui.dp(this, 12), 0);
        heroRow.addView(gauge, gLp);
        LinearLayout heroInfo = Ui.col(this);
        heroInfo.setGravity(Gravity.CENTER_VERTICAL);
        heroInfo.addView(Ui.tvb(this, "BOOST CEPAT", 11, Ui.CYAN));
        heroInfo.addView(Ui.tvb(this, "Optimalkan perangkat", 16, Ui.TEXT), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 5, 0, 0));
        heroInfo.addView(Ui.tv(this, "Pembersihan proses yang dapat diakses sistem.", 11, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 3, 0, 0));
        boostBtn = Ui.button(this, "Boost sekarang", v -> doBoost());
        heroInfo.addView(boostBtn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        resultTv = Ui.tv(this, "", 11, Ui.MINT);
        resultTv.setMaxLines(2);
        heroInfo.addView(resultTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        heroRow.addView(heroInfo, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        hero.addView(heroRow);
        lastTv = Ui.tv(this, "", 11, Ui.SUB);
        lastTv.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(lastTv, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 6, 0, 0));
        page.addView(hero);

        // Three metrics share one surface to avoid a stack of redundant cards.
        LinearLayout metrics = Ui.card(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10));
        ram = makeStat("RAM"); storage = makeStat("Penyimpanan"); battery = makeStat("Baterai");
        metrics.addView(ram.view, statLp(0, 0, 6, 0));
        View divider1 = Ui.divider(this); metrics.addView(divider1, new LinearLayout.LayoutParams(Ui.dp(this, 1), Ui.dp(this, 44)));
        metrics.addView(storage.view, statLp(6, 0, 6, 0));
        View divider2 = Ui.divider(this); metrics.addView(divider2, new LinearLayout.LayoutParams(Ui.dp(this, 1), Ui.dp(this, 44)));
        metrics.addView(battery.view, statLp(6, 0, 0, 0));
        page.addView(metrics, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));

        // One-line cleaner shortcut preserves the original one-tap accessibility flow.
        LinearLayout cleaner = Ui.row(this);
        cleaner.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        cleaner.setBackground(Ui.ripple(this, Ui.outline(this, Ui.PANEL, Ui.LINE, 16), 16));
        cleaner.addView(Ui.badge(this, "✦", Ui.VIOLET, 36));
        LinearLayout cleanText = Ui.col(this);
        cleanText.addView(Ui.tvb(this, "1-Tap Cache Cleaner", 14, Ui.TEXT));
        cleanText.addView(Ui.tv(this, "Pembersihan cache dengan aksesibilitas", 11, Ui.SUB));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        cp.setMargins(Ui.dp(this, 10), 0, Ui.dp(this, 8), 0);
        cleaner.addView(cleanText, cp);
        cleaner.addView(Ui.tvb(this, "›", 26, Ui.SUB));
        cleaner.setClickable(true);
        cleaner.setOnClickListener(v -> {
            Intent i = new Intent(this, CacheCleanerActivity.class);
            i.putExtra("autostart", true);
            startActivity(i);
        });
        page.addView(cleaner, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));

        banner = Ui.col(this);
        banner.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        banner.setBackground(Ui.outline(this, Ui.alpha(Ui.EMBER, 0x14), Ui.alpha(Ui.EMBER, 0x68), 14));
        bannerTv = Ui.tvb(this, "", 12, Ui.EMBER);
        banner.addView(bannerTv);
        banner.addView(Ui.ghost(this, "Atur izin", v -> startActivity(new Intent(this, PermissionsActivity.class))),
                Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        page.addView(banner, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));

        page.addView(Ui.sectionTitle(this, "SEMUA FITUR"));
        LinearLayout categories = Ui.col(this);
        addCategory(categories, "Gaming", "Game & alat bermain", true, new ToolItem[]{
                item("🎮", "Game Booster", "Mode fokus", Ui.PINK, GameBoosterActivity.class),
                item("⚡", "Pusat Gaming", "HUD, GFX, tes & coach", Ui.MINT, GameCenterActivity.class),
                item("▣", "Game Saya", "Cari & favorit game", Ui.CYAN, GameLibraryActivity.class),
                item("☷", "Panel Game", "Kontrol cepat", Ui.BLUE, GamePanelActivity.class)
        });
        addCategory(categories, "Performa & baterai", "Pantau dan kelola perangkat", false, new ToolItem[]{
                item("↯", "RAM Booster", "Proses latar", Ui.CYAN, RamBoosterActivity.class),
                item("◉", "Monitor Performa", "Statistik langsung", Ui.MINT, PerformanceMonitorActivity.class),
                item("▤", "Penyimpanan", "File besar & sisa", Ui.BLUE, StorageActivity.class),
                item("◒", "Hemat Baterai", "Profil daya", Ui.MINT, BatteryActivity.class),
                item("❄", "Pendingin", "Pantau suhu", 0xFF4FC3F7, CoolerActivity.class),
                item("⇢", "Turbo UI", "Animasi sistem", Ui.EMBER, TurboActivity.class)
        });
        addCategory(categories, "Pembersihan & jaringan", "Ruang, aplikasi dan koneksi", false, new ToolItem[]{
                item("✦", "Junk Cleaner", "File sampah", Ui.VIOLET, JunkCleanerActivity.class),
                item("◎", "Network Booster", "DNS, ping, kecepatan", Ui.BLUE, NetworkActivity.class),
                item("▦", "Manajer Aplikasi", "Kelola aplikasi", Ui.EMBER, AppManagerActivity.class),
                item("▤", "Info Perangkat", "Spesifikasi", 0xFF9AA7D0, DeviceInfoActivity.class)
        });
        addCategory(categories, "Rekam & utilitas", "Alat pendukung tambahan", false, new ToolItem[]{
                item("●", "Perekam Layar", "Gameplay ke MP4", Ui.PINK, ScreenRecorderActivity.class),
                item("♫", "Visualisasi Suara", "Meter mikrofon", Ui.VIOLET, SoundVisualizerActivity.class),
                item("✓", "Pusat Izin", "Izin fitur", Ui.MINT, PermissionsActivity.class),
                item("⚙", "Pengaturan", "Tema & Auto Boost", Ui.VIOLET, SettingsActivity.class)
        });
        page.addView(categories);

        String version = "1.0.0";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        TextView foot = Ui.tv(this, "TEINBOOSTER  " + version + "  ·  berjalan tanpa root", 10, Ui.SUB);
        foot.setGravity(Gravity.CENTER);
        page.addView(foot, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 20, 0, 0));
        Ui.reveal(header, hero, metrics, cleaner, categories);

        if (!Prefs.getBool(this, Prefs.ONBOARDED, false)) {
            Prefs.putBool(this, Prefs.ONBOARDED, true);
            startActivity(new Intent(this, PermissionsActivity.class));
        }
    }

    private ToolItem item(String i, String t, String s, int c, Class<?> cl) { return new ToolItem(i,t,s,c,cl); }

    private LinearLayout.LayoutParams statLp(float l, float t, float r, float b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        lp.setMargins(Ui.dp(this, l), Ui.dp(this, t), Ui.dp(this, r), Ui.dp(this, b));
        return lp;
    }

    private Stat makeStat(String label) {
        Stat s = new Stat(); s.view = Ui.col(this); s.view.setGravity(Gravity.CENTER_VERTICAL);
        int q = Ui.dp(this, 3); s.view.setPadding(q, 0, q, 0);
        TextView title = Ui.tv(this, label, 10, Ui.SUB); title.setSingleLine(true); title.setGravity(Gravity.CENTER);
        s.view.addView(title);
        s.value = Ui.num(this, "--", 20, Ui.TEXT); s.value.setGravity(Gravity.CENTER);
        s.view.addView(s.value, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        s.bar = new BarView(this); s.view.addView(s.bar, Ui.lp(this, Ui.MATCH, Ui.dp(this, 4), 0, 5, 0, 0));
        s.sub = Ui.tv(this, "", 9, Ui.SUB); s.sub.setGravity(Gravity.CENTER); s.sub.setSingleLine(true); s.sub.setTextSize(9);
        s.view.addView(s.sub, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 4, 0, 0));
        return s;
    }

    private void addCategory(LinearLayout parent, String title, String subtitle, boolean expanded, ToolItem[] items) {
        LinearLayout group = Ui.col(this);
        group.setBackground(Ui.outline(this, Ui.PANEL, Ui.LINE, 16));
        group.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 2));
        LinearLayout head = Ui.row(this);
        LinearLayout text = Ui.col(this);
        text.addView(Ui.tvb(this, title, 15, Ui.TEXT));
        text.addView(Ui.tv(this, subtitle, 10, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 2, 0, 0));
        head.addView(text, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        TextView count = Ui.chip(this, String.valueOf(items.length) + "  ⌄", Ui.CYAN);
        head.addView(count);
        group.addView(head, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        LinearLayout body = Ui.col(this);
        for (int n = 0; n < items.length; n += 2) {
            View a = tile(items[n]);
            View b = n + 1 < items.length ? tile(items[n + 1]) : emptyTile();
            addRow(body, a, b);
        }
        body.setVisibility(expanded ? View.VISIBLE : View.GONE);
        group.addView(body);
        head.setClickable(true);
        head.setBackground(Ui.ripple(this, Ui.rect(this, 0x00000000, 10), 10));
        head.setOnClickListener(v -> {
            boolean open = body.getVisibility() != View.VISIBLE;
            body.setVisibility(open ? View.VISIBLE : View.GONE);
            count.setText(items.length + (open ? "  ⌃" : "  ⌄"));
        });
        parent.addView(group, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 10));
    }

    private View emptyTile() { View v = new View(this); v.setVisibility(View.INVISIBLE); v.setMinimumHeight(Ui.dp(this, 92)); return v; }

    private View tile(ToolItem x) {
        LinearLayout t = Ui.col(this);
        t.setBackground(Ui.ripple(this, Ui.outline(this, Ui.PANEL2, Ui.LINE, 13), 13));
        int q = Ui.dp(this, 10); t.setPadding(q, q, q, q); t.setMinimumHeight(Ui.dp(this, 91));
        LinearLayout titleRow = Ui.row(this);
        titleRow.addView(Ui.badge(this, x.icon, x.color, 30));
        TextView title = Ui.tvb(this, x.title, 12, Ui.TEXT); title.setMaxLines(2);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        tlp.setMargins(Ui.dp(this, 8), 0, 0, 0); titleRow.addView(title, tlp);
        t.addView(titleRow);
        t.addView(Ui.tv(this, x.sub, 10, Ui.SUB), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 7, 0, 0));
        t.setClickable(true); t.setOnClickListener(v -> startActivity(new Intent(this, x.target))); Ui.pressable(t);
        return t;
    }

    private void addRow(LinearLayout parent, View a, View b) {
        LinearLayout row = Ui.row(this); row.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f); la.setMargins(0, 0, Ui.dp(this, 4), 0);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f); lb.setMargins(Ui.dp(this, 4), 0, 0, 0);
        row.addView(a, la); row.addView(b, lb);
        parent.addView(row, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
    }

    @Override protected void onResume() {
        super.onResume();
        if (themeAtCreate != Ui.theme(this)) { recreate(); return; }
        refreshStats(true); h.removeCallbacks(loop); h.postDelayed(loop, 2500L);
        int miss = Perm.requiredMissing(this);
        banner.setVisibility(miss > 0 ? View.VISIBLE : View.GONE);
        bannerTv.setText("Izin belum lengkap (" + miss + " dari " + Perm.REQUIRED_TOTAL + "). Beberapa fitur memerlukan izin.");
        long last = Prefs.getLong(this, Prefs.LAST_BOOST, 0L);
        lastTv.setText(last > 0 ? "Boost terakhir: " + Fmt.ago(last) : "Data diperbarui otomatis");
    }

    @Override protected void onPause() { super.onPause(); h.removeCallbacks(loop); }

    private int usageColor(float f) { if (f < .60f) return Ui.MINT; if (f < .80f) return Ui.EMBER; return Ui.CORAL; }

    private void refreshStats(boolean animate) {
        if (ram == null || storage == null || battery == null) return;
        long rt = Sys.ramTotal(this), ra = Sys.ramAvail(this);
        float rf = rt > 0 ? 1f - (float) ra / (float) rt : 0f;
        ram.value.setText(Fmt.pct(rf)); ram.sub.setText(Fmt.bytes(rt - ra) + "/" + Fmt.bytes(rt)); ram.bar.setSmooth(rf, usageColor(rf));
        float sf = Sys.storageUsed(); long st = Sys.storageTotal();
        storage.value.setText(Fmt.pct(sf)); storage.sub.setText(Fmt.bytes(st - Sys.storageFree()) + "/" + Fmt.bytes(st)); storage.bar.setSmooth(sf, usageColor(sf));
        Sys.Batt b = Sys.battery(this);
        battery.value.setText(b.level + "%"); battery.sub.setText(String.format(Locale.US, "%.1f°C", b.tempC));
        battery.bar.setSmooth(b.level / 100f, b.level >= 50 ? Ui.MINT : (b.level >= 20 ? Ui.EMBER : Ui.CORAL));
        if (!boosting) {
            int score = Sys.score(this); gauge.setProgress(score / 100f, animate); gauge.setCenter(String.valueOf(score), "skor"); scoreChip.setText(Sys.scoreLabel(score).toUpperCase(Locale.ROOT));
        }
    }

    private void doBoost() {
        if (boosting) return;
        boosting = true; boostBtn.setText("Memproses…"); resultTv.setText(""); gauge.setSpinning(true); gauge.setCenter("…", "optimasi");
        final android.content.Context app = getApplicationContext();
        Bg.run(() -> {
            final Optimizer.Result r = Optimizer.fullBoost(app);
            Bg.ui(() -> {
                boosting = false; if (isFinishing() || isDestroyed()) return;
                gauge.setSpinning(false); boostBtn.setText("Boost sekarang");
                String msg = r.killed + " aplikasi diproses · "; msg += r.ramFreed > 0 ? "RAM bebas +" + Fmt.bytes(r.ramFreed) : "RAM telah diperiksa";
                resultTv.setText("✓ " + msg); lastTv.setText("Boost terakhir: baru saja"); refreshStats(true);
            });
        });
    }
}
