package com.tein.booster;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

/** Kerangka semua layar: header dengan tombol kembali + badan yang bisa di-scroll. */
public abstract class BaseActivity extends Activity {
    protected FrameLayout body;

    protected abstract String title();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int savedTheme = Prefs.getInt(this, Prefs.UI_THEME, 0);
        setTheme(savedTheme == 2 ? R.style.AppThemeLight : (savedTheme == 1 ? R.style.AppTheme : R.style.AppThemeBlack));
        super.onCreate(savedInstanceState);
        Ui.applyTheme(this);
        Ui.applyWindowTheme(this);
        LinearLayout root = Ui.col(this);
        root.setBackgroundColor(Ui.BG);
        root.addView(buildHeader(), new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        body = new FrameLayout(this);
        root.addView(body, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));
        setContentView(root);
    }

    private View buildHeader() {
        LinearLayout h = Ui.row(this);
        h.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 6));
        TextView back = Ui.tvb(this, "\u2190", 22, Ui.TEXT);
        back.setGravity(Gravity.CENTER);
        back.setBackground(Ui.ripple(this, Ui.rect(this, 0x00000000, 24), 24));
        back.setOnClickListener(v -> onBackPressed());
        h.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        TextView t = Ui.tvb(this, title(), 20, Ui.TEXT);
        h.addView(t, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        return h;
    }

    protected LinearLayout scrollBody() {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = Ui.col(this);
        int p = Ui.dp(this, 16);
        col.setPadding(p, Ui.dp(this, 6), p, Ui.dp(this, 28));
        sv.addView(col, new ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP));
        body.addView(sv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        return col;
    }

    protected ListView listBody() {
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setSelector(new ColorDrawable(0x00000000));
        lv.setVerticalScrollBarEnabled(false);
        lv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        body.addView(lv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        return lv;
    }

    protected boolean alive() {
        return !isFinishing() && !isDestroyed();
    }
}
