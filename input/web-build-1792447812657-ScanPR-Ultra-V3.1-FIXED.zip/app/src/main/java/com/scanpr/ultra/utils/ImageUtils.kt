// File: app/src/main/java/com/scanpr/ultra/utils/ImageUtils.kt
package com.scanpr.ultra.utils

import android.content.Context
import android.net.Uri
import android.widget.ImageView
import com.bumptech.glide.Glide

object ImageUtils {
    fun show(context: Context, uri: Uri?, target: ImageView) {
        if (uri == null) { target.setImageDrawable(null); return }
        runCatching { Glide.with(context).load(uri).centerCrop().into(target) }
    }
}
