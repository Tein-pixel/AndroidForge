// File: app/src/main/java/com/scanpr/ultra/viewmodel/ResultViewModel.kt
package com.scanpr.ultra.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scanpr.ultra.utils.AiProvider
import com.scanpr.ultra.utils.AiResult
import com.scanpr.ultra.utils.SolverEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ResultViewModel : ViewModel() {
    private val _result = MutableStateFlow<AiResult?>(null)
    val result: StateFlow<AiResult?> = _result
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    fun solve(text: String) {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            _result.value = try { AiProvider().solveAuto(text) } catch (_: Exception) { SolverEngine.solveOffline(text) }
            _loading.value = false
        }
    }
    fun setResult(value: AiResult) { _result.value = value }
}
