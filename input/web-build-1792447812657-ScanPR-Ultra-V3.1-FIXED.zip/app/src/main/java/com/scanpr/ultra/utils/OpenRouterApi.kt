// File: app/src/main/java/com/scanpr/ultra/utils/OpenRouterApi.kt
package com.scanpr.ultra.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class OpenRouterApi {
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).callTimeout(35, TimeUnit.SECONDS).build()
    suspend fun askOpenRouter(prompt: String, apiKey: String, model: String): String? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext null
        runCatching {
            val body = JSONObject().put("model", model).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                .put("temperature", 0.2).toString()
            val req = Request.Builder().url("https://openrouter.ai/api/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey").header("HTTP-Referer", "https://scanpr.app").header("X-Title", "Scan PR")
                .post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return@use null
                JSONObject(response.body?.string().orEmpty()).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
            }
        }.getOrNull()
    }
}
