// File: app/src/main/java/com/scanpr/ultra/utils/AiProvider.kt
package com.scanpr.ultra.utils

import com.scanpr.ultra.BuildConfig

 data class AiResult(
    val jawabanAkhir: String,
    val langkah: List<String>,
    val mapel: String,
    val modelUsed: String,
    val metodeAlternatif: List<String>
)

class AiProvider {
    suspend fun solveAuto(ocrText: String): AiResult {
        if (ocrText.isBlank()) return SolverEngine.solveOffline(ocrText)
        val safeText = ocrText.take(6000)
        val prompt = "Kamu guru Indonesia tingkat SMP/SMA. Selesaikan soal berikut secara hati-hati dalam Bahasa Indonesia. Soal: \"$safeText\". Kembalikan JSON valid saja tanpa markdown: {\"jawaban_akhir\":\"...\",\"langkah\":[\"Langkah 1: ...\"],\"mapel\":\"Matematika/Fisika/Kimia/Biologi/Umum\",\"metode_alternatif\":[]}. Jangan mengarang informasi; tulis asumsi bila soal kurang jelas."
        runCatching { JsonParser.parse(PollinationsApi().askPollinations(prompt).orEmpty(), "Pollinations Free") }.getOrNull()?.let { return it }
        if (BuildConfig.GEMINI_KEY.isNotBlank()) {
            runCatching { GeminiApi().askGemini(prompt, BuildConfig.GEMINI_KEY)?.let { JsonParser.parse(it, "Gemini Flash") } }.getOrNull()?.let { return it }
        }
        if (BuildConfig.OPENROUTER_KEY.isNotBlank()) {
            for (model in listOf("deepseek/deepseek-r1:free", "qwen/qwen-2.5-72b-instruct:free")) {
                runCatching { OpenRouterApi().askOpenRouter(prompt, BuildConfig.OPENROUTER_KEY, model)?.let { JsonParser.parse(it, model) } }.getOrNull()?.let { return it }
            }
        }
        return SolverEngine.solveOffline(ocrText)
    }
}
