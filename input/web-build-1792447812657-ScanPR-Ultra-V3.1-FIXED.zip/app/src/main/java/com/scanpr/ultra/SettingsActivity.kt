// File: app/src/main/java/com/scanpr/ultra/SettingsActivity.kt
package com.scanpr.ultra

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.scanpr.ultra.databinding.ActivitySettingsBinding
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.utils.ThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private var updating = false
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this); super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater); setContentView(binding.root)
        binding.settingsToolbar.setNavigationOnClickListener { finish() }
        lifecycleScope.launch {
            val mode = ThemeManager.getMode(this@SettingsActivity).first()
            updating = true
            binding.themeRadioGroup.check(when (mode) { ThemeMode.LIGHT -> R.id.radio_light; ThemeMode.DARK -> R.id.radio_dark; ThemeMode.SYSTEM -> R.id.radio_system })
            updating = false
        }
        binding.themeRadioGroup.setOnCheckedChangeListener { _, checked ->
            if (updating || checked == -1) return@setOnCheckedChangeListener
            val mode = when (checked) { R.id.radio_light -> ThemeMode.LIGHT; R.id.radio_dark -> ThemeMode.DARK; else -> ThemeMode.SYSTEM }
            lifecycleScope.launch {
                ThemeManager.saveMode(this@SettingsActivity, mode)
                ThemeManager.applyTheme(mode)
                recreate()
            }
        }
    }
}
