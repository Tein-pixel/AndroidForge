// File: app/src/main/java/com/scanpr/ultra/utils/PollinationsApi.kt
package com.scanpr.ultra.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

class PollinationsApi {
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).callTimeout(20, TimeUnit.SECONDS).build()
    suspend fun askPollinations(prompt: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(prompt, StandardCharsets.UTF_8.toString())
            val request = Request.Builder().url("https://text.pollinations.ai/$encoded?model=openai&json=true")
                .header("Accept", "application/json, text/plain").get().build()
            client.newCall(request).execute().use { response -> if (response.isSuccessful) response.body?.string() else null }
        }.getOrNull()
    }
}
