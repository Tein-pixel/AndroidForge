// File: app/src/main/java/com/scanpr/ultra/HistoryActivity.kt
package com.scanpr.ultra

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.scanpr.ultra.data.ScanHistory
import com.scanpr.ultra.databinding.ActivityHistoryBinding
import com.scanpr.ultra.repository.ScanRepository
import com.scanpr.ultra.utils.ThemeManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryBinding
    private lateinit var repo: ScanRepository
    private val adapter = HistoryAdapter { item ->
        startActivity(Intent(this, ResultActivity::class.java)
            .putExtra(ResultActivity.EXTRA_OCR, item.ocrText).putExtra(ResultActivity.EXTRA_IMAGE_URI, item.imageUri)
            .putExtra(ResultActivity.EXTRA_ANSWER, item.answer).putExtra(ResultActivity.EXTRA_STEPS, item.stepsJson)
            .putExtra(ResultActivity.EXTRA_MAPEL, item.mapel).putExtra(ResultActivity.EXTRA_MODEL, item.modelUsed).putExtra(ResultActivity.EXTRA_ID, item.id))
    }
    private var observeJob: Job? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this); super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater); setContentView(binding.root)
        repo = ScanRepository(this)
        binding.historyToolbar.setNavigationOnClickListener { finish() }
        binding.historyRecyclerView.layoutManager = LinearLayoutManager(this); binding.historyRecyclerView.adapter = adapter
        binding.historySearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean { observe(query.orEmpty()); binding.historySearch.clearFocus(); return true }
            override fun onQueryTextChange(newText: String?): Boolean { observe(newText.orEmpty()); return true }
        })
        observe("")
    }
    private fun observe(query: String) {
        observeJob?.cancel()
        observeJob = lifecycleScope.launch { repeatOnLifecycle(Lifecycle.State.STARTED) {
            repo.search(query.trim()).collect { values -> adapter.submit(values); binding.emptyView.visibility = if (values.isEmpty()) View.VISIBLE else View.GONE }
        } }
    }
    private class HistoryAdapter(private val onClick: (ScanHistory) -> Unit) : RecyclerView.Adapter<HistoryAdapter.Holder>() {
        private var items: List<ScanHistory> = emptyList()
        fun submit(list: List<ScanHistory>) { items = list; notifyDataSetChanged() }
        class Holder(view: View) : RecyclerView.ViewHolder(view) { val question: TextView = view.findViewById(R.id.history_question); val answer: TextView = view.findViewById(R.id.history_answer); val date: TextView = view.findViewById(R.id.history_date) }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false))
        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = items[position]; holder.question.text = item.ocrText.ifBlank { "Soal kosong" }; holder.answer.text = item.answer
            holder.date.text = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID")).format(Date(item.createdAt)); holder.itemView.setOnClickListener { onClick(item) }
        }
        override fun getItemCount() = items.size
    }
}
