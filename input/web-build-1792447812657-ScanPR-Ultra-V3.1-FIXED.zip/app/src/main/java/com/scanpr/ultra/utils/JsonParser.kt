// File: app/src/main/java/com/scanpr/ultra/utils/JsonParser.kt
package com.scanpr.ultra.utils

import com.scanpr.ultra.utils.AiResult
import org.json.JSONArray
import org.json.JSONObject

object JsonParser {
    fun parse(raw: String, model: String): AiResult? = runCatching {
        val cleaned = raw.trim().removePrefix("```json").removePrefix("```JSON").removePrefix("```").removeSuffix("```").trim()
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        require(start >= 0 && end > start) { "JSON object tidak ditemukan" }
        val obj = JSONObject(cleaned.substring(start, end + 1))
        val stepsArray = obj.optJSONArray("langkah") ?: JSONArray()
        val steps = (0 until stepsArray.length()).mapNotNull { stepsArray.optString(it).takeIf(String::isNotBlank) }
        val methodsArray = obj.optJSONArray("metode_alternatif") ?: JSONArray()
        val methods = (0 until methodsArray.length()).mapNotNull { methodsArray.optString(it).takeIf(String::isNotBlank) }
        val answer = obj.optString("jawaban_akhir", "").trim()
        if (answer.isBlank()) return@runCatching null
        AiResult(answer, steps.ifEmpty { listOf("Periksa kembali soal dan langkah perhitungan.") }, obj.optString("mapel", "Umum"), model, methods)
    }.getOrNull()
}
