// File: app/src/main/java/com/scanpr/ultra/utils/SolverEngine.kt
package com.scanpr.ultra.utils

import java.util.Locale
import kotlin.math.abs

object SolverEngine {
    fun solveOffline(text: String): AiResult {
        val input = text.trim().replace(',', '.').replace('×', '*').replace('÷', '/')
        if (input.isBlank()) return AiResult("Teks soal kosong. Masukkan atau scan soal terlebih dahulu.", listOf("Pastikan teks soal terbaca dengan benar."), "Umum", "Offline", emptyList())

        val percent = Regex("""(?i)([-+]?\d+(?:\.\d+)?)\s*%\s*(?:dari|of)\s*([-+]?\d+(?:\.\d+)?)""").find(input)
        if (percent != null) {
            val p = percent.groupValues[1].toDouble()
            val n = percent.groupValues[2].toDouble()
            val result = p / 100.0 * n
            return AiResult(fmt(result), listOf("Ubah persen menjadi desimal: $p% = ${fmt(p / 100.0)}.", "Kalikan dengan nilai dasar: ${fmt(p / 100.0)} × ${fmt(n)} = ${fmt(result)}."), "Matematika", "Offline", emptyList())
        }

        if ('=' in input && Regex("[xX]").containsMatchIn(input)) {
            val parts = input.split('=', limit = 2)
            if (parts.size == 2) {
                val left = linear(parts[0])
                val right = linear(parts[1])
                if (left != null && right != null) {
                    val a = left.first - right.first
                    val b = right.second - left.second
                    if (abs(a) > 1e-9) {
                        val x = b / a
                        return AiResult("x = ${fmt(x)}", listOf("Kelompokkan suku yang memuat x di satu sisi.", "Pindahkan konstanta ke sisi lainnya: ${fmt(a)}x = ${fmt(b)}.", "Bagi kedua sisi dengan ${fmt(a)} sehingga x = ${fmt(b)} ÷ ${fmt(a)} = ${fmt(x)}."), "Matematika", "Offline", emptyList())
                    }
                }
            }
        }

        val expression = input.replace(Regex("""(?i)berapa|hitunglah|hitung|hasil dari|adalah|\s+"""), "").trimEnd('?', '.')
        val arithmetic = Regex("""^([-+]?\d+(?:\.\d+)?)([+-])([-+]?\d+(?:\.\d+)?)$""").find(expression)
        if (arithmetic != null) {
            val a = arithmetic.groupValues[1].toDouble()
            val b = arithmetic.groupValues[3].toDouble()
            val result = if (arithmetic.groupValues[2] == "+") a + b else a - b
            return AiResult(fmt(result), listOf("Tuliskan operasi: ${fmt(a)} ${arithmetic.groupValues[2]} ${fmt(b)}.", "Hitung hasilnya: ${fmt(a)} ${arithmetic.groupValues[2]} ${fmt(b)} = ${fmt(result)}."), "Matematika", "Offline", emptyList())
        }

        return AiResult("Soal terdeteksi: $text\n\nMode offline belum bisa menyelesaikan jenis soal ini. Hubungkan internet agar AI dapat mencoba menjawabnya.", listOf("Periksa apakah OCR sudah menyalin soal dengan benar.", "Identifikasi informasi yang diketahui dan yang ditanyakan.", "Pilih rumus atau konsep yang sesuai, lalu periksa hasilnya."), "Umum", "Offline terbatas", emptyList())
    }

    private fun linear(side: String): Pair<Double, Double>? = runCatching {
        val s = side.replace(" ", "").lowercase(Locale.US).replace("-", "+-")
        var a = 0.0
        var b = 0.0
        for (term in s.split('+').filter { it.isNotBlank() }) {
            if ('x' in term) {
                val coeff = term.substringBefore('x')
                a += when (coeff) { "", "+" -> 1.0; "-" -> -1.0; else -> coeff.toDouble() }
            } else b += term.toDouble()
        }
        a to b
    }.getOrNull()

    private fun fmt(value: Double): String {
        if (!value.isFinite()) return "tidak terdefinisi"
        val rounded = if (abs(value - value.toLong().toDouble()) < 1e-9) value.toLong().toString()
        else String.format(Locale.US, "%.4f", value).trimEnd('0').trimEnd('.')
        return rounded.replace('.', ',')
    }
}
