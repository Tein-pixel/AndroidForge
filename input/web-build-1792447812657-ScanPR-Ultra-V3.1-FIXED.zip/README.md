# Scan PR Ultra

Android project: Kotlin + XML + ViewBinding, package `com.scanpr.ultra`, min SDK 24, target/compile SDK 34.

## Build

Use JDK 17 and Android SDK platform 34. Run `./gradlew assembleDebug` (Linux/macOS) or `gradlew.bat assembleDebug` (Windows). Output: `app/build/outputs/apk/debug/app-debug.apk`.

The launcher script bootstraps Gradle 8.4 if the standard wrapper JAR is not present. It needs network access on the first run. In a normal Android Studio setup you can also run `gradle wrapper --gradle-version 8.4` to generate the standard wrapper files.

## API keys

Copy `local.properties.example` to `local.properties`, then set `GEMINI_KEY` and/or `OPENROUTER_KEY`. Add local.properties to .gitignore. Empty keys are valid: the app tries Pollinations first and then falls back to the limited offline solver.

## Features

- CameraX preview and photo capture, gallery import, ML Kit text recognition.
- Editable recognized question, AI provider chain and limited offline arithmetic/linear-equation fallback.
- Local Room history, search, copy/share, save, and Light/Dark/System theme setting.
- AI model calls require network access; offline mode handles only a small set of arithmetic and linear equations.
