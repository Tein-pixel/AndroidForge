// CropOverlayView.java : java, Android 29+, com.toker.floatingbubble
// Full-screen WindowManager overlay for crop-text selection.
// Draws:  semi-transparent scrim outside the crop rect | thin configurable border lines
//         | corner handles (circles) | edge-mid handles | rule-of-thirds grid (subtle)
//         | X (cancel) and ✓ (confirm) buttons at bottom center.
// Touch:  corners & edge mids -> resize | inside rect -> move | buttons -> action.
// Lines are 1-4 dp configurable; corner handles are 5 dp radius visual, 28 dp hit zone.
package com.toker.floatingbubble;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public final class CropOverlayView extends View {

    // ── callbacks ─────────────────────────────────────────────────────────────

    public interface OnCropListener {
        void onConfirm(Rect cropRect);
        void onCancel();
    }

    // ── constants ─────────────────────────────────────────────────────────────

    private static final int SCRIM_ARGB        = 0x99000000; // scrim outside crop (lighter — less heavy)
    private static final int CORNER_HANDLE_DP  = 5;          // visual radius dp
    private static final int EDGE_HANDLE_DP    = 3;          // visual radius dp (edge mids)
    private static final int HIT_RADIUS_DP     = 28;         // touch hit zone dp (larger than visual)
    private static final int BTN_RADIUS_DP     = 16;         // X / ✓ button visual radius dp (was 24 — too large)
    private static final int BTN_MARGIN_DP     = 42;         // horizontal distance from center (was 54)
    private static final int BTN_BOTTOM_DP     = 50;         // distance from screen bottom (was 68)
    private static final int MIN_CROP_DP       = 60;         // minimum crop dimension dp

    // ── drag modes ────────────────────────────────────────────────────────────

    private enum DragMode {
        NONE, MOVE,
        TL, TR, BL, BR,   // corners
        T, B, L, R,        // edge mids
        BTN_X, BTN_CHECK
    }

    // ── paint ─────────────────────────────────────────────────────────────────

    private final Paint scrimPaint     = new Paint();
    private final Paint linePaint      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint xBgPaint       = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint checkBgPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint symbolPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);


    // ── state ─────────────────────────────────────────────────────────────────

    private RectF cropRect;
    private DragMode dragMode  = DragMode.NONE;
    private float lastTouchX, lastTouchY;
    private final float density;
    private OnCropListener listener;

    // ── constructor ───────────────────────────────────────────────────────────

    public CropOverlayView(Context ctx, float lineThicknessDp, int lineColor) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;

        scrimPaint.setStyle(Paint.Style.FILL);
        scrimPaint.setColor(SCRIM_ARGB);

        float lw = Math.max(1f, lineThicknessDp * density);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setColor(lineColor);
        linePaint.setStrokeWidth(lw);
        linePaint.setStrokeCap(Paint.Cap.SQUARE);

        gridPaint.set(linePaint);
        gridPaint.setAlpha(60); // faint thirds grid

        handlePaint.setStyle(Paint.Style.FILL);
        handlePaint.setColor(lineColor);

        xBgPaint.setStyle(Paint.Style.FILL);
        xBgPaint.setColor(0xCCCC2222);

        checkBgPaint.setStyle(Paint.Style.FILL);
        checkBgPaint.setColor(0xCC22AA44);

        symbolPaint.setStyle(Paint.Style.STROKE);
        symbolPaint.setColor(Color.WHITE);
        symbolPaint.setStrokeWidth(2.6f * density);
        symbolPaint.setStrokeCap(Paint.Cap.ROUND);
        symbolPaint.setStrokeJoin(Paint.Join.ROUND);


    }

    public void setListener(OnCropListener l) { this.listener = l; }

    // ── size changed: initialise crop rect centered at 65% × 42% of screen ──

    @Override
    protected void onSizeChanged(int w, int h, int oldW, int oldH) {
        super.onSizeChanged(w, h, oldW, oldH);
        if (cropRect == null) {
            float pw = w * 0.65f, ph = h * 0.42f;
            float cx = w * 0.5f,  cy = h * 0.46f;
            cropRect = new RectF(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f);
        }
    }

    // ── draw ──────────────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (cropRect == null) return;

        int w = getWidth(), h = getHeight();

        // scrim: four rects around the crop hole
        canvas.drawRect(0,              0,              w,            cropRect.top,    scrimPaint);
        canvas.drawRect(0,              cropRect.bottom, w,           h,               scrimPaint);
        canvas.drawRect(0,              cropRect.top,   cropRect.left, cropRect.bottom, scrimPaint);
        canvas.drawRect(cropRect.right, cropRect.top,   w,            cropRect.bottom, scrimPaint);

        // rule-of-thirds grid REMOVED — cleaner UI without distracting lines

        // crop border (thin configurable line)
        canvas.drawRect(cropRect, linePaint);

        // L-shaped corner handles — clean, minimal, modern
        float arm = dp(14);   // length of each L arm
        float lw2 = linePaint.getStrokeWidth() * 1.6f;
        Paint cornerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cornerPaint.setStyle(Paint.Style.STROKE);
        cornerPaint.setColor(handlePaint.getColor());
        cornerPaint.setStrokeWidth(lw2);
        cornerPaint.setStrokeCap(Paint.Cap.ROUND);

        // Top-left
        canvas.drawLine(cropRect.left,       cropRect.top + arm, cropRect.left,  cropRect.top, cornerPaint);
        canvas.drawLine(cropRect.left,       cropRect.top,       cropRect.left + arm, cropRect.top, cornerPaint);
        // Top-right
        canvas.drawLine(cropRect.right - arm, cropRect.top,      cropRect.right, cropRect.top, cornerPaint);
        canvas.drawLine(cropRect.right,       cropRect.top,      cropRect.right, cropRect.top + arm, cornerPaint);
        // Bottom-left
        canvas.drawLine(cropRect.left,        cropRect.bottom - arm, cropRect.left, cropRect.bottom, cornerPaint);
        canvas.drawLine(cropRect.left,        cropRect.bottom,   cropRect.left + arm, cropRect.bottom, cornerPaint);
        // Bottom-right
        canvas.drawLine(cropRect.right - arm, cropRect.bottom,   cropRect.right, cropRect.bottom, cornerPaint);
        canvas.drawLine(cropRect.right,       cropRect.bottom - arm, cropRect.right, cropRect.bottom, cornerPaint);

        // X and ✓ buttons
        float btnR   = dp(BTN_RADIUS_DP);
        float btnY   = h - dp(BTN_BOTTOM_DP);
        float xBtnX  = w / 2f - dp(BTN_MARGIN_DP);
        float chkX   = w / 2f + dp(BTN_MARGIN_DP);

        canvas.drawCircle(xBtnX, btnY, btnR, xBgPaint);
        canvas.drawCircle(chkX,  btnY, btnR, checkBgPaint);

        // X symbol
        float xs = btnR * 0.38f;
        canvas.drawLine(xBtnX - xs, btnY - xs, xBtnX + xs, btnY + xs, symbolPaint);
        canvas.drawLine(xBtnX + xs, btnY - xs, xBtnX - xs, btnY + xs, symbolPaint);

        // ✓ symbol (checkmark path)
        float cs = btnR * 0.38f;
        Path ck = new Path();
        ck.moveTo(chkX - cs,         btnY);
        ck.lineTo(chkX - cs * 0.15f, btnY + cs * 0.72f);
        ck.lineTo(chkX + cs,         btnY - cs * 0.65f);
        canvas.drawPath(ck, symbolPaint);
    }

    // ── touch ─────────────────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (cropRect == null) return true;
        float tx = ev.getX(), ty = ev.getY();

        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragMode  = detectMode(tx, ty);
                lastTouchX = tx;
                lastTouchY = ty;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (dragMode == DragMode.NONE
                        || dragMode == DragMode.BTN_X
                        || dragMode == DragMode.BTN_CHECK) return true;
                applyDrag(tx - lastTouchX, ty - lastTouchY);
                lastTouchX = tx;
                lastTouchY = ty;
                invalidate();
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragMode == DragMode.BTN_X     && listener != null) listener.onCancel();
                if (dragMode == DragMode.BTN_CHECK && listener != null) listener.onConfirm(toRect(cropRect));
                dragMode = DragMode.NONE;
                return true;
        }
        return true;
    }

    private DragMode detectMode(float tx, float ty) {
        int w = getWidth(), h = getHeight();
        float btnR  = dp(BTN_RADIUS_DP) + dp(8); // slightly larger hit
        float btnY  = h - dp(BTN_BOTTOM_DP);
        float xBtnX = w / 2f - dp(BTN_MARGIN_DP);
        float chkX  = w / 2f + dp(BTN_MARGIN_DP);
        float hit   = dp(HIT_RADIUS_DP);

        if (dist(tx, ty, xBtnX, btnY) <= btnR) return DragMode.BTN_X;
        if (dist(tx, ty, chkX,  btnY) <= btnR) return DragMode.BTN_CHECK;

        // corners (priority over edges)
        if (dist(tx, ty, cropRect.left,  cropRect.top)    <= hit) return DragMode.TL;
        if (dist(tx, ty, cropRect.right, cropRect.top)    <= hit) return DragMode.TR;
        if (dist(tx, ty, cropRect.left,  cropRect.bottom) <= hit) return DragMode.BL;
        if (dist(tx, ty, cropRect.right, cropRect.bottom) <= hit) return DragMode.BR;

        // edge mids
        if (dist(tx, ty, cropRect.centerX(), cropRect.top)    <= hit) return DragMode.T;
        if (dist(tx, ty, cropRect.centerX(), cropRect.bottom) <= hit) return DragMode.B;
        if (dist(tx, ty, cropRect.left,      cropRect.centerY()) <= hit) return DragMode.L;
        if (dist(tx, ty, cropRect.right,     cropRect.centerY()) <= hit) return DragMode.R;

        // inside -> move
        if (cropRect.contains(tx, ty)) return DragMode.MOVE;

        return DragMode.NONE;
    }

    private void applyDrag(float dx, float dy) {
        int sw = getWidth(), sh = getHeight();
        float min = dp(MIN_CROP_DP);

        switch (dragMode) {
            case MOVE:
                float nx = cropRect.left + dx, nr = cropRect.right + dx;
                float ny = cropRect.top  + dy, nb = cropRect.bottom + dy;
                if (nx >= 0 && nr <= sw) { cropRect.left  += dx; cropRect.right  += dx; }
                if (ny >= 0 && nb <= sh) { cropRect.top   += dy; cropRect.bottom += dy; }
                break;
            case TL:
                cropRect.left = clamp(cropRect.left + dx, 0, cropRect.right  - min);
                cropRect.top  = clamp(cropRect.top  + dy, 0, cropRect.bottom - min);
                break;
            case TR:
                cropRect.right = clamp(cropRect.right + dx, cropRect.left + min, sw);
                cropRect.top   = clamp(cropRect.top   + dy, 0,                   cropRect.bottom - min);
                break;
            case BL:
                cropRect.left   = clamp(cropRect.left   + dx, 0,                  cropRect.right  - min);
                cropRect.bottom = clamp(cropRect.bottom + dy, cropRect.top + min,  sh);
                break;
            case BR:
                cropRect.right  = clamp(cropRect.right  + dx, cropRect.left + min, sw);
                cropRect.bottom = clamp(cropRect.bottom + dy, cropRect.top  + min, sh);
                break;
            case T:
                cropRect.top  = clamp(cropRect.top  + dy, 0, cropRect.bottom - min);
                break;
            case B:
                cropRect.bottom = clamp(cropRect.bottom + dy, cropRect.top + min, sh);
                break;
            case L:
                cropRect.left = clamp(cropRect.left + dx, 0, cropRect.right - min);
                break;
            case R:
                cropRect.right = clamp(cropRect.right + dx, cropRect.left + min, sw);
                break;
        }
    }

    // ── utils ─────────────────────────────────────────────────────────────────

    private static float dist(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2, dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private float dp(float v) { return v * density; }

    private static Rect toRect(RectF rf) {
        return new Rect((int) rf.left, (int) rf.top, (int) rf.right, (int) rf.bottom);
    }
}
