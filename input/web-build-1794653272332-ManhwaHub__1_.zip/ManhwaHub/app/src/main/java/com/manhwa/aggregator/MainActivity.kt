package com.manhwa.aggregator

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.manhwa.aggregator.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scraper = ManhwaScraper()
    private var cachedData = listOf<Manhwa>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Menggunakan Grid 2 Kolom standar Manhwa App
        binding.rvManhwa.layoutManager = GridLayoutManager(this, 2)
        
        // Setup Pull-to-Refresh
        binding.swipeRefresh.setOnRefreshListener {
            loadData(isRefresh = true)
        }
        binding.swipeRefresh.setColorSchemeResources(R.color.primary_cyan)

        loadData()
    }

    private fun loadData(isRefresh: Boolean = false) {
        if (!isRefresh) {
            binding.progressBar.visibility = View.VISIBLE
            binding.rvManhwa.visibility = View.GONE
        }

        lifecycleScope.launch {
            try {
                val list = scraper.fetchLatest()
                if (list.isNotEmpty()) {
                    cachedData = list
                    binding.rvManhwa.adapter = ManhwaAdapter(cachedData)
                    binding.progressBar.visibility = View.GONE
                    binding.rvManhwa.visibility = View.VISIBLE
                } else {
                    if (cachedData.isEmpty()) {
                        Toast.makeText(this@MainActivity, "Gagal memuat data. Cek koneksi.", Toast.LENGTH_LONG).show()
                    }
                    binding.progressBar.visibility = View.GONE
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                binding.progressBar.visibility = View.GONE
            } finally {
                if (isRefresh) {
                    binding.swipeRefresh.isRefreshing = false
                }
            }
        }
    }
}
