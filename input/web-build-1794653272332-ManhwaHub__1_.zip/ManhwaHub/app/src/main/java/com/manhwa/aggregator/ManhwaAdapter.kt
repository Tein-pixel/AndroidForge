package com.manhwa.aggregator

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import coil.ImageLoader
import coil.load
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class ManhwaAdapter(private val manhwaList: List<Manhwa>) : RecyclerView.Adapter<ManhwaAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgCover: ImageView = view.findViewById(R.id.imgCover)
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvChapter: TextView = view.findViewById(R.id.tvChapter)
        val tvSource: TextView = view.findViewById(R.id.tvSource)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_manhwa, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = manhwaList[position]
        holder.tvTitle.text = item.title
        holder.tvChapter.text = item.latestChapter
        holder.tvSource.text = "Source: ${item.source}"

        // ImageLoader dengan OkHttpClient yang memalsukan Referer untuk bypass Hotlink
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("Referer", item.link)
                    .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .build()
                chain.proceed(request)
            }
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        val loader = ImageLoader.Builder(holder.itemView.context)
            .okHttpClient { client }
            .build()

        holder.imgCover.load(item.imageUrl, loader)

        holder.itemView.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(item.link))
                holder.itemView.context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(holder.itemView.context, "Tidak dapat membuka tautan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun getItemCount() = manhwaList.size
}
