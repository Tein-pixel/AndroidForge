package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

class ManhwaScraper {

    // Menggunakan sumber Madara-Theme (Kiryuu & Cosmic Scans) yang cepat & update
    private val targetUrls = listOf(
        "https://kiryuu.id/manga/?m_orderby=latest" to "Kiryuu",
        "https://04.cosmicscans.to/manga/?m_orderby=latest" to "Cosmic"
    )

    suspend fun fetchLatest(): List<Manhwa> = withContext(Dispatchers.IO) {
        val allManhwa = mutableListOf<Manhwa>()

        for ((url, sourceName) in targetUrls) {
            try {
                val doc = Jsoup.connect(url)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                    .timeout(15000)
                    .get()

                val elements = doc.select(".page-item-detail, .manga__item")

                for (el in elements) {
                    val title = el.select(".post-title h3 a, .manga__item-title a").text().trim()
                    val link = el.select(".post-title h3 a, .manga__item-title a").attr("href")
                    
                    var imgUrl = el.select(".item-thumb img, .manga__item-thumbnail img").attr("data-src")
                    if (imgUrl.isNullOrEmpty() || !imgUrl.startsWith("http")) {
                        imgUrl = el.select(".item-thumb img, .manga__item-thumbnail img").attr("src")
                    }
                    
                    val latestChapter = el.select(".chapter-item .btn-link, .list-chapter .chapter-item a").first()?.text()?.trim() ?: "Chapter Baru"

                    if (title.isNotEmpty() && link.isNotEmpty() && imgUrl.isNotEmpty()) {
                        allManhwa.add(Manhwa(title, link, imgUrl, latestChapter, sourceName))
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // Shuffle agar campur antara Kiryuu dan Cosmic
        allManhwa.shuffle()
        allManhwa
    }
}
