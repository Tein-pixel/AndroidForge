package com.manhwa.aggregator

data class Manhwa(
    val title: String,
    val link: String,
    val imageUrl: String,
    val latestChapter: String,
    val source: String
)
