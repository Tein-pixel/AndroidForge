package com.manhwa.aggregator

import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.manhwa.aggregator.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scraper = ManhwaScraper()
    private var currentQuery = ""
    private var currentGenre = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvManhwa.layoutManager = GridLayoutManager(this, 2)

        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                currentQuery = binding.etSearch.text.toString()
                currentGenre = ""
                binding.chipAll.isChecked = true
                loadData()
                true
            } else {
                false
            }
        }

        binding.chipGroupGenre.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                currentQuery = ""
                binding.etSearch.text.clear()
                
                currentGenre = when (checkedIds[0]) {
                    R.id.chipAction -> "Action"
                    R.id.chipFantasy -> "Fantasy"
                    R.id.chipRomance -> "Romance"
                    R.id.chipMartial -> "Martial Arts"
                    else -> "Semua"
                }
                loadData()
            }
        }

        binding.swipeRefresh.setOnRefreshListener {
            loadData(isRefresh = true)
        }
        binding.swipeRefresh.setColorSchemeResources(R.color.primary_cyan)

        loadData()
    }

    private fun loadData(isRefresh: Boolean = false) {
        if (!isRefresh) {
            binding.progressBar.visibility = View.VISIBLE
            binding.rvManhwa.visibility = View.GONE
        }

        lifecycleScope.launch {
            try {
                val list = scraper.fetchLatest(currentQuery, currentGenre)
                binding.rvManhwa.adapter = ManhwaAdapter(list)
                binding.progressBar.visibility = View.GONE
                binding.rvManhwa.visibility = View.VISIBLE
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                binding.progressBar.visibility = View.GONE
            } finally {
                if (isRefresh) {
                    binding.swipeRefresh.isRefreshing = false
                }
            }
        }
    }
}
