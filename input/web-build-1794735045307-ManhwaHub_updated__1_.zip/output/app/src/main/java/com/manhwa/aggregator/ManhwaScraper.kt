package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

class ManhwaScraper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val bypassProxy = "https://api.allorigins.win/raw?url="

    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> = withContext(Dispatchers.IO) {
        val allManhwa = mutableListOf<Manhwa>()

        var targetUrl = "https://kiryuu.id/"
        if (query.isNotEmpty()) {
            targetUrl = "https://kiryuu.id/?s=${query.replace(" ", "+")}"
        } else if (genre.isNotEmpty() && genre != "Semua") {
            targetUrl = "https://kiryuu.id/genre/${genre.lowercase().replace(" ", "-")}/?m_orderby=latest"
        } else {
            targetUrl = "https://kiryuu.id/manga/?m_orderby=latest"
        }

        try {
            val finalUrl = bypassProxy + targetUrl
            
            val request = Request.Builder()
                .url(finalUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val html = response.body?.string() ?: ""
                    val doc = Jsoup.parse(html, targetUrl)

                    val elements = doc.select(".listupd .bs, .bsx, .page-item-detail, .manga__item")

                    for (el in elements) {
                        val title = el.select(".tt h3 a, .tt h4 a, .post-title h3 a, .manga__item-title a").text().trim()
                        val link = el.select(".tt h3 a, .tt h4 a, .post-title h3 a, .manga__item-title a").attr("href")
                        var imgUrl = el.select("img").attr("data-src")
                        if (imgUrl.isNullOrEmpty()) imgUrl = el.select("img").attr("src")
                        val latestChapter = el.select(".epxs, .chapter-item .btn-link").first()?.text()?.trim() ?: "Chapter Baru"

                        if (title.isNotEmpty() && link.isNotEmpty() && imgUrl.isNotEmpty()) {
                            allManhwa.add(Manhwa(title, link, imgUrl, latestChapter, "Kiryuu"))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (allManhwa.isEmpty()) {
            allManhwa.add(Manhwa("Data Tidak Ditemukan / Diblokir", "https://google.com", "https://via.placeholder.com/300x400?text=Blocked", "Coba kata kunci lain", "System"))
        }

        allManhwa.distinctBy { it.link }
    }
}
