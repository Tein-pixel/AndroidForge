// MainActivity.java : java, Android 29+, com.media.access
// Entry point: checks overlay permission, starts BubbleService.
// Buttons: Start Bubble | Stop Bubble | Pengaturan | Aksesibilitas
package com.media.access;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Outline;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(0xFF0D1520);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        setContentView(buildUI());
    }

    // ── UI ────────────────────────────────────────────────────────────────────

    private View buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D1520);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(px(28), px(60), px(28), px(40));

        // Logo / title block
        addLogo(root);

        // Version tag
        TextView ver = new TextView(this);
        ver.setText("v3.0 • v4 · stealth + OCR");
        ver.setTextColor(0xFF00BCD4);
        ver.setTextSize(12f);
        ver.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams verLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        verLp.setMargins(0, px(4), 0, px(40));
        root.addView(ver, verLp);

        // Start button
        Button startBtn = roundBtn("▶  Mulai Bubble", 0xFF00BCD4, Color.WHITE);
        startBtn.setOnClickListener(v -> handleStart());
        root.addView(startBtn, btnLp(0));

        // Stop button
        Button stopBtn = roundBtn("■  Stop Bubble", 0xFF1A2D3A, 0xFF00BCD4);
        stopBtn.setOnClickListener(v -> handleStop());
        root.addView(stopBtn, btnLp(px(12)));

        // Divider
        View div = new View(this);
        div.setBackgroundColor(0xFF1A2D3A);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        divLp.setMargins(0, px(28), 0, px(28));
        root.addView(div, divLp);

        // Settings button
        Button settingsBtn = roundBtn("⚙  Pengaturan Bubble", 0xFF162535, 0xFFCCCCCC);
        settingsBtn.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        root.addView(settingsBtn, btnLp(0));

        // Accessibility button
        Button accBtn = roundBtn("♿  Aksesibilitas (AI Crop)", 0xFF162535, 0xFFCCCCCC);
        accBtn.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accBtn, btnLp(px(12)));

        // Status note
        TextView note = new TextView(this);
        note.setText("Aktifkan izin Overlay + Aksesibilitas agar bubble berfungsi penuh.");
        note.setTextColor(0xFF556677);
        note.setTextSize(11.5f);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        noteLp.setMargins(0, px(32), 0, 0);
        root.addView(note, noteLp);

        return root;
    }

    private void addLogo(LinearLayout root) {
        // Cyan circle + app name
        LinearLayout logoRow = new LinearLayout(this);
        logoRow.setOrientation(LinearLayout.HORIZONTAL);
        logoRow.setGravity(Gravity.CENTER_VERTICAL);

        View dot = new View(this);
        dot.setBackgroundColor(0xFF00BCD4);
        dot.setClipToOutline(true);
        dot.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setOval(0, 0, v.getWidth(), v.getHeight());
            }
        });
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(px(14), px(14));
        dotLp.setMargins(0, 0, px(10), 0);
        logoRow.addView(dot, dotLp);

        TextView appName = new TextView(this);
        appName.setText("System Display");
        appName.setTextColor(Color.WHITE);
        appName.setTextSize(26f);
        logoRow.addView(appName);

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, 0, 0, 0);
        root.addView(logoRow, rowLp);
    }

    // ── actions ───────────────────────────────────────────────────────────────

    private void handleStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        Intent svc = new Intent(this, BubbleService.class);
        startForegroundService(svc);
        Toast.makeText(this, "Bubble aktif ✓", Toast.LENGTH_SHORT).show();
    }

    private void handleStop() {
        stopService(new Intent(this, BubbleService.class));
        Toast.makeText(this, "Bubble dihentikan", Toast.LENGTH_SHORT).show();
    }

    // ── builder helpers ───────────────────────────────────────────────────────

    private Button roundBtn(String text, int bgColor, int textColor) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(textColor);
        btn.setTextSize(14.5f);
        btn.setAllCaps(false);
        btn.setBackgroundColor(bgColor);
        btn.setClipToOutline(true);
        btn.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), px(10));
            }
        });
        btn.setPadding(px(16), px(14), px(16), px(14));
        return btn;
    }

    private LinearLayout.LayoutParams btnLp(int topMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, px(50));
        lp.setMargins(0, topMargin, 0, 0);
        return lp;
    }

    private int px(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
