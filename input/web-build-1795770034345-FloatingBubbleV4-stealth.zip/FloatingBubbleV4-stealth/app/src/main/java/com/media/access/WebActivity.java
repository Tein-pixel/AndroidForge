// WebActivity.java : java, Android 29+, com.media.access
// Generic WebView activity for Google Search, Google AI Mode, Google Translate.
// MODE_SEARCH    → https://www.google.com/search?q=QUERY
// MODE_TRANSLATE → https://translate.google.com
// MODE_AI        → https://www.google.com/search?q=QUERY&udm=50 (AI overview)
package com.media.access;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class WebActivity extends Activity {

    public static final String EXTRA_MODE  = "web_mode";
    public static final String EXTRA_QUERY = "web_query";

    public static final int MODE_SEARCH    = 0;
    public static final int MODE_TRANSLATE = 1;
    public static final int MODE_AI        = 2;

    private static final String UA =
            "Mozilla/5.0 (Linux; Android 11; Pixel 5) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36";

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // ── BUG FIX: was FLAG_FULLSCREEN — now a floating panel via Theme.FloatingPanel.
        // No fullscreen flag; window size is set below after setContentView.
        getWindow().setStatusBarColor(0xFF1A1A2E);

        int    mode  = getIntent().getIntExtra(EXTRA_MODE,  MODE_SEARCH);
        String query = getIntent().getStringExtra(EXTRA_QUERY);
        if (query == null) query = "";

        String url = buildUrl(mode, query);

        // ── root ──────────────────────────────────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        // ── top bar ───────────────────────────────────────────────────────────
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0xFF1A1A2E);
        topBar.setPadding(px(10), px(10), px(12), px(10));

        ImageButton closeBtn = new ImageButton(this);
        closeBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeBtn.setBackgroundColor(Color.TRANSPARENT);
        closeBtn.setColorFilter(Color.WHITE);
        closeBtn.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(px(36), px(36));
        closeLp.setMargins(0, 0, px(8), 0);
        topBar.addView(closeBtn, closeLp);

        TextView titleTv = new TextView(this);
        titleTv.setText(modeTitle(mode));
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(16f);
        topBar.addView(titleTv, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // ── webview ───────────────────────────────────────────────────────────
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setUserAgentString(UA);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String loadUrl) {
                // Allow Google domains; intercept external app links
                if (loadUrl.startsWith("http://") || loadUrl.startsWith("https://")) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(loadUrl))); }
                catch (Exception ignored) {}
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(url);

        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        // Panel kecil di tengah layar: 82% lebar × 42% tinggi, posisi CENTER.
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int panelW = (int)(dm.widthPixels  * 0.82f);
        int panelH = (int)(dm.heightPixels * 0.42f);
        getWindow().setLayout(panelW, panelH);
        android.view.WindowManager.LayoutParams wlp = getWindow().getAttributes();
        wlp.gravity = Gravity.CENTER;
        wlp.x = 0;
        wlp.y = 0;
        getWindow().setAttributes(wlp);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }

    // ── url builder ───────────────────────────────────────────────────────────

    private static String buildUrl(int mode, String query) {
        String enc = Uri.encode(query);
        switch (mode) {
            case MODE_TRANSLATE:
                return query.isEmpty()
                        ? "https://translate.google.com"
                        : "https://translate.google.com/?text=" + enc;
            case MODE_AI:
                return query.isEmpty()
                        ? "https://www.google.com/search?udm=50"
                        : "https://www.google.com/search?q=" + enc + "&udm=50";
            case MODE_SEARCH:
            default:
                return query.isEmpty()
                        ? "https://www.google.com"
                        : "https://www.google.com/search?q=" + enc;
        }
    }

    private static String modeTitle(int mode) {
        switch (mode) {
            case MODE_TRANSLATE: return "Google Translate";
            case MODE_AI:        return "Google AI";
            default:             return "Google Search";
        }
    }

    private int px(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
