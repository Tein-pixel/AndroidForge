// ScanSettingDialog.java : java, Android 29+, com.media.access
// Floating WindowManager overlay — scan mode selection dialog.
// Matches screenshot: title bar with drag + −□× controls, two mode sections,
// each with 3 buttons (Google Search | Google AI | Translate), orange border on selected.
// Saves immediately to SharedPrefHelper on button tap — no separate Save button.
// Draggable by title bar.
package com.media.access;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ScanSettingDialog {

    // ── design tokens ─────────────────────────────────────────────────────────
    private static final int CLR_BG           = 0xFF0D1B2C;
    private static final int CLR_TITLE_BAR    = 0xFF101F30;
    private static final int CLR_SECTION_HDR  = 0xFF00BCD4;
    private static final int CLR_BTN_TEXT_MODE  = 0xFF0EA5E9;  // blue-ish for OCR buttons
    private static final int CLR_BTN_IMAGE_MODE = 0xFF16A34A;  // green for screenshot buttons
    private static final int CLR_SELECTED_RING  = 0xFFF59E0B;  // amber/orange border
    private static final int CLR_BORDER         = 0xFF1A3550;
    private static final int CLR_CTRL_BTN       = 0xFF888888;
    private static final int CLR_WARN_TEXT      = 0xFFF59E0B;
    private static final int CLR_WARN_BG        = 0xFF0A1E2E;

    // ── state ─────────────────────────────────────────────────────────────────
    private final Context       context;
    private final WindowManager wm;

    private View                       dialogView;
    private WindowManager.LayoutParams params;
    private boolean                    visible = false;

    private int selText;
    private int selImage;

    // button refs per section [0=SEARCH, 1=AI, 2=TRANSLATE]
    private final Button[] textBtns  = new Button[3];
    private final Button[] imageBtns = new Button[3];

    // ── constructor ───────────────────────────────────────────────────────────

    public ScanSettingDialog(Context context, WindowManager wm) {
        this.context = context;
        this.wm      = wm;
    }

    // ── public ────────────────────────────────────────────────────────────────

    public void show(int anchorX, int anchorY) {
        if (visible) return;
        selText  = SharedPrefHelper.getTextDest(context);
        selImage = SharedPrefHelper.getImageDest(context);
        dialogView = buildDialog();
        params = makeParams(anchorX, anchorY);
        wm.addView(dialogView, params);
        visible = true;
    }

    public void dismiss() {
        if (!visible || dialogView == null) return;
        try { wm.removeView(dialogView); } catch (Exception ignored) {}
        dialogView = null;
        visible    = false;
    }

    public boolean isVisible() { return visible; }

    // ── build ─────────────────────────────────────────────────────────────────

    private View buildDialog() {
        // root card — dark navy, rounded, 1 dp border
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutParams(new ViewGroup.LayoutParams(
                dp(300), ViewGroup.LayoutParams.WRAP_CONTENT));
        card.setBackground(roundRect(CLR_BG, dp(14), dp(1), CLR_BORDER));
        card.setClipToOutline(true);

        // ── title bar ─────────────────────────────────────────────────────────
        LinearLayout titleBar = buildTitleBar();
        card.addView(titleBar, matchWrap());
        attachDrag(titleBar);                // drag moves whole window

        // ── body ──────────────────────────────────────────────────────────────
        LinearLayout body = new LinearLayout(context);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(10), dp(14), dp(16));

        // MODE TEKS (OCR)
        body.addView(sectionHeader("MODE TEKS (OCR)"));
        body.addView(buildModeRow(
                CLR_BTN_TEXT_MODE,
                selText,
                textBtns,
                dest -> {
                    selText = dest;
                    SharedPrefHelper.saveTextDest(context, dest);
                    refreshRow(textBtns, dest, CLR_BTN_TEXT_MODE);
                }
        ));

        // MODE GAMBAR (SCREENSHOT)
        body.addView(sectionHeader("MODE GAMBAR (SCREENSHOT)"));
        body.addView(buildModeRow(
                CLR_BTN_IMAGE_MODE,
                selImage,
                imageBtns,
                dest -> {
                    selImage = dest;
                    SharedPrefHelper.saveImageDest(context, dest);
                    refreshRow(imageBtns, dest, CLR_BTN_IMAGE_MODE);
                }
        ));

        // warning box
        body.addView(buildWarnBox());

        card.addView(body, matchWrap());
        return card;
    }

    private LinearLayout buildTitleBar() {
        LinearLayout bar = new LinearLayout(context);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(CLR_TITLE_BAR);
        bar.setPadding(dp(10), dp(9), dp(6), dp(9));

        // scan icon (sparkle drawable — closest available icon)
        ImageView icon = new ImageView(context);
        icon.setImageDrawable(context.getDrawable(R.drawable.ic_sparkle));
        icon.setColorFilter(CLR_SECTION_HDR);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(18), dp(18));
        iconLp.setMargins(0, 0, dp(8), 0);
        bar.addView(icon, iconLp);

        // title
        TextView titleTv = new TextView(context);
        titleTv.setText("Scan Setting");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(13.5f);
        bar.addView(titleTv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // − □ × control buttons
        bar.addView(ctrlBtn("−", v -> dismiss()));
        bar.addView(ctrlBtn("□", v -> {}));     // no-op; layout placeholder
        bar.addView(ctrlBtn("×", v -> dismiss()));

        return bar;
    }

    // ── mode row ──────────────────────────────────────────────────────────────

    private LinearLayout buildModeRow(int btnColor, int currentDest,
                                      Button[] outBtns, DestCb cb) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        rowLp.setMargins(0, dp(6), 0, dp(10));
        row.setLayoutParams(rowLp);

        // dest[i] maps index → SharedPrefHelper constant
        int[]    dests  = {SharedPrefHelper.DEST_SEARCH, SharedPrefHelper.DEST_AI, SharedPrefHelper.DEST_TRANSLATE};
        String[] labels = {"Google\nSearch", "Google\nAI", "Translate"};

        for (int i = 0; i < 3; i++) {
            final int destForBtn = dests[i];
            boolean   selected   = (destForBtn == currentDest);
            Button    btn        = makeDestBtn(labels[i], btnColor, selected);
            outBtns[i] = btn;
            btn.setOnClickListener(v -> cb.on(destForBtn));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            lp.setMargins(i > 0 ? dp(6) : 0, 0, 0, 0);
            row.addView(btn, lp);
        }
        return row;
    }

    private Button makeDestBtn(String label, int bgColor, boolean selected) {
        Button btn = new Button(context);
        btn.setText(label);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(11f);
        btn.setAllCaps(false);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(2), dp(2), dp(2), dp(2));
        applyDestBtnBg(btn, bgColor, selected);
        return btn;
    }

    private void applyDestBtnBg(Button btn, int bgColor, boolean selected) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(10));
        if (selected) {
            gd.setStroke(dp(3), CLR_SELECTED_RING);
        }
        btn.setBackground(gd);
    }

    /** Redraws all 3 buttons in a row after a selection change. */
    private void refreshRow(Button[] btns, int newDest, int btnColor) {
        int[] dests = {SharedPrefHelper.DEST_SEARCH, SharedPrefHelper.DEST_AI, SharedPrefHelper.DEST_TRANSLATE};
        for (int i = 0; i < btns.length; i++) {
            applyDestBtnBg(btns[i], btnColor, dests[i] == newDest);
        }
    }

    // ── warning box ───────────────────────────────────────────────────────────

    private View buildWarnBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(roundRect(CLR_WARN_BG, dp(8), dp(1), CLR_BORDER));
        box.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(2), 0, 0);
        box.setLayoutParams(lp);

        TextView tv = new TextView(context);
        tv.setText("⚠ Di mode gambar, tidak bisa digunakan di apk Exam yang memiliki keamanan " +
                "FLAG_SECURE. Tidak bisa ss/rekam layar. Maka kalian pilih paket v2 dan admin " +
                "akan memberikan apk exam yang dihilangkan FLAG_SECURE nya dan apk nya saat " +
                "diperiksa pasti ori karena tidak merubah yang lain. Untuk pertanyaan lebih lanjut " +
                "langsung ke ADMIN");
        tv.setTextColor(CLR_WARN_TEXT);
        tv.setTextSize(10.5f);
        box.addView(tv);
        return box;
    }

    // ── drag ──────────────────────────────────────────────────────────────────

    private void attachDrag(View handle) {
        final int[]   initPos   = new int[2];
        final float[] initTouch = new float[2];
        handle.setOnTouchListener((v, ev) -> {
            switch (ev.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initPos[0]   = params.x;
                    initPos[1]   = params.y;
                    initTouch[0] = ev.getRawX();
                    initTouch[1] = ev.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initPos[0] + (int)(ev.getRawX() - initTouch[0]);
                    params.y = initPos[1] + (int)(ev.getRawY() - initTouch[1]);
                    if (dialogView != null) {
                        try { wm.updateViewLayout(dialogView, params); } catch (Exception ignored) {}
                    }
                    return true;
            }
            return false;
        });
    }

    // ── builder helpers ───────────────────────────────────────────────────────

    private TextView sectionHeader(String text) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextColor(CLR_SECTION_HDR);
        tv.setTextSize(11f);
        tv.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    private TextView ctrlBtn(String symbol, View.OnClickListener l) {
        // TextView instead of Button — Button enforces Material minHeight (~48dp)
        // which bloats the title bar even with setBackground(null).
        TextView tv = new TextView(context);
        tv.setText(symbol);
        tv.setTextColor(CLR_CTRL_BTN);
        tv.setTextSize(16f);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(10), dp(8), dp(10), dp(8));
        tv.setOnClickListener(l);
        return tv;
    }

    private GradientDrawable roundRect(int fill, float radius, int strokeW, int strokeColor) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(radius);
        if (strokeW > 0) gd.setStroke(strokeW, strokeColor);
        return gd;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private WindowManager.LayoutParams makeParams(int x, int y) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                dp(300),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x;
        p.y = y;
        return p;
    }

    // ── utils ─────────────────────────────────────────────────────────────────

    private interface DestCb { void on(int dest); }

    private int dp(int v) {
        return (int)(v * context.getResources().getDisplayMetrics().density);
    }
}
