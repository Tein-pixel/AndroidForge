// CameraProxyActivity.java : java, Android 29+, com.media.access
// v4: ML Kit OCR path.
// MODE_CAMERA / MODE_GALLERY → capture image → route:
//   imageDest == DEST_AI        → send image to Gemini Vision (unchanged)
//   imageDest == DEST_SEARCH    → run ML Kit OCR → route text to Google Search
//   imageDest == DEST_TRANSLATE → run ML Kit OCR → route text to Translate
// OCR result replaces the old "image not supported in WebView" fallback.
package com.media.access;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class CameraProxyActivity extends Activity {

    public static final String EXTRA_MODE    = "proxy_mode";
    public static final int    MODE_CAMERA   = 0;
    public static final int    MODE_GALLERY  = 1;

    private static final int REQ_CAMERA  = 2001;
    private static final int REQ_GALLERY = 2002;

    private Uri cameraImageUri;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        int mode = getIntent().getIntExtra(EXTRA_MODE, MODE_CAMERA);
        if (mode == MODE_CAMERA) launchCamera(); else launchGallery();
    }

    // ── launch ────────────────────────────────────────────────────────────────

    private void launchCamera() {
        try {
            File tmpFile = new File(getCacheDir(),
                    "cap_" + System.currentTimeMillis() + ".jpg");
            cameraImageUri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", tmpFile);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
            startActivityForResult(cam, REQ_CAMERA);
        } catch (Exception e) {
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cam, REQ_CAMERA);
        }
    }

    private void launchGallery() {
        Intent pick = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pick.setType("image/*");
        startActivityForResult(pick, REQ_GALLERY);
    }

    // ── result ────────────────────────────────────────────────────────────────

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String imagePath = null;

        if (resultCode == RESULT_OK) {
            if (requestCode == REQ_CAMERA) {
                if (cameraImageUri != null) {
                    imagePath = saveUriToCache(cameraImageUri);
                } else if (data != null && data.getExtras() != null) {
                    Bitmap thumb = (Bitmap) data.getExtras().get("data");
                    if (thumb != null) imagePath = saveBitmapToCache(thumb);
                }
            } else if (requestCode == REQ_GALLERY && data != null && data.getData() != null) {
                imagePath = saveUriToCache(data.getData());
            }
        }

        if (imagePath != null) {
            routeImage(imagePath);
        } else {
            finish();
        }
    }

    // ── routing ───────────────────────────────────────────────────────────────

    private void routeImage(String imagePath) {
        int dest = SharedPrefHelper.getImageDest(this);

        if (dest == SharedPrefHelper.DEST_AI) {
            // Gemini Vision: send image directly (best quality, Gemini understands images)
            openGeminiVision(imagePath);
            finish();
            return;
        }

        // DEST_SEARCH or DEST_TRANSLATE: run ML Kit OCR on the image, route text
        Bitmap bmp = BitmapFactory.decodeFile(imagePath);
        if (bmp == null) {
            Toast.makeText(this, "Gagal membaca gambar", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        final int finalDest = dest;
        final Activity self = this;
        ScreenOcrHelper.runOcr(bmp, text -> {
            bmp.recycle();
            if (text.isEmpty()) {
                Toast.makeText(self,
                        "Tidak ada teks terdeteksi di gambar.\n" +
                        "Coba foto dengan resolusi lebih tinggi.",
                        Toast.LENGTH_LONG).show();
            } else {
                if (finalDest == SharedPrefHelper.DEST_TRANSLATE) {
                    openWebMode(WebActivity.MODE_TRANSLATE, text);
                } else {
                    openWebMode(WebActivity.MODE_SEARCH, text);
                }
            }
            self.finish();
        });
        // Don't call finish() here — wait for OCR callback
    }

    // ── open helpers ──────────────────────────────────────────────────────────

    private void openGeminiVision(String imagePath) {
        Intent intent = new Intent(this, GeminiWebViewActivity.class);
        intent.putExtra(GeminiWebViewActivity.EXTRA_QUERY, "");
        intent.putExtra(GeminiWebViewActivity.EXTRA_IMAGE_PATH, imagePath);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void openWebMode(int mode, String query) {
        Intent intent = new Intent(this, WebActivity.class);
        intent.putExtra(WebActivity.EXTRA_MODE, mode);
        intent.putExtra(WebActivity.EXTRA_QUERY, query);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    // ── save helpers ──────────────────────────────────────────────────────────

    private String saveUriToCache(Uri uri) {
        try {
            File out = new File(getCacheDir(), "img_" + System.currentTimeMillis() + ".jpg");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream fos = new FileOutputStream(out)) {
                if (in == null) return null;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
            }
            return out.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    private String saveBitmapToCache(Bitmap bmp) {
        try {
            File out = new File(getCacheDir(), "img_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream fos = new FileOutputStream(out)) {
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            }
            return out.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }
}
