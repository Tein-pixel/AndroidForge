// ScreenOcrHelper.java : java, Android 29+, com.media.access
// Wraps ML Kit bundled Latin text recognition.
// runOcr(Bitmap, OcrCallback) → asynchronous, callback on main thread.
// Caller owns the Bitmap; recycle it in onResult if no longer needed.
// No Play Services required. Latin model bundled in APK (~1.4 MB).
package com.media.access;

import android.graphics.Bitmap;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public final class ScreenOcrHelper {

    private ScreenOcrHelper() {}

    public interface OcrCallback {
        /** Called on the main thread. text is empty string on failure or no text found. */
        void onResult(String text);
    }

    /**
     * Run ML Kit OCR on {@code bitmap}.
     * Callback fires on the main thread via Tasks API default executor.
     * bitmap is not recycled here — caller decides lifecycle.
     */
    public static void runOcr(Bitmap bitmap, OcrCallback cb) {
        if (bitmap == null || bitmap.isRecycled()) {
            cb.onResult("");
            return;
        }
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        TextRecognizer recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    String text = result.getText().trim();
                    cb.onResult(text);
                    recognizer.close();
                })
                .addOnFailureListener(e -> {
                    cb.onResult("");
                    recognizer.close();
                });
    }
}
