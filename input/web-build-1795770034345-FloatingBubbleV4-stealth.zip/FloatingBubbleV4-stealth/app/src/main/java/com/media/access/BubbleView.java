// BubbleView.java : java, Android 29+, com.media.access
// Custom View that renders the floating bubble in 4 shapes:
//   CIRCLE (0), SQUARE (1), ROUNDED (2), TRIANGLE (3).
// Accepts a fill color and elevation shadow. Replaces the ImageButton + bubble_circle.xml approach.
package com.media.access;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

public class BubbleView extends View {

    // ── shape constants (mirror SharedPrefHelper) ─────────────────────────────
    public static final int SHAPE_CIRCLE   = 0;
    public static final int SHAPE_SQUARE   = 1;
    public static final int SHAPE_ROUNDED  = 2;
    public static final int SHAPE_TRIANGLE = 3;

    private int   shape = SHAPE_CIRCLE;
    private int   fillColor = 0xFF00BCD4;

    private final Paint  paint      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint  shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF  rectF       = new RectF();
    private final Path   triPath     = new Path();

    public BubbleView(Context ctx) {
        super(ctx);
        setLayerType(LAYER_TYPE_SOFTWARE, null); // needed for setShadowLayer
        applyPaints();
    }

    // ── public setters ────────────────────────────────────────────────────────

    public void setShape(int shape) {
        this.shape = shape;
        triPath.reset();
        invalidate();
    }

    public void setFillColor(int color) {
        this.fillColor = color;
        paint.setColor(color);
        invalidate();
    }

    // ── drawing ───────────────────────────────────────────────────────────────

    private void applyPaints() {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(fillColor);
        paint.setShadowLayer(14f, 0f, 4f, 0x66000000);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;
        float pad = 6f;
        paint.setColor(fillColor);

        switch (shape) {
            case SHAPE_CIRCLE:
                float cx = w / 2f;
                float cy = h / 2f;
                float r  = Math.min(cx, cy) - pad;
                canvas.drawCircle(cx, cy, r, paint);
                break;

            case SHAPE_SQUARE:
                rectF.set(pad, pad, w - pad, h - pad);
                canvas.drawRect(rectF, paint);
                break;

            case SHAPE_ROUNDED:
                rectF.set(pad, pad, w - pad, h - pad);
                float radius = Math.min(w, h) * 0.28f;
                canvas.drawRoundRect(rectF, radius, radius, paint);
                break;

            case SHAPE_TRIANGLE:
                triPath.reset();
                triPath.moveTo(w / 2f, pad);
                triPath.lineTo(w - pad, h - pad);
                triPath.lineTo(pad, h - pad);
                triPath.close();
                canvas.drawPath(triPath, paint);
                break;

            default:
                canvas.drawCircle(w / 2f, h / 2f, Math.min(w, h) / 2f - pad, paint);
        }
    }
}
