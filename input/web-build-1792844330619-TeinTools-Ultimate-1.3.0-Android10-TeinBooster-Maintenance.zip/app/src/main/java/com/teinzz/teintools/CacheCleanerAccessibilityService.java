package com.teinzz.teintools;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Explicit, user-started and deterministic Settings navigator for Android 10 cache cleanup.
 * It only looks for exact Storage and Clear cache labels. It never matches Clear data/storage,
 * sends no screen text to a network endpoint, and does not declare itself an accessibility tool.
 */
public final class CacheCleanerAccessibilityService extends AccessibilityService {
    static final String PREFS = "tein_tools_cache_automation";
    private static final long STEP_TIMEOUT_MS = 7500L;
    private static final long PAGE_SETTLE_MS = 650L;

    private static final List<String> STORAGE_LABELS = Arrays.asList(
            "storage", "storage & cache", "storage and cache", "storage usage", "app storage",
            "penyimpanan", "penyimpanan & cache", "penyimpanan dan cache", "penggunaan penyimpanan",
            "ruang penyimpanan", "pemakaian penyimpanan", "penyimpanan aplikasi"
    );
    private static final List<String> CLEAR_CACHE_LABELS = Arrays.asList(
            "clear cache", "hapus cache", "bersihkan cache", "hapus tembolok", "bersihkan tembolok"
    );
    private static final List<String> CACHE_ZERO_HINTS = Arrays.asList(
            "cache is empty", "cache kosong", "0 b cache", "cache: 0 b", "cache 0 b", "cache 0 kb"
    );

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable stepTimeout = this::handleTimeout;
    private boolean handlingEvent;
    private String timeoutArmedStep = "";

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        // Keep the service idle unless the user explicitly starts a cleanup run in TeinTools.
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || handlingEvent) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        CharSequence eventPackage = event.getPackageName();
        String packageName = eventPackage == null ? "" : eventPackage.toString();
        if (!isKnownSettingsPackage(packageName)) return;

        String step = prefs.getString("step", "app_info");
        if ("moving".equals(step) || "after_clear".equals(step) || "done".equals(step)) return;
        // Arm the timeout even if Android has not exposed the active window tree yet.
        armTimeoutForStep(step);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        handlingEvent = true;
        try {
            if ("app_info".equals(step)) {
                // Some OEM settings surfaces expose Clear cache directly. Exact label only.
                NodeMatch directCache = findExact(root, CLEAR_CACHE_LABELS);
                if (directCache != null) {
                    if (!directCache.node.isEnabled()) markCacheAction("already_clean");
                    else if (clickNodeOrClickableParent(directCache.node)) markCacheAction("cleared");
                    else markCacheAction("failed");
                    return;
                }
                NodeMatch storage = findExact(root, STORAGE_LABELS);
                if (storage != null && storage.node.isEnabled() && clickNodeOrClickableParent(storage.node)) {
                    prefs.edit().putString("step", "storage").apply();
                    armTimeoutForStep("storage");
                }
            } else if ("storage".equals(step)) {
                NodeMatch cache = findExact(root, CLEAR_CACHE_LABELS);
                if (cache != null) {
                    if (!cache.node.isEnabled()) markCacheAction("already_clean");
                    else if (clickNodeOrClickableParent(cache.node)) markCacheAction("cleared");
                    else markCacheAction("failed");
                } else if (containsAnyText(root, CACHE_ZERO_HINTS)) {
                    markCacheAction("already_clean");
                }
            }
        } finally {
            handlingEvent = false;
        }
    }

    @Override public void onInterrupt() { /* No continuous feedback or gestures are used. */ }

    @Override public boolean onUnbind(Intent intent) {
        handler.removeCallbacksAndMessages(null);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean("active", false)) {
            prefs.edit().putBoolean("active", false).putBoolean("verification_pending", false)
                    .putString("step", "interrupted").putString("current", "")
                    .putString("status", "Automation interrupted because Accessibility disconnected. Some apps may be untouched; rescan before trying again.").apply();
        }
        return super.onUnbind(intent);
    }

    private boolean isKnownSettingsPackage(String name) {
        String p = name.toLowerCase(Locale.ROOT);
        return p.equals("com.android.settings")
                || p.equals("com.coloros.safecenter")
                || p.equals("com.coloros.settings")
                || p.equals("com.oplus.safecenter")
                || p.equals("com.oplus.settings");
    }

    private void armTimeoutForStep(String step) {
        if (step == null || step.equals(timeoutArmedStep)) return;
        timeoutArmedStep = step;
        handler.removeCallbacks(stepTimeout);
        handler.postDelayed(stepTimeout, STEP_TIMEOUT_MS);
    }

    private void handleTimeout() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        String step = prefs.getString("step", "app_info");
        if ("app_info".equals(step) || "storage".equals(step)) {
            prefs.edit().putInt("failed", prefs.getInt("failed", 0) + 1).putString("step", "after_clear").apply();
            advanceToNext();
        }
    }

    private void markCacheAction(String result) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false) || "after_clear".equals(prefs.getString("step", ""))) return;
        SharedPreferences.Editor edit = prefs.edit().putString("step", "after_clear");
        if ("cleared".equals(result)) edit.putInt("cleared", prefs.getInt("cleared", 0) + 1);
        else if ("already_clean".equals(result)) edit.putInt("already_clean", prefs.getInt("already_clean", 0) + 1);
        else edit.putInt("failed", prefs.getInt("failed", 0) + 1);
        edit.apply();
        handler.removeCallbacks(stepTimeout);
        timeoutArmedStep = "";
        handler.postDelayed(this::advanceToNext, PAGE_SETTLE_MS);
    }

    private void advanceToNext() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        handler.removeCallbacks(stepTimeout);
        String queueRaw = prefs.getString("queue", "");
        String[] queue = queueRaw.isEmpty() ? new String[0] : queueRaw.split("\\n");
        int next = prefs.getInt("index", 0) + 1;
        prefs.edit().putInt("index", next).putString("step", "moving").apply();
        timeoutArmedStep = "";

        // Leave storage screen, then App info. Launch the next package's system-owned App info.
        handler.postDelayed(() -> {
            if (!getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("active", false)) return;
            performGlobalAction(GLOBAL_ACTION_BACK);
            handler.postDelayed(() -> {
                if (!getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("active", false)) return;
                performGlobalAction(GLOBAL_ACTION_BACK);
                handler.postDelayed(() -> {
                    if (!getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("active", false)) return;
                    if (next >= queue.length) finishRun();
                    else openQueueItem(queue, next);
                }, 350L);
            }, 350L);
        }, 350L);
    }

    private void openQueueItem(String[] queue, int index) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (index < 0 || index >= queue.length) { finishRun(); return; }
        String packageName = queue[index].trim();
        if (packageName.isEmpty()) {
            prefs.edit().putInt("failed", prefs.getInt("failed", 0) + 1).putString("step", "moving").apply();
            handler.postDelayed(this::advanceToNext, 150L);
            return;
        }
        prefs.edit().putString("current", packageName).putString("step", "app_info").apply();
        timeoutArmedStep = "";
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            armTimeoutForStep("app_info");
        } catch (Exception e) {
            prefs.edit().putInt("failed", prefs.getInt("failed", 0) + 1).putString("step", "moving").apply();
            handler.postDelayed(this::advanceToNext, 150L);
        }
    }

    private void finishRun() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("active", false)) return;
        int total = prefs.getInt("total", 0);
        int cleared = prefs.getInt("cleared", 0);
        int clean = prefs.getInt("already_clean", 0);
        int failed = prefs.getInt("failed", 0);
        String summary = "Finished · Clear-cache taps accepted: " + cleared + " · already clean: " + clean
                + " · skipped/unsupported: " + failed + " · apps queued: " + total
                + ". Rescan cache sizes to verify the result.";
        prefs.edit().putBoolean("active", false).putBoolean("verification_pending", true).putString("step", "done")
                .putString("status", summary).putString("current", "").putLong("finished_at", System.currentTimeMillis()).apply();
        handler.removeCallbacks(stepTimeout);
        timeoutArmedStep = "";
        handler.postDelayed(() -> {
            Intent back = new Intent(this, MainActivity.class);
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            back.putExtra("show_page", "cleaner");
            try { startActivity(back); } catch (Exception ignored) { }
        }, 500L);
    }

    private NodeMatch findExact(AccessibilityNodeInfo node, List<String> labels) {
        if (node == null) return null;
        CharSequence text = node.getText();
        if (text != null) {
            String value = normalize(text.toString());
            for (String label : labels) if (value.equals(normalize(label))) return new NodeMatch(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            NodeMatch match = findExact(node.getChild(i), labels);
            if (match != null) return match;
        }
        return null;
    }

    private boolean containsAnyText(AccessibilityNodeInfo node, List<String> labels) {
        if (node == null) return false;
        CharSequence text = node.getText();
        if (text != null) {
            String value = normalize(text.toString());
            for (String label : labels) if (value.contains(normalize(label))) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) if (containsAnyText(node.getChild(i), labels)) return true;
        return false;
    }

    private String normalize(String text) {
        return text == null ? "" : text.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private boolean clickNodeOrClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int depth = 0; current != null && depth < 5; depth++) {
            if (current.isEnabled() && current.isClickable()) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            current = current.getParent();
        }
        return false;
    }

    private static final class NodeMatch {
        final AccessibilityNodeInfo node;
        NodeMatch(AccessibilityNodeInfo node) { this.node = node; }
    }
}
