package com.tein.ninjector.manager

import android.content.Context
import android.content.pm.PackageManager

object NetworkManager {
    private val WHITELIST = setOf(
        MLManager.ML_PKG, "com.tein.ninjector",
        "com.android.systemui", "com.google.android.gms", "com.android.phone",
    )

    suspend fun setRestrictBackground(ctx: Context, restrict: Boolean): Result<Unit> {
        val action = if (restrict) "add" else "remove"
        val pkgs = ctx.packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName !in WHITELIST }.map { it.packageName }
        val cmd = pkgs.joinToString("; ") {
            "cmd netpolicy restrict-background-app $action $it 2>/dev/null"
        }
        return ShizukuManager.exec(cmd).map { }
    }

    suspend fun enablePingOptimizer(): Result<String> = ShizukuManager.exec(
        "settings put global wifi_scan_always_enabled 0; " +
        "settings put global wifi_background_scan_throttle_enabled 1; echo done"
    )

    suspend fun disablePingOptimizer(): Result<String> = ShizukuManager.exec(
        "settings put global wifi_scan_always_enabled 1; " +
        "settings delete global wifi_background_scan_throttle_enabled; echo done"
    )
}
