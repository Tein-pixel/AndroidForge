package com.tein.ninjector.ui.fitur

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.tein.ninjector.databinding.FragmentFiturBinding
import com.tein.ninjector.manager.*
import kotlinx.coroutines.launch

class FiturFragment : Fragment() {
    private var _b: FragmentFiturBinding? = null
    private val b get() = _b!!
    private var currentGfx = GFXManager.Preset.ORIGINAL
    private var currentFps = FPSManager.Mode.FPS_60

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentFiturBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        currentGfx = runCatching { GFXManager.Preset.valueOf(PrefsManager.gfxPreset) }
            .getOrDefault(GFXManager.Preset.ORIGINAL)
        currentFps = FPSManager.Mode.entries.firstOrNull { it.fps == PrefsManager.fpsMode }
            ?: FPSManager.Mode.FPS_60
        setupSwitches(); setupGfx(); setupFps(); setupButtons()
        onShizukuState(ShizukuManager.isReady)
    }

    fun onShizukuState(ready: Boolean) {
        if (_b == null) return
        b.tvResolusiInfo.text = if (ready) GFXManager.getInfo()
            else "Info layar dibaca setelah Shizuku terhubung"
    }

    private fun setupSwitches() {
        b.switchMap8bit.isChecked = PrefsManager.map8bit
        b.switchMap8bit.setOnCheckedChangeListener { _, c ->
            PrefsManager.map8bit = c
            lifecycleScope.launch {
                ArtManager.setMap8Bit(requireContext(), c)
                    .onSuccess { toast(it) }.onFailure { toast("Gagal: ${it.message}") }
            }
        }
        b.switchRestrictBg.isChecked = PrefsManager.restrictBackground
        b.switchRestrictBg.setOnCheckedChangeListener { _, c ->
            if (!requireShizuku()) { b.switchRestrictBg.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.restrictBackground = c
            lifecycleScope.launch {
                NetworkManager.setRestrictBackground(requireContext(), c)
                    .onSuccess { toast(if (c) "Data latar dibatasi" else "Batas dilepas") }
                    .onFailure { toast("Gagal: ${it.message}") }
            }
        }
        b.switchAntiLag.isChecked = PrefsManager.antiLag
        b.switchAntiLag.setOnCheckedChangeListener { _, c ->
            if (!requireShizuku()) { b.switchAntiLag.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.antiLag = c
            lifecycleScope.launch {
                (if (c) AntiLagManager.enable() else AntiLagManager.disable())
                    .onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }
        b.switchPingOpt.isChecked = PrefsManager.pingOptimizer
        b.switchPingOpt.setOnCheckedChangeListener { _, c ->
            if (!requireShizuku()) { b.switchPingOpt.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.pingOptimizer = c
            lifecycleScope.launch {
                (if (c) NetworkManager.enablePingOptimizer() else NetworkManager.disablePingOptimizer())
                    .onSuccess { toast(if (c) "Ping optimizer aktif" else "Ping optimizer off") }
                    .onFailure { toast("Gagal") }
            }
        }
    }

    private fun setupGfx() {
        val gfxMap: Map<GFXManager.Preset, Button> = mapOf(
            GFXManager.Preset.ORIGINAL to b.btnGfxOri,
            GFXManager.Preset.LIGHT    to b.btnGfxLight,
            GFXManager.Preset.RETRO    to b.btnGfxRetro,
            GFXManager.Preset.BLOCKY   to b.btnGfxBlocky,
            GFXManager.Preset.EXTREME  to b.btnGfxExtreme,
        )
        gfxMap.forEach { (preset, btn) ->
            btn.setOnClickListener {
                if (!requireShizuku()) return@setOnClickListener
                currentGfx = preset; updateGfxBtns(gfxMap)
                lifecycleScope.launch {
                    GFXManager.apply(preset).onSuccess { PrefsManager.gfxPreset = preset.name; toast(it) }
                        .onFailure { toast("Gagal") }
                }
            }
        }
        updateGfxBtns(gfxMap)
        b.btnGfxRestore.setOnClickListener {
            if (!requireShizuku()) return@setOnClickListener
            lifecycleScope.launch {
                GFXManager.restore().onSuccess {
                    currentGfx = GFXManager.Preset.ORIGINAL
                    updateGfxBtns(gfxMap)
                    PrefsManager.gfxPreset = GFXManager.Preset.ORIGINAL.name
                    toast(it)
                }.onFailure { toast("Gagal") }
            }
        }
    }

    private fun updateGfxBtns(map: Map<GFXManager.Preset, Button>) {
        map.forEach { (p, btn) ->
            val sel = p == currentGfx
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (sel) 0xFFFFFFFF.toInt() else 0xFF2A2A2A.toInt())
            btn.setTextColor(if (sel) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
    }

    private fun setupFps() {
        val fpsMap = mapOf(
            FPSManager.Mode.FPS_30  to b.btnFps30,
            FPSManager.Mode.FPS_60  to b.btnFps60,
            FPSManager.Mode.FPS_90  to b.btnFps90,
            FPSManager.Mode.FPS_120 to b.btnFps120,
        )
        fpsMap.forEach { (m, btn) ->
            btn.setOnClickListener {
                if (!requireShizuku()) return@setOnClickListener
                currentFps = m; updateFpsBtns(fpsMap)
                lifecycleScope.launch {
                    FPSManager.apply(m).onSuccess { PrefsManager.fpsMode = m.fps; toast(it) }
                        .onFailure { toast("Gagal") }
                }
            }
        }
        updateFpsBtns(fpsMap)
    }

    private fun updateFpsBtns(map: Map<FPSManager.Mode, Button>) {
        map.forEach { (m, btn) ->
            val sel = m == currentFps
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (sel) 0xFFFFFFFF.toInt() else 0xFF2A2A2A.toInt())
            btn.setTextColor(if (sel) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
    }

    private fun setupButtons() {
        b.btnBoost.setOnClickListener {
            if (!requireShizuku()) return@setOnClickListener
            lifecycleScope.launch {
                BoostManager.boost().onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }
        b.btnBersihkan.setOnClickListener {
            if (!requireShizuku()) return@setOnClickListener
            b.btnBersihkan.isEnabled = false
            lifecycleScope.launch {
                CacheManager.clearAll(requireContext())
                    .onSuccess { toast("Cache $it app dibersihkan") }
                    .onFailure { toast("Gagal") }
                b.btnBersihkan.isEnabled = true
            }
        }
        b.btnArtCompress.setOnClickListener {
            lifecycleScope.launch {
                b.progressDownload.visibility = View.VISIBLE
                ArtManager.onProgress = { p -> activity?.runOnUiThread { b.progressDownload.progress = p } }
                ArtManager.activateArtCompres(requireContext())
                    .onSuccess { toast(it) }.onFailure { toast("Gagal — cek URL di ArtManager") }
                b.progressDownload.visibility = View.GONE
            }
        }
        b.btnReduceData.setOnClickListener {
            lifecycleScope.launch {
                b.progressDownload.visibility = View.VISIBLE
                ArtManager.onProgress = { p -> activity?.runOnUiThread { b.progressDownload.progress = p } }
                ArtManager.activateReduceData(requireContext())
                    .onSuccess { toast(it) }.onFailure { toast("Gagal — cek URL di ArtManager") }
                b.progressDownload.visibility = View.GONE
            }
        }
    }

    private fun requireShizuku(): Boolean {
        return if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); false } else true
    }

    private fun toast(msg: String) = context?.let { Toast.makeText(it, msg, Toast.LENGTH_SHORT).show() }
    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
