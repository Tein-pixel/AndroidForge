package com.tein.ninjector.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.View
import android.view.WindowManager

/**
 * Floating crosshair overlay using TYPE_APPLICATION_OVERLAY.
 * Draws a red/white crosshair at the center of the screen.
 * Runs as a foreground service (required on API 26+).
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var overlayView: CrosshairView? = null

    companion object {
        const val CHANNEL_ID = "ninjector_overlay"
        const val NOTIF_ID   = 9001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        showCrosshair()
    }

    private fun showCrosshair() {
        val view = CrosshairView(this).also { overlayView = it }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(view, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayView?.let { runCatching { wm.removeView(it) } }
        overlayView = null
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, getString(R.string.overlay_channel),
            NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Ninjector")
            .setContentText(getString(R.string.overlay_notif))
            .build()

    // ── Custom View ─────────────────────────────────────────────────────────────
    private inner class CrosshairView(context: android.content.Context) : View(context) {
        private val paintLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.RED; strokeWidth = 2f; style = Paint.Style.STROKE
        }
        private val paintDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; strokeWidth = 3f
        }
        private val size = 20f  // half-length of crosshair arms

        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f
            // horizontal line
            c.drawLine(cx - size, cy, cx + size, cy, paintLine)
            // vertical line
            c.drawLine(cx, cy - size, cx, cy + size, paintLine)
            // center dot
            c.drawCircle(cx, cy, 3f, paintDot)
        }
    }
}

