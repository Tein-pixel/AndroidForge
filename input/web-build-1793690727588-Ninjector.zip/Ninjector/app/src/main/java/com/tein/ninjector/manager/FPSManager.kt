package com.tein.ninjector.manager

object FPSManager {
    enum class Mode(val fps: Int) { FPS_30(30), FPS_60(60), FPS_90(90), FPS_120(120) }

    suspend fun apply(mode: Mode): Result<String> = ShizukuManager.exec(
        "settings put system min_refresh_rate ${mode.fps} 2>/dev/null; " +
        "settings put system peak_refresh_rate ${mode.fps} 2>/dev/null; " +
        "wm refresh-rate ${mode.fps} 2>/dev/null; echo done"
    ).map { "${mode.fps}fps diterapkan" }
}
