package com.tein.ninjector.manager

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object CacheManager {
    suspend fun clearAll(ctx: Context): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val pkgs = ctx.packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                .map { it.packageName }
            val cmd = pkgs.joinToString("; ") { "pm clear --cache-only $it 2>/dev/null" }
            ShizukuManager.exec(cmd).getOrThrow()
            pkgs.size
        }
    }

    suspend fun clearMLCache(): Result<String> =
        ShizukuManager.exec(
            "rm -rf ${MLManager.ML_CACHE}/* 2>/dev/null; " +
            "pm clear --cache-only ${MLManager.ML_PKG} 2>/dev/null; echo done"
        )
}
