package com.tein.ninjector.manager

object BoostManager {
    suspend fun boost(): Result<String> =
        ShizukuManager.exec("am kill-all").map { "RAM dibebaskan" }
}
