package com.tein.ninjector.ui.drone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.tein.ninjector.R
import com.tein.ninjector.databinding.FragmentDroneBinding
import com.tein.ninjector.manager.DroneManager
import com.tein.ninjector.manager.MLManager
import com.tein.ninjector.manager.PrefsManager
import com.tein.ninjector.manager.ShizukuManager
import kotlinx.coroutines.launch

class DroneFragment : Fragment() {
    private var _b: FragmentDroneBinding? = null
    private val b get() = _b!!
    private var current = DroneManager.Mode.ORIGINAL

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentDroneBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        current = runCatching { DroneManager.Mode.valueOf(PrefsManager.droneMode) }
            .getOrDefault(DroneManager.Mode.ORIGINAL)
        refreshML()
        refreshShizuku(ShizukuManager.isReady)
        setupButtons()
        updateApplyBtn()
        b.btnApply.setOnClickListener { applyDrone() }
    }

    private fun refreshML() {
        val info = MLManager.getInfo(requireContext())
        b.tvMlName.text    = "Mobile Legends"
        b.tvMlVersion.text = if (info.installed) "Versi ${info.versionName}" else "Tidak terinstall"
        b.btnOpenMl.setOnClickListener { MLManager.launch(requireContext()) }
    }

    fun onShizukuState(ready: Boolean) {
        if (_b == null) return; refreshShizuku(ready)
    }

    private fun refreshShizuku(ready: Boolean) {
        b.tvShizukuStatus.text = if (ready) "Shizuku terhubung" else "Shizuku tidak terhubung"
        b.tvShizukuSub.text    = if (ready) "Semua fitur tersedia" else "Jalankan Shizuku lalu periksa lagi"
        b.ivShizukuDot.setImageResource(
            if (ready) android.R.drawable.presence_online else android.R.drawable.presence_offline)
        b.btnShizukuBadge.text = if (ready) "ONLINE" else "OFFLINE"
    }

    private fun setupButtons() {
        val map: Map<DroneManager.Mode, Button> = mapOf(
            DroneManager.Mode.ORIGINAL to b.btnOri,
            DroneManager.Mode.X2       to b.btnX2,
            DroneManager.Mode.X4       to b.btnX4,
            DroneManager.Mode.X6       to b.btnX6,
            DroneManager.Mode.X8       to b.btnX8,
        )
        map.forEach { (mode, btn) ->
            btn.setOnClickListener {
                current = mode; updateSelected(map)
                b.tvDroneLabel.text = mode.label; updateApplyBtn()
            }
        }
        updateSelected(map)
    }

    private fun updateSelected(map: Map<DroneManager.Mode, Button>) {
        map.forEach { (mode, btn) ->
            val sel = mode == current
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (sel) 0xFFFFFFFF.toInt() else 0xFF2A2A2A.toInt())
            btn.setTextColor(if (sel) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
    }

    private fun updateApplyBtn() { b.btnApply.text = "Terapkan ${current.label}" }

    private fun applyDrone() {
        if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); return }
        b.btnApply.isEnabled = false
        lifecycleScope.launch {
            DroneManager.apply(current)
                .onSuccess { PrefsManager.droneMode = current.name; toast(it) }
                .onFailure { toast("Gagal: ${it.message}") }
            b.btnApply.isEnabled = true
        }
    }

    private fun toast(msg: String) = context?.let { Toast.makeText(it, msg, Toast.LENGTH_SHORT).show() }
    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
