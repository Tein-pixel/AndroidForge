package com.tein.ninjector.manager

object AntiLagManager {
    suspend fun enable(): Result<String> = ShizukuManager.exec(
        "pid=\$(pidof ${MLManager.ML_PKG}); [ -n \"\$pid\" ] && renice -n -10 \$pid 2>/dev/null; " +
        "for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do " +
        "  echo performance > \$g 2>/dev/null || echo interactive > \$g 2>/dev/null; done; echo done"
    ).map { "Anti-Lag aktif" }

    suspend fun disable(): Result<String> = ShizukuManager.exec(
        "for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do " +
        "  echo schedutil > \$g 2>/dev/null || echo ondemand > \$g 2>/dev/null; done; echo done"
    ).map { "Anti-Lag off" }
}
