package com.tein.ninjector.manager

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object SkinManager {

    // ML stores hero/skin preference in several JSON config files under
    // external storage. We scan for the hero_id key and patch the skin_id.
    // This is cosmetic-only on the local device; server validates actual ownership.
    private val ML_FILES = MLManager.ML_FILES

    suspend fun patchSkin(heroId: Int, skinId: Int): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            // Try JSON patch via shell sed — works on config files ML writes locally
            val result = ShizukuManager.exec(
                // Find all JSON files in ML's files dir containing the hero id
                "find $ML_FILES -maxdepth 6 -name '*.json' 2>/dev/null | " +
                "xargs grep -l '"hero_id"\|"heroId"\|"heroid"' 2>/dev/null | " +
                "head -5 | while IFS= read -r f; do " +
                // Patch hero $heroId skin to $skinId
                "  sed -i 's/"hero_id":\s*$heroId,\s*"skin_id":[0-9]*/"hero_id":$heroId,"skin_id":$skinId/g' \"\$f\" 2>/dev/null; " +
                "  sed -i 's/"heroId\":\"$heroId\",\"skinId\":\"[0-9]*/\"heroId\":\"$heroId\",\"skinId\":\"$skinId/g' \"\$f\" 2>/dev/null; " +
                "done; echo patched"
            ).getOrThrow()

            // Also try to write a direct preference file
            val prefFile = File("$ML_FILES/skin_override.json")
            val json = "{"hero_id":$heroId,"skin_id":$skinId,"override":true}"
            ShizukuManager.exec("echo '$json' > ${prefFile.absolutePath} 2>/dev/null")

            "Skin patch selesai — hero=$heroId skin=$skinId. Restart ML."
        }
    }

    suspend fun resetSkins(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            ShizukuManager.exec(
                "rm -f $ML_FILES/skin_override.json 2>/dev/null; " +
                "pm clear --cache-only ${MLManager.ML_PKG} 2>/dev/null; echo done"
            ).getOrThrow()
            "Skin direset — restart ML"
        }
    }
}
