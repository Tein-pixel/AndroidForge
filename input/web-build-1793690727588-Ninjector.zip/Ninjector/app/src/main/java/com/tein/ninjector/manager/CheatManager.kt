package com.tein.ninjector.manager

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object CheatManager {

    // ── LAG SWITCH ─────────────────────────────────────────────────────────────
    // Toggles airplane mode on/off to create a deliberate lag spike.
    // Works via settings provider — requires Shizuku shell.
    suspend fun lagOnce(durationMs: Long): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            ShizukuManager.exec("settings put global airplane_mode_on 1; " +
                "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true 2>/dev/null")
                .getOrThrow()
            delay(durationMs)
            ShizukuManager.exec("settings put global airplane_mode_on 0; " +
                "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false 2>/dev/null")
                .getOrThrow()
            "Lag spike ${durationMs}ms selesai"
        }
    }

    suspend fun setAirplane(on: Boolean): Result<String> {
        val v = if (on) 1 else 0
        val state = if (on) "true" else "false"
        return ShizukuManager.exec(
            "settings put global airplane_mode_on $v; " +
            "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state $state 2>/dev/null"
        ).map { if (on) "Lag switch ON" else "Lag switch OFF" }
    }

    // ── NO GRASS / NO BUSH ─────────────────────────────────────────────────────
    // Renames/blanks grass texture files in ML external storage.
    // ML renders black or empty terrain where grass would be → enemies visible.
    // GRASS_DIR: adapt path per ML version if needed.
    private const val GRASS_DIR = "${MLManager.ML_FILES}/res/textures"

    suspend fun setNoGrass(enable: Boolean): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            if (enable) {
                // Find files with grass/bush/foliage in name and zero-out them
                ShizukuManager.exec(
                    "find $GRASS_DIR -type f \( -iname '*grass*' -o -iname '*bush*' " +
                    "-o -iname '*foliage*' -o -iname '*plant*' \) 2>/dev/null | " +
                    "while IFS= read -r f; do " +
                    "  cp \"\$f\" \"\${f}.bak\" 2>/dev/null; " +
                    "  : > \"\$f\"; " +  // truncate to 0 bytes
                    "done; echo done"
                ).getOrThrow()
                "No Grass aktif — restart ML"
            } else {
                // Restore .bak files
                ShizukuManager.exec(
                    "find $GRASS_DIR -name '*.bak' 2>/dev/null | " +
                    "while IFS= read -r f; do mv \"\$f\" \"\${f%.bak}\"; done; echo done"
                ).getOrThrow()
                "Grass dipulihkan — restart ML"
            }
        }
    }

    // ── SPEED BOOST ────────────────────────────────────────────────────────────
    // Raises ML process priority to the highest allowed by shell (non-root).
    // Also tries to lock all CPU cores to max freq via cpufreq sysfs.
    suspend fun setSpeedBoost(enable: Boolean): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            if (enable) {
                ShizukuManager.exec(
                    "pid=\$(pidof ${MLManager.ML_PKG}); " +
                    "[ -n \"\$pid\" ] && renice -n -20 \$pid 2>/dev/null; " +
                    "for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do " +
                    "  max=\$(cat \$cpu/scaling_max_freq 2>/dev/null); " +
                    "  [ -n \"\$max\" ] && echo \$max > \$cpu/scaling_min_freq 2>/dev/null; " +
                    "  echo performance > \$cpu/scaling_governor 2>/dev/null; " +
                    "done; echo done"
                ).getOrThrow()
                "Speed Boost aktif"
            } else {
                ShizukuManager.exec(
                    "for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do " +
                    "  min=\$(cat \$cpu/cpuinfo_min_freq 2>/dev/null); " +
                    "  [ -n \"\$min\" ] && echo \$min > \$cpu/scaling_min_freq 2>/dev/null; " +
                    "  echo schedutil > \$cpu/scaling_governor 2>/dev/null || " +
                    "  echo ondemand > \$cpu/scaling_governor 2>/dev/null; " +
                    "done; echo done"
                ).getOrThrow()
                "Speed Boost off"
            }
        }
    }

    // ── AUTO CLICKER via shell input ───────────────────────────────────────────
    // Fires input tap at (x,y) via Shizuku shell — no accessibility service needed.
    // Runs in a loop on caller's coroutine scope; cancel the job to stop.
    @Volatile var clickerRunning = false

    suspend fun runAutoClicker(x: Int, y: Int, intervalMs: Long): Nothing = withContext(Dispatchers.IO) {
        clickerRunning = true
        try {
            while (clickerRunning) {
                ShizukuManager.exec("input tap $x $y")
                delay(intervalMs)
            }
        } finally {
            clickerRunning = false
        }
        error("unreachable")
    }

    fun stopClicker() { clickerRunning = false }

    // ── MACRO SKILL ────────────────────────────────────────────────────────────
    // Fires a sequence of taps with configurable delay between each.
    @Volatile var macroRunning = false

    suspend fun runMacro(
        s1x: Int, s1y: Int,
        s2x: Int, s2y: Int,
        ultX: Int, ultY: Int,
        delayMs: Long,
        loops: Int
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            macroRunning = true
            var loop = 0
            while (macroRunning && (loops <= 0 || loop < loops)) {
                ShizukuManager.exec("input tap $s1x $s1y"); delay(delayMs)
                if (!macroRunning) break
                ShizukuManager.exec("input tap $s2x $s2y"); delay(delayMs)
                if (!macroRunning) break
                ShizukuManager.exec("input tap $ultX $ultY"); delay(delayMs)
                loop++
            }
            macroRunning = false
            "Macro selesai — $loop loop"
        }
    }

    fun stopMacro() { macroRunning = false }

    // ── CUSTOM SHELL ───────────────────────────────────────────────────────────
    suspend fun execShell(cmd: String): Result<String> = ShizukuManager.exec(cmd)
}
