package com.tein.ninjector.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility-based auto clicker.
 * Uses dispatchGesture() for reliable in-game tapping — more accurate
 * than shell 'input tap' because it fires through the accessibility framework
 * directly into the touch event pipeline.
 *
 * Send broadcast ACTION_START with extras X, Y, INTERVAL_MS to activate.
 * Send ACTION_STOP to deactivate.
 */
class AutoClickerService : AccessibilityService() {

    companion object {
        const val ACTION_START    = "com.tein.ninjector.CLICKER_START"
        const val ACTION_STOP     = "com.tein.ninjector.CLICKER_STOP"
        const val EXTRA_X         = "x"
        const val EXTRA_Y         = "y"
        const val EXTRA_INTERVAL  = "interval_ms"

        @Volatile var isRunning = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var tapX = 540f
    private var tapY = 960f
    private var intervalMs = 300L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_START -> {
                    tapX       = intent.getIntExtra(EXTRA_X, 540).toFloat()
                    tapY       = intent.getIntExtra(EXTRA_Y, 960).toFloat()
                    intervalMs = intent.getLongExtra(EXTRA_INTERVAL, 300L)
                    startTapping()
                }
                ACTION_STOP -> stopTapping()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter().apply {
            addAction(ACTION_START); addAction(ACTION_STOP)
        }
        registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopTapping() }

    private fun startTapping() {
        isRunning = true
        scheduleTap()
    }

    private fun stopTapping() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun scheduleTap() {
        if (!isRunning) return
        val path = Path().apply { moveTo(tapX, tapY) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 50L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gesture: GestureDescription?) {
                if (isRunning) handler.postDelayed({ scheduleTap() }, intervalMs)
            }
            override fun onCancelled(gesture: GestureDescription?) {
                if (isRunning) handler.postDelayed({ scheduleTap() }, intervalMs)
            }
        }, handler)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTapping()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}
