package com.tein.ninjector.manager

import android.content.Context
import android.content.pm.PackageManager

object MLManager {
    const val ML_PKG   = "com.mobile.legends"
    const val ML_EXT   = "/sdcard/Android/data/$ML_PKG"
    const val ML_FILES = "$ML_EXT/files"
    const val ML_CACHE = "$ML_EXT/cache"

    data class MLInfo(val installed: Boolean, val versionName: String)

    fun getInfo(ctx: Context): MLInfo = try {
        val pi = ctx.packageManager.getPackageInfo(ML_PKG, 0)
        MLInfo(true, pi.versionName ?: "?")
    } catch (_: PackageManager.NameNotFoundException) { MLInfo(false, "") }

    fun launch(ctx: Context) {
        ctx.packageManager.getLaunchIntentForPackage(ML_PKG)
            ?.let { ctx.startActivity(it) }
    }
}
