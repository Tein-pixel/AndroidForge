package com.tein.ninjector.manager

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

object DroneManager {
    enum class Mode(val label: String, val divisor: Int) {
        ORIGINAL("Original", 1),
        X2("×2",  2),
        X4("×4",  4),
        X6("×6",  6),
        X8("×8",  8),
    }

    private var realW = 1080
    private var realH = 1920

    fun init(ctx: Context) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wm.currentWindowMetrics.bounds.also { realW = it.width(); realH = it.height() }
        } else {
            @Suppress("DEPRECATION")
            DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it)
                realW = it.widthPixels; realH = it.heightPixels }
        }
    }

    suspend fun apply(mode: Mode): Result<String> {
        val cmd = if (mode == Mode.ORIGINAL) "wm size reset"
                  else "wm size ${realW / mode.divisor}x${realH / mode.divisor}"
        return ShizukuManager.exec(cmd).map { "Drone ${mode.label} diterapkan" }
    }
}
