package com.tein.ninjector.ui.cheat

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.tein.ninjector.databinding.FragmentCheatBinding
import com.tein.ninjector.manager.*
import com.tein.ninjector.service.AutoClickerService
import com.tein.ninjector.service.OverlayService
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class CheatFragment : Fragment() {
    private var _b: FragmentCheatBinding? = null
    private val b get() = _b!!

    private var clickerJob: Job? = null
    private var macroJob:   Job? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentCheatBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        restoreToggles()
        setupAutoClicker()
        setupMacro()
        setupSkin()
        setupVisual()
        setupLag()
        setupShell()
    }

    fun onShizukuState(ready: Boolean) { /* update UI if needed */ }

    // ── AUTO CLICKER ──────────────────────────────────────────────────────────
    private fun setupAutoClicker() {
        b.btnClickerStart.setOnClickListener {
            val x   = b.etClickX.text.toString().toIntOrNull() ?: 540
            val y   = b.etClickY.text.toString().toIntOrNull() ?: 960
            val ms  = b.etClickInterval.text.toString().toLongOrNull() ?: 300L

            if (ShizukuManager.isReady) {
                // Shell-based clicker
                CheatManager.stopClicker()
                clickerJob?.cancel()
                clickerJob = lifecycleScope.launch {
                    b.tvClickerStatus.text = "Running via shell — ${x}x${y} @ ${ms}ms"
                    CheatManager.runAutoClicker(x, y, ms)
                }
            } else {
                // Accessibility-based clicker (requires service enabled in settings first)
                val intent = Intent(AutoClickerService.ACTION_START).apply {
                    setPackage(requireContext().packageName)
                    putExtra(AutoClickerService.EXTRA_X, x)
                    putExtra(AutoClickerService.EXTRA_Y, y)
                    putExtra(AutoClickerService.EXTRA_INTERVAL, ms)
                }
                requireContext().sendBroadcast(intent)
                b.tvClickerStatus.text = "Running via Accessibility — ${x}x${y} @ ${ms}ms"
            }
        }
        b.btnClickerStop.setOnClickListener {
            clickerJob?.cancel(); CheatManager.stopClicker()
            requireContext().sendBroadcast(
                Intent(AutoClickerService.ACTION_STOP).setPackage(requireContext().packageName))
            b.tvClickerStatus.text = "Idle"
        }
    }

    // ── MACRO SKILL ──────────────────────────────────────────────────────────
    private fun setupMacro() {
        b.btnMacroRun.setOnClickListener {
            if (!requireShizuku()) return@setOnClickListener
            val s1x = b.etSkill1X.text.toString().toIntOrNull() ?: 320
            val s1y = b.etSkill1Y.text.toString().toIntOrNull() ?: 1750
            val s2x = b.etSkill2X.text.toString().toIntOrNull() ?: 460
            val s2y = b.etSkill2Y.text.toString().toIntOrNull() ?: 1750
            val ux  = b.etUltX.text.toString().toIntOrNull() ?: 600
            val uy  = b.etUltY.text.toString().toIntOrNull() ?: 1750
            val del = b.etMacroDelay.text.toString().toLongOrNull() ?: 150L
            val lp  = b.etMacroLoops.text.toString().toIntOrNull() ?: 3

            macroJob?.cancel()
            macroJob = lifecycleScope.launch {
                b.tvMacroStatus.text = "Running — loop 0/$lp"
                CheatManager.runMacro(s1x, s1y, s2x, s2y, ux, uy, del, lp)
                    .onSuccess { b.tvMacroStatus.text = it }
                    .onFailure { b.tvMacroStatus.text = "Error: ${it.message}" }
            }
        }
        b.btnMacroStop.setOnClickListener {
            macroJob?.cancel(); CheatManager.stopMacro()
            b.tvMacroStatus.text = "Dihentikan"
        }
    }

    // ── SKIN PATCHER ─────────────────────────────────────────────────────────
    private fun setupSkin() {
        b.btnSkinPatch.setOnClickListener {
            val heroId = b.etSkinHero.text.toString().toIntOrNull() ?: 0
            val skinId = b.etSkinId.text.toString().toIntOrNull() ?: 0
            if (heroId == 0) { toast("Masukkan Hero ID"); return@setOnClickListener }
            lifecycleScope.launch {
                SkinManager.patchSkin(heroId, skinId)
                    .onSuccess { b.tvSkinResult.text = it }
                    .onFailure { b.tvSkinResult.text = "Gagal: ${it.message}" }
            }
        }
        b.btnSkinReset.setOnClickListener {
            lifecycleScope.launch {
                SkinManager.resetSkins()
                    .onSuccess { b.tvSkinResult.text = it }
                    .onFailure { b.tvSkinResult.text = "Gagal" }
            }
        }
    }

    // ── VISUAL HACKS ─────────────────────────────────────────────────────────
    private fun setupVisual() {
        b.switchNoGrass.isChecked = PrefsManager.noGrass
        b.switchNoGrass.setOnCheckedChangeListener { _, checked ->
            if (!requireShizuku()) { b.switchNoGrass.isChecked = !checked; return@setOnCheckedChangeListener }
            PrefsManager.noGrass = checked
            lifecycleScope.launch {
                CheatManager.setNoGrass(checked)
                    .onSuccess { toast(it) }.onFailure { toast("Gagal: ${it.message}") }
            }
        }

        b.switchOverlay.isChecked = PrefsManager.overlayEnabled
        b.switchOverlay.setOnCheckedChangeListener { _, checked ->
            PrefsManager.overlayEnabled = checked
            if (checked) {
                if (!Settings.canDrawOverlays(requireContext())) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                    b.switchOverlay.isChecked = false
                    return@setOnCheckedChangeListener
                }
                requireContext().startForegroundService(Intent(requireContext(), OverlayService::class.java))
                toast("Crosshair aktif")
            } else {
                requireContext().stopService(Intent(requireContext(), OverlayService::class.java))
                toast("Crosshair off")
            }
        }

        b.switchSpeedBoost.isChecked = PrefsManager.speedBoost
        b.switchSpeedBoost.setOnCheckedChangeListener { _, checked ->
            if (!requireShizuku()) { b.switchSpeedBoost.isChecked = !checked; return@setOnCheckedChangeListener }
            PrefsManager.speedBoost = checked
            lifecycleScope.launch {
                CheatManager.setSpeedBoost(checked)
                    .onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }
    }

    // ── LAG SWITCH ───────────────────────────────────────────────────────────
    private fun setupLag() {
        b.switchLag.setOnCheckedChangeListener { _, checked ->
            if (!requireShizuku()) { b.switchLag.isChecked = !checked; return@setOnCheckedChangeListener }
            lifecycleScope.launch {
                CheatManager.setAirplane(checked)
                    .onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }
        b.btnLagOnce.setOnClickListener {
            if (!requireShizuku()) return@setOnClickListener
            val dur = b.etLagDuration.text.toString().toLongOrNull() ?: 1500L
            lifecycleScope.launch {
                b.btnLagOnce.isEnabled = false
                CheatManager.lagOnce(dur)
                    .onSuccess { toast(it) }.onFailure { toast("Gagal: ${it.message}") }
                b.btnLagOnce.isEnabled = true
                b.switchLag.isChecked = false
            }
        }
    }

    // ── CUSTOM SHELL ─────────────────────────────────────────────────────────
    private fun setupShell() {
        b.btnShellExec.setOnClickListener {
            val cmd = b.etShellCmd.text.toString().trim()
            if (cmd.isEmpty()) return@setOnClickListener
            if (!requireShizuku()) return@setOnClickListener
            b.tvShellOutput.visibility = View.VISIBLE
            b.tvShellOutput.text = "Menjalankan..."
            lifecycleScope.launch {
                CheatManager.execShell(cmd)
                    .onSuccess { b.tvShellOutput.text = it.ifEmpty { "(no output)" } }
                    .onFailure { b.tvShellOutput.text = "Error: ${it.message}" }
            }
        }
    }

    private fun restoreToggles() {
        // switches restored in setupVisual; keep state from prefs
    }

    private fun requireShizuku(): Boolean {
        return if (!ShizukuManager.isReady) {
            toast("Shizuku diperlukan untuk fitur ini"); false
        } else true
    }

    private fun toast(msg: String) = context?.let { Toast.makeText(it, msg, Toast.LENGTH_SHORT).show() }
    override fun onDestroyView() {
        super.onDestroyView()
        clickerJob?.cancel(); macroJob?.cancel()
        _b = null
    }
}
