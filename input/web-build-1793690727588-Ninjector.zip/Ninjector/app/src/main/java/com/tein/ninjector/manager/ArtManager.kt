package com.tein.ninjector.manager

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipFile

object ArtManager {
    // FILL: ganti URL dengan server CDN milik Sam
    private const val ART_COMPRESS_URL = "https://YOUR_SERVER/ml_art_compressed.zip"
    private const val REDUCE_DATA_URL  = "https://YOUR_SERVER/ml_art_reduced.zip"

    var onProgress: ((Int) -> Unit)? = null

    suspend fun setMap8Bit(ctx: Context, enable: Boolean): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (enable) {
                    val assets = ctx.assets.list("map_8bit") ?: emptyArray()
                    val mapDir = File("${MLManager.ML_FILES}/map").also { it.mkdirs() }
                    assets.forEach { name ->
                        ctx.assets.open("map_8bit/$name").use { inp ->
                            File(mapDir, name).outputStream().use { inp.copyTo(it) }
                        }
                    }
                    if (assets.isEmpty()) "Tambahkan file ke assets/map_8bit/" else "MAP 8BIT aktif — ${assets.size} file"
                } else {
                    ShizukuManager.exec("pm clear --cache-only ${MLManager.ML_PKG}")
                    "MAP 8BIT off — buka ML untuk reload"
                }
            }
        }

    suspend fun activateArtCompres(ctx: Context): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val dest = File(ctx.cacheDir, "art_c.zip")
            download(ART_COMPRESS_URL, dest)
            unzip(dest, File("${MLManager.ML_FILES}/art"))
            dest.delete(); "Art Compres aktif"
        }
    }

    suspend fun activateReduceData(ctx: Context): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val dest = File(ctx.cacheDir, "art_r.zip")
            download(REDUCE_DATA_URL, dest)
            unzip(dest, File("${MLManager.ML_FILES}/art"))
            dest.delete(); "Reduce Data aktif"
        }
    }

    private fun download(url: String, dest: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connect()
        val total = conn.contentLength.toLong()
        conn.inputStream.use { inp ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(8192); var dl = 0L; var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n); dl += n
                    if (total > 0) onProgress?.invoke(((dl * 100) / total).toInt())
                }
            }
        }
        conn.disconnect()
    }

    private fun unzip(zip: File, target: File) {
        target.mkdirs()
        ZipFile(zip).use { zf ->
            zf.entries().asSequence().forEach { e ->
                val out = File(target, e.name)
                if (e.isDirectory) out.mkdirs()
                else { out.parentFile?.mkdirs()
                    zf.getInputStream(e).use { i -> out.outputStream().use { i.copyTo(it) } }
                }
            }
        }
    }
}
