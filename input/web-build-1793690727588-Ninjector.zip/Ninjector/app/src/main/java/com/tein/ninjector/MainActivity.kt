package com.tein.ninjector

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.tein.ninjector.databinding.ActivityMainBinding
import com.tein.ninjector.manager.*
import com.tein.ninjector.ui.about.AboutFragment
import com.tein.ninjector.ui.cheat.CheatFragment
import com.tein.ninjector.ui.drone.DroneFragment
import com.tein.ninjector.ui.fitur.FiturFragment

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val droneFragment by lazy { DroneFragment() }
    private val fiturFragment by lazy { FiturFragment() }
    private val cheatFragment by lazy { CheatFragment() }
    private val aboutFragment by lazy { AboutFragment() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        PrefsManager.init(this)
        DroneManager.init(this)
        GFXManager.init(this)

        ShizukuManager.init { connected ->
            val ready = connected && ShizukuManager.hasPermission()
            runOnUiThread {
                droneFragment.onShizukuState(ready)
                fiturFragment.onShizukuState(ready)
                cheatFragment.onShizukuState(ready)
            }
        }

        ShizukuManager.requestPermission { granted ->
            val ready = ShizukuManager.isConnected && granted
            runOnUiThread {
                droneFragment.onShizukuState(ready)
                fiturFragment.onShizukuState(ready)
                cheatFragment.onShizukuState(ready)
            }
        }

        b.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_drone -> { showFragment(droneFragment); true }
                R.id.nav_fitur -> { showFragment(fiturFragment); true }
                R.id.nav_cheat -> { showFragment(cheatFragment); true }
                R.id.nav_about -> { showFragment(aboutFragment); true }
                else -> false
            }
        }

        if (savedInstanceState == null) showFragment(droneFragment)
        requestStorage()
    }

    private fun showFragment(target: Fragment) {
        val tag = target::class.simpleName ?: return
        val fm = supportFragmentManager
        val tx = fm.beginTransaction()
        if (fm.findFragmentByTag(tag) == null) tx.add(R.id.fragment_container, target, tag)
        else tx.show(target)
        fm.fragments.filter { it != target && it.isAdded }.forEach { tx.hide(it) }
        tx.commit()
    }

    private fun requestStorage() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R &&
            !Environment.isExternalStorageManager()) {
            runCatching {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
    }

    override fun onDestroy() { super.onDestroy(); ShizukuManager.destroy() }
}
