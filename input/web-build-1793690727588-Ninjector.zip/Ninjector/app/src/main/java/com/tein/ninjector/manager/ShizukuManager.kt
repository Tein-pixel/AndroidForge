package com.tein.ninjector.manager

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object ShizukuManager {
    private const val PERM_CODE = 1001
    var isConnected = false
        private set
    private var stateCallback: ((Boolean) -> Unit)? = null
    private var permCallback: ((Boolean) -> Unit)? = null

    private val onReceived = Shizuku.OnBinderReceivedListener {
        isConnected = true; stateCallback?.invoke(true)
    }
    private val onDead = Shizuku.OnBinderDeadListener {
        isConnected = false; stateCallback?.invoke(false)
    }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == PERM_CODE) permCallback?.invoke(result == PackageManager.PERMISSION_GRANTED)
    }

    fun init(onState: (Boolean) -> Unit) {
        stateCallback = onState
        Shizuku.addBinderReceivedListenerSticky(onReceived)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    fun destroy() {
        Shizuku.removeBinderReceivedListener(onReceived)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: IllegalStateException) { false }

    fun requestPermission(onResult: (Boolean) -> Unit) {
        permCallback = onResult
        try { Shizuku.requestPermission(PERM_CODE) } catch (_: Exception) { onResult(false) }
    }

    val isReady: Boolean get() = isConnected && hasPermission()

    suspend fun exec(cmd: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val proc = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val out = proc.inputStream.bufferedReader().use { it.readText() }.trim()
            val err = proc.errorStream.bufferedReader().use { it.readText() }.trim()
            proc.waitFor()
            if (out.isEmpty() && err.isNotEmpty()) err else out
        }
    }

    suspend fun execMulti(vararg cmds: String): List<Result<String>> =
        cmds.map { exec(it) }
}
