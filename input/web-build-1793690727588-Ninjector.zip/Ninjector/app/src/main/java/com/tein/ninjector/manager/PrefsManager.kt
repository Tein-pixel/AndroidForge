package com.tein.ninjector.manager

import android.content.Context
import android.content.SharedPreferences

object PrefsManager {
    private const val NAME = "ninjector_prefs"
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
    }

    var droneMode: String
        get() = prefs.getString("drone_mode", "ORIGINAL") ?: "ORIGINAL"
        set(v) = prefs.edit().putString("drone_mode", v).apply()

    var gfxPreset: String
        get() = prefs.getString("gfx_preset", "ORIGINAL") ?: "ORIGINAL"
        set(v) = prefs.edit().putString("gfx_preset", v).apply()

    var fpsMode: Int
        get() = prefs.getInt("fps_mode", 60)
        set(v) = prefs.edit().putInt("fps_mode", v).apply()

    var map8bit: Boolean
        get() = prefs.getBoolean("map_8bit", false)
        set(v) = prefs.edit().putBoolean("map_8bit", v).apply()

    var restrictBackground: Boolean
        get() = prefs.getBoolean("restrict_bg", false)
        set(v) = prefs.edit().putBoolean("restrict_bg", v).apply()

    var antiLag: Boolean
        get() = prefs.getBoolean("anti_lag", false)
        set(v) = prefs.edit().putBoolean("anti_lag", v).apply()

    var pingOptimizer: Boolean
        get() = prefs.getBoolean("ping_opt", false)
        set(v) = prefs.edit().putBoolean("ping_opt", v).apply()

    var noGrass: Boolean
        get() = prefs.getBoolean("no_grass", false)
        set(v) = prefs.edit().putBoolean("no_grass", v).apply()

    var speedBoost: Boolean
        get() = prefs.getBoolean("speed_boost", false)
        set(v) = prefs.edit().putBoolean("speed_boost", v).apply()

    var overlayEnabled: Boolean
        get() = prefs.getBoolean("overlay_enabled", false)
        set(v) = prefs.edit().putBoolean("overlay_enabled", v).apply()

    var clickX: Int
        get() = prefs.getInt("click_x", 540)
        set(v) = prefs.edit().putInt("click_x", v).apply()

    var clickY: Int
        get() = prefs.getInt("click_y", 960)
        set(v) = prefs.edit().putInt("click_y", v).apply()

    var clickInterval: Int
        get() = prefs.getInt("click_interval", 300)
        set(v) = prefs.edit().putInt("click_interval", v).apply()
}
