package com.tein.ninjector.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.View
import android.view.WindowManager
import com.tein.ninjector.R

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var view: CrosshairView? = null

    companion object {
        const val CH  = "ninj_ol"
        const val NID = 9001
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val ch = NotificationChannel(CH, getString(R.string.overlay_channel), NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        startForeground(NID, Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Ninjector")
            .setContentText(getString(R.string.overlay_notif))
            .build())
        val v = CrosshairView(this).also { view = it }
        wm.addView(v, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ))
    }

    override fun onDestroy() {
        super.onDestroy()
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }

    private inner class CrosshairView(ctx: android.content.Context) : View(ctx) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.RED; strokeWidth = 2.5f; style = Paint.Style.STROKE
        }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; strokeWidth = 3f
        }
        private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(100, 0, 0, 0); strokeWidth = 4f; style = Paint.Style.STROKE
        }
        private val sz = 22f; private val gap = 5f

        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f
            // outer shadow
            c.drawLine(cx - sz - 1f, cy, cx - gap - 1f, cy, outer)
            c.drawLine(cx + gap + 1f, cy, cx + sz + 1f, cy, outer)
            c.drawLine(cx, cy - sz - 1f, cx, cy - gap - 1f, outer)
            c.drawLine(cx, cy + gap + 1f, cx, cy + sz + 1f, outer)
            // main crosshair with center gap
            c.drawLine(cx - sz, cy, cx - gap, cy, line)
            c.drawLine(cx + gap, cy, cx + sz, cy, line)
            c.drawLine(cx, cy - sz, cx, cy - gap, line)
            c.drawLine(cx, cy + gap, cx, cy + sz, line)
            c.drawCircle(cx, cy, 2.5f, dot)
        }
    }
}