package com.tein.ninjector.manager

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipFile

object ArtManager {
    // FILL: Sam's CDN URLs for the art pack ZIPs
    private const val ART_URL    = "https://YOUR_SERVER/ml_art_compressed.zip"
    private const val REDUCE_URL = "https://YOUR_SERVER/ml_art_reduced.zip"

    var onProgress: ((Int) -> Unit)? = null

    // MAP 8BIT: reduce map texture resolution by applying low GFX settings
    // The actual texture files are in Dragon 2017/assets — ML redownloads them on restart
    suspend fun setMap8Bit(ctx: Context, on: Boolean): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (on) {
                    // Check for bundled 8bit textures in assets
                    val assets = try { ctx.assets.list("map_8bit") ?: emptyArray() }
                    catch (_: Exception) { emptyArray() }

                    if (assets.isNotEmpty()) {
                        // Bundle method: copy from app assets
                        val dir = File("${MLManager.DRAGON_ASSETS}/Textures/map").also { it.mkdirs() }
                        assets.forEach { name ->
                            ctx.assets.open("map_8bit/$name").use { inp ->
                                File(dir, name).outputStream().use { inp.copyTo(it) }
                            }
                        }
                        "MAP 8BIT aktif — ${assets.size} file dari bundle"
                    } else {
                        // Fallback: delete map textures so ML uses lower quality on reload
                        ShizukuManager.exec(
                            "find '${MLManager.DRAGON_ASSETS}' -name '*.astc' " +
                            "-o -name '*.etc2' 2>/dev/null | " +
                            "grep -i 'terrain\\|ground\\|tile\\|map' 2>/dev/null | " +
                            "while IFS= read -r f; do " +
                            "  cp \"\$f\" \"\${f}.bak8\" 2>/dev/null; " +
                            "  truncate -s 1 \"\$f\" 2>/dev/null; " +
                            "done; echo done"
                        ).getOrThrow()
                        "MAP 8BIT aktif (fallback) — restart ML"
                    }
                } else {
                    // Restore backed up textures
                    ShizukuManager.exec(
                        "find '${MLManager.DRAGON_ASSETS}' -name '*.bak8' 2>/dev/null | " +
                        "while IFS= read -r f; do mv \"\$f\" \"\${f%.bak8}\"; done; " +
                        "pm clear --cache-only ${MLManager.ML_PKG} 2>/dev/null; echo done"
                    ).getOrThrow()
                    "MAP 8BIT off — reload ML"
                }
            }
        }

    suspend fun activateArtCompres(ctx: Context): Result<String> =
        withContext(Dispatchers.IO) { runCatching { dlAndExtract(ctx, ART_URL, "art_c.zip"); "Art Compres aktif" } }

    suspend fun activateReduceData(ctx: Context): Result<String> =
        withContext(Dispatchers.IO) { runCatching { dlAndExtract(ctx, REDUCE_URL, "art_r.zip"); "Reduce Data aktif" } }

    private fun dlAndExtract(ctx: Context, url: String, name: String) {
        val dest = File(ctx.cacheDir, name)
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connect()
        val total = conn.contentLength.toLong()
        conn.inputStream.use { inp ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(8192); var dl = 0L; var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n); dl += n
                    if (total > 0) onProgress?.invoke(((dl * 100) / total).toInt())
                }
            }
        }
        conn.disconnect()
        val target = File(MLManager.ML_ART).also { it.mkdirs() }
        ZipFile(dest).use { zf ->
            zf.entries().asSequence().forEach { e ->
                val out = File(target, e.name)
                if (e.isDirectory) out.mkdirs()
                else { out.parentFile?.mkdirs(); zf.getInputStream(e).use { i -> out.outputStream().use { i.copyTo(it) } } }
            }
        }
        dest.delete()
    }
}