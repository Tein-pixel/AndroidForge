package com.tein.ninjector.manager

import android.content.Context
import android.content.pm.PackageManager

object MLManager {
    const val ML_PKG = "com.mobile.legends"
    // External storage paths — confirmed from community research (2024-2025)
    const val ML_EXT       = "/sdcard/Android/data/$ML_PKG"
    const val ML_FILES     = "$ML_EXT/files"
    // mini_patch: the folder that blocks drone view when present (must be deleted first)
    // Source: phcorner.org/threads/2224472 and pinoygamer.ph
    const val MINI_PATCH   = "$ML_FILES/mini_patch"
    const val MINI_PATCH_BACKUP = "$ML_FILES/mini_patch_bak"
    // Dragon 2017: older asset path, still present in some ML versions
    const val DRAGON_ASSETS = "$ML_FILES/Dragon 2017/assets"
    // Art resource paths
    const val ML_ART       = "$ML_FILES/art"
    const val ML_CACHE     = "$ML_EXT/cache"

    fun getVersion(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ML_PKG, 0).versionName ?: "?"
    } catch (_: PackageManager.NameNotFoundException) { "" }

    fun isInstalled(ctx: Context) = try {
        ctx.packageManager.getPackageInfo(ML_PKG, 0); true
    } catch (_: PackageManager.NameNotFoundException) { false }

    fun launch(ctx: Context) {
        ctx.packageManager.getLaunchIntentForPackage(ML_PKG)?.let { ctx.startActivity(it) }
    }
}