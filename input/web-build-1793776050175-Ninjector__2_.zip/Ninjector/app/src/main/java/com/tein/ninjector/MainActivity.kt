package com.tein.ninjector

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.tein.ninjector.databinding.ActivityMainBinding
import com.tein.ninjector.manager.*
import com.tein.ninjector.ui.about.AboutFragment
import com.tein.ninjector.ui.cheat.CheatFragment
import com.tein.ninjector.ui.drone.DroneFragment
import com.tein.ninjector.ui.fitur.FiturFragment

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val droneF by lazy { DroneFragment() }
    private val fiturF by lazy { FiturFragment() }
    private val cheatF by lazy { CheatFragment() }
    private val aboutF by lazy { AboutFragment() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        PrefsManager.init(this); DroneManager.init(this); GFXManager.init(this)

        ShizukuManager.init { ready ->
            runOnUiThread {
                droneF.onShizuku(ready); fiturF.onShizuku(ready); cheatF.onShizuku(ready)
            }
        }
        ShizukuManager.requestPerm { granted ->
            val r = ShizukuManager.isConnected && granted
            runOnUiThread {
                droneF.onShizuku(r); fiturF.onShizuku(r); cheatF.onShizuku(r)
            }
        }

        b.bottomNav.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.nav_drone -> { show(droneF); true }
                R.id.nav_fitur -> { show(fiturF); true }
                R.id.nav_cheat -> { show(cheatF); true }
                R.id.nav_about -> { show(aboutF); true }
                else -> false
            }
        }
        if (s == null) show(droneF)
        reqStorage()
    }

    private fun show(f: Fragment) {
        val tag = f::class.simpleName ?: return
        val tx = supportFragmentManager.beginTransaction()
        if (supportFragmentManager.findFragmentByTag(tag) == null)
            tx.add(R.id.fragment_container, f, tag)
        else tx.show(f)
        supportFragmentManager.fragments.filter { it != f && it.isAdded }.forEach { tx.hide(it) }
        tx.commit()
    }

    private fun reqStorage() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R &&
            !Environment.isExternalStorageManager()) {
            runCatching {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
    }

    override fun onDestroy() { super.onDestroy(); ShizukuManager.destroy() }
}