package com.tein.ninjector.manager

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object CheatManager {

    // ── LAG SWITCH ────────────────────────────────────────────────────────────
    suspend fun lagOnce(ms: Long): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            ShizukuManager.exec(
                "settings put global airplane_mode_on 1; " +
                "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true 2>/dev/null"
            ).getOrThrow()
            delay(ms)
            ShizukuManager.exec(
                "settings put global airplane_mode_on 0; " +
                "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false 2>/dev/null"
            ).getOrThrow()
            "Lag ${ms}ms selesai"
        }
    }

    suspend fun setAirplane(on: Boolean): Result<String> {
        val v = if (on) 1 else 0; val s = if (on) "true" else "false"
        return ShizukuManager.exec(
            "settings put global airplane_mode_on $v; " +
            "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state $s 2>/dev/null"
        ).map { if (on) "Lag switch ON" else "Lag switch OFF" }
    }

    // ── NO GRASS — delete grass textures from ML files ────────────────────────
    // Targets Dragon 2017/assets texture files with grass/bush/foliage names
    suspend fun setNoGrass(on: Boolean): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val base = MLManager.DRAGON_ASSETS
            if (on) {
                ShizukuManager.exec(
                    "find '$base' -type f \\( " +
                    "  -iname '*grass*' -o -iname '*bush*' " +
                    "  -o -iname '*foliage*' -o -iname '*weed*' " +
                    "  -o -iname '*shrub*' \\) 2>/dev/null | " +
                    "while IFS= read -r f; do " +
                    "  cp \"\$f\" \"\${f}.bak\" 2>/dev/null; " +
                    "  truncate -s 1 \"\$f\" 2>/dev/null; " +
                    "done; echo done"
                ).getOrThrow()
                "No Grass aktif — restart ML"
            } else {
                ShizukuManager.exec(
                    "find '$base' -name '*.bak' 2>/dev/null | " +
                    "while IFS= read -r f; do mv \"\$f\" \"\${f%.bak}\"; done; echo done"
                ).getOrThrow()
                "Grass dipulihkan — restart ML"
            }
        }
    }

    // ── SPEED BOOST ───────────────────────────────────────────────────────────
    suspend fun setSpeedBoost(on: Boolean): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            if (on) {
                val cmd = buildString {
                    append("ml=\$(pidof ${MLManager.ML_PKG} 2>/dev/null); ")
                    append("[ -n \"\$ml\" ] && renice -n -20 \$ml 2>/dev/null; ")
                    append("for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do ")
                    append("  max=\$(cat \$cpu/scaling_max_freq 2>/dev/null); ")
                    append("  [ -n \"\$max\" ] && echo \$max > \$cpu/scaling_min_freq 2>/dev/null; ")
                    append("  echo performance > \$cpu/scaling_governor 2>/dev/null; ")
                    append("done; echo done")
                }
                ShizukuManager.exec(cmd).getOrThrow()
                "Speed Boost aktif"
            } else {
                val cmd = buildString {
                    append("for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do ")
                    append("  min=\$(cat \$cpu/cpuinfo_min_freq 2>/dev/null); ")
                    append("  [ -n \"\$min\" ] && echo \$min > \$cpu/scaling_min_freq 2>/dev/null; ")
                    append("  echo schedutil > \$cpu/scaling_governor 2>/dev/null || ")
                    append("  echo ondemand > \$cpu/scaling_governor 2>/dev/null; ")
                    append("done; echo done")
                }
                ShizukuManager.exec(cmd).getOrThrow()
                "Speed Boost off"
            }
        }
    }

    // ── AUTO CLICKER ──────────────────────────────────────────────────────────
    @Volatile var clickerRunning = false

    suspend fun runAutoClicker(x: Int, y: Int, intervalMs: Long): Nothing =
        withContext(Dispatchers.IO) {
            clickerRunning = true
            try {
                while (clickerRunning) {
                    ShizukuManager.exec("input tap $x $y")
                    delay(intervalMs)
                }
            } finally { clickerRunning = false }
            error("unreachable")
        }

    fun stopClicker() { clickerRunning = false }

    // ── MACRO SKILL ───────────────────────────────────────────────────────────
    @Volatile var macroRunning = false

    suspend fun runMacro(
        s1x: Int, s1y: Int, s2x: Int, s2y: Int,
        ux: Int, uy: Int, delayMs: Long, loops: Int
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            macroRunning = true; var n = 0
            while (macroRunning && (loops <= 0 || n < loops)) {
                ShizukuManager.exec("input tap $s1x $s1y"); delay(delayMs)
                if (!macroRunning) break
                ShizukuManager.exec("input tap $s2x $s2y"); delay(delayMs)
                if (!macroRunning) break
                ShizukuManager.exec("input tap $ux $uy"); delay(delayMs)
                n++
            }
            macroRunning = false; "Macro selesai — $n loop"
        }
    }

    fun stopMacro() { macroRunning = false }

    // ── CUSTOM SHELL ──────────────────────────────────────────────────────────
    suspend fun execShell(cmd: String): Result<String> = ShizukuManager.exec(cmd)
}