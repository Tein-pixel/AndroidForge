package com.tein.ninjector.ui.fitur

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.tein.ninjector.databinding.FragmentFiturBinding
import com.tein.ninjector.manager.*
import kotlinx.coroutines.launch

class FiturFragment : Fragment() {
    private var _b: FragmentFiturBinding? = null
    private val b get() = _b!!
    private var curGfx = GFXManager.GfxPreset.ORIGINAL
    private var curFps = FPSManager.FpsMode.FPS_60

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentFiturBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        curGfx = runCatching { GFXManager.GfxPreset.valueOf(PrefsManager.gfxPreset) }
            .getOrDefault(GFXManager.GfxPreset.ORIGINAL)
        curFps = FPSManager.FpsMode.values().firstOrNull { it.fps == PrefsManager.fpsMode }
            ?: FPSManager.FpsMode.FPS_60
        onShizuku(ShizukuManager.isReady)
        setupSwitches(); setupRes(); setupGfx(); setupFps(); setupActions()
    }

    fun onShizuku(ready: Boolean) {
        if (_b == null) return
        b.tvResolusiInfo.text = if (ready) GFXManager.getInfo() else "Memuat info layar..."
    }

    private fun setupSwitches() {
        b.switchMap8bit.isChecked = PrefsManager.map8bit
        b.switchMap8bit.setOnCheckedChangeListener { _, c ->
            PrefsManager.map8bit = c
            lifecycleScope.launch {
                ArtManager.setMap8Bit(requireContext(), c)
                    .onSuccess { toast(it) }.onFailure { toast("Gagal: ${it.message}") }
            }
        }

        b.switchRestrictBg.isChecked = PrefsManager.restrictBg
        b.switchRestrictBg.setOnCheckedChangeListener { _, c ->
            if (!req()) { b.switchRestrictBg.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.restrictBg = c
            lifecycleScope.launch {
                NetworkManager.setRestrictBg(requireContext(), c)
                    .onSuccess { toast(if (c) "Data latar dibatasi" else "Batas dilepas") }
                    .onFailure { toast("Gagal") }
            }
        }

        b.switchAntiLag.isChecked = PrefsManager.antiLag
        b.switchAntiLag.setOnCheckedChangeListener { _, c ->
            if (!req()) { b.switchAntiLag.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.antiLag = c
            lifecycleScope.launch {
                (if (c) AntiLagManager.enable() else AntiLagManager.disable())
                    .onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }

        b.switchPingOpt.isChecked = PrefsManager.pingOpt
        b.switchPingOpt.setOnCheckedChangeListener { _, c ->
            if (!req()) { b.switchPingOpt.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.pingOpt = c
            lifecycleScope.launch {
                (if (c) NetworkManager.pingOn() else NetworkManager.pingOff())
                    .onSuccess { toast(if (c) "Ping optimizer aktif" else "Ping optimizer off") }
                    .onFailure { toast("Gagal") }
            }
        }
    }

    private fun setupRes() {
        val dpi = requireContext().resources.displayMetrics.densityDpi
        listOf("ori" to b.btnResOri, "540p" to b.btnRes540,
               "720p" to b.btnRes720, "900p" to b.btnRes900
        ).forEach { (preset, btn) ->
            btn.setOnClickListener {
                if (!req()) return@setOnClickListener
                lifecycleScope.launch {
                    DroneManager.applyRes(preset, dpi)
                        .onSuccess { toast(it) }.onFailure { toast("Gagal") }
                }
            }
        }
    }

    private fun setupGfx() {
        val gMap: Map<GFXManager.GfxPreset, Button> = mapOf(
            GFXManager.GfxPreset.ORIGINAL to b.btnGfxOri,
            GFXManager.GfxPreset.LIGHT    to b.btnGfxLight,
            GFXManager.GfxPreset.RETRO    to b.btnGfxRetro,
            GFXManager.GfxPreset.BLOCKY   to b.btnGfxBlocky,
            GFXManager.GfxPreset.EXTREME  to b.btnGfxExtreme,
        )
        gMap.forEach { (p, btn) ->
            btn.setOnClickListener {
                if (!req()) return@setOnClickListener
                curGfx = p; updateGfxBtns(gMap)
                lifecycleScope.launch {
                    GFXManager.apply(p).onSuccess { PrefsManager.gfxPreset = p.name; toast(it) }
                        .onFailure { toast("Gagal") }
                }
            }
        }
        updateGfxBtns(gMap)
        b.btnGfxRestore.setOnClickListener {
            if (!req()) return@setOnClickListener
            lifecycleScope.launch {
                GFXManager.restore().onSuccess {
                    curGfx = GFXManager.GfxPreset.ORIGINAL
                    updateGfxBtns(gMap); PrefsManager.gfxPreset = "ORIGINAL"; toast(it)
                }.onFailure { toast("Gagal") }
            }
        }
    }

    private fun updateGfxBtns(map: Map<GFXManager.GfxPreset, Button>) {
        map.forEach { (p, btn) ->
            val s = p == curGfx
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (s) 0xFFFFFFFF.toInt() else 0xFF222222.toInt())
            btn.setTextColor(if (s) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
    }

    private fun setupFps() {
        val fMap = mapOf(
            FPSManager.FpsMode.FPS_30  to b.btnFps30,
            FPSManager.FpsMode.FPS_60  to b.btnFps60,
            FPSManager.FpsMode.FPS_90  to b.btnFps90,
            FPSManager.FpsMode.FPS_120 to b.btnFps120,
        )
        fMap.forEach { (m, btn) ->
            btn.setOnClickListener {
                if (!req()) return@setOnClickListener
                curFps = m; updateFpsBtns(fMap)
                lifecycleScope.launch {
                    FPSManager.apply(m).onSuccess { PrefsManager.fpsMode = m.fps; toast(it) }
                        .onFailure { toast("Gagal") }
                }
            }
        }
        updateFpsBtns(fMap)
    }

    private fun updateFpsBtns(map: Map<FPSManager.FpsMode, Button>) {
        map.forEach { (m, btn) ->
            val s = m == curFps
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (s) 0xFFFFFFFF.toInt() else 0xFF222222.toInt())
            btn.setTextColor(if (s) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
    }

    private fun setupActions() {
        b.btnBoost.setOnClickListener {
            if (!req()) return@setOnClickListener
            lifecycleScope.launch { BoostManager.boost().onSuccess { toast(it) }.onFailure { toast("Gagal") } }
        }
        b.btnBersihkan.setOnClickListener {
            if (!req()) return@setOnClickListener
            b.btnBersihkan.isEnabled = false
            lifecycleScope.launch {
                BoostManager.clearCache(requireContext())
                    .onSuccess { toast("Cache $it app dibersihkan") }.onFailure { toast("Gagal") }
                b.btnBersihkan.isEnabled = true
            }
        }
        b.btnArtCompress.setOnClickListener {
            lifecycleScope.launch {
                b.llArtSteps.visibility = View.VISIBLE
                b.progressArt.visibility = View.VISIBLE; b.progressArt.isIndeterminate = true
                ArtManager.onProgress = { p -> activity?.runOnUiThread {
                    b.progressArt.isIndeterminate = false; b.progressArt.progress = p } }
                ArtManager.activateArtCompres(requireContext())
                    .onSuccess { toast(it) }.onFailure { toast("Gagal — isi URL di ArtManager.kt") }
                b.progressArt.visibility = View.GONE; b.llArtSteps.visibility = View.GONE
            }
        }
        b.btnReduceData.setOnClickListener {
            lifecycleScope.launch {
                b.progressReduce.visibility = View.VISIBLE; b.progressReduce.isIndeterminate = true
                ArtManager.onProgress = { p -> activity?.runOnUiThread {
                    b.progressReduce.isIndeterminate = false; b.progressReduce.progress = p } }
                ArtManager.activateReduceData(requireContext())
                    .onSuccess { toast(it) }.onFailure { toast("Gagal — isi URL di ArtManager.kt") }
                b.progressReduce.visibility = View.GONE
            }
        }
    }

    private fun req(): Boolean =
        if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); false } else true
    private fun toast(m: String) =
        context?.let { Toast.makeText(it, m, Toast.LENGTH_SHORT).show() }
    override fun onDestroyView() { super.onDestroyView(); _b = null }
}