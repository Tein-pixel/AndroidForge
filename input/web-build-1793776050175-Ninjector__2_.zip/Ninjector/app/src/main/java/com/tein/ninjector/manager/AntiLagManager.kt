package com.tein.ninjector.manager

object AntiLagManager {
    suspend fun enable(): Result<String> {
        val cmd = buildString {
            append("ml=\$(pidof ${MLManager.ML_PKG} 2>/dev/null); ")
            append("[ -n \"\$ml\" ] && renice -n -10 \$ml 2>/dev/null; ")
            append("for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do ")
            append("  echo performance > \$g 2>/dev/null || echo interactive > \$g 2>/dev/null; ")
            append("done; echo done")
        }
        return ShizukuManager.exec(cmd).map { "Anti-Lag aktif" }
    }

    suspend fun disable(): Result<String> {
        val cmd = buildString {
            append("for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do ")
            append("  echo schedutil > \$g 2>/dev/null || echo ondemand > \$g 2>/dev/null; ")
            append("done; echo done")
        }
        return ShizukuManager.exec(cmd).map { "Anti-Lag off" }
    }
}