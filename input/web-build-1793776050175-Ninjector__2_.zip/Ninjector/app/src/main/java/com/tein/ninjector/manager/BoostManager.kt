package com.tein.ninjector.manager

import android.content.Context
import android.content.pm.PackageManager

object BoostManager {
    suspend fun boost(): Result<String> =
        ShizukuManager.exec("am kill-all").map { "RAM dibebaskan" }

    suspend fun clearCache(ctx: Context): Result<Int> {
        val pkgs = ctx.packageManager
            .getInstalledApplications(PackageManager.GET_META_DATA)
            .map { it.packageName }
        return ShizukuManager.exec(
            pkgs.joinToString("; ") { "pm clear --cache-only $it 2>/dev/null" }
        ).map { pkgs.size }
    }
}