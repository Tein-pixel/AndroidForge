package com.tein.ninjector.manager

import android.content.Context
import android.content.SharedPreferences

object PrefsManager {
    private const val NAME = "nj_prefs"
    private lateinit var p: SharedPreferences
    fun init(ctx: Context) { p = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE) }

    private fun str(k: String, d: String) = p.getString(k, d) ?: d
    private fun bool(k: String, d: Boolean = false) = p.getBoolean(k, d)
    private fun int(k: String, d: Int = 0) = p.getInt(k, d)
    private fun set(k: String, v: String)   { p.edit().putString(k, v).apply() }
    private fun set(k: String, v: Boolean)  { p.edit().putBoolean(k, v).apply() }
    private fun set(k: String, v: Int)      { p.edit().putInt(k, v).apply() }

    var droneMode: String   get() = str("drone", "ORIGINAL"); set(v) { set("drone", v) }
    var fixDone: Boolean    get() = bool("fix_done");          set(v) { set("fix_done", v) }
    var gfxPreset: String   get() = str("gfx", "ORIGINAL");   set(v) { set("gfx", v) }
    var fpsMode: Int        get() = int("fps", 60);            set(v) { set("fps", v) }
    var map8bit: Boolean    get() = bool("map8");              set(v) { set("map8", v) }
    var restrictBg: Boolean get() = bool("rbg");               set(v) { set("rbg", v) }
    var antiLag: Boolean    get() = bool("alag");              set(v) { set("alag", v) }
    var pingOpt: Boolean    get() = bool("ping");              set(v) { set("ping", v) }
    var noGrass: Boolean    get() = bool("nograss");           set(v) { set("nograss", v) }
    var speedBoost: Boolean get() = bool("spd");               set(v) { set("spd", v) }
    var overlayOn: Boolean  get() = bool("overlay");           set(v) { set("overlay", v) }
}