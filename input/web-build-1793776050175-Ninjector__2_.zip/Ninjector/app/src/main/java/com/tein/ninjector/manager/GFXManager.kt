package com.tein.ninjector.manager

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

object GFXManager {
    enum class GfxPreset(val label: String, val scale: Float) {
        ORIGINAL("Original", 1.0f),
        LIGHT   ("Light",    0.70f),
        RETRO   ("Retro",    0.50f),
        BLOCKY  ("Blocky",   0.35f),
        EXTREME ("Extreme",  0.25f),
    }

    private var realW = 1080; private var realH = 1920; private var realDpi = 420

    fun init(ctx: Context) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wm.currentWindowMetrics.bounds.also { realW = it.width(); realH = it.height() }
        } else {
            @Suppress("DEPRECATION")
            DisplayMetrics().also {
                wm.defaultDisplay.getRealMetrics(it)
                realW = it.widthPixels; realH = it.heightPixels
            }
        }
        realDpi = ctx.resources.displayMetrics.densityDpi
    }

    fun getInfo() = "${realW}x${realH} @ ${realDpi}dpi"

    suspend fun apply(preset: GfxPreset): Result<String> {
        val cmd = if (preset == GfxPreset.ORIGINAL) "wm size reset; wm density reset"
        else {
            val w = (realW * preset.scale).toInt()
            val h = (realH * preset.scale).toInt()
            val d = (realDpi * preset.scale).toInt().coerceAtLeast(120)
            "wm size ${w}x${h}; wm density $d"
        }
        return ShizukuManager.exec(cmd).map { "${preset.label} diterapkan" }
    }

    suspend fun restore(): Result<String> =
        ShizukuManager.exec("wm size reset; wm density reset").map { "Resolusi dipulihkan" }
}