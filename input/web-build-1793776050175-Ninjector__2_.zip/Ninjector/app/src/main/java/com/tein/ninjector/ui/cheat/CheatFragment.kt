package com.tein.ninjector.ui.cheat

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.tein.ninjector.databinding.FragmentCheatBinding
import com.tein.ninjector.manager.*
import com.tein.ninjector.service.OverlayService
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class CheatFragment : Fragment() {
    private var _b: FragmentCheatBinding? = null
    private val b get() = _b!!
    private var clickJob: Job? = null
    private var macroJob: Job? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentCheatBinding.inflate(i, c, false); return b.root
    }
    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        setupClicker(); setupMacro(); setupVisual(); setupLag(); setupShell()
    }
    fun onShizuku(ready: Boolean) {}

    private fun setupClicker() {
        b.btnClickerStart.setOnClickListener {
            if (!req()) return@setOnClickListener
            val x  = b.etClickX.text.toString().toIntOrNull() ?: 540
            val y  = b.etClickY.text.toString().toIntOrNull() ?: 960
            val ms = b.etClickInterval.text.toString().toLongOrNull() ?: 300L
            CheatManager.stopClicker(); clickJob?.cancel()
            clickJob = lifecycleScope.launch {
                b.tvClickerStatus.text = "Running — ${x}x${y} @ ${ms}ms"
                CheatManager.runAutoClicker(x, y, ms)
            }
        }
        b.btnClickerStop.setOnClickListener {
            clickJob?.cancel(); CheatManager.stopClicker()
            b.tvClickerStatus.text = "Idle"
        }
    }

    private fun setupMacro() {
        b.btnMacroRun.setOnClickListener {
            if (!req()) return@setOnClickListener
            val s1x = b.etS1x.text.toString().toIntOrNull() ?: 320
            val s1y = b.etS1y.text.toString().toIntOrNull() ?: 1750
            val s2x = b.etS2x.text.toString().toIntOrNull() ?: 460
            val s2y = b.etS2y.text.toString().toIntOrNull() ?: 1750
            val ux  = b.etUltx.text.toString().toIntOrNull() ?: 600
            val uy  = b.etUlty.text.toString().toIntOrNull() ?: 1750
            val del = b.etMacroDelay.text.toString().toLongOrNull() ?: 150L
            val lp  = b.etMacroLoops.text.toString().toIntOrNull() ?: 3
            macroJob?.cancel()
            macroJob = lifecycleScope.launch {
                b.tvMacroStatus.text = "Running..."
                CheatManager.runMacro(s1x, s1y, s2x, s2y, ux, uy, del, lp)
                    .onSuccess { b.tvMacroStatus.text = it }
                    .onFailure { b.tvMacroStatus.text = "Error: ${it.message}" }
            }
        }
        b.btnMacroStop.setOnClickListener {
            macroJob?.cancel(); CheatManager.stopMacro()
            b.tvMacroStatus.text = "Dihentikan"
        }
    }

    private fun setupVisual() {
        b.switchNoGrass.isChecked = PrefsManager.noGrass
        b.switchNoGrass.setOnCheckedChangeListener { _, c ->
            if (!req()) { b.switchNoGrass.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.noGrass = c
            lifecycleScope.launch {
                CheatManager.setNoGrass(c).onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }

        b.switchOverlay.isChecked = PrefsManager.overlayOn
        b.switchOverlay.setOnCheckedChangeListener { _, c ->
            PrefsManager.overlayOn = c
            if (c) {
                if (!Settings.canDrawOverlays(requireContext())) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                    b.switchOverlay.isChecked = false; return@setOnCheckedChangeListener
                }
                requireContext().startForegroundService(
                    Intent(requireContext(), OverlayService::class.java))
                toast("Crosshair aktif")
            } else {
                requireContext().stopService(Intent(requireContext(), OverlayService::class.java))
                toast("Crosshair off")
            }
        }

        b.switchSpeedBoost.isChecked = PrefsManager.speedBoost
        b.switchSpeedBoost.setOnCheckedChangeListener { _, c ->
            if (!req()) { b.switchSpeedBoost.isChecked = !c; return@setOnCheckedChangeListener }
            PrefsManager.speedBoost = c
            lifecycleScope.launch {
                CheatManager.setSpeedBoost(c).onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }
    }

    private fun setupLag() {
        b.switchLag.setOnCheckedChangeListener { _, c ->
            if (!req()) { b.switchLag.isChecked = !c; return@setOnCheckedChangeListener }
            lifecycleScope.launch {
                CheatManager.setAirplane(c).onSuccess { toast(it) }.onFailure { toast("Gagal") }
            }
        }
        b.btnLagOnce.setOnClickListener {
            if (!req()) return@setOnClickListener
            val ms = b.etLagDuration.text.toString().toLongOrNull() ?: 1500L
            b.btnLagOnce.isEnabled = false
            lifecycleScope.launch {
                CheatManager.lagOnce(ms)
                    .onSuccess { toast(it) }.onFailure { toast("Gagal: ${it.message}") }
                b.btnLagOnce.isEnabled = true; b.switchLag.isChecked = false
            }
        }
    }

    private fun setupShell() {
        b.btnShellExec.setOnClickListener {
            val cmd = b.etShellCmd.text.toString().trim()
            if (cmd.isEmpty() || !req()) return@setOnClickListener
            b.tvShellOutput.visibility = View.VISIBLE
            b.tvShellOutput.text = "Menjalankan..."
            lifecycleScope.launch {
                CheatManager.execShell(cmd)
                    .onSuccess { b.tvShellOutput.text = it.ifEmpty { "(no output)" } }
                    .onFailure { b.tvShellOutput.text = "Error: ${it.message}" }
            }
        }
    }

    private fun req(): Boolean =
        if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); false } else true
    private fun toast(m: String) =
        context?.let { Toast.makeText(it, m, Toast.LENGTH_SHORT).show() }
    override fun onDestroyView() {
        super.onDestroyView(); clickJob?.cancel(); macroJob?.cancel(); _b = null
    }
}