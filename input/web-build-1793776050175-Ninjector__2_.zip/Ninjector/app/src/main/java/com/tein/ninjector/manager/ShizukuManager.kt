package com.tein.ninjector.manager

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object ShizukuManager {
    private const val PERM = 1001
    var isConnected = false; private set
    private var onState: ((Boolean) -> Unit)? = null
    private var onPerm:  ((Boolean) -> Unit)? = null

    private val recv = Shizuku.OnBinderReceivedListener { isConnected = true;  onState?.invoke(true)  }
    private val dead = Shizuku.OnBinderDeadListener    { isConnected = false; onState?.invoke(false) }
    private val perm = Shizuku.OnRequestPermissionResultListener { c, r ->
        if (c == PERM) onPerm?.invoke(r == PackageManager.PERMISSION_GRANTED)
    }

    fun init(cb: (Boolean) -> Unit) {
        onState = cb
        Shizuku.addBinderReceivedListenerSticky(recv)
        Shizuku.addBinderDeadListener(dead)
        Shizuku.addRequestPermissionResultListener(perm)
    }
    fun destroy() {
        Shizuku.removeBinderReceivedListener(recv)
        Shizuku.removeBinderDeadListener(dead)
        Shizuku.removeRequestPermissionResultListener(perm)
    }
    fun hasPerm() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: IllegalStateException) { false }

    fun requestPerm(cb: (Boolean) -> Unit) {
        onPerm = cb
        try { Shizuku.requestPermission(PERM) } catch (_: Exception) { cb(false) }
    }
    val isReady get() = isConnected && hasPerm()

    suspend fun exec(cmd: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val proc = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val out = proc.inputStream.bufferedReader().use { it.readText() }.trim()
            val err = proc.errorStream.bufferedReader().use { it.readText() }.trim()
            proc.waitFor()
            if (out.isEmpty() && err.isNotEmpty()) err else out
        }
    }
}