package com.tein.ninjector.manager

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

object DroneManager {

    enum class DroneMode(val label: String) {
        ORIGINAL("Original"),
        X2("x2"),
        X4("x4"),
        X6("x6"),
        X8("x8"),
        VERTIKAL("Vertikal"),
    }

    private var realW = 1080
    private var realH = 1920

    fun init(ctx: Context) {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wm.currentWindowMetrics.bounds.also { realW = it.width(); realH = it.height() }
        } else {
            @Suppress("DEPRECATION")
            DisplayMetrics().also {
                wm.defaultDisplay.getRealMetrics(it)
                realW = it.widthPixels; realH = it.heightPixels
            }
        }
    }

    // ── Backup mini_patch before deleting ────────────────────────────────────
    // Allows user to restore if needed. Research: community recommends backup first.
    suspend fun backupMiniPatch(): Result<String> =
        ShizukuManager.exec(
            "if [ -d '${MLManager.MINI_PATCH}' ]; then " +
            "  cp -r '${MLManager.MINI_PATCH}' '${MLManager.MINI_PATCH_BACKUP}' 2>/dev/null && echo backed; " +
            "else echo 'mini_patch tidak ditemukan'; fi"
        ).map { it }

    // ── Delete mini_patch — required step before drone view works ─────────────
    // Research: "Delete mini_patch folder in com.mobile.legends/files"
    // Source: phcorner.org, pinoygamer.ph (2025)
    suspend fun deleteMiniPatch(): Result<String> =
        ShizukuManager.exec(
            "rm -rf '${MLManager.MINI_PATCH}' 2>/dev/null; " +
            // Also search for any fix_ prefixed folders in files dir
            "find '${MLManager.ML_FILES}' -maxdepth 2 -name 'fix_*' -type d 2>/dev/null | " +
            "xargs rm -rf 2>/dev/null; " +
            "echo done"
        ).map { "Folder FIX_ / mini_patch berhasil dihapus" }

    // ── Restore mini_patch from backup ────────────────────────────────────────
    suspend fun restoreMiniPatch(): Result<String> =
        ShizukuManager.exec(
            "if [ -d '${MLManager.MINI_PATCH_BACKUP}' ]; then " +
            "  cp -r '${MLManager.MINI_PATCH_BACKUP}' '${MLManager.MINI_PATCH}' 2>/dev/null && echo restored; " +
            "else echo 'Backup tidak ditemukan'; fi"
        ).map { it }

    // ── Apply drone via wm size (display resolution change) ───────────────────
    // After deleting mini_patch, changing wm size creates the drone view effect.
    // The game renders at lower resolution → sees more of the map.
    suspend fun apply(mode: DroneMode): Result<String> {
        val cmd = when (mode) {
            DroneMode.ORIGINAL -> "wm size reset"
            DroneMode.X2       -> "wm size ${realW / 2}x${realH / 2}"
            DroneMode.X4       -> "wm size ${realW / 4}x${realH / 4}"
            DroneMode.X6       -> "wm size ${realW / 6}x${realH / 6}"
            DroneMode.X8       -> "wm size ${realW / 8}x${realH / 8}"
            // Vertikal: swap W/H for a rotated perspective
            DroneMode.VERTIKAL -> "wm size ${realH / 4}x${realW / 4}"
        }
        return ShizukuManager.exec(cmd).map { "Drone ${mode.label} diterapkan" }
    }

    // ── Resolution presets matching original Ninjector APK ───────────────────
    // 540p / 720p / 900p — from original APK string analysis
    suspend fun applyRes(preset: String, baseDpi: Int): Result<String> {
        val cmd = when (preset) {
            "540p"  -> "wm size 540x960; wm density ${baseDpi / 2}"
            "720p"  -> "wm size 720x1280; wm density ${(baseDpi * 0.65).toInt()}"
            "900p"  -> "wm size 900x1600; wm density ${(baseDpi * 0.8).toInt()}"
            else    -> "wm size reset; wm density reset"
        }
        return ShizukuManager.exec(cmd).map {
            if (preset == "ori") "Resolusi dipulihkan" else "Resolusi $preset diterapkan"
        }
    }
}