package com.tein.ninjector.ui.drone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.tein.ninjector.databinding.FragmentDroneBinding
import com.tein.ninjector.manager.DroneManager
import com.tein.ninjector.manager.GFXManager
import com.tein.ninjector.manager.MLManager
import com.tein.ninjector.manager.PrefsManager
import com.tein.ninjector.manager.ShizukuManager
import kotlinx.coroutines.launch

class DroneFragment : Fragment() {
    private var _b: FragmentDroneBinding? = null
    private val b get() = _b!!
    private var current = DroneManager.DroneMode.ORIGINAL
    private var fixDone = false

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentDroneBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        fixDone = PrefsManager.fixDone
        current = runCatching { DroneManager.DroneMode.valueOf(PrefsManager.droneMode) }
            .getOrDefault(DroneManager.DroneMode.ORIGINAL)
        refreshML(); refreshShizuku(ShizukuManager.isReady)
        setupFixButtons(); setupDroneBtns(); updateApplyBtn()
        b.btnApply.setOnClickListener { applyDrone() }
    }

    fun onShizuku(ready: Boolean) { if (_b == null) return; refreshShizuku(ready) }

    private fun refreshML() {
        val ctx = requireContext()
        b.tvMlName.text    = "Mobile Legends"
        b.tvMlVersion.text = if (MLManager.isInstalled(ctx)) "Versi ${MLManager.getVersion(ctx)}"
                             else "Tidak terinstall"
        b.btnOpenMl.setOnClickListener { MLManager.launch(ctx) }
    }

    private fun refreshShizuku(ready: Boolean) {
        b.tvShizukuStatus.text = if (ready) "Shizuku terhubung" else "Shizuku tidak terhubung"
        b.tvShizukuSub.text    = if (ready) "Semua fitur tersedia" else "Jalankan Shizuku lalu periksa lagi"
        b.ivShizukuDot.setImageResource(
            if (ready) android.R.drawable.presence_online else android.R.drawable.presence_offline)
        b.btnShizukuBadge.text = if (ready) "ONLINE" else "OFFLINE"
        b.btnApply.isEnabled = fixDone && ready
    }

    private fun setupFixButtons() {
        updateFixStatus()

        b.btnBackupPatch.setOnClickListener {
            if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); return@setOnClickListener }
            lifecycleScope.launch {
                DroneManager.backupMiniPatch().onSuccess { toast(it) }.onFailure { toast("Gagal: ${it.message}") }
            }
        }

        b.btnHapusFix.setOnClickListener {
            if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); return@setOnClickListener }
            b.btnHapusFix.isEnabled = false
            b.progressDrone.visibility = View.VISIBLE
            lifecycleScope.launch {
                DroneManager.deleteMiniPatch()
                    .onSuccess {
                        fixDone = true; PrefsManager.fixDone = true
                        updateFixStatus(); toast(it)
                    }
                    .onFailure { toast("Gagal: ${it.message}") }
                b.progressDrone.visibility = View.GONE
                b.btnHapusFix.isEnabled = true
            }
        }

        b.btnRestorePatch.setOnClickListener {
            if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); return@setOnClickListener }
            lifecycleScope.launch {
                DroneManager.restoreMiniPatch()
                    .onSuccess {
                        fixDone = false; PrefsManager.fixDone = false
                        updateFixStatus(); toast(it)
                    }
                    .onFailure { toast("Gagal: ${it.message}") }
            }
        }
    }

    private fun updateFixStatus() {
        b.tvFixStatus.text = if (fixDone) "AKTIF — mini_patch sudah dihapus" else "Belum dijalankan"
        b.tvFixStatus.setTextColor(if (fixDone) 0xFF44CC44.toInt() else 0xFF888888.toInt())
        b.tvApplyNote.visibility = if (fixDone) View.GONE else View.VISIBLE
        b.btnApply.isEnabled = fixDone && ShizukuManager.isReady
    }

    private fun setupDroneBtns() {
        val map: Map<DroneManager.DroneMode, Button> = mapOf(
            DroneManager.DroneMode.ORIGINAL to b.btnOri,
            DroneManager.DroneMode.X2       to b.btnX2,
            DroneManager.DroneMode.X4       to b.btnX4,
            DroneManager.DroneMode.X6       to b.btnX6,
            DroneManager.DroneMode.X8       to b.btnX8,
            DroneManager.DroneMode.VERTIKAL to b.btnVertikal,
        )
        map.forEach { (mode, btn) ->
            btn.setOnClickListener {
                current = mode; updateSelected(map)
                b.tvDroneLabel.text = mode.label; updateApplyBtn()
            }
        }
        updateSelected(map)
    }

    private fun updateSelected(map: Map<DroneManager.DroneMode, Button>) {
        map.forEach { (m, btn) ->
            val sel = m == current
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (sel) 0xFFFFFFFF.toInt() else 0xFF222222.toInt())
            btn.setTextColor(if (sel) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
    }

    private fun updateApplyBtn() {
        b.btnApply.text = "Terapkan ${current.label}"
        b.btnApply.isEnabled = fixDone && ShizukuManager.isReady
    }

    private fun applyDrone() {
        if (!ShizukuManager.isReady) { toast("Shizuku diperlukan"); return }
        if (!fixDone) { toast("Jalankan HAPUS FIX_ dulu"); return }
        b.btnApply.isEnabled = false
        b.progressDrone.visibility = View.VISIBLE
        lifecycleScope.launch {
            DroneManager.apply(current)
                .onSuccess { PrefsManager.droneMode = current.name; toast(it) }
                .onFailure { toast("Gagal: ${it.message}") }
            b.progressDrone.visibility = View.GONE
            b.btnApply.isEnabled = true
        }
    }

    private fun toast(m: String) =
        context?.let { Toast.makeText(it, m, Toast.LENGTH_SHORT).show() }
    override fun onDestroyView() { super.onDestroyView(); _b = null }
}