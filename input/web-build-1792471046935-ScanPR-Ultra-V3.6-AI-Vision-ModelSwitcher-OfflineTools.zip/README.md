# Scan PR Ultra 3.6.0

Android homework helper using CameraX, ML Kit OCR, crop selection, and online multimodal AI.

## Accuracy-focused scan pipeline
- Capture or select image, crop it, and run local OCR only as a secondary reference.
- The original cropped image is always attached to a vision-capable AI provider when answering a photo question.
- OCR text is explicitly treated as potentially incorrect; direct visual interpretation takes precedence.
- Photo answers are audited by a second configured vision provider when another provider key is available.
- If no vision model is reachable, the app shows an error instead of silently answering from OCR alone or inventing an offline answer.
- EXIF rotation is normalized and image compression preserves more detail for handwriting, fractions, roots, superscripts, and division bars.

## AI providers / changing models
- Gemini API: the live catalog is checked and known free-tier capable model IDs are listed in Settings.
- OpenRouter: the free router (`openrouter/free`) can route image requests to available free vision models; live catalog filters `:free` variants with image input support.
- Groq: supports a vision route using Qwen where enabled by the account/model catalog. It is available as an explicit provider choice only; check the account billing/tier first.
- Cerebras: included for typed-text requests only. Photo mode refuses to fall back to text-only models.
- Provider/model can be chosen in Settings. Auto mode uses only Gemini free-tier model IDs and OpenRouter free routes. Groq/Cerebras are not used automatically to avoid unexpected provider billing; choose them deliberately and check the account terms. Quotas, access, model names, free limits, and regional availability can change. API keys are supplied by the user and saved through encrypted preferences; no shared secrets are shipped in the APK.
- This project does not claim OpenAI or xAI/Grok direct APIs are free. Those can charge separately even if their consumer apps have free plans.

## Offline study tools (not answer-generation)
- Calculator for +, -, ×, ÷, parentheses, exponent, square root, percentage, π, and e.
- Multiple saved notes, editable on device.
- Unit converter for length, mass, time, volume, and temperature.
- Searchable formula/reference list for math, physics, chemistry, statistics, and economics.
- Quick element reference and focus timer.

## Build
- Android Gradle Plugin 8.3.2, Gradle 8.4, JDK 17, compile/target SDK 34, min SDK 24.
- AndroidForge can regenerate the wrapper if it is absent. Build `:app:assembleDebug`.
- Do not put personal API keys in Gradle or BuildConfig. Add provider API keys in the app Settings.

## Limitations
No image/OCR model can guarantee 99% accuracy for every handwritten photo. Strong blur, glare, shadows, cropped symbols, and very small handwriting can remain ambiguous. The application is designed to ask for a clearer image rather than silently fabricate uncertain digits or symbols.
