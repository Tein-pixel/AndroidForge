// File: app/src/main/java/com/scanpr/ultra/viewmodel/ResultViewModel.kt
package com.scanpr.ultra.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scanpr.ultra.utils.AiProvider
import com.scanpr.ultra.utils.AiResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ResultViewModel : ViewModel() {
    private val _result = MutableStateFlow<AiResult?>(null)
    val result: StateFlow<AiResult?> = _result
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    fun solve(context: Context, text: String, imageUri: Uri? = null) {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            _result.value = try {
                AiProvider(context.applicationContext).solveAuto(text, imageUri)
            } catch (e: Exception) {
                AiResult(
                    jawabanAkhir = "AI online belum berhasil menjawab. Periksa koneksi internet, API key, kuota, atau coba model lain di Pengaturan.",
                    langkah = listOf("Tidak ada jawaban yang dibuat. Periksa internet, API key, kuota, atau ganti model/provider."),
                    mapel = "Umum",
                    modelUsed = "AI online gagal",
                    metodeAlternatif = emptyList(),
                    catatan = e.message ?: "Provider AI tidak tersedia."
                )
            }
            _loading.value = false
        }
    }

    fun setResult(value: AiResult) { _result.value = value }
}
