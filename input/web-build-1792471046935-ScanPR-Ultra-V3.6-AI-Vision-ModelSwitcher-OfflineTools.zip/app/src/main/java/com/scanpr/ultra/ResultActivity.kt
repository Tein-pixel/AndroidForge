package com.scanpr.ultra

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.scanpr.ultra.data.ScanHistory
import com.scanpr.ultra.databinding.ActivityResultBinding
import com.scanpr.ultra.repository.ScanRepository
import com.scanpr.ultra.utils.AiResult
import com.scanpr.ultra.utils.ImageUtils
import com.scanpr.ultra.utils.ThemeManager
import com.scanpr.ultra.viewmodel.ResultViewModel
import androidx.activity.viewModels
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.util.Locale

class ResultActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_OCR = "ocr_text"
        const val EXTRA_IMAGE_URI = "image_uri"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_STEPS = "steps_json"
        const val EXTRA_MAPEL = "mapel"
        const val EXTRA_MODEL = "model_used"
        const val EXTRA_ID = "history_id"
    }

    private lateinit var binding: ActivityResultBinding
    private val vm: ResultViewModel by viewModels()
    private lateinit var repository: ScanRepository
    private var imageUri = ""
    private var lastResult: AiResult? = null
    private var alreadySaved = false
    private var textToSpeech: TextToSpeech? = null

    private val createPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportPdf(uri)
    }
    private val speechInput = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) { binding.followupEditText.setText(spoken); submitFollowup() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = ScanRepository(this)
        imageUri = intent.getStringExtra(EXTRA_IMAGE_URI).orEmpty()
        val parsedUri = runCatching { Uri.parse(imageUri).takeIf { imageUri.isNotBlank() } }.getOrNull()
        if (parsedUri == null) binding.resultImage.visibility = View.GONE else ImageUtils.show(this, parsedUri, binding.resultImage)
        binding.resultToolbar.setNavigationOnClickListener { finish() }
        binding.ocrEditText.setText(intent.getStringExtra(EXTRA_OCR).orEmpty())
        binding.editOcrButton.setOnClickListener { binding.ocrEditText.requestFocus(); binding.ocrEditText.setSelection(binding.ocrEditText.text.length) }
        binding.stepsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.solveButton.setOnClickListener {
            val correctedText = binding.ocrEditText.text.toString()
            // Always attach the actual cropped image when available. The AI prompt treats OCR as secondary,
            // so an incorrectly recognized string must not replace what is visible in the photo.
            vm.solve(applicationContext, correctedText, parsedUri)
        }
        binding.copyButton.setOnClickListener { copyResult() }
        binding.shareButton.setOnClickListener { shareResult() }
        binding.saveButton.setOnClickListener { saveResult() }
        binding.exportPdfButton.setOnClickListener { createPdf.launch("ScanPR-Hasil.pdf") }
        binding.graphButton.setOnClickListener { startActivity(Intent(this, GraphActivity::class.java).putExtra(GraphActivity.EXTRA_EQUATION, binding.ocrEditText.text.toString())) }
        binding.speakAnswerButton.setOnClickListener { speakAnswer() }
        binding.searchSourcesButton.setOnClickListener { searchSources() }
        binding.followupSendButton.setOnClickListener { submitFollowup() }
        binding.followupEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitFollowup(); true } else false
        }
        binding.followupVoiceButton.setOnClickListener { startVoiceFollowup() }
        binding.toolShortButton.setOnClickListener { applyStudyTool("Tulis ulang jawaban sebelumnya secara ringkas dan langsung ke inti. Pertahankan angka, satuan, rumus penting, serta hasil akhir; jangan menghilangkan informasi yang mengubah makna.") }
        binding.toolDetailedButton.setOnClickListener { applyStudyTool("Perluas jawaban sebelumnya menjadi penjelasan lebih rinci dan runtut. Verifikasi ulang angka, satuan, rumus, dan fakta; jangan menambah detail yang tidak didukung soal.") }
        binding.toolHintButton.setOnClickListener { applyStudyTool("Berikan petunjuk bertahap tanpa langsung menampilkan jawaban akhir. Berhenti setelah petunjuk yang cukup untuk saya coba.") }
        binding.toolSimpleButton.setOnClickListener { applyStudyTool("Jelaskan jawaban dan konsepnya dengan bahasa yang lebih sederhana untuk pelajar, sertakan satu contoh singkat bila membantu.") }
        binding.toolExampleButton.setOnClickListener { applyStudyTool("Buat satu contoh soal baru yang sejenis tetapi memakai angka/konteks berbeda, lalu jelaskan jawaban langkah demi langkah.") }
        binding.toolSummaryButton.setOnClickListener { applyStudyTool("Buat rangkuman singkat materi yang dibutuhkan untuk memahami soal ini, dalam poin-poin dan definisi penting.") }
        binding.toolVerifyButton.setOnClickListener {
            applyStudyTool("Audit jawaban sebelumnya secara kritis. Cocokkan kembali teks soal, setiap angka/satuan, rumus, perhitungan dan fakta yang disebut. Jika soal matematika, hitung ulang secara independen. Sebutkan bagian yang benar, bagian yang mungkin salah, dan koreksi bila dapat dibuktikan. Jangan menyatakan benar bila tidak bisa diverifikasi.")
        }
        binding.toolQuizButton.setOnClickListener { openStudyActivity("quiz") }
        binding.toolFlashcardsButton.setOnClickListener { openStudyActivity("cards") }
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) textToSpeech?.language = Locale("id", "ID")
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.result.collect { result -> if (result != null) renderResult(result) } }
                launch {
                    vm.loading.collect { loading ->
                        binding.aiProgress.visibility = if (loading) View.VISIBLE else View.GONE
                        binding.solveButton.isEnabled = !loading
                        binding.followupSendButton.isEnabled = !loading
                        binding.modelChip.text = if (loading) "AI: mencoba provider…" else (lastResult?.modelUsed?.let { "AI: $it" } ?: "AI: menunggu")
                    }
                }
            }
        }
        val savedAnswer = intent.getStringExtra(EXTRA_ANSWER).orEmpty()
        if (savedAnswer.isNotBlank()) {
            val steps = runCatching {
                val array = JSONArray(intent.getStringExtra(EXTRA_STEPS).orEmpty())
                (0 until array.length()).map { array.optString(it) }
            }.getOrDefault(emptyList())
            vm.setResult(AiResult(savedAnswer, steps, intent.getStringExtra(EXTRA_MAPEL).orEmpty().ifBlank { "Umum" }, intent.getStringExtra(EXTRA_MODEL).orEmpty().ifBlank { "Riwayat" }, emptyList()))
            alreadySaved = true
            binding.saveButton.isEnabled = false
        } else if (binding.ocrEditText.text.isNotBlank() || parsedUri != null) {
            vm.solve(applicationContext, binding.ocrEditText.text.toString(), parsedUri)
        } else {
            binding.answerText.text = "Ketik atau koreksi teks soal di atas, lalu tekan Selesaikan soal."
            binding.resultNotesText.text = "Belum ada jawaban. Jika teks tidak terbaca, perbaiki secara manual sebelum mengirim ke AI."
        }
    }

    private fun renderResult(result: AiResult) {
        lastResult = result
        binding.subjectChip.text = result.mapel
        binding.modelChip.text = "AI: ${result.modelUsed}"
        binding.answerText.text = result.jawabanAkhir
        binding.stepsRecyclerView.adapter = StepsAdapter(result.langkah)
        binding.methodsText.text = if (result.metodeAlternatif.isEmpty()) "" else "Metode alternatif: " + result.metodeAlternatif.joinToString(" • ")
        binding.resultNotesText.text = "Catatan akurasi: ${result.catatan}\n\nAI dapat keliru. Cocokkan angka, satuan, dan instruksi soal dengan sumber pelajaran."
    }

    private fun openStudyActivity(mode: String) {
        val contextForStudy = buildString {
            appendLine("Soal atau materi sumber:")
            appendLine(binding.ocrEditText.text?.toString()?.trim().orEmpty())
            val answer = lastResult?.jawabanAkhir.orEmpty()
            if (answer.isNotBlank()) {
                appendLine("Jawaban/pembahasan yang sudah tersedia:")
                appendLine(answer)
                lastResult?.langkah?.takeIf { it.isNotEmpty() }?.let { appendLine("Langkah:"); it.forEach { step -> appendLine("- $step") } }
            }
        }.trim()
        startActivity(Intent(this, StudyActivity::class.java)
            .putExtra(StudyActivity.EXTRA_MODE, mode)
            .putExtra(StudyActivity.EXTRA_CONTEXT, contextForStudy))
    }

    private fun applyStudyTool(instruction: String) {
        binding.followupEditText.setText(instruction)
        submitFollowup()
    }

    private fun submitFollowup() {
        val followup = binding.followupEditText.text?.toString()?.trim().orEmpty()
        if (followup.isBlank()) {
            Toast.makeText(this, "Ketik pertanyaan lanjutan terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val originalQuestion = binding.ocrEditText.text?.toString()?.trim().orEmpty()
        val previous = lastResult?.jawabanAkhir.orEmpty()
        val contextPrompt = buildString {
            appendLine("KONTEKS TUTOR LANJUTAN")
            appendLine("Soal asli pengguna:")
            appendLine(originalQuestion.ifBlank { "Teks soal asli belum tersedia; gunakan konteks lanjutan yang diberikan." })
            if (previous.isNotBlank()) { appendLine("Jawaban sebelumnya:"); appendLine(previous) }
            appendLine("Permintaan lanjutan pengguna:")
            appendLine(followup)
            append("Jawab hanya sesuai permintaan lanjutan dan gunakan konteks soal asli. Jangan mengarang detail yang tidak tercantum.")
        }
        alreadySaved = false
        binding.saveButton.isEnabled = true
        val originalImage = runCatching { Uri.parse(imageUri).takeIf { imageUri.isNotBlank() } }.getOrNull()
        vm.solve(applicationContext, contextPrompt, originalImage)
        binding.followupEditText.setText("")
    }

    private fun startVoiceFollowup() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan pertanyaan lanjutan")
        runCatching { speechInput.launch(intent) }.onFailure { Toast.makeText(this, "Input suara tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show() }
    }

    private fun resultText(): String {
        val result = lastResult
        return "SCAN PR ULTRA\n\nSoal:\n${binding.ocrEditText.text}\n\nMata pelajaran: ${result?.mapel.orEmpty()}\nModel: ${result?.modelUsed.orEmpty()}\n\nJawaban:\n${result?.jawabanAkhir.orEmpty()}\n\nLangkah/penjelasan:\n${result?.langkah?.joinToString("\n").orEmpty()}\n\nMetode alternatif:\n${result?.metodeAlternatif?.joinToString("\n").orEmpty()}\n\nCatatan:\n${result?.catatan.orEmpty()}\n\nCatatan: Periksa kembali hasil dengan sumber pelajaran. AI dapat keliru."
    }

    private fun searchSources() {
        val query = binding.ocrEditText.text?.toString()?.trim().orEmpty()
        if (query.isBlank()) {
            Toast.makeText(this, "Masukkan soal atau kata kunci terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val url = "https://www.google.com/search?q=" + java.net.URLEncoder.encode(query.take(1000), Charsets.UTF_8.name())
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { Toast.makeText(this, "Browser tidak tersedia untuk mencari sumber.", Toast.LENGTH_LONG).show() }
    }

    private fun copyResult() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Scan PR Ultra", resultText()))
        Toast.makeText(this, "Hasil disalin.", Toast.LENGTH_SHORT).show()
    }

    private fun shareResult() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, resultText()), "Bagikan hasil"))
    }

    private fun speakAnswer() {
        val text = lastResult?.let { "Jawaban. ${it.jawabanAkhir}. Penjelasan. ${it.langkah.joinToString(". ")}" }.orEmpty()
        if (text.isBlank()) { Toast.makeText(this, "Belum ada jawaban untuk dibacakan.", Toast.LENGTH_SHORT).show(); return }
        val tts = textToSpeech
        if (tts == null) Toast.makeText(this, "Fitur bacakan belum siap.", Toast.LENGTH_SHORT).show()
        else tts.speak(text.take(4000), TextToSpeech.QUEUE_FLUSH, null, "scanpr_answer")
    }

    private fun exportPdf(uri: Uri) {
        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    val document = PdfDocument()
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = android.graphics.Color.BLACK }
                    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 17f; typeface = android.graphics.Typeface.DEFAULT_BOLD; color = android.graphics.Color.BLACK }
                    val lines = wrapLines(resultText(), 84)
                    val pageWidth = 595; val pageHeight = 842; val margin = 40f; val lineHeight = 16f
                    var pageNumber = 1
                    var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                    var canvas = page.canvas
                    var y = margin
                    canvas.drawText("Scan PR Ultra", margin, y, titlePaint)
                    y += 30f
                    for (line in lines) {
                        if (y > pageHeight - margin) {
                            document.finishPage(page)
                            pageNumber++
                            page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                            canvas = page.canvas; y = margin
                        }
                        canvas.drawText(line.take(95), margin, y, paint)
                        y += lineHeight
                    }
                    document.finishPage(page)
                    contentResolver.openOutputStream(uri)?.use { document.writeTo(it) } ?: error("Tidak dapat membuka lokasi penyimpanan")
                    document.close()
                }
            }
            Toast.makeText(this@ResultActivity, if (saved.isSuccess) "PDF berhasil disimpan." else "Gagal membuat PDF. Coba lokasi lain.", Toast.LENGTH_LONG).show()
        }
    }

    private fun wrapLines(text: String, width: Int): List<String> = buildList {
        text.lines().forEach { line ->
            if (line.isBlank()) { add(""); return@forEach }
            var rest = line
            while (rest.length > width) {
                var cut = rest.lastIndexOf(' ', width)
                if (cut < width / 2) cut = width
                add(rest.substring(0, cut).trimEnd())
                rest = rest.substring(cut).trimStart()
            }
            add(rest)
        }
    }

    private fun saveResult() {
        if (alreadySaved) {
            Toast.makeText(this, "Hasil ini sudah tersimpan di riwayat.", Toast.LENGTH_SHORT).show()
            return
        }
        val result = lastResult ?: run { Toast.makeText(this, "Tunggu sampai hasil tersedia.", Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            runCatching {
                repository.save(ScanHistory(ocrText = binding.ocrEditText.text.toString(), answer = result.jawabanAkhir,
                    stepsJson = JSONArray(result.langkah).toString(), mapel = result.mapel, modelUsed = result.modelUsed, imageUri = imageUri))
            }.onSuccess {
                alreadySaved = true; binding.saveButton.isEnabled = false
                Toast.makeText(this@ResultActivity, "Hasil disimpan ke riwayat.", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(this@ResultActivity, "Gagal menyimpan riwayat.", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }

    private class StepsAdapter(private val items: List<String>) : RecyclerView.Adapter<StepsAdapter.StepViewHolder>() {
        class StepViewHolder(val text: TextView, val number: TextView, val line: View) : RecyclerView.ViewHolder(text.parent as View)
        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): StepViewHolder {
            val view = android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_step, parent, false)
            return StepViewHolder(view.findViewById(R.id.step_text), view.findViewById(R.id.step_number), view.findViewById(R.id.step_line))
        }
        override fun onBindViewHolder(holder: StepViewHolder, position: Int) {
            holder.number.text = (position + 1).toString(); holder.text.text = items[position]
            holder.line.visibility = if (position == items.lastIndex) View.INVISIBLE else View.VISIBLE
        }
        override fun getItemCount() = items.size
    }
}
