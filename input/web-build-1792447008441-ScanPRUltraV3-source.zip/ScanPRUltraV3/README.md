# Scan PR Ultra V3

Android Kotlin/XML project. Requirements: JDK 17 and Android SDK 34. Build with `./gradlew assembleDebug`; APK path: `app/build/outputs/apk/debug/app-debug.apk`.

Features included: CameraX capture, gallery import, ML Kit OCR, editable OCR text, no-key online AI attempt, basic offline arithmetic/equation solver, Room history, and Light/Dark/System theme preference.

Important limitations: no third-party API keys are embedded. The public AI endpoint can rate-limit, change, or be unavailable; offline solver only supports a few simple expression/linear equation patterns. This is a source project, not a verified APK; run a Gradle build and test on a device before release. Crop UI, flash control, advanced handwritten OCR, stepwise alternate methods, and full MVVM wiring are not yet implemented.
