// File: app/src/main/java/com/scanpr/app/viewmodel/ResultViewModel.kt
package com.scanpr.app.viewmodel
import androidx.lifecycle.ViewModel
class ResultViewModel:ViewModel()
