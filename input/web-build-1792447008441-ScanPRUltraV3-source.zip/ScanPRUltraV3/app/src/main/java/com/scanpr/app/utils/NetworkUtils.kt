// File: app/src/main/java/com/scanpr/app/utils/NetworkUtils.kt
package com.scanpr.app
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
object NetworkUtils { fun isOnline(c:Context):Boolean { val cm=c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager;val n=cm.activeNetwork?:return false;val cap=cm.getNetworkCapabilities(n)?:return false;return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) } }
