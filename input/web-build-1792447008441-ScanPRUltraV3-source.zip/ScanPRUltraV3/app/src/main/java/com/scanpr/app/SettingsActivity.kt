// File: app/src/main/java/com/scanpr/app/SettingsActivity.kt
package com.scanpr.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.scanpr.app.databinding.ActivitySettingsBinding
class SettingsActivity:AppCompatActivity(){override fun onCreate(savedInstanceState:Bundle?){ThemeManager.applySaved(this);super.onCreate(savedInstanceState);val b=ActivitySettingsBinding.inflate(layoutInflater);setContentView(b.root);when(ThemeManager.getMode(this)){ThemeMode.LIGHT->b.themeLight.isChecked=true;ThemeMode.DARK->b.themeDark.isChecked=true;else->b.themeSystem.isChecked=true};b.themeGroup.setOnCheckedChangeListener{_,id->val m=when(id){b.themeLight.id->ThemeMode.LIGHT;b.themeDark.id->ThemeMode.DARK;else->ThemeMode.SYSTEM};ThemeManager.setMode(this,m);recreate()}}}
