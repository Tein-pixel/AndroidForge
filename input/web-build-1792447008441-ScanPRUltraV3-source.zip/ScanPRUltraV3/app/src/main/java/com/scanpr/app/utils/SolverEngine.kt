// File: app/src/main/java/com/scanpr/app/utils/SolverEngine.kt
package com.scanpr.app
import kotlin.math.sqrt
object SolverEngine { fun solveOffline(input:String):AiResult { val s=input.replace("×","*").replace("÷","/").replace("−","-").trim(); val linear=Regex("(-?\\d+(?:\\.\\d+)?)\\s*([+*/-])\\s*(-?\\d+(?:\\.\\d+)?)").find(s)
  if(linear!=null){val a=linear.groupValues[1].toDoubleOrNull();val op=linear.groupValues[2];val b=linear.groupValues[3].toDoubleOrNull();if(a!=null&&b!=null){val v=when(op){"+"->a+b;"-"->a-b;"*"->a*b;"/"->if(b!=0.0)a/b else Double.NaN;else->Double.NaN};if(v.isFinite()){val ans=fmt(v);return AiResult(ans,listOf("Identifikasi operasi: $a $op $b","Hitung sesuai operasi $op.","Hasil perhitungan adalah $ans."),"Matematika",emptyList(),"Solver offline dasar")}}}
  val eq=Regex("(-?\\d+)x\\s*([+-])\\s*(\\d+)\\s*=\\s*(-?\\d+)",RegexOption.IGNORE_CASE).find(s)
  if(eq!=null){val a=eq.groupValues[1].toDouble();val sign=if(eq.groupValues[2]=="+")1 else -1;val b=eq.groupValues[3].toDouble()*sign;val c=eq.groupValues[4].toDouble();if(a!=0.0){val x=(c-b)/a;return AiResult("x = ${fmt(x)}",listOf("Persamaan: ${eq.value}","Pindahkan konstanta ke ruas kanan: ${fmt(a)}x = ${fmt(c-b)}","Bagi kedua ruas dengan ${fmt(a)}.","Jadi x = ${fmt(x)}."),"Matematika",emptyList(),"Solver offline dasar")}}
  return AiResult("Solver offline belum mendukung bentuk soal ini.",listOf("Periksa kembali teks hasil OCR.","Jika internet tersedia, coba ulangi agar layanan AI dapat membantu."),"Umum",emptyList(),"Offline fallback") }
 private fun fmt(d:Double)=if(d%1.0==0.0)d.toLong().toString() else String.format(java.util.Locale.US,"%.4f",d).trimEnd('0').trimEnd('.') }
