// File: app/src/main/java/com/scanpr/app/utils/EmbeddedKeys.kt
package com.scanpr.app
/** Intentionally empty: never ship third-party API secrets inside a client APK. */
object EmbeddedKeys { fun getGeminiKeys():List<String> = emptyList(); fun getOpenRouterKeys():List<String> = emptyList() }
