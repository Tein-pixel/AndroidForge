// File: app/src/main/java/com/scanpr/app/MainActivity.kt
package com.scanpr.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.scanpr.app.databinding.ActivityMainBinding
import java.io.File

class MainActivity : AppCompatActivity() {
 private lateinit var b: ActivityMainBinding
 private var capture: ImageCapture? = null
 private val gallery = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? -> uri?.let { openResult(it) } }
 private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startCamera() else Toast.makeText(this,"Izin kamera diperlukan untuk scan. Kamu masih bisa memilih foto dari galeri.",Toast.LENGTH_LONG).show() }
 override fun onCreate(savedInstanceState: Bundle?) { ThemeManager.applySaved(this); super.onCreate(savedInstanceState); b=ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
  b.galleryButton.setOnClickListener { gallery.launch("image/*") }; b.historyButton.setOnClickListener { startActivity(Intent(this,HistoryActivity::class.java)) }
  b.captureButton.setOnClickListener { takePhoto() }
  if (ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera() else cameraPermission.launch(Manifest.permission.CAMERA)
 }
 private fun startCamera() { val future=ProcessCameraProvider.getInstance(this); future.addListener({ try { val provider=future.get(); val preview=Preview.Builder().build().also { it.setSurfaceProvider(b.previewView.surfaceProvider) }; capture=ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build(); provider.unbindAll(); provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,preview,capture) } catch(e:Exception) { Toast.makeText(this,"Kamera tidak dapat dibuka.",Toast.LENGTH_SHORT).show() } },ContextCompat.getMainExecutor(this)) }
 private fun takePhoto() { val c=capture ?: run { gallery.launch("image/*"); return }; val f=File(cacheDir,"scan_${System.currentTimeMillis()}.jpg"); c.takePicture(androidx.camera.core.ImageCapture.OutputFileOptions.Builder(f).build(),ContextCompat.getMainExecutor(this),object:ImageCapture.OnImageSavedCallback { override fun onImageSaved(output:ImageCapture.OutputFileResults) { openResult(Uri.fromFile(f)) }; override fun onError(e:ImageCaptureException) { Toast.makeText(this@MainActivity,"Gagal mengambil foto. Coba galeri.",Toast.LENGTH_SHORT).show() } }) }
 private fun openResult(uri:Uri) { startActivity(Intent(this,ResultActivity::class.java).putExtra("image_uri",uri.toString())) }
}
