// File: app/src/main/java/com/scanpr/app/HistoryActivity.kt
package com.scanpr.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.scanpr.app.databinding.ActivityHistoryBinding
class HistoryActivity:AppCompatActivity(){ override fun onCreate(savedInstanceState:Bundle?){ThemeManager.applySaved(this);super.onCreate(savedInstanceState);val b=ActivityHistoryBinding.inflate(layoutInflater);setContentView(b.root);val rows=ScanRepository(this).readAll();b.historyItems.text=if(rows.isEmpty()) "Belum ada scan" else rows.joinToString("

──────────

"){it} ; b.searchText.setOnEditorActionListener { v,_,_-> b.historyItems.text=rows.filter{it.contains(v.text.toString(),true)}.joinToString("

──────────

").ifBlank{"Tidak ada hasil"};true }} }
