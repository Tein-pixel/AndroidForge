// File: app/src/main/java/com/scanpr/app/data/ScanHistory.kt
package com.scanpr.app.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName="scan_history") data class ScanHistory(@PrimaryKey(autoGenerate=true) val id:Long=0,val question:String,val answer:String,val createdAt:Long=System.currentTimeMillis())
