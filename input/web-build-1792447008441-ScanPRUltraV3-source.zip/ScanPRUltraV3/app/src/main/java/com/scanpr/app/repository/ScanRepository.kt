// File: app/src/main/java/com/scanpr/app/repository/ScanRepository.kt
package com.scanpr.app
import android.content.Context
import com.scanpr.app.data.AppDatabase
import com.scanpr.app.data.ScanHistory
import kotlinx.coroutines.runBlocking
class ScanRepository(c:Context){private val dao=AppDatabase.get(c).scanDao();fun save(q:String,a:String)=runBlocking{kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){dao.insert(ScanHistory(question=q,answer=a))}};fun readAll():List<String> = runBlocking{kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){dao.all().map{"${it.question}
${it.answer}"}}}}
