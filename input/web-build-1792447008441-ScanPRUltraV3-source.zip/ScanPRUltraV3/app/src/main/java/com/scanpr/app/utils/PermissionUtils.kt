// File: app/src/main/java/com/scanpr/app/utils/PermissionUtils.kt
package com.scanpr.app
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
object PermissionUtils { fun hasCamera(c:Context)=ContextCompat.checkSelfPermission(c,android.Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED }
