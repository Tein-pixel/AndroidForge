// File: app/src/main/java/com/scanpr/app/viewmodel/MainViewModel.kt
package com.scanpr.app.viewmodel
import androidx.lifecycle.ViewModel
class MainViewModel:ViewModel()
