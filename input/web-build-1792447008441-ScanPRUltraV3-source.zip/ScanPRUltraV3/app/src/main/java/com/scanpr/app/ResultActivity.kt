// File: app/src/main/java/com/scanpr/app/ResultActivity.kt
package com.scanpr.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.scanpr.app.databinding.ActivityResultBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ResultActivity : AppCompatActivity() {
 private lateinit var b: ActivityResultBinding
 private var resultText=""
 override fun onCreate(savedInstanceState:Bundle?) { ThemeManager.applySaved(this); super.onCreate(savedInstanceState); b=ActivityResultBinding.inflate(layoutInflater); setContentView(b.root)
  b.backButton.setOnClickListener { finish() }; b.solveButton.setOnClickListener { solve() }; b.copyButton.setOnClickListener { val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager; cm.setPrimaryClip(ClipData.newPlainText("Scan PR",resultText)); Toast.makeText(this,"Hasil disalin",Toast.LENGTH_SHORT).show() }
  b.shareButton.setOnClickListener { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,resultText),"Bagikan hasil")) }
  intent.getStringExtra("image_uri")?.let { runOcr(Uri.parse(it)) }
 }
 private fun runOcr(uri:Uri) { try { val image=InputImage.fromFilePath(this,uri); val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS); recognizer.process(image).addOnSuccessListener { b.ocrText.setText(it.text) }.addOnFailureListener { Toast.makeText(this,"OCR gagal. Ketik soal secara manual.",Toast.LENGTH_LONG).show() } } catch(e:Exception) { Toast.makeText(this,"Foto tidak dapat dibaca. Ketik soal secara manual.",Toast.LENGTH_LONG).show() } }
 private fun solve() { val q=b.ocrText.text.toString().trim(); if(q.isBlank()){b.ocrText.error="Masukkan atau scan soal terlebih dahulu";return}; b.progress.visibility=View.VISIBLE; b.solveButton.isEnabled=false
  lifecycleScope.launch { val r=withContext(Dispatchers.IO) { AutoAiChain().solveWithAutoChain(q) }; b.progress.visibility=View.GONE; b.solveButton.isEnabled=true; resultText="Jawaban: ${r.answer}

Langkah:
${r.steps.joinToString("
")}

Metode alternatif: ${r.alternatives.joinToString("; ")}
Model: ${r.source}"; b.answerText.text=r.answer; b.stepsText.text=r.steps.mapIndexed { i,s -> "● ${i+1}   $s" }.joinToString("

") + if(r.alternatives.isNotEmpty()) "

Metode alternatif
"+r.alternatives.joinToString("
") else ""; ScanRepository(this@ResultActivity).save(q,resultText) }
 }
}
