// File: app/src/main/java/com/scanpr/app/utils/AutoAiChain.kt
package com.scanpr.app
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class AiResult(val answer:String,val steps:List<String>,val subject:String,val alternatives:List<String>,val source:String)
class AutoAiChain { private val client=OkHttpClient.Builder().callTimeout(30,TimeUnit.SECONDS).build()
 suspend fun solveWithAutoChain(text:String):AiResult { val prompt="Kamu guru Indonesia. Selesaikan soal ini dengan teliti: $text. Jawab dalam JSON: {"jawaban_akhir":"...","langkah":["..."],"mapel":"...","metode_alternatif":["..."]}. Jika tidak yakin, katakan." 
  // Public no-key endpoint availability, rate limits and terms can change. Never assume it is guaranteed.
  try { val url="https://text.pollinations.ai/"+URLEncoder.encode(prompt,"UTF-8")+"?model=openai";val req=Request.Builder().url(url).get().build();client.newCall(req).execute().use{res->if(res.isSuccessful){val body=res.body?.string().orEmpty();parse(body,"Pollinations (tanpa key)")?.let{return it}}} }catch(_:Exception){}
  return SolverEngine.solveOffline(text)
 }
 private fun parse(raw:String,source:String):AiResult? { return try { val s=raw.substring(raw.indexOf('{').coerceAtLeast(0),raw.lastIndexOf('}')+1);val j=JSONObject(s);AiResult(j.optString("jawaban_akhir","Jawaban tidak ditemukan"),j.optJSONArray("langkah").toStringList(),j.optString("mapel","Umum"),j.optJSONArray("metode_alternatif").toStringList(),source) }catch(_:Exception){null} }
 private fun org.json.JSONArray?.toStringList():List<String>{if(this==null)return emptyList();return (0 until length()).map{optString(it)}.filter{it.isNotBlank()}}
}
