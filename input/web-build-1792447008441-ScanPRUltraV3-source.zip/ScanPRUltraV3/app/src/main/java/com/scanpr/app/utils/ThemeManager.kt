// File: app/src/main/java/com/scanpr/app/utils/ThemeManager.kt
package com.scanpr.app
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
private val Context.themeStore by preferencesDataStore(name="settings")
enum class ThemeMode{LIGHT,DARK,SYSTEM}
object ThemeManager{private val KEY=stringPreferencesKey("theme_mode");fun getMode(c:Context):ThemeMode=runBlocking{ThemeMode.valueOf(c.themeStore.data.first()[KEY]?:"SYSTEM")};fun applySaved(c:Context){apply(getMode(c))};fun setMode(c:Context,m:ThemeMode){runBlocking{kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){c.themeStore.edit{it[KEY]=m.name}}};apply(m)};private fun apply(m:ThemeMode){AppCompatDelegate.setDefaultNightMode(when(m){ThemeMode.LIGHT->AppCompatDelegate.MODE_NIGHT_NO;ThemeMode.DARK->AppCompatDelegate.MODE_NIGHT_YES;ThemeMode.SYSTEM->AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM})}}
