// File: app/src/main/java/com/scanpr/app/data/AppDatabase.kt
package com.scanpr.app.data
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
@Database(entities=[ScanHistory::class],version=1,exportSchema=false) abstract class AppDatabase:RoomDatabase(){abstract fun scanDao():ScanDao;companion object{ @Volatile private var INSTANCE:AppDatabase?=null;fun get(c:Context)=INSTANCE?: synchronized(this){INSTANCE?:Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"scanpr.db").build().also{INSTANCE=it}}}}
