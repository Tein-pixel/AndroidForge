// File: app/src/main/java/com/scanpr/app/data/ScanDao.kt
package com.scanpr.app.data
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
@Dao interface ScanDao { @Insert suspend fun insert(item:ScanHistory); @Query("SELECT * FROM scan_history ORDER BY createdAt DESC") suspend fun all():List<ScanHistory> }
