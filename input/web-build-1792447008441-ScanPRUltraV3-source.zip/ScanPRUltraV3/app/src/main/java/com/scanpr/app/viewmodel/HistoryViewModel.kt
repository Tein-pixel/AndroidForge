// File: app/src/main/java/com/scanpr/app/viewmodel/HistoryViewModel.kt
package com.scanpr.app.viewmodel
import androidx.lifecycle.ViewModel
class HistoryViewModel:ViewModel()
