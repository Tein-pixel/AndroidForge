// File: app/src/main/java/com/scanpr/app/utils/ImageUtils.kt
package com.scanpr.app
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Context
import android.net.Uri
object ImageUtils { fun decodeSampled(c:Context,uri:Uri,maxPx:Int=1024):Bitmap? { return try { c.contentResolver.openInputStream(uri).use { input -> val bytes=input?.readBytes()?:return null; val opts=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(bytes,0,bytes.size,opts);var sample=1;while(opts.outWidth/sample>maxPx||opts.outHeight/sample>maxPx)sample*=2;BitmapFactory.decodeByteArray(bytes,0,bytes.size,BitmapFactory.Options().apply{inSampleSize=sample}) } }catch(_:OutOfMemoryError){null}catch(_:Exception){null} } }
