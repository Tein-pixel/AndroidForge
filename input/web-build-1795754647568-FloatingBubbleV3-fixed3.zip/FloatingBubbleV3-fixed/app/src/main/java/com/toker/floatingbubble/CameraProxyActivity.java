// CameraProxyActivity.java : java, Android 29+, com.toker.floatingbubble
// Transparent trampoline activity.
// MODE_CAMERA  → launches default camera intent, saves result to cache, routes by imageDest pref.
// MODE_GALLERY → launches gallery/media picker,  saves result to cache, routes by imageDest pref.
// Theme: Theme.Translucent.NoTitleBar — invisible to user, no flash.
// Routing (SharedPrefHelper.getImageDest):
//   DEST_AI        → GeminiWebViewActivity (default — combo saran)
//   DEST_SEARCH    → Google Search (image saved; Lens fallback)
//   DEST_TRANSLATE → Google Translate (no image — web mode)
package com.toker.floatingbubble;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class CameraProxyActivity extends Activity {

    public static final String EXTRA_MODE    = "proxy_mode";
    public static final int    MODE_CAMERA   = 0;
    public static final int    MODE_GALLERY  = 1;

    private static final int REQ_CAMERA  = 2001;
    private static final int REQ_GALLERY = 2002;

    private Uri cameraImageUri; // temp file URI for camera capture

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        int mode = getIntent().getIntExtra(EXTRA_MODE, MODE_CAMERA);
        if (mode == MODE_CAMERA) {
            launchCamera();
        } else {
            launchGallery();
        }
    }

    // ── launch helpers ────────────────────────────────────────────────────────

    private void launchCamera() {
        try {
            File tmpFile = new File(getCacheDir(), "bubble_capture_" + System.currentTimeMillis() + ".jpg");
            cameraImageUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    tmpFile);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
            startActivityForResult(cam, REQ_CAMERA);
        } catch (Exception e) {
            // FileProvider not configured — fall back to thumbnail capture
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cam, REQ_CAMERA);
        }
    }

    private void launchGallery() {
        Intent pick = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pick.setType("image/*");
        startActivityForResult(pick, REQ_GALLERY);
    }

    // ── result ────────────────────────────────────────────────────────────────

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String imagePath = null;

        if (resultCode == RESULT_OK) {
            if (requestCode == REQ_CAMERA) {
                if (cameraImageUri != null) {
                    // full-size capture via FileProvider
                    imagePath = saveUriToCache(cameraImageUri);
                } else if (data != null && data.getExtras() != null) {
                    // thumbnail fallback
                    Bitmap thumb = (Bitmap) data.getExtras().get("data");
                    if (thumb != null) imagePath = saveBitmapToCache(thumb);
                }
            } else if (requestCode == REQ_GALLERY && data != null && data.getData() != null) {
                imagePath = saveUriToCache(data.getData());
            }
        }

        if (imagePath != null) {
            routeImage(imagePath);
        }
        finish();
    }

    // ── routing ───────────────────────────────────────────────────────────────

    /**
     * Routes the captured/picked image to the destination set in Scan Setting.
     * Default (combo saran): DEST_AI → Gemini Vision.
     * DEST_SEARCH → Google Search (image not supported in WebView; opens search home).
     * DEST_TRANSLATE → Google Translate (text-only; opens translate home).
     */
    private void routeImage(String imagePath) {
        int dest = SharedPrefHelper.getImageDest(this);
        switch (dest) {
            case SharedPrefHelper.DEST_SEARCH:
                // Google Search — image upload not supported in embedded WebView.
                // Opens Google Search so user can manually describe/search.
                openWebMode(WebActivity.MODE_SEARCH, "");
                break;
            case SharedPrefHelper.DEST_TRANSLATE:
                openWebMode(WebActivity.MODE_TRANSLATE, "");
                break;
            case SharedPrefHelper.DEST_AI:
            default:
                openGeminiVision(imagePath);
                break;
        }
    }

    private void openGeminiVision(String imagePath) {
        Intent intent = new Intent(this, GeminiWebViewActivity.class);
        intent.putExtra(GeminiWebViewActivity.EXTRA_QUERY, "");
        intent.putExtra(GeminiWebViewActivity.EXTRA_IMAGE_PATH, imagePath);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void openWebMode(int mode, String query) {
        Intent intent = new Intent(this, WebActivity.class);
        intent.putExtra(WebActivity.EXTRA_MODE, mode);
        intent.putExtra(WebActivity.EXTRA_QUERY, query);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    // ── save helpers ──────────────────────────────────────────────────────────

    /** Copy a content URI to our private cache and return the absolute path. */
    private String saveUriToCache(Uri uri) {
        try {
            File out = new File(getCacheDir(), "gemini_img_" + System.currentTimeMillis() + ".jpg");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream fos = new FileOutputStream(out)) {
                if (in == null) return null;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
            }
            return out.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    /** Compress a Bitmap thumbnail to cache JPEG and return path. */
    private String saveBitmapToCache(Bitmap bmp) {
        try {
            File out = new File(getCacheDir(), "gemini_img_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream fos = new FileOutputStream(out)) {
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            }
            return out.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }
}
