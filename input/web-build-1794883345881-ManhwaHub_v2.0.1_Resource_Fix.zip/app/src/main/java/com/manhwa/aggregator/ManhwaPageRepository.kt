package com.manhwa.aggregator

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Detail, chapter and reader repository. MangaDex is handled through its JSON API;
 * existing HTML parser fallback remains available for supported source URLs.
 */
object ManhwaPageRepository {
    private const val PROXY_BASE = "https://api.allorigins.win/raw?url="
    private const val CHAPTER_PAGE_SIZE = 100

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(18, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .callTimeout(35, TimeUnit.SECONDS)
            .followRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    data class PageDetails(
        val description: String,
        val genres: List<String>,
        val status: String,
        val chapters: List<Chapter>,
        val manga: MangaDetail? = null,
        val totalChapters: Int = chapters.size,
        val nextChapterOffset: Int = chapters.size,
        val hasMoreChapters: Boolean = false,
        val chapterLoadError: Boolean = false
    )

    data class Chapter(
        val title: String,
        val url: String,
        val chapterNumber: String = "",
        val volume: String = "",
        val publishedAt: String = "",
        val scanlationGroup: String = ""
    )

    data class ChapterPage(
        val chapters: List<Chapter>,
        val total: Int,
        val nextOffset: Int,
        val hasMore: Boolean
    )

    suspend fun fetchDetails(pageUrl: String): PageDetails =
        withContext(Dispatchers.IO) {
            val mangaDexId = mangaDexTitleId(pageUrl)

            if (mangaDexId != null) {
                return@withContext fetchMangaDexDetails(mangaDexId)
            }

            val html = fetchHtml(pageUrl)
            val doc = Jsoup.parse(html, pageUrl)

            val description = doc.select(
                ".entry-content, .description-summary, .manga-excerpt, .summary__content, .desc, .synopsis, [itemprop=description]"
            ).firstOrNull()?.text()?.trim().orEmpty()

            val genres = doc.select(
                ".manga-genres a, .seriestugenre a, .genres a, .mgen a, .tag-links a"
            ).map {
                it.text().trim()
            }.filter {
                it.isNotBlank()
            }.distinct().take(12)

            val status = doc.select(
                ".post-status .summary-content, .summary-content, .status, .manga-status"
            ).firstOrNull()?.text()?.trim().orEmpty()

            val chapters = doc.select(
                ".eplister a, .listing-chapters_wrap a, .wp-manga-chapter a, .chapter-list a, .chapter-item a, .chbox a, .eph-num a, a[href*='chapter'], a[href*='/ch-']"
            ).mapNotNull { anchor ->
                val url = anchor.absUrl("href")
                    .ifBlank { anchor.attr("href") }

                val title = anchor.text()
                    .trim()
                    .ifBlank { anchor.attr("title").trim() }

                if (url.startsWith("http") && title.isNotBlank()) {
                    Chapter(title, url)
                } else {
                    null
                }
            }.distinctBy {
                it.url
            }.take(250)

            PageDetails(description, genres, status, chapters)
        }

    /** Fetch another MangaDex chapter page when the user approaches the end of the list. */
    suspend fun fetchMoreChapters(pageUrl: String, offset: Int): ChapterPage =
        withContext(Dispatchers.IO) {
            val mangaDexId = mangaDexTitleId(pageUrl)
                ?: return@withContext ChapterPage(emptyList(), offset, offset, false)
            fetchMangaDexChapterPage(mangaDexId, offset)
        }

    /** Public helper used by the detail screen to enable MangaDex-only pagination. */
    fun isMangaDexTitle(pageUrl: String): Boolean = mangaDexTitleId(pageUrl) != null

    suspend fun fetchReaderImages(chapterUrl: String): List<String> =
        withContext(Dispatchers.IO) {
            val mangaDexChapterId = mangaDexChapterId(chapterUrl)

            if (mangaDexChapterId != null) {
                return@withContext fetchMangaDexReaderImages(mangaDexChapterId)
            }

            val html = fetchHtml(chapterUrl)
            val doc = Jsoup.parse(html, chapterUrl)

            doc.select(
                "#readerarea img, .reading-content img, .reader-area img, .chapter-content img, .rdminimal img, .chapter-images img, .reading-area img"
            ).mapNotNull { image ->
                val candidate = listOf(
                    "data-src",
                    "data-lazy-src",
                    "data-original",
                    "data-cfsrc",
                    "src"
                ).firstNotNullOfOrNull { key ->
                    image.attr(key).takeIf {
                        it.isNotBlank() && !it.startsWith("data:")
                    }
                }

                val absolute = candidate?.let { raw ->
                    image.absUrl("src").takeIf {
                        it == raw
                    } ?: resolveUrl(chapterUrl, raw)
                }

                absolute?.takeIf {
                    it.startsWith("http")
                }
            }.distinct()
        }

    private fun mangaDexTitleId(pageUrl: String): String? =
        try {
            val uri = java.net.URI(pageUrl)
            val host = uri.host?.lowercase().orEmpty()
            val parts = uri.path.split('/').filter { it.isNotBlank() }

            if (
                (host == "mangadex.org" || host.endsWith(".mangadex.org")) &&
                parts.size >= 2 &&
                parts[0] == "title"
            ) {
                parts[1].takeIf { it.isNotBlank() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }

    private fun mangaDexChapterId(chapterUrl: String): String? =
        try {
            val uri = java.net.URI(chapterUrl)
            val host = uri.host?.lowercase().orEmpty()
            val parts = uri.path.split('/').filter { it.isNotBlank() }

            if (
                (host == "mangadex.org" || host.endsWith(".mangadex.org")) &&
                parts.size >= 2 &&
                parts[0] == "chapter"
            ) {
                parts[1].takeIf { it.isNotBlank() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }

    private suspend fun fetchMangaDexDetails(mangaId: String): PageDetails {
        val mangaUrl = MangaDexApiSource.apiUrl("manga", mangaId)
            .addQueryParameter("includes[]", "cover_art")
            .addQueryParameter("includes[]", "author")
            .addQueryParameter("includes[]", "artist")
            .build()

        val mangaJson = MangaDexApiSource.getJson(mangaUrl)
        val manga = mangaJson.optJSONObject("data")
            ?: throw IllegalStateException("Detail MangaDex tidak ditemukan")
        val attributes = manga.optJSONObject("attributes")
            ?: throw IllegalStateException("Metadata MangaDex kosong")

        val title = MangaDexApiSource.preferredLocalizedValue(
            attributes.optJSONObject("title")
        ).ifBlank { "Judul tidak tersedia" }

        val description = MangaDexApiSource.preferredLocalizedValue(
            attributes.optJSONObject("description")
        )

        val status = when (attributes.optString("status")) {
            "ongoing" -> "Berjalan"
            "completed" -> "Tamat"
            "hiatus" -> "Hiatus"
            "cancelled" -> "Dihentikan"
            else -> "Status tidak tersedia"
        }

        val year = attributes.optInt("year").takeIf { it > 0 }?.toString().orEmpty()
        var coverUrl = ""
        val authors = linkedSetOf<String>()
        val artists = linkedSetOf<String>()
        val relationships = manga.optJSONArray("relationships")

        if (relationships != null) {
            for (index in 0 until relationships.length()) {
                val relation = relationships.optJSONObject(index) ?: continue
                val relationAttributes = relation.optJSONObject("attributes")
                val name = relationAttributes?.optString("name")
                    ?.trim()
                    ?.takeIf { it.isNotBlank() && it != "null" }

                when (relation.optString("type")) {
                    "author" -> if (name != null) authors.add(name)
                    "artist" -> if (name != null) artists.add(name)
                    "cover_art" -> {
                        val fileName = relationAttributes?.optString("fileName")
                            ?.takeIf { it.isNotBlank() && it != "null" }
                        if (fileName != null) {
                            coverUrl = "https://uploads.mangadex.org/covers/$mangaId/$fileName.256.jpg"
                        }
                    }
                }
            }
        }

        val tags = mutableListOf<String>()
        val tagArray = attributes.optJSONArray("tags")
        if (tagArray != null) {
            for (index in 0 until tagArray.length()) {
                val tag = tagArray.optJSONObject(index) ?: continue
                val name = MangaDexApiSource.preferredLocalizedValue(
                    tag.optJSONObject("attributes")?.optJSONObject("name")
                )
                if (name.isNotBlank()) tags.add(name)
            }
        }

        val genreTags = mutableListOf<String>()
        if (tagArray != null) {
            for (index in 0 until tagArray.length()) {
                val tag = tagArray.optJSONObject(index) ?: continue
                val tagAttributes = tag.optJSONObject("attributes") ?: continue
                if (tagAttributes.optString("group") == "genre") {
                    val name = MangaDexApiSource.preferredLocalizedValue(
                        tagAttributes.optJSONObject("name")
                    )
                    if (name.isNotBlank()) genreTags.add(name)
                }
            }
        }

        val mangaDetail = MangaDetail(
            title = title,
            coverUrl = coverUrl,
            author = authors.joinToString(", "),
            artist = artists.joinToString(", "),
            synopsis = description,
            tags = tags.distinct().take(14),
            status = status,
            year = year
        )

        var firstChapterPage = ChapterPage(emptyList(), 0, 0, false)
        var chapterLoadError = false
        try {
            firstChapterPage = fetchMangaDexChapterPage(mangaId, 0)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // Metadata remains useful even if the chapter feed is temporarily unavailable.
            chapterLoadError = true
        }

        return PageDetails(
            description = description,
            genres = genreTags.distinct(),
            status = status,
            chapters = firstChapterPage.chapters,
            manga = mangaDetail,
            totalChapters = firstChapterPage.total,
            nextChapterOffset = firstChapterPage.nextOffset,
            hasMoreChapters = firstChapterPage.hasMore,
            chapterLoadError = chapterLoadError
        )
    }

    private suspend fun fetchMangaDexChapterPage(
        mangaId: String,
        offset: Int
    ): ChapterPage {
        val safeOffset = offset.coerceAtLeast(0)
        val chapterUrl = MangaDexApiSource.apiUrl("manga", mangaId, "feed")
            .addQueryParameter("limit", CHAPTER_PAGE_SIZE.toString())
            .addQueryParameter("offset", safeOffset.toString())
            .addQueryParameter("order[volume]", "desc")
            .addQueryParameter("order[chapter]", "desc")
            .addQueryParameter("translatedLanguage[]", "id")
            .addQueryParameter("contentRating[]", "safe")
            .addQueryParameter("includes[]", "scanlation_group")
            .build()

        val chapterJson = MangaDexApiSource.getJson(chapterUrl)
        val chapterData = chapterJson.optJSONArray("data")
        val total = chapterJson.optInt("total", safeOffset + (chapterData?.length() ?: 0))
        val chapters = mutableListOf<Chapter>()

        if (chapterData != null) {
            for (index in 0 until chapterData.length()) {
                val chapter = chapterData.optJSONObject(index) ?: continue
                val id = chapter.optString("id").takeIf { it.isNotBlank() } ?: continue
                val chapterAttributes = chapter.optJSONObject("attributes") ?: continue

                val number = chapterAttributes.optString("chapter")
                    .takeIf { it.isNotBlank() && it != "null" }.orEmpty()
                val volume = chapterAttributes.optString("volume")
                    .takeIf { it.isNotBlank() && it != "null" }.orEmpty()
                val name = chapterAttributes.optString("title")
                    .trim().takeIf { it.isNotBlank() && it != "null" }.orEmpty()
                val publishedAt = chapterAttributes.optString("publishAt")
                    .takeIf { it.isNotBlank() && it != "null" }.orEmpty()

                val group = chapter.optJSONArray("relationships")
                    ?.let { relations ->
                        (0 until relations.length()).firstNotNullOfOrNull { relationIndex ->
                            val relation = relations.optJSONObject(relationIndex)
                                ?: return@firstNotNullOfOrNull null
                            if (relation.optString("type") == "scanlation_group") {
                                relation.optJSONObject("attributes")
                                    ?.optString("name")
                                    ?.takeIf { it.isNotBlank() && it != "null" }
                            } else {
                                null
                            }
                        }
                    }.orEmpty()

                val label = buildString {
                    append("Chapter ")
                    append(number.ifBlank { "spesial" })
                    if (name.isNotBlank()) append(" · ").append(name)
                }

                chapters.add(
                    Chapter(
                        title = label,
                        url = "https://mangadex.org/chapter/$id",
                        chapterNumber = number,
                        volume = volume,
                        publishedAt = publishedAt,
                        scanlationGroup = group
                    )
                )
            }
        }

        val received = chapterData?.length() ?: 0
        val nextOffset = safeOffset + received
        val hasMore = received > 0 && nextOffset < total

        return ChapterPage(
            chapters = chapters.distinctBy { it.url },
            total = total,
            nextOffset = nextOffset,
            hasMore = hasMore
        )
    }

    private suspend fun fetchMangaDexReaderImages(chapterId: String): List<String> {
        val url = MangaDexApiSource.apiUrl("at-home", "server", chapterId).build()
        val json = MangaDexApiSource.getJson(url)

        val baseUrl = json.optString("baseUrl").trimEnd('/')
        val chapter = json.optJSONObject("chapter") ?: return emptyList()
        val hash = chapter.optString("hash")
        val originalFiles = chapter.optJSONArray("data")
        val useDataSaver = originalFiles == null
        val files = originalFiles ?: chapter.optJSONArray("dataSaver") ?: return emptyList()
        val qualityPath = if (useDataSaver) "data-saver" else "data"

        if (baseUrl.isBlank() || hash.isBlank()) return emptyList()

        return (0 until files.length()).mapNotNull { index ->
            val file = files.optString(index)
            if (file.isBlank()) {
                null
            } else {
                "$baseUrl/$qualityPath/$hash/${
                    java.net.URLEncoder.encode(file, "UTF-8").replace("+", "%20")
                }"
            }
        }
    }

    private fun fetchHtml(url: String): String {
        val proxiedUrl = PROXY_BASE + URLEncoder.encode(url, "UTF-8")
        val request = Request.Builder()
            .url(proxiedUrl)
            .header(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36"
            )
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Server sumber merespons ${response.code}")
            }
            return response.body?.string().orEmpty()
        }
    }

    private fun resolveUrl(base: String, value: String): String =
        try {
            java.net.URI(base).resolve(value).toString()
        } catch (_: Exception) {
            value
        }
}
