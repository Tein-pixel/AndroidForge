package com.manhwa.aggregator

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.manhwa.aggregator.databinding.ActivityManhwaDetailBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class ManhwaDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityManhwaDetailBinding
    private lateinit var item: Manhwa
    private val library by lazy { LibraryStore(this) }

    private lateinit var headerAdapter: DetailHeaderAdapter
    private lateinit var chapterAdapter: ChapterAdapter
    private var chapters: List<ManhwaPageRepository.Chapter> = emptyList()
    private var nextChapterOffset = 0
    private var totalChapterCount = 0
    private var hasMoreChapters = false
    private var isLoadingMore = false
    private var isDetailsLoaded = false

    companion object {
        const val EXTRA_TITLE = "manhwa_title"
        const val EXTRA_LINK = "manhwa_link"
        const val EXTRA_IMAGE = "manhwa_image"
        const val EXTRA_CHAPTER = "manhwa_latest_chapter"
        const val EXTRA_SOURCE = "manhwa_source"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManhwaDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        item = ManhwaUrlResolver.resolveItem(
            Manhwa(
                intent.getStringExtra(EXTRA_TITLE).orEmpty(),
                intent.getStringExtra(EXTRA_LINK).orEmpty(),
                intent.getStringExtra(EXTRA_IMAGE).orEmpty(),
                intent.getStringExtra(EXTRA_CHAPTER).orEmpty(),
                intent.getStringExtra(EXTRA_SOURCE).orEmpty()
            )
        )

        library.addToHistory(item)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnOpenSourceTop.setOnClickListener { openSource(item.link, item.title) }
        binding.btnRetryDetails.setOnClickListener { loadDetails() }

        binding.rvChapters.layoutManager = LinearLayoutManager(this).apply {
            isItemPrefetchEnabled = true
            initialPrefetchItemCount = 6
        }
        binding.rvChapters.setItemViewCacheSize(8)
        // ListAdapter + RecyclerView recycling keeps long chapter lists responsive.
        binding.rvChapters.itemAnimator = null
        binding.rvChapters.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0) maybeLoadMoreChapters()
            }
        })

        loadDetails()
    }

    private fun loadDetails() {
        isDetailsLoaded = false
        hasMoreChapters = false
        binding.progressDetails.visibility = View.VISIBLE
        binding.detailErrorPanel.visibility = View.GONE
        binding.rvChapters.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                val response = ManhwaPageRepository.fetchDetails(item.link)
                val manga = response.manga ?: MangaDetail(
                    title = item.title,
                    coverUrl = item.imageUrl,
                    author = "",
                    artist = "",
                    synopsis = response.description,
                    tags = response.genres,
                    status = response.status,
                    year = ""
                )

                chapters = response.chapters
                totalChapterCount = response.totalChapters.coerceAtLeast(chapters.size)
                nextChapterOffset = response.nextChapterOffset
                hasMoreChapters = response.hasMoreChapters &&
                    ManhwaPageRepository.isMangaDexTitle(item.link)

                headerAdapter = DetailHeaderAdapter(
                    detail = manga.copy(
                        title = manga.title.ifBlank { item.title },
                        coverUrl = manga.coverUrl.ifBlank { item.imageUrl }
                    ),
                    fallbackCoverUrl = item.imageUrl,
                    initialChapterCount = totalChapterCount,
                    initialChapterLabel = when {
                        response.chapterLoadError -> "Gagal memuat daftar chapter"
                        totalChapterCount > 0 -> "$totalChapterCount chapter"
                        else -> "Belum ada chapter Bahasa Indonesia"
                    },
                    onStartReading = { startReading() },
                    onFavorite = { toggleFavorite() },
                    onReadingStatus = { showReadingStatusPicker() }
                )

                chapterAdapter = ChapterAdapter { chapter -> openReader(chapter) }
                chapterAdapter.submitList(chapters.toList())
                binding.rvChapters.adapter = ConcatAdapter(headerAdapter, chapterAdapter)

                updateHeaderActions()
                isDetailsLoaded = true
                binding.detailErrorPanel.visibility = View.GONE

                if (response.chapterLoadError) {
                    Toast.makeText(
                        this@ManhwaDetailActivity,
                        "Detail komik dimuat, tetapi daftar chapter sedang bermasalah.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                binding.tvDetailsError.text =
                    "Detail komik belum dapat dimuat. Periksa koneksi, lalu coba lagi."
                binding.detailErrorPanel.visibility = View.VISIBLE
                binding.rvChapters.visibility = View.GONE
                isDetailsLoaded = false
            } finally {
                binding.progressDetails.visibility = View.GONE
            }
        }
    }

    private fun maybeLoadMoreChapters() {
        if (!isDetailsLoaded || !hasMoreChapters || isLoadingMore) return

        val layoutManager = binding.rvChapters.layoutManager as? LinearLayoutManager ?: return
        val lastVisible = layoutManager.findLastVisibleItemPosition()
        val totalItems = binding.rvChapters.adapter?.itemCount ?: return

        if (totalItems > 0 && lastVisible >= totalItems - 7) {
            loadMoreChapters()
        }
    }

    private fun loadMoreChapters() {
        if (!hasMoreChapters || isLoadingMore) return
        isLoadingMore = true
        binding.progressMore.visibility = View.VISIBLE

        lifecycleScope.launch {
            val requestedOffset = nextChapterOffset
            try {
                val page = ManhwaPageRepository.fetchMoreChapters(item.link, requestedOffset)
                val merged = (chapters + page.chapters)
                    .distinctBy { it.url }

                chapterAdapter.submitList(merged)
                chapters = merged
                totalChapterCount = page.total.coerceAtLeast(merged.size)

                val madeProgress = page.nextOffset > requestedOffset && page.chapters.isNotEmpty()
                nextChapterOffset = page.nextOffset
                hasMoreChapters = page.hasMore && madeProgress
                headerAdapter.updateChapterCount(totalChapterCount)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                Toast.makeText(
                    this@ManhwaDetailActivity,
                    "Chapter berikutnya gagal dimuat. Geser lagi untuk mencoba ulang.",
                    Toast.LENGTH_SHORT
                ).show()
            } finally {
                isLoadingMore = false
                binding.progressMore.visibility = View.GONE
            }
        }
    }

    private fun updateHeaderActions() {
        if (!::headerAdapter.isInitialized) return
        val favoriteText = if (library.isFavorite(item)) "Tersimpan ✓" else "Simpan"
        val progress = library.getProgress(item.link)
        val startText = if (progress != null) "Lanjutkan baca" else "Mulai baca"
        val readingStatus = library.readingStatus(item)
            ?.let { "Daftar bacaan · $it" }
            ?: "Tambah ke daftar bacaan"

        headerAdapter.updateActions(startText, favoriteText, readingStatus)
    }

    private fun toggleFavorite() {
        library.toggleFavorite(item)
        updateHeaderActions()
    }

    private fun showReadingStatusPicker() {
        val options = arrayOf(
            "Sedang dibaca",
            "Rencana baca",
            "Selesai",
            "Ditunda",
            "Dihentikan",
            "Hapus dari daftar"
        )

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Status bacaan")
            .setItems(options) { _, which ->
                val selected = if (which == options.lastIndex) null else options[which]
                library.setReadingStatus(item, selected)
                updateHeaderActions()
                val message = if (selected == null) {
                    "Dihapus dari daftar bacaan"
                } else {
                    "Status: $selected"
                }
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun startReading() {
        val saved = library.getProgress(item.link)
        val chapter = saved?.let {
            ManhwaPageRepository.Chapter(it.chapterTitle, it.chapterUrl)
        } ?: chapters.firstOrNull()

        if (chapter != null) {
            openReader(chapter)
        } else {
            Toast.makeText(
                this,
                "Chapter belum tersedia dalam Bahasa Indonesia.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun openReader(chapter: ManhwaPageRepository.Chapter) {
        startActivity(Intent(this, ReaderActivity::class.java).apply {
            putExtra(ReaderActivity.EXTRA_CHAPTER_URL, chapter.url)
            putExtra(ReaderActivity.EXTRA_CHAPTER_TITLE, chapter.title)
            putExtra(ReaderActivity.EXTRA_MANGA_TITLE, item.title)
            putExtra(ReaderActivity.EXTRA_ITEM_LINK, item.link)
            putExtra(ReaderActivity.EXTRA_ITEM_IMAGE, item.imageUrl)
            putExtra(ReaderActivity.EXTRA_ITEM_SOURCE, item.source)
        })
    }

    private fun openSource(url: String, title: String) {
        if (url.isBlank()) {
            Toast.makeText(this, "Tautan sumber tidak tersedia.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, SourceWebActivity::class.java).apply {
            putExtra(SourceWebActivity.EXTRA_URL, url)
            putExtra(SourceWebActivity.EXTRA_TITLE, title)
        })
    }

    override fun onResume() {
        super.onResume()
        if (isDetailsLoaded) updateHeaderActions()
    }
}
