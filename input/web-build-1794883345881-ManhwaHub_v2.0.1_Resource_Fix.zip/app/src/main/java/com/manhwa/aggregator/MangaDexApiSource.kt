package com.manhwa.aggregator

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/** Direct JSON integration for MangaDex. Android HTTP requests do not require a CORS proxy. */
internal object MangaDexApiSource {
    private const val API_HOST = "api.mangadex.org"

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .callTimeout(24, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val tagMutex = Mutex()

    @Volatile
    private var tagIdsByName: Map<String, String>? = null

    internal fun apiUrl(vararg pathSegments: String): HttpUrl.Builder {
        val builder = HttpUrl.Builder().scheme("https").host(API_HOST)
        pathSegments.forEach { segment -> builder.addPathSegment(segment) }
        return builder
    }

    /**
     * Returns the newest safe titles, or title-search results when query is supplied.
     * Only titles with Indonesian translations are requested for this Indonesian-first app.
     * The app intentionally keeps the catalog restricted to the Safe content rating.
     */
    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> {
        val builder = apiUrl("manga")
            .addQueryParameter("limit", "30")
            .addQueryParameter("includes[]", "cover_art")
            .addQueryParameter("contentRating[]", "safe")
            .addQueryParameter("availableTranslatedLanguage[]", "id")

        if (query.isNotBlank()) {
            builder.addQueryParameter("title", query.trim())
                .addQueryParameter("order[relevance]", "desc")
        } else {
            builder.addQueryParameter("order[latestUploadedChapter]", "desc")
        }

        if (genre.isNotBlank() && !genre.equals("Semua", ignoreCase = true)) {
            val tagId = resolveTagId(genre)
                ?: throw IllegalArgumentException("Genre $genre belum tersedia di katalog.")
            builder.addQueryParameter("includedTags[]", tagId)
        }

        val response = getJson(builder.build())
        val data = response.optJSONArray("data") ?: return emptyList()
        val results = ArrayList<Manhwa>(data.length())

        for (index in 0 until data.length()) {
            val manga = data.optJSONObject(index) ?: continue
            val id = manga.optString("id").takeIf { it.isNotBlank() } ?: continue
            val attributes = manga.optJSONObject("attributes") ?: continue
            val title = preferredLocalizedValue(attributes.optJSONObject("title"))
            if (title.isBlank()) continue

            var coverFile = ""
            val relationships = manga.optJSONArray("relationships")
            if (relationships != null) {
                for (relIndex in 0 until relationships.length()) {
                    val relation = relationships.optJSONObject(relIndex) ?: continue
                    if (relation.optString("type") == "cover_art") {
                        coverFile = relation.optJSONObject("attributes")
                            ?.optString("fileName")
                            .orEmpty()
                        if (coverFile.isNotBlank()) break
                    }
                }
            }

            val coverUrl = if (coverFile.isNotBlank()) {
                "https://uploads.mangadex.org/covers/$id/$coverFile.256.jpg"
            } else {
                ""
            }

            val latestChapterId = attributes.optString("latestUploadedChapter")
            val hasLatestChapter = latestChapterId.isNotBlank() && latestChapterId != "null"

            results.add(
                Manhwa(
                    title = title,
                    link = "https://mangadex.org/title/$id",
                    imageUrl = coverUrl,
                    latestChapter = if (hasLatestChapter) "Update tersedia" else "Belum ada chapter",
                    source = "MangaDex"
                )
            )
        }

        return results
    }

    /** Load MangaDex tag names once per process, then resolve the requested chip locally. */
    private suspend fun resolveTagId(name: String): String? {
        val key = name.trim().lowercase()
        if (key.isBlank()) return null

        tagIdsByName?.let { cached -> return cached[key] }

        return tagMutex.withLock {
            tagIdsByName?.let { cached -> return@withLock cached[key] }

            val response = getJson(apiUrl("manga", "tag").build())
            val data = response.optJSONArray("data")
            val map = LinkedHashMap<String, String>()

            if (data != null) {
                for (index in 0 until data.length()) {
                    val tag = data.optJSONObject(index) ?: continue
                    val id = tag.optString("id").takeIf { it.isNotBlank() } ?: continue
                    val attributes = tag.optJSONObject("attributes") ?: continue
                    val localizedName = preferredLocalizedValue(attributes.optJSONObject("name"))
                    if (localizedName.isNotBlank()) {
                        map[localizedName.trim().lowercase()] = id
                    }
                }
            }

            tagIdsByName = map
            map[key]
        }
    }

    internal suspend fun getJson(url: HttpUrl): JSONObject = suspendCancellableCoroutine { continuation ->
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "ManhwaHub-Android/2.0")
            .header("Accept", "application/json")
            .build()
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }

        call.enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) {
                if (continuation.isActive) continuation.resumeWithException(error)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!continuation.isActive) return
                    if (!response.isSuccessful) {
                        continuation.resumeWithException(
                            IllegalStateException("MangaDex HTTP ${response.code}")
                        )
                        return
                    }

                    try {
                        val body = response.body?.string().orEmpty()
                        val json = JSONObject(body)
                        if (json.optString("result") == "error") {
                            continuation.resumeWithException(
                                IllegalStateException("MangaDex API mengembalikan error")
                            )
                        } else {
                            continuation.resume(json)
                        }
                    } catch (error: Exception) {
                        if (continuation.isActive) continuation.resumeWithException(error)
                    }
                }
            }
        })
    }

    internal fun preferredLocalizedValue(values: JSONObject?): String {
        if (values == null) return ""
        val preferred = listOf("id", "en", "ja-ro", "ja")
        for (key in preferred) {
            val value = values.optString(key).trim()
            if (value.isNotBlank() && value != "null") return value
        }
        val keys = values.keys()
        while (keys.hasNext()) {
            val value = values.optString(keys.next()).trim()
            if (value.isNotBlank() && value != "null") return value
        }
        return ""
    }
}
