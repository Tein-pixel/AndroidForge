package com.manhwa.aggregator

/**
 * Catalog provider for the app. The old Comick endpoint is no longer used;
 * MangaDex is the active JSON source for search and latest-title discovery.
 */
class ManhwaScraper {
    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> {
        return MangaDexApiSource.fetchLatest(query = query, genre = genre)
    }
}
