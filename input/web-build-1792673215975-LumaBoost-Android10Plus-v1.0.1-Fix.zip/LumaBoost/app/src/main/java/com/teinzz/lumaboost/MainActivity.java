package com.teinzz.lumaboost;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.database.Cursor;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_TREE = 6001;
    private static final String PREFS = "lumaboost_settings";
    private LinearLayout root, body, bottomNav;
    private TextView headerSubtitle;
    private String currentTab = "home";
    private String themeMode = "amoled";
    private Palette p;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getString("theme", "amoled");
        p = Palette.from(themeMode);
        buildShell();
        renderHome();
        updateBars();
    }

    @Override protected void onResume() {
        super.onResume();
        if (root != null) {
            updateBars();
            if ("apps".equals(currentTab)) {
                currentTab = "home";
                renderHome();
            }
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        worker.shutdown();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);
        root.setPadding(dp(18), dp(8), dp(18), dp(4));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(0, dp(8), 0, dp(14));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        logoLp.rightMargin = dp(11);
        header.addView(logo, logoLp);

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("LumaBoost", 21, p.text, true);
        title.setLetterSpacing(-0.02f);
        titleWrap.addView(title);
        headerSubtitle = text("Perawatan perangkat yang aman", 11, p.muted, false);
        headerSubtitle.setPadding(0, dp(2), 0, 0);
        titleWrap.addView(headerSubtitle);
        header.addView(titleWrap, new LinearLayout.LayoutParams(0, -2, 1));

        TextView themeButton = text("◐", 24, p.text, true);
        themeButton.setGravity(Gravity.CENTER);
        themeButton.setBackground(shape(p.card, p.stroke, 16));
        themeButton.setClickable(true);
        themeButton.setFocusable(true);
        header.addView(themeButton, new LinearLayout.LayoutParams(dp(46), dp(44)));
        themeButton.setOnClickListener(v -> showThemeMenu(themeButton));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setClipToPadding(false);
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setPadding(dp(4), dp(7), dp(4), dp(7));
        bottomNav.setBackground(shape(p.nav, p.stroke, 22));
        bottomNav.addView(navButton("⌂", "Beranda", "home"), new LinearLayout.LayoutParams(0, dp(55), 1));
        bottomNav.addView(navButton("▦", "Aplikasi", "apps"), new LinearLayout.LayoutParams(0, dp(55), 1));
        bottomNav.addView(navButton("◉", "Perangkat", "device"), new LinearLayout.LayoutParams(0, dp(55), 1));
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(-1, -2);
        navLp.topMargin = dp(8);
        root.addView(bottomNav, navLp);
        setContentView(root);
    }

    private View navButton(String glyph, String label, String tab) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(3), dp(5), dp(3), dp(4));
        boolean selected = currentTab.equals(tab);
        item.setBackground(shape(selected ? p.accentSoft : p.nav, selected ? p.accent : p.nav, 15));
        TextView icon = text(glyph, 20, selected ? p.accent : p.muted, true);
        icon.setGravity(Gravity.CENTER);
        TextView caption = text(label, 10, selected ? p.text : p.muted, selected);
        caption.setGravity(Gravity.CENTER);
        item.addView(icon);
        item.addView(caption);
        item.setOnClickListener(v -> {
            currentTab = tab;
            if ("home".equals(tab)) renderHome();
            else if ("device".equals(tab)) renderDevice();
            else startActivity(new Intent(this, AppManagerActivity.class));
            refreshNav();
        });
        return item;
    }

    private void refreshNav() {
        bottomNav.removeAllViews();
        bottomNav.addView(navButton("⌂", "Beranda", "home"), new LinearLayout.LayoutParams(0, dp(55), 1));
        bottomNav.addView(navButton("▦", "Aplikasi", "apps"), new LinearLayout.LayoutParams(0, dp(55), 1));
        bottomNav.addView(navButton("◉", "Perangkat", "device"), new LinearLayout.LayoutParams(0, dp(55), 1));
    }

    private void renderHome() {
        currentTab = "home";
        body.removeAllViews();
        headerSubtitle.setText("Perawatan perangkat yang aman");
        DeviceSnapshot s = snapshot();

        LinearLayout hero = card(true);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout status = row();
        TextView statusLabel = text("RINGKASAN PERANGKAT", 10, p.onAccent, true);
        statusLabel.setLetterSpacing(0.12f);
        status.addView(statusLabel, new LinearLayout.LayoutParams(0, -2, 1));
        TextView statusChip = text(s.thermalLabel, 10, p.onAccent, true);
        statusChip.setPadding(dp(9), dp(5), dp(9), dp(5));
        statusChip.setBackground(shape(p.chipOverlay, 0x00FFFFFF, 30));
        status.addView(statusChip);
        hero.addView(status);

        LinearLayout intro = row();
        intro.setGravity(Gravity.CENTER_VERTICAL);
        CircularGauge gauge = new CircularGauge(this, s.ramPercent, p.onAccent, 0x88FFFFFF);
        LinearLayout.LayoutParams gaugeLp = new LinearLayout.LayoutParams(dp(100), dp(100));
        gaugeLp.rightMargin = dp(16);
        gaugeLp.topMargin = dp(13);
        intro.addView(gauge, gaugeLp);
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        TextView headline = text(s.thermalHot ? "Istirahatkan perangkat" : "Perangkat terpantau", 18, p.onAccent, true);
        info.addView(headline);
        TextView ram = text("RAM digunakan sekitar " + s.ramPercent + "%", 12, 0xFFE7DFFF, false);
        ram.setPadding(0, dp(5), 0, dp(10));
        info.addView(ram);
        TextView free = text(s.storageFree + " tersedia", 12, 0xFFE7DFFF, false);
        info.addView(free);
        intro.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        hero.addView(intro);

        Button optimize = button("✦   OPTIMASI AMAN 1 TAP", true);
        LinearLayout.LayoutParams optLp = new LinearLayout.LayoutParams(-1, dp(51));
        optLp.topMargin = dp(18);
        hero.addView(optimize, optLp);
        optimize.setOnClickListener(v -> runSafeOptimize());
        TextView small = text("Membersihkan cache LumaBoost dan memperbarui status. Tidak menghapus data aplikasi lain.", 10, 0xFFD6C9FF, false);
        small.setGravity(Gravity.CENTER);
        small.setPadding(dp(8), dp(10), dp(8), 0);
        hero.addView(small);
        body.addView(hero, marginBottom(16));

        LinearLayout stats = row();
        stats.addView(statCard("RAM TERPAKAI", s.ramUsed, s.ramTotal, "◌"), weightedLp(1, 4));
        stats.addView(statCard("PENYIMPANAN", s.storageFree, "ruang kosong", "▤"), weightedLp(1, 4));
        stats.addView(statCard("BATERAI", s.battery + "%", s.batteryTemp, "ϟ"), weightedLp(1, 4));
        body.addView(stats, marginBottom(20));

        sectionHeading("PINTASAN CEPAT", "Aksi yang sering dipakai");
        LinearLayout shortcuts = row();
        shortcuts.addView(shortcut("▤", "File sementara", "Pilih folder", () -> chooseTree()), weightedLp(1, 7));
        shortcuts.addView(shortcut("▦", "Aplikasi", "Kelola", () -> startActivity(new Intent(this, AppManagerActivity.class))), weightedLp(1, 7));
        shortcuts.addView(shortcut("⚙", "Penyimpanan", "Pengaturan", () -> openStorageSettings()), weightedLp(1, 7));
        body.addView(shortcuts, marginBottom(20));

        sectionHeading("OPTIMASI PERANGKAT", "Informasi nyata, tanpa klaim palsu");
        LinearLayout detailCard = card(false);
        detailCard.setPadding(dp(15), dp(5), dp(15), dp(5));
        addInfoRow(detailCard, "RAM tersedia", s.ramAvailable, "Kapasitas yang saat ini tersedia untuk sistem dan aplikasi.", "◌");
        addDivider(detailCard);
        addInfoRow(detailCard, "Suhu baterai", s.batteryTemp, s.thermalLabel, "ϟ");
        addDivider(detailCard);
        addInfoRow(detailCard, "File sementara", "Pindai folder pilihan", "Kamu memilih folder dan mengonfirmasi sebelum file dihapus.", "⌕");
        addDivider(detailCard);
        addInfoRow(detailCard, "Cache aplikasi", "Buka pengaturan Android", "Android mengatur cache aplikasi lain. Penghapusan dilakukan lewat sistem.", "▤");
        body.addView(detailCard, marginBottom(14));

        TextView note = text("Catatan: Android mengelola RAM otomatis. LumaBoost tidak mengklaim dapat mengosongkan RAM seluruh aplikasi secara paksa.", 11, p.muted, false);
        note.setLineSpacing(dp(3), 1f);
        note.setPadding(dp(5), dp(2), dp(5), dp(12));
        body.addView(note);
        refreshNav();
    }

    private void renderDevice() {
        currentTab = "device";
        body.removeAllViews();
        headerSubtitle.setText("Status perangkat dan pengaturan");
        DeviceSnapshot s = snapshot();
        sectionHeading("STATUS PERANGKAT", "Diperbarui saat halaman dibuka");
        LinearLayout panel = card(false);
        panel.setPadding(dp(16), dp(8), dp(16), dp(8));
        addInfoRow(panel, "Merek dan model", Build.MANUFACTURER + " " + Build.MODEL, "Nama perangkat dari Android.", "▣");
        addDivider(panel);
        addInfoRow(panel, "Versi Android", "Android " + Build.VERSION.RELEASE + " · API " + Build.VERSION.SDK_INT, "LumaBoost membutuhkan Android 10 atau lebih baru.", "◉");
        addDivider(panel);
        addInfoRow(panel, "RAM total", s.ramTotal, s.ramAvailable + " tersedia", "◌");
        addDivider(panel);
        addInfoRow(panel, "Penyimpanan", s.storageTotal, s.storageFree + " kosong", "▤");
        addDivider(panel);
        addInfoRow(panel, "Baterai", s.battery + "%", s.batteryTemp + " · " + s.thermalLabel, "ϟ");
        body.addView(panel, marginBottom(16));

        sectionHeading("PENGATURAN CEPAT", "Kontrol resmi dari sistem");
        body.addView(actionRow("Penyimpanan Android", "Lihat penggunaan dan bersihkan cache aplikasi", "BUKA", () -> openStorageSettings()), marginBottom(9));
        body.addView(actionRow("Penghemat baterai", "Aktifkan penghematan daya melalui Android", "BUKA", () -> openBatterySettings()), marginBottom(9));
        body.addView(actionRow("Info aplikasi LumaBoost", "Perizinan, penggunaan penyimpanan, dan detail aplikasi", "BUKA", () -> openOwnAppInfo()), marginBottom(9));
        body.addView(actionRow("Tema tampilan", "AMOLED, Gelap, atau Terang", "UBAH", () -> showThemeMenu(body)), marginBottom(18));

        sectionHeading("PRIVASI", "Tidak memerlukan akun atau koneksi internet");
        TextView privacy = text("LumaBoost bekerja lokal. Daftar aplikasi dipakai untuk menampilkan aplikasi yang terpasang. Pemindaian file hanya masuk ke folder yang kamu pilih melalui pemilih file Android. Tidak ada izin akses semua file, root, Shizuku, VPN, atau layanan latar belakang.", 12, p.muted, false);
        privacy.setLineSpacing(dp(4), 1f);
        LinearLayout privacyCard = card(false);
        privacyCard.setPadding(dp(15), dp(15), dp(15), dp(15));
        privacyCard.addView(privacy);
        body.addView(privacyCard);
        refreshNav();
    }

    private void runSafeOptimize() {
        long before = directoryBytes(getCacheDir()) + directoryBytes(getExternalCacheDir());
        int removed = clearDirectory(getCacheDir());
        removed += clearDirectory(getExternalCacheDir());
        System.gc();
        DeviceSnapshot s = snapshot();
        renderHome();
        new AlertDialog.Builder(this)
                .setTitle("Optimasi aman selesai")
                .setMessage("Cache milik LumaBoost dibersihkan (" + formatBytes(before) + ", " + removed + " file). Status RAM dan penyimpanan diperbarui.\n\nCache/data aplikasi lain tidak dihapus karena Android melindunginya. Untuk mengelola cache aplikasi lain, buka Pengaturan Penyimpanan.")
                .setNegativeButton("Selesai", (d, w) -> { })
                .setPositiveButton("Pengaturan penyimpanan", (d, w) -> openStorageSettings())
                .show();
    }

    private void chooseTree() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQ_TREE); }
        catch (ActivityNotFoundException ex) { toast("Pemilih folder tidak tersedia di perangkat ini."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri tree = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(tree, flags);
        } catch (Exception ignored) { }
        toast("Folder dipilih. Memindai file sementara…");
        worker.execute(() -> {
            List<TempFile> matches = scanTemporaryFiles(tree);
            runOnUiThread(() -> showTempResults(tree, matches));
        });
    }

    private void showTempResults(Uri tree, List<TempFile> files) {
        if (isFinishing()) return;
        long total = 0;
        StringBuilder details = new StringBuilder();
        for (int i = 0; i < files.size(); i++) {
            TempFile f = files.get(i);
            if (f.size > 0) total += f.size;
            if (i < 10) details.append("• ").append(f.name).append("  ·  ").append(f.size >= 0 ? formatBytes(f.size) : "ukuran tidak diketahui").append('\n');
        }
        if (files.size() > 10) details.append("… dan ").append(files.size() - 10).append(" file lain\n");
        if (files.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Folder sudah bersih")
                    .setMessage("Tidak ditemukan file sementara yang dikenali (.tmp, .temp, .bak, dan thumbs.db) di folder pilihan.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        String message = "Ditemukan " + files.size() + " kandidat file sementara (ukuran yang terbaca: " + formatBytes(total) + ").\n\n" + details + "\nHanya file yang cocok dengan pola sementara/backup yang akan dihapus. Pastikan folder yang dipilih benar.";
        new AlertDialog.Builder(this).setTitle("Tinjau sebelum menghapus")
                .setMessage(message)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus file ini", (d, w) -> worker.execute(() -> {
                    int deleted = 0;
                    for (TempFile f : files) {
                        try { if (DocumentsContract.deleteDocument(getContentResolver(), f.uri)) deleted++; }
                        catch (Exception ignored) { }
                    }
                    final int finalDeleted = deleted;
                    runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("Pembersihan folder selesai")
                            .setMessage(finalDeleted + " dari " + files.size() + " file berhasil dihapus. Folder lain tidak disentuh.")
                            .setPositiveButton("Selesai", null).show());
                })).show();
    }

    private List<TempFile> scanTemporaryFiles(Uri tree) {
        ArrayList<TempFile> out = new ArrayList<>();
        try {
            String rootId = DocumentsContract.getTreeDocumentId(tree);
            scanChildren(tree, rootId, 0, out, new int[]{0});
        } catch (Exception ignored) { }
        return out;
    }

    private void scanChildren(Uri tree, String parentId, int depth, List<TempFile> out, int[] visited) {
        if (depth > 8 || out.size() >= 500 || visited[0] >= 10000) return;
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        String[] projection = new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE};
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(childrenUri, projection, null, null, null);
            if (cursor == null) return;
            while (cursor.moveToNext() && out.size() < 500 && visited[0] < 10000) {
                visited[0]++;
                String id = cursor.getString(0);
                String name = cursor.getString(1);
                String mime = cursor.getString(2);
                long size = cursor.isNull(3) ? -1 : cursor.getLong(3);
                if (name == null) name = "(tanpa nama)";
                Uri docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    scanChildren(tree, id, depth + 1, out, visited);
                } else if (isTempCandidate(name)) {
                    out.add(new TempFile(docUri, name, size));
                }
            }
        } catch (Exception ignored) {
        } finally { if (cursor != null) cursor.close(); }
    }

    private boolean isTempCandidate(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".bak") || n.equals("thumbs.db") || n.equals(".ds_store");
    }

    private DeviceSnapshot snapshot() {
        DeviceSnapshot s = new DeviceSnapshot();
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) am.getMemoryInfo(mi);
        long totalRam = mi.totalMem;
        long available = mi.availMem;
        long used = Math.max(0, totalRam - available);
        s.ramPercent = totalRam > 0 ? (int) Math.min(100, Math.round(100d * used / totalRam)) : 0;
        s.ramTotal = formatBytes(totalRam);
        s.ramAvailable = formatBytes(available);
        s.ramUsed = formatBytes(used);
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            s.storageTotal = formatBytes(stat.getTotalBytes());
            s.storageFree = formatBytes(stat.getAvailableBytes());
        } catch (Exception ex) { s.storageTotal = "—"; s.storageFree = "—"; }
        Intent battery = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            s.battery = (level >= 0 && scale > 0) ? Math.round(100f * level / scale) : 0;
            int tenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            s.batteryTemp = tenths >= 0 ? String.format(Locale.getDefault(), "%.1f°C", tenths / 10f) : "Suhu tidak tersedia";
        } else { s.battery = 0; s.batteryTemp = "Suhu tidak tersedia"; }
        int thermal = PowerManager.THERMAL_STATUS_NONE;
        try { PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE); if (pm != null && Build.VERSION.SDK_INT >= 29) thermal = pm.getCurrentThermalStatus(); } catch (Exception ignored) { }
        s.thermalHot = thermal >= PowerManager.THERMAL_STATUS_SEVERE;
        s.thermalLabel = thermalLabel(thermal);
        return s;
    }

    private String thermalLabel(int t) {
        switch (t) {
            case PowerManager.THERMAL_STATUS_LIGHT: return "Hangat";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Suhu naik";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Suhu tinggi";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Sangat panas";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Darurat termal";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Shutdown termal";
            default: return "Suhu normal";
        }
    }

    private void openStorageSettings() {
        Intent[] intents = new Intent[]{new Intent(Settings.ACTION_MANAGE_STORAGE), new Intent(Settings.ACTION_SETTINGS)};
        for (Intent i : intents) { try { startActivity(i); return; } catch (Exception ignored) { } }
        toast("Pengaturan penyimpanan tidak tersedia.");
    }
    private void openBatterySettings() {
        try { startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)); }
        catch (Exception ex) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { } }
    }
    private void openOwnAppInfo() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
        catch (Exception ignored) { }
    }

    private long directoryBytes(File dir) {
        if (dir == null || !dir.exists()) return 0;
        if (dir.isFile()) return Math.max(0, dir.length());
        long sum = 0;
        File[] children = dir.listFiles();
        if (children != null) for (File f : children) sum += directoryBytes(f);
        return sum;
    }
    private int clearDirectory(File dir) {
        if (dir == null || !dir.exists()) return 0;
        int count = 0;
        File[] children = dir.listFiles();
        if (children == null) return 0;
        for (File f : children) {
            if (f.isDirectory()) count += clearDirectory(f);
            if (f.delete()) count++;
        }
        return count;
    }

    private LinearLayout statCard(String label, String value, String sub, String glyph) {
        LinearLayout card = card(false);
        card.setPadding(dp(10), dp(11), dp(10), dp(11));
        TextView icon = text(glyph, 20, p.accent, true);
        card.addView(icon);
        TextView title = text(label, 9, p.muted, true);
        title.setPadding(0, dp(7), 0, dp(3));
        title.setLetterSpacing(0.04f);
        card.addView(title);
        TextView val = text(value, 15, p.text, true);
        card.addView(val);
        TextView hint = text(sub, 10, p.muted, false);
        hint.setPadding(0, dp(4), 0, 0);
        card.addView(hint);
        return card;
    }

    private View shortcut(String glyph, String title, String subtitle, Runnable action) {
        LinearLayout item = card(false);
        item.setPadding(dp(11), dp(12), dp(11), dp(12));
        TextView icon = text(glyph, 23, p.accent, true);
        item.addView(icon);
        TextView name = text(title, 12, p.text, true);
        name.setPadding(0, dp(7), 0, dp(3));
        item.addView(name);
        TextView sub = text(subtitle, 10, p.muted, false);
        item.addView(sub);
        item.setClickable(true);
        item.setFocusable(true);
        pressAnimation(item);
        item.setOnClickListener(v -> action.run());
        return item;
    }

    private void sectionHeading(String title, String subtitle) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(2), dp(1), dp(2), dp(10));
        TextView a = text(title, 12, p.text, true);
        a.setLetterSpacing(0.07f);
        wrap.addView(a);
        TextView b = text(subtitle, 11, p.muted, false);
        b.setPadding(0, dp(3), 0, 0);
        wrap.addView(b);
        body.addView(wrap);
    }

    private LinearLayout actionRow(String title, String desc, String buttonText, Runnable action) {
        LinearLayout panel = card(false);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(13), dp(13), dp(11), dp(13));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(text(title, 14, p.text, true));
        TextView d = text(desc, 10, p.muted, false);
        d.setPadding(0, dp(4), dp(5), 0);
        copy.addView(d);
        panel.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        Button b = button(buttonText, false);
        b.setTextSize(10);
        b.setPadding(dp(12), 0, dp(12), 0);
        panel.addView(b, new LinearLayout.LayoutParams(-2, dp(37)));
        b.setOnClickListener(v -> action.run());
        return panel;
    }

    private void addInfoRow(LinearLayout target, String label, String value, String detail, String iconText) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(11), 0, dp(11));
        TextView ico = text(iconText, 20, p.accent, true);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(34), dp(38)));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        TextView l = text(label, 13, p.text, true);
        copy.addView(l);
        TextView v = text(value, 12, p.accent, true);
        v.setPadding(0, dp(3), 0, 0);
        copy.addView(v);
        TextView d = text(detail, 10, p.muted, false);
        d.setPadding(0, dp(4), 0, 0);
        d.setLineSpacing(dp(2), 1f);
        copy.addView(d);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
        cp.leftMargin = dp(8);
        row.addView(copy, cp);
        target.addView(row);
    }

    private void addDivider(LinearLayout target) {
        View line = new View(this);
        line.setBackgroundColor(p.stroke);
        target.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private LinearLayout card(boolean hero) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        if (hero) c.setBackground(gradient(new int[]{p.heroTop, p.heroBottom}, p.stroke, 24));
        else c.setBackground(shape(p.card, p.stroke, 20));
        return c;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextColor(primary ? p.onAccent : p.accent);
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setBackground(primary ? gradient(new int[]{p.accent, p.accent2}, 0x00FFFFFF, 17) : shape(p.accentSoft, p.stroke, 14));
        b.setStateListAnimator(null);
        pressAnimation(b);
        return b;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout.LayoutParams marginBottom(int dp) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(dp); return lp; }
    private LinearLayout.LayoutParams weightedLp(float weight, int sideDp) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, weight); lp.leftMargin = dp(sideDp / 2); lp.rightMargin = dp(sideDp / 2); return lp; }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private GradientDrawable gradient(int[] colors, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(radius)); if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }

    private void showThemeMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add(0, 1, 0, "AMOLED Black");
        menu.getMenu().add(0, 2, 1, "Midnight Purple");
        menu.getMenu().add(0, 3, 2, "Light / Terang");
        menu.setOnMenuItemClickListener(item -> {
            themeMode = item.getItemId() == 1 ? "amoled" : item.getItemId() == 2 ? "midnight" : "light";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("theme", themeMode).apply();
            p = Palette.from(themeMode);
            buildShell();
            if ("device".equals(currentTab)) renderDevice(); else renderHome();
            updateBars();
            return true;
        });
        menu.show();
    }

    private void updateBars() {
        Window w = getWindow();
        w.setStatusBarColor(p.bg);
        w.setNavigationBarColor(p.bg);
        if (Build.VERSION.SDK_INT >= 26) {
            int flags = themeMode.equals("light") ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private void pressAnimation(View v) {
        v.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) view.animate().scaleX(0.985f).scaleY(0.985f).setDuration(80).start();
            else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) view.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
            return false;
        });
    }

    private String formatBytes(long bytes) {
        if (bytes < 0) return "—";
        if (bytes < 1024) return bytes + " B";
        double value = bytes; String[] units = {"B", "KB", "MB", "GB", "TB"}; int unit = 0;
        while (value >= 1024 && unit < units.length - 1) { value /= 1024.0; unit++; }
        return new DecimalFormat(value >= 10 ? "0.#" : "0.##").format(value) + " " + units[unit];
    }

    private static class DeviceSnapshot {
        int ramPercent, battery; String ramTotal, ramAvailable, ramUsed, storageTotal, storageFree, batteryTemp, thermalLabel; boolean thermalHot;
    }
    private static class TempFile { Uri uri; String name; long size; TempFile(Uri u, String n, long s) { uri=u; name=n; size=s; } }

    private static class CircularGauge extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int value, accent, track;
        private final RectF oval = new RectF();
        private final float density;
        CircularGauge(Context c, int value, int accent, int track) { super(c); this.value=value; this.accent=accent; this.track=track; density=c.getResources().getDisplayMetrics().density; setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w=getWidth(), h=getHeight(), size=Math.min(w,h)-12*density, left=(w-size)/2, top=(h-size)/2;
            oval.set(left,top,left+size,top+size);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(8*density); paint.setStrokeCap(Paint.Cap.ROUND); paint.setColor(track); canvas.drawArc(oval, -90, 360, false, paint);
            paint.setColor(accent); paint.setShadowLayer(7*density,0,0,accent); canvas.drawArc(oval, -90, 360f*value/100f, false, paint); paint.clearShadowLayer();
            paint.setStyle(Paint.Style.FILL); paint.setColor(ColorUtil.white()); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(22*density); canvas.drawText(value+"%", w/2, h/2+3*density, paint);
            paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); paint.setTextSize(8*density); paint.setColor(0xFFE6DDFF); canvas.drawText("RAM", w/2, h/2+18*density, paint);
        }
    }
    private static class ColorUtil { static int white() { return 0xFFFFFFFF; } }

    private static class Palette {
        int bg, card, nav, text, muted, accent, accent2, accentSoft, stroke, heroTop, heroBottom, onAccent, chipOverlay;
        static Palette from(String mode) {
            Palette c=new Palette();
            if ("light".equals(mode)) {
                c.bg=0xFFF3F4F9; c.card=0xFFFFFFFF; c.nav=0xFFFFFFFF; c.text=0xFF171925; c.muted=0xFF777C90; c.accent=0xFF7554E8; c.accent2=0xFF9A6CFF; c.accentSoft=0xFFEDE7FF; c.stroke=0xFFE1DDF0; c.heroTop=0xFF8062F4; c.heroBottom=0xFF633FE0; c.onAccent=0xFFFFFFFF; c.chipOverlay=0x337A5BFF;
            } else if ("midnight".equals(mode)) {
                c.bg=0xFF10101A; c.card=0xFF191827; c.nav=0xFF141320; c.text=0xFFF6F4FF; c.muted=0xFF9C9AAF; c.accent=0xFF9C78FF; c.accent2=0xFF64D7FF; c.accentSoft=0xFF282040; c.stroke=0xFF39304F; c.heroTop=0xFF382064; c.heroBottom=0xFF201633; c.onAccent=0xFFFFFFFF; c.chipOverlay=0x335C45AD;
            } else {
                c.bg=0xFF080910; c.card=0xFF141520; c.nav=0xFF0D0E17; c.text=0xFFF8F7FF; c.muted=0xFF9394A7; c.accent=0xFF9A76FF; c.accent2=0xFF6D55E8; c.accentSoft=0xFF251B40; c.stroke=0xFF302843; c.heroTop=0xFF30204F; c.heroBottom=0xFF171322; c.onAccent=0xFFFFFFFF; c.chipOverlay=0x335E4B99;
            }
            return c;
        }
    }
}
