# Manhwa Hub 1.3 — Native Reader Update

## Reader flow
- Kept the existing in-app native flow: catalog → manga details → chapter list → vertical image reader.
- Removed the embedded WebView; source fallback links are handed to the system browser.
- Chapter list now uses MangaDex `GET /manga/{id}/feed` and requests `translatedLanguage[]=id` only.
- Chapter feed is restricted to `contentRating[]=safe`.
- Image pages continue to load through MangaDex At-Home and the existing Coil image pipeline.
- Reading progress restoration and history/library integration remain in place.

## UI and loading
- Added compact dark glass chapter rows with Indonesian-language metadata.
- Refined the reader toolbar and pure-black vertical reading canvas.
- Added a retry action when chapter images fail to load.
- Splash loading remains animated until the initial catalog request completes, with a 5-second fallback so a poor connection cannot trap the app.
- Tightened bottom-navigation icon/label spacing without changing its four destinations.
- Kept the title-free Home surface and Discover-only search controls.

## Compatibility / preservation
- No duplicate `Chapter.kt` or `ChapterActivity` was added; the existing `ManhwaPageRepository.Chapter`, `ManhwaDetailActivity`, and `ReaderActivity` are reused.
- Existing library, favorites, history, backup/restore, source web fallback, detail metadata, and scraping fallback are retained.
- The MangaDex catalog remains restricted to Safe content and now requires an Indonesian translation.

## Verification performed
- XML parsing and resource ID checks are performed on the generated archive.
- A full Android Gradle build was not available in this environment; final APK compilation must be verified in AndroidForge.
