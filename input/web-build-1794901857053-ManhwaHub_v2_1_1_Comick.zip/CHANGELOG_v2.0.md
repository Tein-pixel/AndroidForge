# Manhwa Hub 2.0

## Detail experience
- Redesigned the title detail page around a centered cover, title, author/artist credits, status/year, synopsis, tags, and chapter section.
- Removed fabricated view-count text and the non-functional “similar series” tab from the reference snippet.
- Preserved favorite, reading-status, continue-reading, and external-source actions.

## Chapter list
- Replaced the nested ScrollView + wrap-content RecyclerView combination with a single RecyclerView using ConcatAdapter.
- Chapter rows now include a dedicated **Baca** action and publication/volume/scanlation metadata when available.
- Uses ListAdapter + DiffUtil so updates to long chapter lists are incremental.
- MangaDex Indonesian Safe chapters are loaded in pages of 100 as the reader approaches the end of the list.

## API and reliability
- MangaDex title requests now request cover art, author, and artist relationships.
- Chapter feed remains restricted to Indonesian translation and Safe content.
- Metadata still appears when the chapter feed is temporarily unavailable.
- Empty author, artist, cover, description, and date fields are handled without placeholder data being invented.
- Existing source-page parsing and native vertical reader paths remain available.

## UI
- Consistent black-first palette with restrained lavender accents.
- Updated detail header, chapter rows, loading/error states, and touch targets.
- Version name: 2.0; version code: 5.
