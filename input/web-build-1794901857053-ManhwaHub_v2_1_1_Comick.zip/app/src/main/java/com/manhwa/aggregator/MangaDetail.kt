package com.manhwa.aggregator

/** Display-ready metadata returned by the MangaDex title endpoint. */
data class MangaDetail(
    val title: String,
    val coverUrl: String,
    val author: String,
    val artist: String,
    val synopsis: String,
    val tags: List<String>,
    val status: String,
    val year: String
)
