package com.manhwa.aggregator

import android.content.Context
import coil.ImageLoader
import okhttp3.OkHttpClient
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Reuses one image pipeline per source host instead of constructing one per card. */
object ManhwaImageLoader {
    private val instances = ConcurrentHashMap<String, ImageLoader>()

    fun get(context: Context, referer: String): ImageLoader {
        val sourceOrigin = try {
            val uri = URI(referer)
            if (uri.scheme != null && uri.host != null) "${uri.scheme}://${uri.host}/" else ""
        } catch (_: Exception) { "" }
        val key = sourceOrigin.ifBlank { "default" }
        return instances[key] ?: synchronized(instances) {
            instances[key] ?: ImageLoader.Builder(context.applicationContext)
                .okHttpClient {
                    OkHttpClient.Builder()
                        .addInterceptor { chain ->
                            val request = chain.request().newBuilder()
                                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
                            if (sourceOrigin.isNotBlank()) request.header("Referer", sourceOrigin)
                            chain.proceed(request.build())
                        }
                        .connectTimeout(15, TimeUnit.SECONDS)
                        .readTimeout(20, TimeUnit.SECONDS)
                        .build()
                }
                .crossfade(220)
                .build()
                .also { instances[key] = it }
        }
    }
}
