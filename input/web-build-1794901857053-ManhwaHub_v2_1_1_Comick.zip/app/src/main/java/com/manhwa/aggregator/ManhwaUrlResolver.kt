package com.manhwa.aggregator

/** Resolves relative page/cover URLs returned by existing scrapers without changing source endpoints. */
object ManhwaUrlResolver {
    fun resolveItem(item: Manhwa): Manhwa {
        val base = when (item.source.lowercase()) {
            "kiryuu" -> "https://kiryuu.to"
            "komikcast" -> "https://komikcast.mom"
            "asura" -> "https://asuracomic.net"
            else -> item.link.takeIf { it.startsWith("http") } ?: ""
        }
        val absoluteLink = resolve(base, item.link)
        return item.copy(
            link = absoluteLink,
            imageUrl = resolve(absoluteLink.ifBlank { base }, item.imageUrl)
        )
    }

    fun resolve(base: String, value: String): String {
        if (value.isBlank() || value.startsWith("data:")) return value
        if (value.startsWith("//")) return "https:$value"
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        if (base.isBlank()) return value
        return try {
            java.net.URI(base).resolve(value).toString()
        } catch (_: Exception) {
            value
        }
    }
}
