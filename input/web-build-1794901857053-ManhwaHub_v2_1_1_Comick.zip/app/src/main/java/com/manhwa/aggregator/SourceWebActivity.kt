package com.manhwa.aggregator

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Opens a source page in the user's browser; manga reading remains inside the native reader. */
class SourceWebActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_URL = "source_web_url"
        const val EXTRA_TITLE = "source_web_title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rawUrl = intent.getStringExtra(EXTRA_URL).orEmpty()
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull()
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "Tautan sumber tidak valid.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak ada browser yang dapat membuka tautan ini.", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
