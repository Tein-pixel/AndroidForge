package com.manhwa.aggregator

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import android.widget.TextView
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.chip.Chip
import com.manhwa.aggregator.databinding.ActivityMainBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.UnknownHostException
import java.net.SocketTimeoutException

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scraper by lazy(LazyThreadSafetyMode.NONE) { ManhwaScraper(applicationContext) }
    private val library by lazy { LibraryStore(this) }
    private var currentQuery = ""
    private var currentGenre = ""
    private var loadJob: Job? = null
    private var currentMode = Mode.HOME
    private var currentLibraryFilter = "Semua"
    private var splashPulse: ObjectAnimator? = null
    private var splashStartedAt = 0L
    private var splashDismissed = false
    private var initialLoadHandled = false

    private val exportBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                    it.write(library.exportBackup())
                } ?: throw IllegalStateException("File tujuan tidak dapat dibuka")
                Toast.makeText(this, "Backup berhasil disimpan", Toast.LENGTH_LONG).show()
            } catch (error: Exception) {
                Toast.makeText(this, "Backup gagal: ${error.localizedMessage ?: "kesalahan file"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val importBackupLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("File backup tidak dapat dibaca")
                if (library.importBackup(raw)) {
                    currentLibraryFilter = "Semua"
                    currentMode = Mode.LIBRARY
                    binding.bottomNavigation.selectedItemId = R.id.nav_library
                    updateHeader()
                    loadData()
                    Toast.makeText(this, "Backup berhasil dipulihkan", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "File backup tidak valid atau tidak didukung", Toast.LENGTH_LONG).show()
                }
            } catch (error: Exception) {
                Toast.makeText(this, "Restore gagal: ${error.localizedMessage ?: "kesalahan file"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private enum class Mode { HOME, DISCOVER, LIBRARY, HISTORY }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        startSplashAnimation()
        setupRecyclerView()
        setupSearch()
        setupChips()
        setupSwipeRefresh()
        setupNavigation()
        tightenNavigationLabels()
        setupTools()
        setupEntranceAnimations()
        updateHeader()
        loadData()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && (currentMode == Mode.LIBRARY || currentMode == Mode.HISTORY)) loadData()
    }

    private fun tightenNavigationLabels() {
        binding.bottomNavigation.post {
            val density = resources.displayMetrics.density
            fun adjust(view: View) {
                when (view) {
                    is TextView -> {
                        view.includeFontPadding = false
                        view.translationY = -2.5f * density
                    }
                    is android.widget.ImageView -> view.translationY = 1.0f * density
                }
                if (view is ViewGroup) {
                    for (index in 0 until view.childCount) adjust(view.getChildAt(index))
                }
            }
            adjust(binding.bottomNavigation)
        }
    }

    private fun setupTools() {
        binding.btnTools.setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menu.add(0, 1, 0, "Backup koleksi")
            popup.menu.add(0, 2, 1, "Pulihkan backup")
            popup.menu.add(0, 3, 2, "Filter koleksi")
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> {
                        exportBackupLauncher.launch("manhwa-hub-backup-${System.currentTimeMillis()}.json")
                        true
                    }
                    2 -> {
                        importBackupLauncher.launch(arrayOf("application/json", "text/plain"))
                        true
                    }
                    3 -> {
                        showLibraryFilter()
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    private fun showLibraryFilter() {
        val filters = arrayOf("Semua", "Sedang dibaca", "Rencana baca", "Selesai", "Ditunda", "Dihentikan")
        AlertDialog.Builder(this)
            .setTitle("Filter koleksi")
            .setSingleChoiceItems(filters, filters.indexOf(currentLibraryFilter).coerceAtLeast(0)) { dialog, which ->
                currentLibraryFilter = filters[which]
                if (currentMode != Mode.LIBRARY) {
                    currentMode = Mode.LIBRARY
                    binding.bottomNavigation.selectedItemId = R.id.nav_library
                }
                updateHeader()
                loadData()
                dialog.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun setupRecyclerView() {
        binding.rvManhwa.layoutManager = GridLayoutManager(this, 2)
        binding.rvManhwa.setHasFixedSize(true)
        binding.rvManhwa.setItemViewCacheSize(8)
    }

    private fun setupSearch() {
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (currentMode == Mode.DISCOVER && actionId == EditorInfo.IME_ACTION_SEARCH) {
                currentQuery = binding.etSearch.text.toString().trim()
                currentGenre = ""
                currentMode = Mode.DISCOVER
                binding.chipGroupGenre.setOnCheckedStateChangeListener(null)
                binding.chipAll.isChecked = true
                allChips().forEach { applyChipStyle(it, it.id == R.id.chipAll) }
                reattachChipListener()
                updateHeader()
                loadData()
                true
            } else false
        }
        binding.etSearch.setOnFocusChangeListener { view, hasFocus ->
            view.background = ContextCompat.getDrawable(this,
                if (hasFocus) R.drawable.glass_search_focused else R.drawable.glass_search)
            view.animate().scaleX(if (hasFocus) 1.012f else 1f).scaleY(if (hasFocus) 1.012f else 1f)
                .setDuration(180).start()
        }
    }

    private fun setupChips() {
        allChips().forEach { chip ->
            applyChipStyle(chip, chip.isChecked)
            chip.setOnCheckedChangeListener { _, checked ->
                applyChipStyle(chip, checked)
                if (checked) chip.animate().scaleX(1.035f).scaleY(1.035f).setDuration(90)
                    .withEndAction { chip.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
            }
        }
        reattachChipListener()
    }

    private fun reattachChipListener() {
        binding.chipGroupGenre.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                currentQuery = ""
                binding.etSearch.text.clear()
                currentMode = Mode.DISCOVER
                currentGenre = when (checkedIds[0]) {
                    R.id.chipAction -> "Action"
                    R.id.chipFantasy -> "Fantasy"
                    R.id.chipRomance -> "Romance"
                    R.id.chipMartial -> "Martial Arts"
                    else -> "Semua"
                }
                updateHeader()
                loadData()
            }
        }
    }

    private fun setupNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            currentQuery = ""
            currentGenre = ""
            binding.etSearch.text.clear()
            binding.chipGroupGenre.setOnCheckedStateChangeListener(null)
            binding.chipAll.isChecked = true
            allChips().forEach { applyChipStyle(it, it.id == R.id.chipAll) }
            reattachChipListener()
            when (item.itemId) {
                R.id.nav_home -> currentMode = Mode.HOME
                R.id.nav_discover -> currentMode = Mode.DISCOVER
                R.id.nav_library -> currentMode = Mode.LIBRARY
                R.id.nav_history -> currentMode = Mode.HISTORY
                else -> return@setOnItemSelectedListener false
            }
            updateHeader()
            loadData()
            true
        }
    }

    private fun updateHeader() {
        // Keep the home surface free of a large title/subtitle block.
        // Search and genre controls are only shown on the Discover tab.
        binding.topBar.visibility = if (currentMode == Mode.DISCOVER) View.VISIBLE else View.GONE
        binding.sectionHeader.visibility = View.VISIBLE
        binding.btnTools.visibility = View.VISIBLE
    }

    private fun startSplashAnimation() {
        val logo = binding.splashLogo
        logo.scaleX = 0.9f
        logo.scaleY = 0.9f
        logo.alpha = 0.72f

        splashPulse = ObjectAnimator.ofPropertyValuesHolder(
            logo,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 0.92f, 1.04f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.92f, 1.04f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.72f, 1f)
        ).apply {
            duration = 780L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }

        splashStartedAt = System.currentTimeMillis()
        splashDismissed = false
        binding.splashOverlay.alpha = 1f
        binding.splashOverlay.visibility = View.VISIBLE
        // Safety timeout: a slow or offline connection must never trap the user on the splash.
        binding.splashOverlay.postDelayed({ dismissSplash(force = true) }, 5000L)
    }

    private fun requestSplashDismiss() {
        if (initialLoadHandled || splashDismissed) return
        initialLoadHandled = true
        val elapsed = System.currentTimeMillis() - splashStartedAt
        val remaining = (1050L - elapsed).coerceAtLeast(0L)
        binding.splashOverlay.postDelayed({ dismissSplash() }, remaining)
    }

    private fun dismissSplash(force: Boolean = false) {
        if (splashDismissed || isFinishing || !::binding.isInitialized) return
        if (!force && !initialLoadHandled) return
        splashDismissed = true
        splashPulse?.cancel()
        binding.splashOverlay.animate()
            .alpha(0f)
            .setDuration(420L)
            .withEndAction {
                binding.splashOverlay.visibility = View.GONE
                binding.splashOverlay.alpha = 1f
            }
            .start()
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener { loadData(isRefresh = true) }
        binding.swipeRefresh.setColorSchemeColors(Color.parseColor("#BDA8FF"), Color.parseColor("#7F9CFF"))
    }

    private fun setupEntranceAnimations() {
        // Header: drop down from above
        binding.sectionHeader.apply {
            translationY = -10f
            alpha = 0f
            animate().translationY(0f).alpha(1f).setDuration(360)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f))
                .start()
        }
        // Bottom nav: rise from below with spring overshoot
        binding.bottomNavigation.apply {
            translationY = 60f
            alpha = 0f
            animate().translationY(0f).alpha(1f).setDuration(420).setStartDelay(100)
                .setInterpolator(android.view.animation.OvershootInterpolator(1.1f))
                .start()
        }
    }

    private fun allChips(): List<Chip> = listOf(
        binding.chipAll, binding.chipAction, binding.chipFantasy, binding.chipRomance, binding.chipMartial
    )

    private fun applyChipStyle(chip: Chip, checked: Boolean) {
        val density = resources.displayMetrics.density
        chip.chipBackgroundColor = android.content.res.ColorStateList.valueOf(
            if (checked) Color.parseColor("#302B3B") else Color.parseColor("#141417")
        )
        chip.chipStrokeColor = android.content.res.ColorStateList.valueOf(
            if (checked) Color.parseColor("#99BDA8FF") else Color.parseColor("#20FFFFFF")
        )
        chip.chipStrokeWidth = density
        chip.isCheckedIconVisible = false
        chip.setTextColor(if (checked) Color.parseColor("#D6C8FF") else Color.parseColor("#A4A2B7"))
        chip.chipCornerRadius = density * 22f
    }

    private var skeletonAdapter: SkeletonAdapter? = null

    private fun loadData(isRefresh: Boolean = false) {
        // Cancel the previous request when the user changes tab, query, or genre.
        loadJob?.cancel()
        skeletonAdapter?.cancelAll()
        skeletonAdapter = null
        val requestedMode = currentMode
        val requestedQuery = currentQuery
        val requestedGenre = currentGenre
        val requestedLibraryFilter = currentLibraryFilter

        loadJob = lifecycleScope.launch {
            if (!isRefresh) {
                delay(60)
                binding.tvEmpty.visibility = View.GONE
                // Show skeleton cards immediately — faster perceived load
                val skeleton = SkeletonAdapter()
                skeletonAdapter = skeleton
                binding.rvManhwa.adapter = skeleton
                binding.progressBar.visibility = View.GONE // spinner hidden; skeleton is the indicator
            }
            try {
                val catalogResult = if (requestedMode == Mode.HOME || requestedMode == Mode.DISCOVER) {
                    scraper.fetchLatestResult(requestedQuery, requestedGenre)
                } else {
                    null
                }
                val rawItems = when (requestedMode) {
                    Mode.HOME, Mode.DISCOVER -> catalogResult?.items.orEmpty()
                    Mode.LIBRARY -> library.libraryItems(requestedLibraryFilter)
                    Mode.HISTORY -> library.history()
                }
                // Do not let a cancelled/older request repaint the currently selected tab.
                if (!isActive) return@launch
                val list = rawItems.filterNot { it.source == "System" }
                    .map { ManhwaUrlResolver.resolveItem(it) }

                skeletonAdapter?.cancelAll()
                skeletonAdapter = null
                binding.rvManhwa.adapter = ManhwaAdapter(list) { openDetails(it) }
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                binding.tvEmpty.text = when (requestedMode) {
                    Mode.LIBRARY -> "Belum ada judul di kategori ini.\nBuka detail komik lalu pilih status bacaan."
                    Mode.HISTORY -> "Riwayat bacaan masih kosong.\nKomik yang kamu buka akan muncul di sini."
                    Mode.HOME, Mode.DISCOVER -> if (requestedQuery.isNotBlank()) {
                        "Tidak ada hasil yang ditemukan. Coba kata kunci lain atau tarik layar untuk memuat ulang."
                    } else {
                        "Belum ada judul yang cocok. Tarik layar ke bawah untuk mencoba lagi."
                    }
                }

                if (catalogResult?.fromCache == true) {
                    Toast.makeText(
                        this@MainActivity,
                        "Koneksi katalog bermasalah. Menampilkan data terakhir yang tersimpan.",
                        Toast.LENGTH_LONG
                    ).show()
                } else if (catalogResult?.broadenedLanguageFilter == true) {
                    Toast.makeText(
                        this@MainActivity,
                        "Menampilkan judul Safe tambahan. Sebagian mungkin belum memiliki chapter Bahasa Indonesia.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (cancelled: CancellationException) {
                // A tab change or lifecycle stop is expected; never show it as a network error.
                throw cancelled
            } catch (error: Exception) {
                if (!isActive) return@launch
                skeletonAdapter?.cancelAll()
                skeletonAdapter = null
                val message = catalogErrorMessage(error)
                if (isRefresh) {
                    // Keep the previously rendered cards visible if a refresh fails.
                    binding.tvEmpty.visibility = View.GONE
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                } else {
                    binding.tvEmpty.text = message
                    binding.tvEmpty.visibility = View.VISIBLE
                    binding.rvManhwa.adapter = ManhwaAdapter(emptyList()) { }
                }
            } finally {
                // A cancelled older job must not hide the loading state of its replacement.
                if (isActive) {
                    binding.progressBar.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    requestSplashDismiss()
                }
            }
        }
    }

    private fun catalogErrorMessage(error: Throwable): String {
        val allMessages = generateSequence(error) { it.cause }
            .mapNotNull { it.message }
            .joinToString(" | ")
        val httpCode = Regex("MangaDex HTTP (\\d{3})")
            .find(allMessages)?.groupValues?.getOrNull(1)?.toIntOrNull()

        return when {
            httpCode == 429 -> "MangaDex sedang membatasi permintaan. Tunggu sebentar, lalu tarik layar untuk mencoba lagi."
            httpCode == 403 -> "Akses ke API MangaDex ditolak (403). Kemungkinan ada pembatasan jaringan atau permintaan."
            httpCode != null && httpCode in 500..599 -> "Server katalog sedang bermasalah ($httpCode). Coba lagi beberapa saat."
            generateSequence(error) { it.cause }.any { it is UnknownHostException } ->
                "Alamat server katalog tidak dapat ditemukan. Periksa DNS atau koneksi internet, lalu coba lagi."
            generateSequence(error) { it.cause }.any { it is SocketTimeoutException } ->
                "Koneksi ke server katalog terlalu lama. Periksa jaringan, lalu coba lagi."
            generateSequence(error) { it.cause }.any { it is IOException } ->
                "Koneksi ke server katalog gagal. Periksa jaringan atau coba lagi nanti."
            else -> "Katalog gagal dimuat. ${error.message?.take(100).orEmpty()} Coba tarik layar untuk memuat ulang."
        }
    }

    override fun onDestroy() {
        splashPulse?.cancel()
        skeletonAdapter?.cancelAll()
        loadJob?.cancel()
        super.onDestroy()
    }

    private fun openDetails(item: Manhwa) {
        library.addToHistory(item)
        startActivity(Intent(this, ManhwaDetailActivity::class.java).apply {
            putExtra(ManhwaDetailActivity.EXTRA_TITLE, item.title)
            putExtra(ManhwaDetailActivity.EXTRA_LINK, item.link)
            putExtra(ManhwaDetailActivity.EXTRA_IMAGE, item.imageUrl)
            putExtra(ManhwaDetailActivity.EXTRA_CHAPTER, item.latestChapter)
            putExtra(ManhwaDetailActivity.EXTRA_SOURCE, item.source)
        })
    }
}
