package com.manhwa.aggregator

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Detail, chapter and reader repository.
 * Comick.fun is handled via JSON API; HTML scraper fallback remains for other source URLs.
 */
object ManhwaPageRepository {
    private const val PROXY_BASE = "https://api.allorigins.win/raw?url="

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(18, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .callTimeout(35, TimeUnit.SECONDS)
            .followRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    data class PageDetails(
        val description: String,
        val genres: List<String>,
        val status: String,
        val chapters: List<Chapter>,
        val manga: MangaDetail? = null,
        val totalChapters: Int = chapters.size,
        val nextChapterOffset: Int = chapters.size,
        val hasMoreChapters: Boolean = false,
        val chapterLoadError: Boolean = false
    )

    data class Chapter(
        val title: String,
        val url: String,
        val chapterNumber: String = "",
        val volume: String = "",
        val publishedAt: String = "",
        val scanlationGroup: String = ""
    )

    data class ChapterPage(
        val chapters: List<Chapter>,
        val total: Int,
        val nextOffset: Int,
        val hasMore: Boolean
    )

    // ── Public API ────────────────────────────────────────────────────────────

    suspend fun fetchDetails(pageUrl: String): PageDetails =
        withContext(Dispatchers.IO) {
            val comickSlug = comickSlug(pageUrl)
            if (comickSlug != null) {
                return@withContext fetchComickDetails(comickSlug)
            }

            // HTML scraper fallback for non-Comick URLs
            val html = fetchHtml(pageUrl)
            val doc  = Jsoup.parse(html, pageUrl)

            val description = doc.select(
                ".entry-content, .description-summary, .manga-excerpt, .summary__content, .desc, .synopsis, [itemprop=description]"
            ).firstOrNull()?.text()?.trim().orEmpty()

            val genres = doc.select(
                ".manga-genres a, .seriestugenre a, .genres a, .mgen a, .tag-links a"
            ).map { it.text().trim() }.filter { it.isNotBlank() }.distinct().take(12)

            val status = doc.select(
                ".post-status .summary-content, .summary-content, .status, .manga-status"
            ).firstOrNull()?.text()?.trim().orEmpty()

            val chapters = doc.select(
                ".eplister a, .listing-chapters_wrap a, .wp-manga-chapter a, .chapter-list a, " +
                ".chapter-item a, .chbox a, .eph-num a, a[href*='chapter'], a[href*='/ch-']"
            ).mapNotNull { anchor ->
                val url   = anchor.absUrl("href").ifBlank { anchor.attr("href") }
                val title = anchor.text().trim().ifBlank { anchor.attr("title").trim() }
                if (url.startsWith("http") && title.isNotBlank()) Chapter(title, url) else null
            }.distinctBy { it.url }.take(250)

            PageDetails(description, genres, status, chapters)
        }

    suspend fun fetchMoreChapters(pageUrl: String, offset: Int): ChapterPage =
        withContext(Dispatchers.IO) {
            val slug = comickSlug(pageUrl)
                ?: return@withContext ChapterPage(emptyList(), offset, offset, false)
            ComickApiSource.fetchChapters(slug, offset)
        }

    /** True when pageUrl belongs to Comick, enabling paginated chapter loading. */
    fun isComickTitle(pageUrl: String): Boolean = comickSlug(pageUrl) != null

    /** Backward-compat alias kept so existing callers compile without change. */
    @Suppress("unused")
    fun isMangaDexTitle(pageUrl: String): Boolean = isComickTitle(pageUrl)

    suspend fun fetchReaderImages(chapterUrl: String): List<String> =
        withContext(Dispatchers.IO) {
            val hid = comickChapterHid(chapterUrl)
            if (hid != null) {
                return@withContext ComickApiSource.fetchChapterImages(hid)
            }

            // HTML scraper fallback
            val html = fetchHtml(chapterUrl)
            val doc  = Jsoup.parse(html, chapterUrl)
            doc.select(
                "#readerarea img, .reading-content img, .reader-area img, " +
                ".chapter-content img, .rdminimal img, .chapter-images img, .reading-area img"
            ).mapNotNull { image ->
                val candidate = listOf("data-src", "data-lazy-src", "data-original", "data-cfsrc", "src")
                    .firstNotNullOfOrNull { key ->
                        image.attr(key).takeIf { it.isNotBlank() && !it.startsWith("data:") }
                    }
                val absolute = candidate?.let { raw ->
                    image.absUrl("src").takeIf { it == raw } ?: resolveUrl(chapterUrl, raw)
                }
                absolute?.takeIf { it.startsWith("http") }
            }.distinct()
        }

    // ── Comick detail + chapters ──────────────────────────────────────────────

    private suspend fun fetchComickDetails(slug: String): PageDetails = coroutineScope {
        val detailRequest  = async { ComickApiSource.fetchDetail(slug) }
        val chapterRequest = async {
            try {
                ComickApiSource.fetchChapters(slug, 0) to false
            } catch (c: CancellationException) {
                throw c
            } catch (_: Exception) {
                ChapterPage(emptyList(), 0, 0, false) to true
            }
        }

        val detail = detailRequest.await()
        val (chapterPage, chapterLoadError) = chapterRequest.await()

        PageDetails(
            description      = detail.synopsis,
            genres           = detail.tags,
            status           = detail.status,
            chapters         = chapterPage.chapters,
            manga            = detail,
            totalChapters    = chapterPage.total.coerceAtLeast(chapterPage.chapters.size),
            nextChapterOffset = chapterPage.nextOffset,
            hasMoreChapters  = chapterPage.hasMore,
            chapterLoadError = chapterLoadError
        )
    }

    // ── URL parsers ───────────────────────────────────────────────────────────

    /** Extracts slug from https://comick.io/comic/<slug> (or /comic/<slug>/...). */
    private fun comickSlug(url: String): String? = try {
        val uri   = java.net.URI(url)
        val host  = uri.host?.lowercase().orEmpty()
        val parts = uri.path.split('/').filter { it.isNotBlank() }
        if ((host == "comick.io" || host.endsWith(".comick.io")) &&
            parts.size >= 2 && parts[0] == "comic") {
            parts[1].takeIf { it.isNotBlank() }
        } else null
    } catch (_: Exception) { null }

    /** Extracts chapter HID from https://comick.io/chapter/<hid>. */
    private fun comickChapterHid(url: String): String? = try {
        val uri   = java.net.URI(url)
        val host  = uri.host?.lowercase().orEmpty()
        val parts = uri.path.split('/').filter { it.isNotBlank() }
        if ((host == "comick.io" || host.endsWith(".comick.io")) &&
            parts.size >= 2 && parts[0] == "chapter") {
            parts[1].takeIf { it.isNotBlank() }
        } else null
    } catch (_: Exception) { null }

    // ── HTML helpers ──────────────────────────────────────────────────────────

    private fun fetchHtml(url: String): String {
        val proxied = PROXY_BASE + URLEncoder.encode(url, "UTF-8")
        val request = Request.Builder()
            .url(proxied)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Server sumber merespons ${response.code}")
            return response.body?.string().orEmpty()
        }
    }

    private fun resolveUrl(base: String, value: String): String =
        try { java.net.URI(base).resolve(value).toString() } catch (_: Exception) { value }
}
