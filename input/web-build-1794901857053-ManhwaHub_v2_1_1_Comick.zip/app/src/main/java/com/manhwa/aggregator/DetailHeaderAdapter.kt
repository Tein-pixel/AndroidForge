package com.manhwa.aggregator

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class DetailHeaderAdapter(
    private val detail: MangaDetail,
    private val fallbackCoverUrl: String,
    initialChapterCount: Int,
    initialChapterLabel: String,
    private val onStartReading: () -> Unit,
    private val onFavorite: () -> Unit,
    private val onReadingStatus: () -> Unit
) : RecyclerView.Adapter<DetailHeaderAdapter.HeaderHolder>() {

    private var chapterCount = initialChapterCount
    private var chapterCountLabel = initialChapterLabel
    private var startLabel = "Mulai baca"
    private var favoriteLabel = "Simpan"
    private var readingStatusLabel = "Tambah ke daftar bacaan"
    private var synopsisExpanded = false

    class HeaderHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cover: ImageView = view.findViewById(R.id.imgCoverDetail)
        val source: TextView = view.findViewById(R.id.tvSourceBadge)
        val title: TextView = view.findViewById(R.id.tvTitleDetail)
        val author: TextView = view.findViewById(R.id.tvAuthorDetail)
        val status: TextView = view.findViewById(R.id.tvStatusDetail)
        val synopsis: TextView = view.findViewById(R.id.tvSynopsisDetail)
        val synopsisMore: TextView = view.findViewById(R.id.btnSynopsisMore)
        val tags: ChipGroup = view.findViewById(R.id.chipGroupTags)
        val episodeCount: TextView = view.findViewById(R.id.tvEpisodeCount)
        val start: MaterialButton = view.findViewById(R.id.btnStartReading)
        val favorite: MaterialButton = view.findViewById(R.id.btnFavorite)
        val readingStatus: MaterialButton = view.findViewById(R.id.btnReadingStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HeaderHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_detail_header, parent, false)
        return HeaderHolder(view)
    }

    override fun onBindViewHolder(holder: HeaderHolder, position: Int) {
        holder.title.text = detail.title.ifBlank { "Judul tidak tersedia" }

        val credits = buildList {
            if (detail.author.isNotBlank()) add("Author: ${detail.author}")
            if (detail.artist.isNotBlank() && !detail.artist.equals(detail.author, true)) {
                add("Artist: ${detail.artist}")
            }
        }
        holder.author.text = credits.joinToString("  ·  ")
            .ifBlank { "Kreator tidak tercantum" }

        val statusParts = listOfNotNull(
            detail.status.takeIf { it.isNotBlank() },
            detail.year.takeIf { it.isNotBlank() }
        )
        holder.status.text = statusParts.joinToString("  ·  ")
            .ifBlank { "Informasi status tidak tersedia" }

        holder.source.text = "MANGADEX"
        val cover = detail.coverUrl.ifBlank { fallbackCoverUrl }
        holder.cover.load(cover) {
            crossfade(220)
            placeholder(R.drawable.cover_placeholder)
            error(R.drawable.cover_placeholder)
        }

        val synopsis = detail.synopsis.ifBlank { "Sinopsis belum tersedia dari sumber." }
        holder.synopsis.text = synopsis
        holder.synopsis.maxLines = if (synopsisExpanded) Int.MAX_VALUE else 5
        holder.synopsisMore.visibility = if (synopsis.length > 220) View.VISIBLE else View.GONE
        holder.synopsisMore.text = if (synopsisExpanded) "Tampilkan lebih sedikit" else "Selengkapnya"
        holder.synopsisMore.setOnClickListener {
            synopsisExpanded = !synopsisExpanded
            notifyItemChanged(0)
        }

        holder.tags.removeAllViews()
        detail.tags.distinct().take(8).forEach { label ->
            val chip = Chip(holder.itemView.context).apply {
                text = label
                isClickable = false
                isCheckable = false
                chipBackgroundColor = ColorStateList.valueOf(0xFF17131F.toInt())
                chipStrokeColor = ColorStateList.valueOf(0x553F354F)
                chipStrokeWidth = holder.itemView.resources.displayMetrics.density
                chipCornerRadius = 18f * holder.itemView.resources.displayMetrics.density
                setTextColor(0xFFCDBEFF.toInt())
                textSize = 10f
                minHeight = (29 * holder.itemView.resources.displayMetrics.density).toInt()
            }
            holder.tags.addView(chip)
        }

        holder.episodeCount.text = chapterCountLabel

        holder.start.text = startLabel
        holder.favorite.text = favoriteLabel
        holder.readingStatus.text = readingStatusLabel
        holder.start.setOnClickListener { onStartReading() }
        holder.favorite.setOnClickListener { onFavorite() }
        holder.readingStatus.setOnClickListener { onReadingStatus() }
    }

    fun updateChapterCount(count: Int) {
        chapterCount = count.coerceAtLeast(0)
        chapterCountLabel = if (chapterCount > 0) "$chapterCount chapter" else "Chapter belum tersedia"
        if (itemCount > 0) notifyItemChanged(0)
    }

    fun updateActions(
        startText: String,
        favoriteText: String,
        readingStatusText: String
    ) {
        startLabel = startText
        favoriteLabel = favoriteText
        readingStatusLabel = readingStatusText
        if (itemCount > 0) notifyItemChanged(0)
    }

    override fun getItemCount(): Int = 1
}
