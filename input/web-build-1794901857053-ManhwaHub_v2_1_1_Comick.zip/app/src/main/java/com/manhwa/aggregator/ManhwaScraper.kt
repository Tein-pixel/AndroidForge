package com.manhwa.aggregator

import android.content.Context
import kotlinx.coroutines.CancellationException

/**
 * Catalog orchestration.
 * Comick.fun is now the primary source — Indonesian chapters are natively filtered
 * via lang=id in the chapter endpoint, so the two-pass broadening is no longer needed.
 * Successful results are still cached locally to survive temporary network outages.
 */
class ManhwaScraper(context: Context) {
    private val cache = CatalogCache(context.applicationContext)

    data class CatalogResult(
        val items: List<Manhwa>,
        val fromCache: Boolean = false,
        val broadenedLanguageFilter: Boolean = false
    )

    suspend fun fetchLatestResult(
        query: String = "",
        genre: String = ""
    ): CatalogResult {
        try {
            val items = ComickApiSource.fetchLatest(query = query, genre = genre)

            if (items.isNotEmpty()) {
                cache.save(query, genre, items)
                return CatalogResult(items)
            }

            // Nothing from network — try local cache before returning empty.
            val cached = cache.read(query, genre)
            return if (cached.isNotEmpty()) {
                CatalogResult(cached, fromCache = true)
            } else {
                CatalogResult(emptyList())
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            val cached = cache.read(query, genre)
            if (cached.isNotEmpty()) {
                return CatalogResult(cached, fromCache = true)
            }
            throw error
        }
    }

    /** Backward-compatible list API for existing call sites. */
    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> =
        fetchLatestResult(query, genre).items
}
