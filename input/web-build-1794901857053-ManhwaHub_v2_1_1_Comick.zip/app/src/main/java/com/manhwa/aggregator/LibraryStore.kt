package com.manhwa.aggregator

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local library and reading progress. Existing scraper/API data is kept separate. */
class LibraryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("manhwa_hub_library", Context.MODE_PRIVATE)

    data class ReadingProgress(
        val chapterTitle: String,
        val chapterUrl: String,
        val pageIndex: Int,
        val offsetPx: Int,
        val updatedAt: Long
    )

    @Synchronized
    fun isFavorite(item: Manhwa): Boolean = favorites().any { it.link == item.link }

    @Synchronized
    fun toggleFavorite(item: Manhwa): Boolean {
        val items = favorites().toMutableList()
        val existing = items.indexOfFirst { it.link == item.link }
        val nowFavorite = existing < 0
        if (nowFavorite) {
            items.add(0, item)
            val library = (read("library_items") + items).distinctBy { it.link }
            save("library_items", library)
        } else {
            items.removeAt(existing)
        }
        save("favorites", items)
        return nowFavorite
    }

    @Synchronized
    fun addToHistory(item: Manhwa) {
        val items = history().filterNot { it.link == item.link }.toMutableList()
        items.add(0, item)
        save("history", items.take(150))
        prefs.edit().putString("last_opened", item.link).apply()
    }

    @Synchronized
    fun favorites(): List<Manhwa> = read("favorites")

    @Synchronized
    fun history(): List<Manhwa> = read("history")

    /** Adds or updates a title in the user's reading lists. */
    @Synchronized
    fun setReadingStatus(item: Manhwa, status: String?) {
        val allowed = setOf("Sedang dibaca", "Rencana baca", "Selesai", "Ditunda", "Dihentikan")
        val library = read("library_items").toMutableList()
        val index = library.indexOfFirst { it.link == item.link }
        if (status == null || status !in allowed) {
            if (index >= 0) library.removeAt(index)
        } else if (index >= 0) {
            library[index] = item
        } else {
            library.add(0, item)
        }
        save("library_items", library)

        val statuses = readObject("statuses")
        if (status == null || status !in allowed) statuses.remove(item.link) else statuses.put(item.link, status)
        prefs.edit().putString("statuses", statuses.toString()).apply()
    }

    @Synchronized
    fun readingStatus(item: Manhwa): String? = readObject("statuses").optString(item.link).takeIf { it.isNotBlank() }

    @Synchronized
    fun libraryItems(status: String? = null): List<Manhwa> {
        // Old installations only had Favorites; use them as a safe migration fallback.
        val stored = (read("library_items") + favorites()).distinctBy { it.link }
        return if (status.isNullOrBlank() || status == "Semua") stored
        else stored.filter { readingStatus(it) == status }
    }

    @Synchronized
    fun saveProgress(item: Manhwa, chapterTitle: String, chapterUrl: String, pageIndex: Int, offsetPx: Int) {
        if (item.link.isBlank() || chapterUrl.isBlank()) return
        val all = readObject("reading_progress")
        all.put(item.link, JSONObject().apply {
            put("chapterTitle", chapterTitle)
            put("chapterUrl", chapterUrl)
            put("pageIndex", pageIndex.coerceAtLeast(0))
            put("offsetPx", offsetPx.coerceAtLeast(0))
            put("updatedAt", System.currentTimeMillis())
        })
        prefs.edit().putString("reading_progress", all.toString()).apply()
        if (readingStatus(item).isNullOrBlank()) setReadingStatus(item, "Sedang dibaca")
    }

    @Synchronized
    fun getProgress(link: String): ReadingProgress? {
        if (link.isBlank()) return null
        val value = readObject("reading_progress").optJSONObject(link) ?: return null
        val url = value.optString("chapterUrl")
        if (url.isBlank()) return null
        return ReadingProgress(
            value.optString("chapterTitle"), url,
            value.optInt("pageIndex", 0).coerceAtLeast(0),
            value.optInt("offsetPx", 0).coerceAtLeast(0),
            value.optLong("updatedAt", 0L)
        )
    }

    /** Portable metadata-only backup; it never exports credentials or source endpoint settings. */
    @Synchronized
    fun exportBackup(): String = JSONObject().apply {
        put("backupVersion", 2)
        put("app", "Manhwa Hub")
        put("createdAt", System.currentTimeMillis())
        put("favorites", JSONArray(prefs.getString("favorites", "[]")))
        put("history", JSONArray(prefs.getString("history", "[]")))
        put("library_items", JSONArray(prefs.getString("library_items", "[]")))
        put("statuses", readObject("statuses"))
        put("reading_progress", readObject("reading_progress"))
    }.toString(2)

    @Synchronized
    fun importBackup(raw: String): Boolean {
        if (raw.isBlank() || raw.length > 8_000_000) return false
        return try {
            val root = JSONObject(raw)
            val version = root.optInt("backupVersion", 0)
            if (version !in 1..2) return false
            val favorites = root.optJSONArray("favorites") ?: JSONArray()
            val history = root.optJSONArray("history") ?: JSONArray()
            val library = root.optJSONArray("library_items") ?: JSONArray()
            val statuses = root.optJSONObject("statuses") ?: JSONObject()
            val progress = root.optJSONObject("reading_progress") ?: JSONObject()
            // Validate every collection before replacing existing local data.
            if (!validItemArray(favorites) || !validItemArray(history) || !validItemArray(library)) return false
            prefs.edit()
                .putString("favorites", favorites.toString())
                .putString("history", history.toString())
                .putString("library_items", library.toString())
                .putString("statuses", statuses.toString())
                .putString("reading_progress", progress.toString())
                .apply()
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun validItemArray(array: JSONArray): Boolean {
        if (array.length() > 5_000) return false
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: return false
            if (item.optString("title").isBlank() || item.optString("link").isBlank()) return false
        }
        return true
    }

    private fun readObject(key: String): JSONObject = try {
        JSONObject(prefs.getString(key, "{}") ?: "{}")
    } catch (_: Exception) { JSONObject() }

    private fun read(key: String): List<Manhwa> {
        val raw = prefs.getString(key, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val title = obj.optString("title")
                    val link = obj.optString("link")
                    if (title.isNotBlank() && link.isNotBlank()) {
                        add(Manhwa(title, link, obj.optString("imageUrl"), obj.optString("latestChapter"), obj.optString("source")))
                    }
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun save(key: String, items: List<Manhwa>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().apply {
                put("title", item.title)
                put("link", item.link)
                put("imageUrl", item.imageUrl)
                put("latestChapter", item.latestChapter)
                put("source", item.source)
            })
        }
        prefs.edit().putString(key, array.toString()).apply()
    }
}
