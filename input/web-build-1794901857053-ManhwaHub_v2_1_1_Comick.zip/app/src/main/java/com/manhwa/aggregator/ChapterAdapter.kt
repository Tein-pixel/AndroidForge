package com.manhwa.aggregator

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Locale

class ChapterAdapter(
    private val onReadClick: (ManhwaPageRepository.Chapter) -> Unit
) : ListAdapter<ManhwaPageRepository.Chapter, ChapterAdapter.ChapterHolder>(DIFF) {

    class ChapterHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.tvChapterTitle)
        val meta: TextView = view.findViewById(R.id.tvChapterMeta)
        val read: MaterialButton = view.findViewById(R.id.btnRead)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChapterHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chapter, parent, false)
        return ChapterHolder(view)
    }

    override fun onBindViewHolder(holder: ChapterHolder, position: Int) {
        val chapter = getItem(position)

        holder.title.text = chapter.title.ifBlank { "Chapter spesial" }

        val metadata = buildList {
            if (chapter.volume.isNotBlank()) add("Vol. ${chapter.volume}")
            formatDate(chapter.publishedAt)?.let { add(it) }
            if (chapter.scanlationGroup.isNotBlank()) add(chapter.scanlationGroup)
            if (isEmpty()) add("Terjemahan Bahasa Indonesia")
        }
        holder.meta.text = metadata.joinToString("  ·  ")

        val click = View.OnClickListener { onReadClick(chapter) }
        holder.read.setOnClickListener(click)
        holder.itemView.setOnClickListener(click)
    }


    private fun formatDate(raw: String): String? {
        if (raw.length < 10) return null
        return try {
            val parser = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                isLenient = false
            }
            val date = parser.parse(raw.substring(0, 10)) ?: return null
            SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(date)
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<ManhwaPageRepository.Chapter>() {
            override fun areItemsTheSame(
                oldItem: ManhwaPageRepository.Chapter,
                newItem: ManhwaPageRepository.Chapter
            ): Boolean = oldItem.url == newItem.url

            override fun areContentsTheSame(
                oldItem: ManhwaPageRepository.Chapter,
                newItem: ManhwaPageRepository.Chapter
            ): Boolean = oldItem == newItem
        }
    }
}
