package com.manhwa.aggregator

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets

/** Small SharedPreferences cache for the latest successful safe catalog results. */
internal class CatalogCache(context: Context) {
    private val preferences = context.getSharedPreferences("manhwa_catalog_cache_v1", Context.MODE_PRIVATE)

    fun save(query: String, genre: String, items: List<Manhwa>) {
        if (items.isEmpty()) return
        val array = JSONArray()
        items.take(60).forEach { item ->
            array.put(JSONObject().apply {
                put("title", item.title)
                put("link", item.link)
                put("imageUrl", item.imageUrl)
                put("latestChapter", item.latestChapter)
                put("source", item.source)
            })
        }
        preferences.edit().putString(cacheKey(query, genre), array.toString()).apply()
    }

    fun read(query: String, genre: String): List<Manhwa> {
        val raw = preferences.getString(cacheKey(query, genre), null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val value = array.optJSONObject(index) ?: continue
                    val title = value.optString("title").trim()
                    val link = value.optString("link").trim()
                    if (title.isBlank() || link.isBlank()) continue
                    add(
                        Manhwa(
                            title = title,
                            link = link,
                            imageUrl = value.optString("imageUrl"),
                            latestChapter = value.optString("latestChapter"),
                            source = value.optString("source", "MangaDex")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun cacheKey(query: String, genre: String): String {
        val raw = "${query.trim().lowercase()}|${genre.trim().lowercase()}"
        val encoded = Base64.encodeToString(
            raw.toByteArray(StandardCharsets.UTF_8),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
        return "catalog_$encoded"
    }
}
