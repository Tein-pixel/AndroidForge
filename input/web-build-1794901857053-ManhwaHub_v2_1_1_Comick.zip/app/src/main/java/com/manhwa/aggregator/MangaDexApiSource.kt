package com.manhwa.aggregator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Comick.fun API source — replaces MangaDex as the catalog/chapter provider.
 * File name preserved for compatibility; internal object renamed to ComickApiSource.
 */
internal object ComickApiSource {
    private const val API_BASE  = "https://api.comick.fun"
    internal const val CDN_BASE = "https://meo.comick.pictures"

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .callTimeout(24, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // ── Catalog ──────────────────────────────────────────────────────────────

    suspend fun fetchLatest(query: String = "", genre: String = ""): List<Manhwa> =
        withContext(Dispatchers.IO) {
            val sb = StringBuilder("$API_BASE/v1.0/search?limit=30")
            if (query.isNotBlank()) {
                sb.append("&q=${URLEncoder.encode(query.trim(), "UTF-8")}")
            } else {
                sb.append("&order=new")
                if (genre.isNotBlank() && !genre.equals("Semua", ignoreCase = true)) {
                    sb.append("&genres=${URLEncoder.encode(genre.uppercase(), "UTF-8")}")
                }
            }

            val body = getBody(sb.toString())

            // Comick /v1.0/search returns a top-level JSON array.
            val dataArray: JSONArray = try {
                JSONArray(body)
            } catch (_: Exception) {
                JSONObject(body).optJSONArray("data") ?: return@withContext emptyList()
            }

            buildList {
                for (i in 0 until dataArray.length()) {
                    val item = dataArray.optJSONObject(i) ?: continue
                    val title = item.optString("title").trim()
                    val slug  = item.optString("slug").trim()
                    if (title.isBlank() || slug.isBlank()) continue

                    val imageUrl = item.optJSONArray("md_covers")
                        ?.optJSONObject(0)
                        ?.optString("b2key")
                        ?.takeIf { it.isNotBlank() }
                        ?.let { "$CDN_BASE/$it" }
                        ?: ""

                    add(Manhwa(
                        title        = title,
                        link         = "https://comick.io/comic/$slug",
                        imageUrl     = imageUrl,
                        latestChapter = "",
                        source       = "Comick"
                    ))
                }
            }
        }

    // ── Detail ───────────────────────────────────────────────────────────────

    suspend fun fetchDetail(slug: String): MangaDetail = withContext(Dispatchers.IO) {
        val body  = getBody("$API_BASE/comic/$slug")
        val json  = JSONObject(body)
        val comic = json.optJSONObject("comic")
            ?: throw IllegalStateException("Detail komik tidak ditemukan untuk slug: $slug")

        val title = comic.optString("title").trim().ifBlank { "Judul tidak tersedia" }
        val desc  = comic.optString("desc").trim()
        val year  = comic.optInt("year").takeIf { it > 0 }?.toString().orEmpty()

        val status = when (comic.optString("status")) {
            "1"  -> "Berjalan"
            "2"  -> "Tamat"
            "3"  -> "Hiatus"
            "4"  -> "Dihentikan"
            else -> "Status tidak diketahui"
        }

        val imageUrl = comic.optJSONArray("md_covers")
            ?.optJSONObject(0)
            ?.optString("b2key")
            ?.takeIf { it.isNotBlank() }
            ?.let { "$CDN_BASE/$it" }
            ?: ""

        val genres = mutableListOf<String>()
        val genreArr = comic.optJSONArray("md_comic_md_genres")
        if (genreArr != null) {
            for (i in 0 until genreArr.length()) {
                val name = genreArr.optJSONObject(i)
                    ?.optJSONObject("md_genres")
                    ?.optString("name")
                    ?.trim()
                if (!name.isNullOrBlank()) genres.add(name)
            }
        }

        // author field may be a plain string or inside mu_comics
        val author = comic.optString("author").trim().ifBlank {
            comic.optJSONArray("mu_comics")
                ?.optJSONObject(0)
                ?.optJSONArray("mu_comic_creators")
                ?.optJSONObject(0)
                ?.optJSONObject("mu_creators")
                ?.optString("name")
                ?.trim()
                .orEmpty()
        }

        MangaDetail(
            title    = title,
            coverUrl = imageUrl,
            author   = author,
            artist   = "",
            synopsis = desc,
            tags     = genres.distinct().take(14),
            status   = status,
            year     = year
        )
    }

    // ── Chapters ─────────────────────────────────────────────────────────────

    suspend fun fetchChapters(
        slug: String,
        offset: Int = 0
    ): ManhwaPageRepository.ChapterPage = withContext(Dispatchers.IO) {
        val limit = 300
        val page  = (offset / limit) + 1
        val body  = getBody("$API_BASE/comic/$slug/chapters?lang=id&limit=$limit&page=$page")
        val json  = JSONObject(body)
        val chArr = json.optJSONArray("chapters")
            ?: return@withContext ManhwaPageRepository.ChapterPage(emptyList(), 0, 0, false)
        val total = json.optInt("total", chArr.length())

        val chapters = buildList {
            for (i in 0 until chArr.length()) {
                val ch   = chArr.optJSONObject(i) ?: continue
                val hid  = ch.optString("hid").trim().takeIf { it.isNotBlank() } ?: continue
                val chapNum  = ch.optString("chap").trim()
                val chapTitle = ch.optString("title").trim()
                val publishAt = ch.optString("publish_at").trim()
                val vol      = ch.optString("vol").trim()
                val group    = ch.optJSONArray("group_name")
                    ?.optString(0)?.trim().orEmpty()

                val label = buildString {
                    append("Chapter ")
                    append(chapNum.ifBlank { "spesial" })
                    if (chapTitle.isNotBlank()) append(" · ").append(chapTitle)
                }
                add(ManhwaPageRepository.Chapter(
                    title          = label,
                    url            = "https://comick.io/chapter/$hid",
                    chapterNumber  = chapNum,
                    volume         = vol,
                    publishedAt    = publishAt,
                    scanlationGroup = group
                ))
            }
        }

        val received   = chArr.length()
        val nextOffset = offset + received
        val hasMore    = received >= limit && nextOffset < total

        ManhwaPageRepository.ChapterPage(
            chapters   = chapters.distinctBy { it.url },
            total      = total,
            nextOffset = nextOffset,
            hasMore    = hasMore
        )
    }

    // ── Reader Images ─────────────────────────────────────────────────────────

    suspend fun fetchChapterImages(hid: String): List<String> = withContext(Dispatchers.IO) {
        val body    = getBody("$API_BASE/chapter/$hid?tachiyomi=true")
        val json    = JSONObject(body)
        val chapter = json.optJSONObject("chapter") ?: return@withContext emptyList()
        val images  = chapter.optJSONArray("images")  ?: return@withContext emptyList()
        buildList {
            for (i in 0 until images.length()) {
                val url = images.optJSONObject(i)?.optString("url")?.trim()
                if (!url.isNullOrBlank()) add(url)
            }
        }
    }

    // ── HTTP ──────────────────────────────────────────────────────────────────

    internal fun getBody(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "ManhwaHub-Android/2.1.0 (Android)")
            .header("Accept",     "application/json")
            .build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Comick HTTP ${response.code} — $url")
            }
            response.body?.string().orEmpty().also {
                if (it.isBlank()) throw IllegalStateException("Respons Comick kosong — $url")
            }
        }
    }
}

// ── Backward-compat alias so any stale reference still compiles ──────────────
@Suppress("unused")
internal typealias MangaDexApiSource = ComickApiSource
