package com.manhwa.aggregator

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.manhwa.aggregator.databinding.ActivityReaderBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ReaderActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReaderBinding
    private lateinit var library: LibraryStore
    private lateinit var mangaItem: Manhwa
    private var chapterUrl = ""
    private var chapterTitle = ""
    private var pagesLoaded = false
    private var progressSaveJob: Job? = null

    companion object {
        const val EXTRA_CHAPTER_URL = "reader_chapter_url"
        const val EXTRA_CHAPTER_TITLE = "reader_chapter_title"
        const val EXTRA_MANGA_TITLE = "reader_manga_title"
        const val EXTRA_ITEM_LINK = "reader_item_link"
        const val EXTRA_ITEM_IMAGE = "reader_item_image"
        const val EXTRA_ITEM_SOURCE = "reader_item_source"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        library = LibraryStore(this)
        chapterUrl = intent.getStringExtra(EXTRA_CHAPTER_URL).orEmpty()
        chapterTitle = intent.getStringExtra(EXTRA_CHAPTER_TITLE).orEmpty()
        mangaItem = Manhwa(
            intent.getStringExtra(EXTRA_MANGA_TITLE).orEmpty(),
            intent.getStringExtra(EXTRA_ITEM_LINK).orEmpty(),
            intent.getStringExtra(EXTRA_ITEM_IMAGE).orEmpty(),
            chapterTitle,
            intent.getStringExtra(EXTRA_ITEM_SOURCE).orEmpty()
        )
        binding.tvReaderTitle.text = mangaItem.title
        binding.tvReaderSubtitle.text = chapterTitle
        binding.btnReaderBack.setOnClickListener {
            saveReaderProgress()
            finish()
        }
        binding.btnReaderSource.setOnClickListener { openSource() }
        binding.btnReaderRetry.setOnClickListener { loadPages() }
        binding.rvPages.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false).apply {
            isItemPrefetchEnabled = true
            initialPrefetchItemCount = 3
        }
        binding.rvPages.setHasFixedSize(false)
        binding.rvPages.setItemViewCacheSize(4)
        binding.rvPages.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (pagesLoaded) queueProgressSave()
            }
        })
        if (mangaItem.link.isNotBlank()) {
            library.addToHistory(mangaItem)
            val saved = library.getProgress(mangaItem.link)
            if (saved?.chapterUrl != chapterUrl) {
                library.saveProgress(mangaItem, chapterTitle, chapterUrl, 0, 0)
            }
        }
        loadPages()
    }

    private fun loadPages() {
        binding.progressReader.visibility = View.VISIBLE
        binding.tvReaderEmpty.visibility = View.GONE
        binding.btnReaderRetry.visibility = View.GONE
        lifecycleScope.launch {
            try {
                val pages = ManhwaPageRepository.fetchReaderImages(chapterUrl)
                if (pages.isEmpty()) {
                    showReaderError("Halaman chapter belum tersedia atau tidak dapat diambil dari server.")
                } else {
                    binding.rvPages.adapter = ReaderPageAdapter(pages, chapterUrl)
                    pagesLoaded = true
                    val saved = library.getProgress(mangaItem.link)?.takeIf { it.chapterUrl == chapterUrl }
                    binding.rvPages.post {
                        if (saved != null && saved.pageIndex in pages.indices) {
                            (binding.rvPages.layoutManager as? LinearLayoutManager)
                                ?.scrollToPositionWithOffset(saved.pageIndex, -saved.offsetPx)
                        }
                        saveReaderProgress()
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                showReaderError("Halaman gagal dimuat. Periksa koneksi, lalu coba lagi.")
            } finally {
                binding.progressReader.visibility = View.GONE
            }
        }
    }

    private fun showReaderError(message: String) {
        binding.tvReaderEmpty.text = message
        binding.tvReaderEmpty.visibility = View.VISIBLE
        binding.btnReaderRetry.visibility = View.VISIBLE
    }

    private fun queueProgressSave() {
        progressSaveJob?.cancel()
        progressSaveJob = lifecycleScope.launch {
            delay(550)
            saveReaderProgress()
        }
    }

    private fun saveReaderProgress() {
        if (!pagesLoaded || mangaItem.link.isBlank() || chapterUrl.isBlank()) return
        val manager = binding.rvPages.layoutManager as? LinearLayoutManager ?: return
        val position = manager.findFirstVisibleItemPosition().coerceAtLeast(0)
        val firstView = manager.findViewByPosition(position)
        val offset = (firstView?.top?.let { -it } ?: 0).coerceAtLeast(0)
        library.saveProgress(mangaItem, chapterTitle, chapterUrl, position, offset)
    }

    private fun openSource() {
        startActivity(Intent(this, SourceWebActivity::class.java).apply {
            putExtra(SourceWebActivity.EXTRA_URL, chapterUrl)
            putExtra(SourceWebActivity.EXTRA_TITLE, chapterTitle)
        })
    }

    override fun onPause() {
        saveReaderProgress()
        super.onPause()
    }

    override fun onDestroy() {
        progressSaveJob?.cancel()
        super.onDestroy()
    }
}

private class ReaderPageAdapter(
    private val pages: List<String>,
    private val referer: String
) : RecyclerView.Adapter<ReaderPageAdapter.PageHolder>() {
    class PageHolder(val image: ImageView) : RecyclerView.ViewHolder(image)

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): PageHolder {
        val image = ImageView(parent.context).apply {
            layoutParams = RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT,
                RecyclerView.LayoutParams.WRAP_CONTENT
            )
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(android.graphics.Color.BLACK)
            contentDescription = "Halaman komik"
        }
        return PageHolder(image)
    }

    override fun onBindViewHolder(holder: PageHolder, position: Int) {
        holder.image.load(pages[position], ManhwaImageLoader.get(holder.image.context, referer)) {
            crossfade(160)
            placeholder(R.drawable.cover_placeholder)
            error(R.drawable.cover_placeholder)
        }
    }

    override fun getItemCount(): Int = pages.size
}
