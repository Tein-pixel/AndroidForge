# Manhwa Hub Enhanced v2 - Additions

This revision keeps the existing source integrations and adds local reading/library capabilities.

## Added
- Reading lists with statuses: Sedang dibaca, Rencana baca, Selesai, Ditunda, and Dihentikan.
- Library status filtering from the library subtitle or Tools menu.
- Reader progress persistence by manga, chapter URL, visible page index, and scroll offset.
- Resume Reading action on the detail screen.
- JSON metadata backup and restore using Android's system file picker.
- Legacy Favorites and History remain readable and are included in backups.

## Source/API preservation
- The existing Kiryuu, Komikcast, and Asura configured listing URLs are retained.
- The existing AllOrigins proxy base URL is retained.
- The source request pipeline now isolates failures per source, fetches sources concurrently, and tries direct source access only if the existing proxy request fails.
- No new third-party API endpoint or source domain was introduced.
- Existing model, detail/reader parser, URL resolver, Android application ID, SDK levels, and dependency versions are retained.

## Verification
- XML files parsed successfully.
- New ViewBinding IDs checked against their layouts.
- Original project files are retained; additional files are additive.
- The configured source listing URLs and AllOrigins proxy URL are present unchanged.
- APK compilation was not run because this environment has no Android SDK or Gradle installation. The archive remains a source project, not a compiled APK.
