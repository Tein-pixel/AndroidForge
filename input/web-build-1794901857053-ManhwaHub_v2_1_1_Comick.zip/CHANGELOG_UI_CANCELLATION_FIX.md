# Manhwa Hub – UI & Cancellation Fix

## UI updates
- Removed the large MANHWA HUB branding/tagline block and wide TOOLS pill from the Home screen.
- Moved the existing Tools/Backup/Restore/Library Filter menu to a compact overflow control beside the section heading. Existing actions remain available.
- Search field and genre chips are visible only on the Jelajah tab.
- Rebuilt the bottom navigation as a floating, rounded translucent dock with screen-edge spacing and consistent vector icons.
- Adjusted spacing and typography for a more balanced layout.

## Network and coroutine updates
- Added `https://corsproxy.io/?url=` as the first proxy attempt.
- Kept the existing AllOrigins proxy URL as a fallback, followed by direct source access.
- Kept the Kiryuu, Komikcast, and Asura source URLs unchanged.
- Added 10-second connect, 15-second read, and 20-second total call timeouts, plus retry-on-connection-failure.
- Changed network calls to OkHttp's async callback API and connected coroutine cancellation to `Call.cancel()` so switching tabs cancels the active request.
- Re-throws `CancellationException` from source requests and MainActivity rather than displaying it as a network error.
- Keeps individual source failures isolated so one source can fail without blocking the others.
- Removed the fake/system placeholder item path; empty results now show an actionable empty state.
- Prevents a cancelled older load job from replacing the currently selected tab or hiding a newer job's loading indicator.

## Preserved integrations
- Kiryuu endpoint: unchanged.
- Komikcast endpoint: unchanged.
- Asura endpoint: unchanged.
- Existing AllOrigins proxy endpoint: retained as fallback.
- Existing reader, detail, library, backup, restore, and navigation files: retained.

## Verification
- XML well-formedness and app resource references checked.
- Source endpoint and legacy AllOrigins URL preservation checked against the v2 project.
- ZIP archive integrity checked.
- Android APK build not run: this environment has no Android SDK or Gradle installation.
