# Manhwa Hub — API & UI update

## Added
- Added MangaDex as the primary direct JSON catalog provider for latest and title search.
- Original HTML sources are retained as fallback when MangaDex is unavailable/returns no results.
- MangaDex catalog requests use `contentRating[]=safe` and available translated languages `id` and `en`.
- Added MangaDex detail metadata, genre extraction, chapter list, at-home image endpoint, and scanlation-group credit in chapter labels.
- Existing Kiryuu, Komikcast, Asura endpoints, CorsProxy fallback, and AllOrigins fallback remain in `ManhwaScraper.kt`; they are queried as fallback rather than blocking a successful API catalog.
- Reworked the dark palette to graphite/indigo with violet and periwinkle accents.
- Narrowed the bottom navigation dock and reduced icon/label spacing so the four destinations sit closer together.

## Intentionally not hardcoded
- The sample `https://api.coorenlabs.com` host was not enabled because it could not be verified as a public deployment. CoorenLabs documentation describes `/manga/allmanga/...` as routes exposed by a running/deployed Cooren server; the docs' examples use a locally running host. A real deployed base URL is required before enabling it.
- No placeholder Cloudflare Worker URL or open proxy was added. Native Android OkHttp calls do not need browser CORS headers; direct API and CDN requests are used where supported.

## Preserved
- Original 3 scraper source URLs remain unchanged.
- Original proxy URLs remain unchanged.
- Existing details, reader, library, reading progress, backup/restore, and navigation screens remain.

## Validation
- XML parsing and ZIP integrity are checked during packaging.
- Android Gradle build has not been executed in this environment; run AndroidForge to verify compilation and device behavior.
