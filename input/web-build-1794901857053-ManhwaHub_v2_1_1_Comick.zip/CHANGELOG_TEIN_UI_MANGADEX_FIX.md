# Manhwa Hub — Catalog and UI update

## Catalog
- Replaced the old Comick catalog request with the existing MangaDex API client.
- Added dynamic MangaDex tag lookup for Action, Fantasy, Romance, and Martial Arts filters.
- Catalog requests are limited to the `safe` content rating and Indonesian/English translated chapters.
- Kept API failures visible as a retry-friendly empty/error state; no fake manga entry is inserted.

## UI
- Removed the large Home heading and subtitle.
- Kept the small utility menu so backup and restore remain available.
- Added a black startup splash with a pulsing app mark and fade-out transition.
- Kept skeleton-card loading and card entrance animations.
- Tightened bottom-navigation icon/label spacing and adjusted its bottom inset spacing.
- Changed the status and navigation bars to solid black.

## Preserved
- Existing detail, reader, library, history, backup/restore, and chapter parsing files remain in the project.
- Android package, application ID, min SDK, and existing dependencies are unchanged.
