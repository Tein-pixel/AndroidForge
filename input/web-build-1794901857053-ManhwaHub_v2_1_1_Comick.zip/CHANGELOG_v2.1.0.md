# Manhwa Hub 2.1.0 — Catalog resilience and chapter reliability

## Catalog behavior
- Keep MangaDex production API as the primary JSON catalog source.
- Retry the same request against MangaDex's documented public development host only when the production request fails because of an I/O/network error, HTTP 403, or HTTP 5xx. Other client errors and rate limits (429) are not retried on another host. The development host is explicitly a public development environment, so it remains a fallback rather than the primary source.
- Keep `contentRating[]=safe` on every catalog query.
- Prefer titles with Indonesian chapter availability. If that search returns no results, make a second Safe-only title search without the availability filter so valid manga titles do not disappear from Home/Search just because an Indonesian translation is not indexed yet.
- Keep the chapter feed restricted to `translatedLanguage[]=id` and `contentRating[]=safe`; the broader catalog fallback does not silently switch the Reader to another language.
- Cache the last successful catalog per search/genre locally. On a later network failure, show the cached titles rather than a blank Home screen.
- Show more useful connection errors (DNS, timeout, HTTP 403/429/5xx) instead of the same generic message for every failure.
- Keep existing cards visible if a pull-to-refresh request fails.

## Detail and reader performance
- Fetch MangaDex title metadata and the first Indonesian chapter page concurrently.
- Keep the existing paginated chapter feed and MangaDex At-Home image reader.
- Keep the Safe content-rating filter on the chapter feed.

## Preserved
- Application ID `com.manhwa.aggregator`, minSdk 24, compile/target SDK, current dependencies, detail screen, reader, library, history, bookmarks/favorites, reading progress, backup/restore, navigation, and UI layouts remain in place.
- Existing URL resolver roots and AllOrigins HTML parsing fallback code remain unchanged. The uploaded ZIP does not contain active Kiryuu/Komikcast/Asura listing-provider implementations, so no replacement listing paths were guessed or fabricated.
- No Firebase plugin was added because this ZIP does not include `google-services.json`; enabling Google Services/Crashlytics without the matching project configuration can break the build and does not fix catalog connectivity.
- No Consumet public endpoint was hardcoded. Current Consumet documentation says its public API is no longer available and requires self-hosting.

## Validation limits
- XML parsing, Kotlin source sanity checks, resource references, and ZIP integrity are checked during packaging.
- A full Android Gradle build and live API request could not be run in this runtime because Gradle/Android SDK/network DNS access are unavailable. AndroidForge must confirm compilation and device-side connectivity.
