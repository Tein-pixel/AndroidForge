# Manhwa Hub — Resource Build Fix

Applied fixes for the AndroidForge resource-processing failures:

1. Updated the app theme background item to use the platform attribute `android:colorBackground`, avoiding the unresolved app attribute `colorBackground` during AAPT2 resource linking.
2. Regenerated the empty `mipmap-mdpi/ic_launcher_round.png` from the existing valid `mipmap-hdpi/ic_launcher_round.png`, resized to 48×48 pixels.

No application source APIs, source URLs, dependencies, manifest activities, or existing feature code were intentionally changed.

Validation performed in this environment: XML parsing and PNG integrity checks. A full Android Gradle build was not run here because the Android SDK and Gradle executable are not installed in this runtime.
