# TeinLite Ultra

Minimal native Android home/app-drawer launcher for Android 10+ (API 29+).

## Design goals
- No third-party runtime libraries, internet permission, ads, analytics, widgets, wallpaper engine, acrylic blur, or background service.
- Native Android Views and a single activity.
- Black dark UI; app search and four-column app drawer.
- Release build enables R8 minification and resource shrinking.

## Build
GitHub Actions builds `:app:assembleRelease` on push to `main` and uploads a release APK signed with the temporary CI debug certificate so it can be installed for testing. This is not a stable production signing key; future builds may not update over the existing install.

## Important
APK size depends on the Android Gradle Plugin, aapt2, DEX, and packaging overhead. The workflow prints the exact APK byte count. The 35 KB target is a strict goal, not guaranteed until the APK is built and measured. Smoothness and 60 FPS must be tested on a physical device; no launcher can guarantee a fixed frame rate on every device.
