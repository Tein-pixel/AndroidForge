# No third-party libraries. Keep only Android entry points required by the manifest.
