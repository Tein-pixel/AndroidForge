package com.teinzz.teinlite;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class LauncherActivity extends Activity {
    private final ArrayList<AppEntry> all = new ArrayList<>();
    private final ArrayList<AppEntry> shown = new ArrayList<>();
    private AppAdapter adapter;
    private EditText search;
    private static final int BG = Color.BLACK;
    private static final int FG = Color.WHITE;
    private static final int MUTED = 0xFFB8B8B8;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        w.setFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
                WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        buildUi();
        loadApps();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(12), dp(12), dp(4));

        TextView title = new TextView(this);
        title.setText("TeinLite");
        title.setTextColor(FG);
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(4), dp(3), 0, dp(12));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(44)));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(16);
        search.setTextColor(FG);
        search.setHintTextColor(0xFF888888);
        search.setHint("Cari aplikasi");
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackgroundColor(0xFF171717);
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));

        GridView grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setHorizontalSpacing(dp(2));
        grid.setVerticalSpacing(dp(4));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setVerticalScrollBarEnabled(false);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, 0, 1f);
        gp.topMargin = dp(12);
        root.addView(grid, gp);

        grid.setOnItemClickListener((parent, view, position, id) -> {
            AppEntry app = shown.get(position);
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage(app.pkg);
                if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); }
            } catch (Exception ignored) { }
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filter(s.toString()); }
            @Override public void afterTextChanged(Editable e) { }
        });
        setContentView(root);
    }

    private void loadApps() {
        // Package enumeration and icon decoding happen off the UI thread.
        Thread worker = new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN, null);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> results = pm.queryIntentActivities(query, 0);
            ArrayList<AppEntry> loaded = new ArrayList<>(results.size());
            for (ResolveInfo ri : results) {
                if (ri.activityInfo == null || getPackageName().equals(ri.activityInfo.packageName)) continue;
                try {
                    String label = ri.loadLabel(pm).toString();
                    Drawable icon = ri.loadIcon(pm);
                    loaded.add(new AppEntry(label, ri.activityInfo.packageName, icon));
                } catch (Exception ignored) { }
            }
            Collections.sort(loaded, Comparator.comparing(a -> a.label.toLowerCase(Locale.ROOT)));
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                all.clear();
                all.addAll(loaded);
                filter(search.getText().toString());
            });
        }, "TeinLite-AppScan");
        worker.setPriority(Thread.NORM_PRIORITY - 1);
        worker.start();
    }

    private void filter(String q) {
        String key = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        shown.clear();
        for (AppEntry app : all) if (key.isEmpty() || app.label.toLowerCase(Locale.ROOT).contains(key)) shown.add(app);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private static final class AppEntry {
        final String label, pkg; final Drawable icon;
        AppEntry(String l, String p, Drawable i) { label=l; pkg=p; icon=i; }
    }

    private final class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return shown.get(p).pkg.hashCode(); }
        @Override public View getView(int position, View convert, ViewGroup parent) {
            LinearLayout cell;
            ImageView icon;
            TextView label;
            if (convert instanceof LinearLayout) {
                cell = (LinearLayout) convert;
                icon = (ImageView) cell.getChildAt(0);
                label = (TextView) cell.getChildAt(1);
            } else {
                cell = new LinearLayout(LauncherActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(2), dp(4), dp(2), dp(4));
                icon = new ImageView(LauncherActivity.this);
                icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
                cell.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
                label = new TextView(LauncherActivity.this);
                label.setTextColor(FG);
                label.setTextSize(11);
                label.setGravity(Gravity.CENTER);
                label.setMaxLines(1);
                label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(22));
                lp.topMargin = dp(3);
                cell.addView(label, lp);
            }
            AppEntry app = shown.get(position);
            icon.setImageDrawable(app.icon);
            label.setText(app.label);
            return cell;
        }
    }
}
